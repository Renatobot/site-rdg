# RDG instaPRO - Automação Avançada para Instagram

## 🚀 Sobre a Extensão

O **RDG instaPRO** é uma ferramenta de automação e inteligência para o Instagram, desenvolvida com foco em segurança (**Escudo Anti-Block**), simulação de comportamento humano e alta performance visual (**Command Center Glassmorphism**).

---

## ✨ Principais Funcionalidades (Etapas 1, 2 e 3)

### 🎨 **1. Dashboard Executivo & Visual Glassmorphism**
- **Command Center**: Interface em estilo vidro esfumaçado com modo escuro premium e tipografia `Inter`.
- **Métricas em Tempo Real**: Monitoramento no topo da tela indicando **Ações Hoje**, **Taxa de Sucesso (%)**, **Tempo de Sessão** e **Status Anti-Block**.
- **Harmonização de Cores**: Paleta equilibrada (Verde, Azul e Roxo) com botões estilo *pill* com gradientes dinâmicos e sombras elevadas.

### 🛡️ **2. Escudo Anti-Block & Simulação Humana (Smart Warm-up)**
- **Modo Aquecimento (Warm-up)**: Sistema de proteção para contas novas ou recém-recuperadas com espaçamento inteligente de tempo.
- **Pausa para Café (Coffee Break)**: Pausas automáticas programadas de `X` minutos a cada `Y` ações para mimetizar com perfeição a navegação humana e evitar bloqueios ou restrições do Instagram.
- **Registro Hacker (Log Tech)**: Terminal escuro estilo console de programação para acompanhamento em tempo real e com máxima clareza.

### 🔥 **3. Funil VIP em Cadeia (Seguir ➔ Curtir ➔ Direct em Massa Automatizado)**
- **Automação 3 em 1 Sem Trocar de Aba**: Na aba **Alvos & Ações (Tab 1)**, o robô executa a sequência completa de engajamento no mesmo perfil: Seguir ➔ Curtir X foto(s) ➔ Enviar Direct de boas-vindas.
- **Painel VIP Colapsável**: Configuração rápida de mensagens com variáveis personalizadas (`{username}` e `{full_name}`) ou reaproveitamento automático dos templates da aba de Direct em Massa.
- **Dupla Proteção de Envio (API + Relé)**: Tenta o envio invisível via API GraphQL em background; caso o Instagram solicite verificação na thread, aciona automaticamente o relé humanizado abrindo a conversa temporariamente.

---

## 📁 Estrutura de Arquivos RDG

- **`rdg.html`**: Painel principal da interface injetada no Instagram.
- **`rdg-interface.css`**: Sistema completo de design visual (Command Center, Glassmorphism, animações e layout vertical).
- **`theme.rdg.css`**: Tema visual complementar de tabelas e listas.
- **`contentscript.js`**: Motor principal de execução, contendo o cérebro da automação, funis em cadeia e gestão de filas.
- **`backgroundscript.js`**: Service worker responsável pelo gerenciamento de abas, chamadas em background e permissões do navegador.

---

## 📦 Como Instalar / Atualizar no Google Chrome

1. Abra o navegador Chrome e acesse `chrome://extensions/`.
2. Ative o **Modo do desenvolvedor** na chave seletora no canto superior direito.
3. Se for a primeira vez, clique em **Carregar sem compactação** e selecione a pasta `Minha_Extensao_RDG_Instagram`.
4. Se já estiver instalada, basta clicar no botão de **Recarregar (🔄)** no card da extensão **RDG instaPRO**.
5. Abra o Instagram no navegador e pressione `F5` para recarregar a página e ver a nova interface!

---

*Copyright (C) RDG Soluções Digitais 2026 - Todos os Direitos Reservados.*  
*Desenvolvido por RDG Soluções Digitais <suporte@rdgsolucoes.com.br>*
