document.addEventListener('DOMContentLoaded', function() {
    const assistenteTab = document.getElementById('rdg_tab6');
    if (assistenteTab) assistenteTab.checked = true;

    function toggleUI() {
        const uiContainer = document.getElementById('igBotInjectedContainer');
        if (uiContainer.style.display === 'none') {
            uiContainer.style.display = 'flex';
            document.body.classList.add('body-no-scroll');
        } else {
            uiContainer.style.display = 'none';
            document.body.classList.remove('body-no-scroll');
        }
    }

    /* ==========================================================================
       EXTENSION ANNOUNCEMENTS (RDG instaPRO 1.0) - Logic for Extension UI
       ========================================================================== */
    const ANNOUNCEMENTS_URL = 'https://adljdeekwifwcdcgbpit.supabase.co/storage/v1/object/public/user-data/admin/extensionver84-announcements.json';
    const STORAGE_KEY_ANNOUNCEMENTS = 'rdg_extensionver84_announcements';

    async function fetchExtensionAnnouncements() {
      try {
        const response = await fetch(ANNOUNCEMENTS_URL + '?t=' + Date.now());
        if (!response.ok) return [];
        
        const data = await response.json();
        return data.announcements || [];
      } catch (error) {
        console.error('Erro ao buscar avisos:', error);
        return [];
      }
    }

    function getViewedAnnouncements() {
      try {
        return JSON.parse(localStorage.getItem(STORAGE_KEY_ANNOUNCEMENTS) || '{}');
      } catch { return {}; }
    }

    function saveViewedAnnouncement(id, announcement) {
      const viewed = getViewedAnnouncements();
      const now = Date.now();
      
      viewed[id] = {
        viewCount: ((viewed[id] && viewed[id].viewCount) || 0) + 1,
        lastViewed: now,
        firstViewed: (viewed[id] && viewed[id].firstViewed) || now
      };
      
      localStorage.setItem(STORAGE_KEY_ANNOUNCEMENTS, JSON.stringify(viewed));
    }

    function shouldShowAnnouncement(announcement) {
      if (!announcement.isActive) return false;
      
      const viewed = getViewedAnnouncements()[announcement.id];
      if (!viewed) return true;
      
      const { frequencyType, frequencyValue, frequencyHours } = announcement;
      
      if (frequencyType === 'times_per_day') {
        const today = new Date().toDateString();
        const lastViewedDate = new Date(viewed.lastViewed).toDateString();
        if (today !== lastViewedDate) {
          return true;
        }
        return (viewed.viewCount || 0) < frequencyValue;
      }
      
      if (frequencyType === 'times_per_hours') {
        const hoursMs = (frequencyHours || 1) * 60 * 60 * 1000;
        const timeSinceFirst = Date.now() - (viewed.firstViewed || 0);
        if (timeSinceFirst >= hoursMs) return true;
        return (viewed.viewCount || 0) < frequencyValue;
      }
      
      if (frequencyType === 'once') {
        return viewed.viewCount < 1;
      }
      
      return true;
    }

    async function showAnnouncementWithDelay(announcement) {
      const delayMs = (announcement.delaySeconds || 0) * 1000;
      
      if (delayMs > 0) {
        await new Promise(resolve => setTimeout(resolve, delayMs));
      }
      
      if (shouldShowAnnouncement(announcement)) {
        displayAnnouncementPopup(announcement);
        saveViewedAnnouncement(announcement.id, announcement);
        return true;
      }
      return false;
    }

    function displayAnnouncementPopup(announcement) {
      const existing = document.getElementById('rdg-extension-popup');
      if (existing) existing.remove();
      
      const popup = document.createElement('div');
      popup.id = 'rdg-extension-popup';
      popup.innerHTML = `
        <div style="
          position: fixed;
          top: 0; left: 0; right: 0; bottom: 0;
          background: rgba(0,0,0,0.8);
          z-index: 999999;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        ">
          <div style="
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 16px;
            max-width: 500px;
            width: 100%;
            overflow: hidden;
            box-shadow: 0 25px 50px rgba(0,0,0,0.5);
            border: 1px solid rgba(255,255,255,0.1);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
          ">
            ${announcement.thumbnailUrl ? `
              <img src="${announcement.thumbnailUrl}" style="width: 100%; max-height: 300px; object-fit: cover; display: block;" />
            ` : ''}
            
            <div style="padding: 24px;">
              <h2 style="color: #fff; font-size: 20px; font-weight: bold; margin: 0 0 12px 0;">
                ${announcement.title}
              </h2>
              <p style="color: #a0aec0; font-size: 14px; line-height: 1.6; white-space: pre-wrap; margin: 0 0 16px 0;">
                ${announcement.content}
              </p>
              
              ${announcement.buttonUrl ? `
                <a id="rdg-announcement-cta-btn" href="${announcement.buttonUrl}" target="_blank" style="
                  display: inline-block;
                  margin-top: 16px;
                  padding: 12px 24px;
                  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                  color: white;
                  text-decoration: none;
                  border-radius: 8px;
                  font-weight: 600;
                ">
                  ${announcement.buttonText || 'Saiba Mais'}
                </a>
              ` : ''}
              
              <button id="rdg-announcement-close-btn" style="
                display: block;
                width: 100%;
                margin-top: 16px;
                padding: 12px;
                background: transparent;
                border: 1px solid rgba(255,255,255,0.2);
                color: #a0aec0;
                border-radius: 8px;
                cursor: pointer;
                font-size: 14px;
              ">
                Fechar
              </button>
            </div>
          </div>
        </div>
      `;
      
      document.body.appendChild(popup);

      function closeAnnouncementPopup() {
        const p = document.getElementById('rdg-extension-popup');
        if (p) p.remove();
      }

      function wireAnnouncementButtonHover(el) {
        if (!el) return;
        var isCloseButton = el.id === 'rdg-announcement-close-btn';
        var activate = function() {
          if (isCloseButton) {
            el.style.background = 'rgba(255,255,255,0.08)';
            el.style.color = '#fff';
            el.style.borderColor = 'rgba(255,255,255,0.28)';
            return;
          }
          el.style.filter = 'brightness(1.08)';
        };
        var reset = function() {
          if (isCloseButton) {
            el.style.background = 'transparent';
            el.style.color = '#a0aec0';
            el.style.borderColor = 'rgba(255,255,255,0.2)';
            return;
          }
          el.style.filter = 'none';
        };
        el.addEventListener('mouseenter', activate);
        el.addEventListener('mouseleave', reset);
        el.addEventListener('mousedown', activate);
        el.addEventListener('mouseup', function() {
          if (el.matches(':hover')) activate();
          else reset();
        });
      }
      
      // Add event listener for close button to comply with CSP
      const closeBtn = document.getElementById('rdg-announcement-close-btn');
      if (closeBtn) {
        wireAnnouncementButtonHover(closeBtn);
        closeBtn.addEventListener('click', function() {
            closeAnnouncementPopup();
        });
      }
      const ctaBtn = document.getElementById('rdg-announcement-cta-btn');
      if (ctaBtn) {
        wireAnnouncementButtonHover(ctaBtn);
        ctaBtn.addEventListener('click', function() {
            setTimeout(closeAnnouncementPopup, 80);
        });
      }
    }

    async function initExtensionAnnouncements() {
      try {
        if (!(window.location && window.location.hostname && window.location.hostname.includes('instagram.com'))) {
          return;
        }
      } catch (e) {}

      const announcements = await fetchExtensionAnnouncements();
      for (const announcement of announcements) {
        if (shouldShowAnnouncement(announcement)) {
          showAnnouncementWithDelay(announcement);
          break; 
        }
      }
    }

    // Init
    initExtensionAnnouncements();
});
