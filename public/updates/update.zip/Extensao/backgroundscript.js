﻿/** 
 * Copyright (C) RDG instaPRO 2016-2023 - All Rights Reserved
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by RDG instaPRO <rdgautomator@gmail.com>, 2016-2023
 */

var mainRdgTabId = 0;
var lastStoryAcct;
var clickedViewStoryTabIds = [];
var announcementSessionGateState = 'unknown';
var rdgStoryVideoUploadTransfers = {};

function rdgStoryVideoDebugLog(hypothesisId, location, msg, data) {
    fetch("http://127.0.0.1:7778/event",{method:"POST",body:JSON.stringify({sessionId:"story-video-upload",runId:"post-fix",hypothesisId:hypothesisId,location:location,msg:msg,data:data||{},ts:Date.now()})}).catch(function(){});
}

function rdgStoryVideoNormalizeChunk(chunk) {
    if (!chunk) return null;
    if (typeof chunk === 'string') {
        var binaryString = atob(chunk);
        var bytes = new Uint8Array(binaryString.length);
        for (var i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        return bytes.buffer;
    }
    if (chunk instanceof ArrayBuffer) return chunk;
    if (ArrayBuffer.isView(chunk)) return chunk.buffer.slice(chunk.byteOffset, chunk.byteOffset + chunk.byteLength);
    if (Array.isArray(chunk)) return new Uint8Array(chunk).buffer;
    return null;
}

function rdgHandleStoryVideoUploadMessage(request, sendResponse) {
    var transferId = request.transferId || '';
    if (!transferId) {
        sendResponse({ ok: false, message: 'transferId ausente' });
        return true;
    }

    if (request.action === 'rdgStoryVideoUploadBufferInit') {
        rdgStoryVideoUploadTransfers[transferId] = {
            mimeType: request.mimeType || 'video/mp4',
            totalBytes: parseInt(request.totalBytes || 0, 10) || 0,
            receivedBytes: 0,
            chunks: []
        };
        sendResponse({ ok: true });
        return true;
    }

    if (request.action === 'rdgStoryVideoUploadBufferChunk') {
        var transfer = rdgStoryVideoUploadTransfers[transferId];
        if (!transfer) {
            sendResponse({ ok: false, message: 'transferencia nao iniciada' });
            return true;
        }
        var normalizedChunk = rdgStoryVideoNormalizeChunk(request.chunk);
        if (!normalizedChunk) {
            sendResponse({ ok: false, message: 'chunk invalido' });
            return true;
        }
        transfer.chunks.push(normalizedChunk);
        transfer.receivedBytes += normalizedChunk.byteLength || 0;
        sendResponse({ ok: true, receivedBytes: transfer.receivedBytes });
        return true;
    }

    if (request.action === 'rdgStoryVideoUploadBufferCleanup') {
        delete rdgStoryVideoUploadTransfers[transferId];
        sendResponse({ ok: true });
        return true;
    }

    if (request.action === 'rdgStoryVideoUploadBufferCommit') {
        var activeTransfer = rdgStoryVideoUploadTransfers[transferId];
        if (!activeTransfer) {
            sendResponse({ ok: false, message: 'transferencia nao encontrada para commit' });
            return true;
        }
        rdgStoryVideoDebugLog('B', 'backgroundscript.js:rdgHandleStoryVideoUploadMessage:commit-start', '[DEBUG] inicio commit video no background', {
            transferId: transferId,
            totalBytes: activeTransfer.totalBytes,
            receivedBytes: activeTransfer.receivedBytes,
            url: request.url || ''
        });
        fetch(request.url, {
            method: request.method || 'POST',
            credentials: 'include',
            headers: request.headers || {},
            body: new Blob(activeTransfer.chunks, { type: activeTransfer.mimeType || 'video/mp4' })
        }).then(function(response) {
            return response.text().then(function(text) {
                rdgStoryVideoDebugLog('B', 'backgroundscript.js:rdgHandleStoryVideoUploadMessage:commit-response', '[DEBUG] resposta upload video background', {
                    transferId: transferId,
                    status: response.status,
                    ok: response.ok,
                    textSample: String(text || '').slice(0, 240)
                });
                delete rdgStoryVideoUploadTransfers[transferId];
                sendResponse({ ok: response.ok, status: response.status, text: text });
            });
        }).catch(function(err) {
            rdgStoryVideoDebugLog('C', 'backgroundscript.js:rdgHandleStoryVideoUploadMessage:commit-error', '[DEBUG] erro upload video background', {
                transferId: transferId,
                name: err && err.name ? err.name : '',
                message: err && err.message ? err.message : String(err || ''),
                stack: err && err.stack ? String(err.stack).slice(0, 500) : ''
            });
            delete rdgStoryVideoUploadTransfers[transferId];
            sendResponse({
                ok: false,
                networkError: true,
                name: err && err.name ? err.name : '',
                message: err && err.message ? err.message : String(err || ''),
                stack: err && err.stack ? String(err.stack).slice(0, 500) : ''
            });
        });
        return true;
    }

    return false;
}

function handleAnnouncementSessionRequest(sendResponse) {
    if (announcementSessionGateState === 'showing' || announcementSessionGateState === 'shown') {
        sendResponse({ shown: true });
        return;
    }

    announcementSessionGateState = 'showing';
    chrome.storage.session.get(['announcementShownThisSession'], function(result) {
        const alreadyShown = result && result.announcementShownThisSession === true;
        if (alreadyShown) {
            announcementSessionGateState = 'shown';
            sendResponse({ shown: true });
        } else {
            chrome.storage.session.set({ announcementShownThisSession: true }, function() {
                announcementSessionGateState = 'shown';
                sendResponse({ shown: false });
            });
        }
    });
}


chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action && String(request.action).indexOf('rdgStoryVideoUploadBuffer') === 0) {
        return rdgHandleStoryVideoUploadMessage(request, sendResponse);
    }

    if (request.action === 'rdgFetchAiToken') {
        sendResponse({ value: 'active' });
        return true;
    }

    if (request.action === 'rdgCallAiApi') {
        var prompt = request.prompt || '';
        var cleanPrompt = encodeURIComponent(prompt);
        var url = 'https://text.pollinations.ai/prompt/' + cleanPrompt + '?model=openai';
        
        fetch(url)
            .then(res => res.text())
            .then(text => {
                if (text && !text.includes('error') && !text.includes('Payment Required') && text.length > 5) {
                    sendResponse({ suggested: text.trim() });
                } else {
                    sendResponse({ suggested: null });
                }
            })
            .catch(err => {
                sendResponse({ suggested: null });
            });
        return true;
    }

    if (request.action === 'checkAndMarkAnnouncementSession') {
        handleAnnouncementSessionRequest(sendResponse);
        return true;
    }

    if (request.follow) {

        var u = request.follow;

        chrome.tabs.create({
            url: "https://www.instagram.com/" + u.username
        }, function(tab) {
            var tabId = tab.id;
            chrome.tabs.onUpdated.addListener(function(tabId, info) {
                if (info.status === 'complete') {

                    setTimeout(function() {
                        chrome.tabs.sendMessage(tab.id, {
                            hideRdg: true
                        });

                        chrome.tabs.sendMessage(tab.id, {
                            clickSomething: 'button div[dir="auto"]:contains("Follow")'
                        });
                    }, 3000);

                    setTimeout(function() {
                        chrome.tabs.remove(tab.id);
                    }, 20000);
                }
            });
        });
    }


    if (request.openReelTab) {

        var shortcode = request.openReelTab.code || request.openReelTab.shortcode;

        chrome.tabs.create({
            url: "https://www.instagram.com/p/" + shortcode
        }, function(tab) {


            var tabId = tab.id;

            chrome.tabs.onUpdated.addListener(function(tabId, info) {
                if (info.status === 'complete' && sender.tab.id == tabId) {
                    chrome.tabs.sendMessage(tabId, {
                        hideRdg: true
                    });

                    setTimeout(function() {
                        chrome.tabs.sendMessage(tabId, {
                            hideRdg: true
                        });
                    }, 3000);


                    if (request.openReelTab.LikeWhenWatchingReel == true) {
                        setTimeout(function() {
                            // click Like
                            chrome.tabs.sendMessage(tabId, {
                                clickSomething: 'svg[aria-label="Like"][width="24"]',
                                parent: 'div[role="button"]'

                            });
                        }, (((request.openReelTab.video_duration || 20) * 750)));
                    }


                    if (request.openReelTab.SaveWhenWatchingReel == true) {
                        setTimeout(function() {
                            // click Save
                            chrome.tabs.sendMessage(tabId, {
                                clickSomething: 'svg[aria-label="Save"]',
                                parent: 'div[role="button"]'
                            });
                        }, (((request.openReelTab.video_duration || 20) * 750) + 2000));
                    }


                    setTimeout(function() {
                        chrome.tabs.remove(tab.id);
                    }, (((request.openReelTab.video_duration || 20) * 1000) + 1000));
                }
            });



        });

    }


    if (request.closeStoryTab) {
        console.log(mainRdgTabId + ' closing ' + lastStoryAcct.username);

        var hasStory = clickedViewStoryTabIds.includes(request.closeStoryTab.tabId);

        chrome.tabs.sendMessage(mainRdgTabId, {
            "closedStory": true,
            "acct": lastStoryAcct,
            "tabId": request.closeStoryTab.tabId,
            "viewed": hasStory
        });

        chrome.tabs.remove(request.closeStoryTab.tabId);
    }

    if (request.openStoryTab) {

        mainRdgTabId = sender.tab.id;
        lastStoryAcct = request.openStoryTab.acct;


        console.log(mainRdgTabId + ' opening ' + lastStoryAcct.username);


        chrome.tabs.create({
            url: "https://www.instagram.com/stories/" + request.openStoryTab.username
        }, function(tab) {

            var createdTabId = tab.id;

            chrome.tabs.onUpdated.addListener(function(tabId, info) {
                if (info.status === 'complete' && createdTabId == tabId) {

                    chrome.tabs.sendMessage(tabId, {
                        hideRdg: true
                    });

                    setTimeout(function() {
                        chrome.tabs.sendMessage(tabId, {
                            hideRdg: true
                        });
                    }, 3000);

                    if (clickedViewStoryTabIds.includes(tabId) == false) {
                        setTimeout(function() {
                            chrome.tabs.sendMessage(tabId, {
                                clickViewStory: true,
                                clickSomething: true,
                                tabId: tabId
                            });
                        }, 1234);
                    }

                    if (request.openStoryTab.LikeWhenWatchingStory == true) {
                        setTimeout(function() {
                            // click Like
                            chrome.tabs.sendMessage(tabId, {
                                clickSomething: 'svg[aria-label="Like"][width="24"]',
                                parent: 'div[role="button"]'

                            });
                        }, 3000);
                    }

                }
            });
        });

        return true;

    }

    if (request.viewedStory) {
        var tabId = sender.tab.id;
        if (clickedViewStoryTabIds.includes(tabId) == false) {
            clickedViewStoryTabIds.push(tabId);
        }
    }


    if (request.updatewanted && request.updatewanted == true) {
        gblIgBotUser.init();
    }

    if (request.guidCookie) {
        gblIgBotUser.overrideGuid(request.guidCookie);
    }

    if (request.ftOver == "true") {
        gblIgBotUser.overrideFT();
    }


    if (request.ig_user) {
        gblIgBotUser.ig_users.push(request.ig_user);
        gblIgBotUser.ig_users = uniq(gblIgBotUser.ig_users);
        gblIgBotUser.current_ig_username = request.ig_user.username;

        if (request.ig_user_account_stats) {
            gblIgBotUser.account_growth_stats.push(request.ig_user_account_stats);
            gblIgBotUser.account_growth_stats = uniq(gblIgBotUser.account_growth_stats);
        }

        checkInstallDate();

        gblIgBotUser.saveToLocal();
        gblIgBotUser.saveToServer();
    }

    if (request.fnc == 'openBuyScreen') {
        openBuyScreen();
    }

    sendResponse();

    return true;

});



var gblIgBotUser = {
    user_guid: undefined,
    install_date: new Date().toUTCString(),
    instabot_install_date: undefined,
    ig_users: [],
    licenses: {},
    actions: [{
        date: '',
        action: ''
    }],
    account_growth_stats: [],
    options: {},
    //      whitelist: [],
    //      savedQueue: [{ name: 'q1',date:datetime,queue:[]},{ name: 'q1',date:datetime,queue:[]}]
    init: async function() {

        runWinVarsScript();

        this.user_guid = await this.getPref('rdg_user_guid');

        if (!this.user_guid || this.user_guid == false) {
            this.user_guid = this.uuidGenerator();
            this.setPref('rdg_user_guid', this.user_guid);
        }

        // Silenciado para não contabilizar mais trial
        //checkInstallDate();

    },
    overrideGuid: function(newGuid) {
        this.user_guid = newGuid;
        this.setPref('rdg_user_guid', this.user_guid);
    },
    overrideFT: function() {
        this.instabot_free_trial_time = 0;
        openBuyScreen();
    },
    uuidGenerator: function() {
        var S4 = function() {
            return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
        };
        return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
    },
    getPref: async function(name) {
        return new Promise(function(resolve) {
            chrome.storage.local.get(name, function(value) {
                if (Object.keys(value).length > 0) {
                    resolve(value[name]);
                } else {
                    resolve(false);
                }
            });
        });
    },
    setPref: async function(name, value) {
        chrome.storage.local.set({
            [name]: value
        }, function() {});
    },
    saveToLocal: function() {
        chrome.storage.local.set({
            'igBotUser': JSON.stringify(gblIgBotUser)
        }, function() {});
    },
    saveToServer: function() {
        for (var i = 0; i < this.ig_users.length; i++) {
            fetch("https://www.rdgforfollowers.com/igBotUser/", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    'user_guid': this.user_guid,
                    'ig_username': this.current_ig_username,
                    'install_date': this.install_date,
                    'instabot_install_date': this.instabot_install_date
                })
            });
        }
    }
};


// Silenciado - Trial desativado
var instabot_free_trial_time = 0; // Trial desativado
var first_run = false;
var todaysdate = new Date();
var today = todaysdate.getTime();
var timeSinceInstall;

chrome.action.onClicked.addListener(function(tab) {
    chrome.tabs.query({
        url: ["https://www.instagram.com/", "https://www.instagram.com/*"],
        currentWindow: true
    }, tabs => {
        if (tabs.length === 0) {
            chrome.tabs.create({
                url: 'https://www.instagram.com/'
            }, function(tab) {
                chrome.tabs.sendMessage(tab.id, {
                    "openRdg": true,
                    igBotUser: gblIgBotUser
                });
            });
        } else {
            var toggled = false;
            for (var i = 0; i < tabs.length; i++) {
                if (tabs[i].active === true) {
                    toggled = true;
                    chrome.tabs.sendMessage(tabs[i].id, {
                        "toggleRdg": true,
                        igBotUser: gblIgBotUser
                    });
                }
            }
            if (toggled === false) {
                // only runs if instagram wasn't the active tab:
                chrome.tabs.update(tabs[0].id, {
                    active: true
                });
                chrome.tabs.sendMessage(tabs[0].id, {
                    "openRdg": true,
                    igBotUser: gblIgBotUser
                });
            }
        }
    });
});


chrome.runtime.onInstalled.addListener(installedOrUpdated);

function installedOrUpdated(details) {
    try {
        gblIgBotUser.init();
    } catch (e) {}
}

function runWinVarsScript() {
    chrome.tabs.query({
        url: ["https://www.instagram.com/*", "https://www.instagram.com/"]
    }, tabs => {
        for (var i = 0; i < tabs.length; i++) {
            var igTabId = tabs[i].id;
            chrome.scripting.executeScript({
                    target: {
                        tabId: igTabId
                    },
                    files: ['winvars.js'],
                    world: 'MAIN'
                },
                function() {});
        }
    });
}


async function checkInstallDate() {

    var installDate = await gblIgBotUser.getPref('instabot_install_date');

    if (installDate == false) {
        first_run = true;
        installDate = '' + today;
        gblIgBotUser.setPref('instabot_install_date', installDate);
    }

    gblIgBotUser.instabot_install_date = installDate;

    // string -> int -> date -> UTCString for python
    gblIgBotUser.install_date = new Date(+installDate).toUTCString();
    timeSinceInstall = today - installDate;
    checkLicenseOnServer();

}

function sendMessageToInstagramTabs(message) {
    chrome.tabs.query({
        url: ["https://www.instagram.com/", "https://www.instagram.com/*", "https://www.rdgforfollowers.com/*"]
    }, function(tabs) {
        //if (tabs.length == 0) return false;
        for (var i = 0; i < tabs.length; i++) {
            chrome.tabs.sendMessage(tabs[i].id, message).then(response => {
                // console.log("Message from the content script:");
                // console.log(response.response);
            }).catch(function() {
                // console.log('error when: ' + message);
                // console.log(message);
            });
        }
    });
}


function onError(error) {
    //console.error(`Error: ${error}`);
}

function checkLicenseOnServer() {
    // Silenciado - Sempre retorna licença ativa
    allLicensesFetched(1, {
        "rdg_license": 1
    });
}

function allLicensesFetched(count, licenses) {
    // Modificado para sempre considerar licença ativa
    if (count === 2 || count === 1 || count === 0) {
        // Sempre retorna licença ativa (VIP)
        sendMessageToInstagramTabs({
            "instabot_install_date": gblIgBotUser.instabot_install_date,
            "instabot_free_trial_time": instabot_free_trial_time,
            "instabot_has_license": true, // Sempre true
            igBotUser: gblIgBotUser
        });
    } else {
        // Fallback para licença ativa
        sendMessageToInstagramTabs({
            "instabot_install_date": gblIgBotUser.instabot_install_date,
            "instabot_free_trial_time": instabot_free_trial_time,
            "instabot_has_license": true, // Sempre true
            igBotUser: gblIgBotUser
        });
    }

    gblIgBotUser.licenses = licenses;

    gblIgBotUser.saveToLocal();
}


function openBuyScreen() {
    //console.log(gblIgBotUser);
    // Silenciado - Não abre tela de compras
    // sendMessageToInstagramTabs({
    //     "openBuyScreen": true,
    //     igBotUser: gblIgBotUser,
    //     "instabot_free_trial_time": instabot_free_trial_time
    // });
}


function uniq(ar) {
    return Array.from(new Set(ar.map(JSON.stringify))).map(JSON.parse);
}
