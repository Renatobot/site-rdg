/**
 * beta_logic.js
 * Logic for New Followers and Mass DM (Beta)
 */

var massDMQueue = [];
var isMassDMRunning = false;
var massDMTimer = null;
var currentDMWindow = null;
var betaInitialized = false;
var betaDmRequestCounter = 0;
var betaAiSuggestionTargetSelector = '#txtMassDM';
var betaAiTokenCache = { value: null, fetchedAt: 0 };
var betaMassDmTemplateSelectors = ['#txtMassDM', '#txtMassDM2', '#txtMassDM3'];
var betaAssistantDmTemplateSelectors = ['#rdgAssistantDmTemplate', '#rdgAssistantDmTemplate2', '#rdgAssistantDmTemplate3'];
var betaChainDmTemplateSelectors = ['#txtChainDmMessage', '#txtChainDmMessage2', '#txtChainDmMessage3'];
var betaLastFocusedChainDmTextarea = '#txtChainDmMessage';

function betaResolveMassDmRuntimeStorageKey() {
    try {
        if (typeof rdgAssistantGetStorageScopeId === 'function') {
            var scopeId = rdgAssistantGetStorageScopeId();
            if (scopeId) return 'rdg_mass_dm_runtime:' + String(scopeId);
        }
    } catch (e) {}
    try {
        if (typeof rdgAssistantGetViewerUsername === 'function') {
            var viewer = rdgAssistantGetViewerUsername();
            if (viewer) return 'rdg_mass_dm_runtime:ig:' + String(viewer).toLowerCase();
        }
    } catch (e2) {}
    return 'rdg_mass_dm_runtime';
}

function betaBuildMassDmRuntimeState(override) {
    var processed = 0;
    for (var i = 0; i < massDMQueue.length; i++) {
        if (massDMQueue[i] && massDMQueue[i].processed) processed++;
    }
    return $.extend(true, {
        queue: Array.isArray(massDMQueue) ? JSON.parse(JSON.stringify(massDMQueue)) : [],
        running: isMassDMRunning === true,
        processedCount: processed,
        statusText: $('#massDMStatus').text() || '',
        updatedAt: Date.now()
    }, override || {});
}

function betaSaveMassDmRuntime(callback, override) {
    var key = betaResolveMassDmRuntimeStorageKey();
    var payload = {};
    payload[key] = betaBuildMassDmRuntimeState(override);
    chrome.storage.local.set(payload, function() {
        if (typeof callback === 'function') callback(payload[key]);
    });
}

function betaLoadMassDmRuntime(callback) {
    var key = betaResolveMassDmRuntimeStorageKey();
    chrome.storage.local.get([key, 'rdg_mass_dm_runtime'], function(result) {
        result = result || {};
        var state = result[key] || result.rdg_mass_dm_runtime || null;
        if (typeof callback === 'function') callback(state);
    });
}

function betaClearMassDmRuntime(callback) {
    var key = betaResolveMassDmRuntimeStorageKey();
    chrome.storage.local.remove([key, 'rdg_mass_dm_runtime'], function() {
        if (typeof callback === 'function') callback();
    });
}

function betaResumeMassDMFromRuntime(callback) {
    if (isMassDMRunning === true && Array.isArray(massDMQueue) && massDMQueue.some(function(user) { return user && user.processed !== true; })) {
        betaNotifyAssistantDmProgress($('#massDMStatus').text() || 'Envio em massa em andamento.', { resumed: true });
        if (typeof callback === 'function') callback(true);
        return;
    }
    betaLoadMassDmRuntime(function(state) {
        if (!state || !Array.isArray(state.queue) || !state.queue.length) {
            if (typeof callback === 'function') callback(false);
            return;
        }
        loadDMHistory(function(history) {
            history = history || {};
            massDMQueue = state.queue.map(function(user) {
                var clone = $.extend(true, {}, user || {});
                var alreadySent = !!history[String(clone.id || '')];
                if (alreadySent) clone.processed = true;
                return clone;
            });
            var hasPending = massDMQueue.some(function(user) {
                return user && user.processed !== true;
            });
            if (!hasPending) {
                betaClearMassDmRuntime(function() {
                    if (typeof callback === 'function') callback(false);
                });
                return;
            }
            isMassDMRunning = true;
            $('#btnStartMassDM').hide();
            $('#btnStopMassDM').show();
            $('#massDMStatus').text(state.statusText || 'Retomando envio em massa...');
            betaNotifyAssistantDmProgress(state.statusText || 'Retomando envio em massa...', { resumed: true });
            betaSaveMassDmRuntime(function() {
                setTimeout(processNextDM, 200);
                if (typeof callback === 'function') callback(true);
            }, {
                running: true,
                statusText: state.statusText || 'Retomando envio em massa...'
            });
        });
    });
}

function betaGetMassDmRetryDelayMs(attempt) {
    var n = Math.max(1, parseInt(attempt || 1, 10) || 1);
    return Math.min(15 * 60 * 1000, 5000 * n);
}

function betaScheduleRetryForUser(nextUser, queueIndex, reasonText, options) {
    options = options || {};
    if (!nextUser) {
        setTimeout(processNextDM, options.delayMs || 5000);
        return;
    }
    var attempt = Math.max(0, parseInt(nextUser._dmRetryCount || 0, 10) || 0) + 1;
    nextUser._dmRetryCount = attempt;
    nextUser._lastDmRetryAt = Date.now();
    nextUser._lastDmRetryReason = reasonText || 'Nova tentativa pendente';
    var delayMs = Math.max(5000, parseInt(options.delayMs || betaGetMassDmRetryDelayMs(attempt), 10) || 5000);
    var username = nextUser.username || ('usuario-' + (queueIndex + 1));
    var statusText = (reasonText || 'Falha temporaria.') + ' Nova tentativa para @' + username + ' em ' + Math.round(delayMs / 1000) + 's.';
    updateStatus(nextUser.id, 'Aguardando nova tentativa (' + attempt + ')');
    $('#massDMStatus').text(statusText);
    betaNotifyAssistantDmProgress(statusText, { currentUsername: username });
    betaSaveMassDmRuntime(function() {}, {
        running: true,
        statusText: statusText
    });
    chrome.storage.local.remove(['pending_dm_task'], function() {});
    if (currentDMWindow && currentDMWindow.type !== 'fixed_window' && currentDMWindow.close && !currentDMWindow.closed) {
        try { currentDMWindow.close(); } catch (e) {}
    }
    currentDMWindow = null;
    setTimeout(processNextDM, delayMs);
}

function betaGetCheckFollowersButtonLabel(source) {
    if (source === 'interacted') return 'Verificar novos seguidores';
    if (source === 'myFollowers') return 'Buscar meus seguidores';
    if (source === 'targetProfile') return 'Buscar seguidores agora';
    if (source === 'customList') return '📥 Carregar @Usuários na Fila';
    return 'Buscar seguidores agora';
}

function betaUpdateCheckFollowersButtonLabel() {
    try {
        var source = $('input[name="dmSource"]:checked').val();
        var btn = $('#btnCheckNewFollowers');
        if (!btn || btn.length === 0) return;
        if (btn.hasClass('inactive')) return;
        btn.text(betaGetCheckFollowersButtonLabel(source));
    } catch (e) {}
}

(function() {
    // Check for DM Sender Mode (running in the new tab)
    if (window.location.href.indexOf('/direct/t/') > -1) {
        // Wait for page load
        if (document.readyState === 'complete') {
            handleDMSenderMode();
        } else {
            window.addEventListener('load', handleDMSenderMode);
        }
    }

    function initBeta() {
        console.log("Initializing Beta Logic...");
        
        // Ensure UI State
        if ($('#rdg_tab7').is(':checked')) {
             var activeTab = $('.beta-tab-btn.active').data('tab') || 'send';
             $('.beta-tab-content').hide();
             $('#beta-tab-' + activeTab).show();
             $('.beta-tab-btn').removeClass('active');
             $('.beta-tab-btn[data-tab="' + activeTab + '"]').addClass('active');
        }

        if (betaInitialized) return;
        betaInitialized = true;

        // Event Listeners
        $(document).on('click', '#btnCheckNewFollowers', checkNewFollowers);
        $(document).on('click', '#btnClearNewFollowers', clearNewFollowers);
        $(document).on('click', '#btnStartMassDM', startMassDM);
        $(document).on('click', '#btnStopMassDM', stopMassDM);
        $(document).on('click', '#btnInsertUsername', function() {
            betaInsertAtTextarea(betaResolveActiveTextarea(betaMassDmTemplateSelectors, '#txtMassDM'), '{username}');
        });
        $(document).on('click', '#btnAssistantInsertUsername', function() {
            betaInsertAtTextarea(betaResolveActiveTextarea(betaAssistantDmTemplateSelectors, '#rdgAssistantDmTemplate'), '{username}');
        });
        $(document).on('click', '#btnAiImprove', function() { handleAiImprove(betaResolveActiveTextarea(betaMassDmTemplateSelectors, '#txtMassDM')); });
        $(document).on('click', '#btnAiCorrect', function() { handleAiCorrection(betaResolveActiveTextarea(betaMassDmTemplateSelectors, '#txtMassDM')); });
        $(document).on('click', '#btnAiEmojify', function() { handleAiEmojify(betaResolveActiveTextarea(betaMassDmTemplateSelectors, '#txtMassDM')); });
        $(document).on('click', '#btnAiPersuasive', function() { handleAiPersuasive(betaResolveActiveTextarea(betaMassDmTemplateSelectors, '#txtMassDM')); });
        $(document).on('click', '#btnAssistantAiImprove', function() { handleAiImprove(betaResolveActiveTextarea(betaAssistantDmTemplateSelectors, '#rdgAssistantDmTemplate')); });
        $(document).on('click', '#btnAssistantAiCorrect', function() { handleAiCorrection(betaResolveActiveTextarea(betaAssistantDmTemplateSelectors, '#rdgAssistantDmTemplate')); });
        $(document).on('click', '#btnAssistantAiEmojify', function() { handleAiEmojify(betaResolveActiveTextarea(betaAssistantDmTemplateSelectors, '#rdgAssistantDmTemplate')); });
        $(document).on('click', '#btnAssistantAiPersuasive', function() { handleAiPersuasive(betaResolveActiveTextarea(betaAssistantDmTemplateSelectors, '#rdgAssistantDmTemplate')); });
        $(document).on('focus click input', '#txtChainDmMessage, #txtChainDmMessage2, #txtChainDmMessage3', function() { betaLastFocusedChainDmTextarea = '#' + this.id; });
        $(document).on('click', '#btnChainInsertUsername', function(e) { e.preventDefault(); betaInsertAtTextarea(betaResolveActiveTextarea(betaChainDmTemplateSelectors, betaLastFocusedChainDmTextarea), '{username}'); });
        $(document).on('click', '#btnChainAiImprove', function(e) { e.preventDefault(); handleAiImprove(betaResolveActiveTextarea(betaChainDmTemplateSelectors, betaLastFocusedChainDmTextarea)); });
        $(document).on('click', '#btnChainAiCorrect', function(e) { e.preventDefault(); handleAiCorrection(betaResolveActiveTextarea(betaChainDmTemplateSelectors, betaLastFocusedChainDmTextarea)); });
        $(document).on('click', '#btnChainAiEmojify', function(e) { e.preventDefault(); handleAiEmojify(betaResolveActiveTextarea(betaChainDmTemplateSelectors, betaLastFocusedChainDmTextarea)); });
        $(document).on('click', '#btnChainAiPersuasive', function(e) { e.preventDefault(); handleAiPersuasive(betaResolveActiveTextarea(betaChainDmTemplateSelectors, betaLastFocusedChainDmTextarea)); });
        $(document).on('click', '#btnAiCancel', closeAiModal);
        $(document).on('click', '#btnAiApply', applyAiSuggestion);
        $(document).on('input', '#txtMassDM, #txtMassDM2, #txtMassDM3', betaUpdateDmCharCount);
        // $(document).on('change', '#txtOpenAiKey', saveOpenAiKey);
        
        // New Event Listeners
        $(document).on('click', '#btnRemoveSelected', removeSelectedUsers);
        $(document).on('change', '#cbSelectAllFollowers', toggleSelectAll);

        // Tabs
        $(document).on('click', '.beta-tab-btn', function() {
            var tabId = $(this).data('tab');
            $('.beta-tab-btn').removeClass('active');
            $(this).addClass('active');
            $('.beta-tab-content').hide();
            $('#beta-tab-' + tabId).show();
            if (tabId === 'history') refreshHistoryTable();
        });

        $(document).on('click', '#btnRefreshHistory', refreshHistoryTable);
        $(document).on('click', '#btnClearHistory', clearHistoryTable);
        
        // UI Updates
        $(document).on('change', 'input[name="dmSource"]', updateBetaUI);
        
        // Initial UI State
        updateBetaUI();
        try { betaDockApply(false); } catch (e) {}

        // loadOpenAiKey();
    }

    function updateBetaUI() {
        var source = $('input[name="dmSource"]:checked').val();
        if (source === 'interacted') {
            $('#divSortOrder').hide();
            $('#divTimeFilter').show();
            $('#customListContainer').slideUp(200);
        } else if (source === 'customList') {
            $('#divSortOrder').hide();
            $('#divTimeFilter').hide();
            $('#customListContainer').slideDown(250);
        } else {
            $('#divSortOrder').show();
            $('#divTimeFilter').hide();
            $('#customListContainer').slideUp(200);
        }
        betaUpdateCheckFollowersButtonLabel();
    }

function betaGetAttemptedStorageKey() {
    try {
        if (typeof rdgResolveAttemptedStorageKey === 'function') {
            return rdgResolveAttemptedStorageKey();
        }
    } catch (e) {}
    return 'acctsAttempted';
}

function betaGetAttemptedStorageKeys() {
    try {
        if (typeof rdgResolveAttemptedStorageKeyCandidates === 'function') {
            return rdgResolveAttemptedStorageKeyCandidates();
        }
    } catch (e) {}
    return ['acctsAttempted'];
}

function betaLoadAttemptedHistory(callback) {
    var scopedKey = betaGetAttemptedStorageKey();
    var storageKeys = betaGetAttemptedStorageKeys();
    chrome.storage.local.get(storageKeys, function(data) {
        var interacted = [];
        if (Array.isArray(data[scopedKey])) {
            interacted = data[scopedKey];
            callback(interacted);
            return;
        }
        for (var i = 0; i < storageKeys.length; i++) {
            var candidateKey = storageKeys[i];
            if (!candidateKey || candidateKey === scopedKey || candidateKey === 'acctsAttempted') continue;
            if (!Array.isArray(data[candidateKey])) continue;
            interacted = data[candidateKey];
            callback(interacted);
            return;
        }
        if (Array.isArray(data.acctsAttempted)) interacted = data.acctsAttempted;
        callback(interacted);
    });
}

    function loadDMHistory(callback) {
        chrome.storage.local.get("dm_history", function(result) {
            callback(result.dm_history || {});
        });
    }

    function saveDMHistory(user, message) {
        chrome.storage.local.get("dm_history", function(result) {
            var history = result.dm_history || {};
            history[user.id] = {
                timestamp: Date.now(),
                username: user.username,
                userId: user.id,
                message: message,
                status: 'sent'
            };
            chrome.storage.local.set({ "dm_history": history });
        });
    }

    function refreshHistoryTable() {
        loadDMHistory(function(history) {
            var tbody = $('#tblHistory tbody');
            tbody.empty();
            
            var entries = Object.entries(history).sort(function(a, b) {
                var valA = a[1];
                var valB = b[1];
                var tA = valA.timestamp || valA;
                var tB = valB.timestamp || valB;
                return tB - tA; // Descending
            });

            if (entries.length === 0) {
                tbody.append('<tr><td colspan="5" style="text-align:center;">Nenhum histórico encontrado.</td></tr>');
                return;
            }

            entries.forEach(function(entry) {
                var id = entry[0];
                var val = entry[1];
                
                var ts = val.timestamp || val;
                var dateStr = new Date(ts).toLocaleString();
                var username = val.username || "-";
                var status = val.status || "Enviado";
                var message = val.message || "-";
                
                // Truncate long messages
                if (message.length > 50) message = message.substring(0, 47) + "...";
                
                if (typeof val === 'number') status = "Enviado (Legado)";
                
                var row = `<tr>
                    <td>${dateStr}</td>
                    <td>${username}</td>
                    <td>${id}</td>
                    <td title="${(val.message || "").replace(/"/g, '&quot;')}">${message}</td>
                    <td><span class="beta-status-sent">${status}</span></td>
                </tr>`;
                tbody.append(row);
            });
        });
    }

    function clearHistoryTable() {
        if (!confirm("Tem certeza que deseja apagar todo o histórico de envios?")) return;
        chrome.storage.local.remove("dm_history", function() {
            refreshHistoryTable();
        });
    }

    function toggleSelectAll() {
        var checked = $('#cbSelectAllFollowers').is(':checked');
        $('.user-checkbox').prop('checked', checked);
    }

    function removeSelectedUsers() {
        var toRemove = [];
        $('.user-checkbox:checked').each(function() {
            // Use .attr() instead of .data() to prevent jQuery from converting long IDs to numbers and losing precision
            toRemove.push(String($(this).attr('data-id')));
        });

        if (toRemove.length === 0) {
            alert("Nenhum usuário selecionado.");
            return;
        }

        if (!confirm("Remover " + toRemove.length + " usuários da lista?")) return;

        // Filter queue
        massDMQueue = massDMQueue.filter(u => !toRemove.includes(String(u.id)));
        
        loadDMHistory(function(history) {
             renderTableWithHistory(massDMQueue, history);
        });
    }

/*
    function loadOpenAiKey() {
        chrome.storage.local.get("openai_api_key", function(result) {
            if (result.openai_api_key) {
                $('#txtOpenAiKey').val(result.openai_api_key);
            }
        });
    }

    function saveOpenAiKey() {
        var key = $('#txtOpenAiKey').val();
        chrome.storage.local.set({ "openai_api_key": key }, function() {
            logBeta("Chave de API salva.");
        });
    }
*/

    function closeAiModal() {
        $('#aiConfirmModal').hide();
    }

    function applyAiSuggestion() {
        var newText = $('#aiSuggestedText').text();
        var targetSelector = betaAiSuggestionTargetSelector || '#txtMassDM';
        $(targetSelector).val(newText).trigger('input');
        closeAiModal();
    }

    function betaGetAiButtonMap() {
        return {
            '#btnAiImprove': '✍ IA: Melhorar',
            '#btnAiCorrect': '✨ IA: Corrigir',
            '#btnAiEmojify': '😍 IA: Emojis',
            '#btnAiPersuasive': '🚀 IA: Conversao',
            '#btnAssistantAiImprove': '✍ IA: Melhorar',
            '#btnAssistantAiCorrect': '✨ IA: Corrigir',
            '#btnAssistantAiEmojify': '😍 IA: Emojis',
            '#btnAssistantAiPersuasive': '🚀 IA: Conversao',
            '#btnChainAiImprove': '✍ IA: Melhorar',
            '#btnChainAiCorrect': '✨ IA: Corrigir',
            '#btnChainAiEmojify': '😍 IA: Emojis',
            '#btnChainAiPersuasive': '🚀 IA: Conversao'
        };
    }

    function betaSetAiButtonsLoading(selectors, loading) {
        var labels = betaGetAiButtonMap();
        (selectors || []).forEach(function(selector) {
            var btn = $(selector);
            if (!btn || !btn.length) return;
            if (loading) {
                btn.addClass('inactive').text('Processando...');
            } else {
                btn.removeClass('inactive').text(labels[selector] || 'IA');
            }
        });
    }

    function betaResolveActiveTextarea(selectors, fallbackSelector) {
        var active = document.activeElement;
        if (active) {
            var activeId = active.id ? ('#' + active.id) : '';
            if (activeId && selectors.indexOf(activeId) > -1) return activeId;
        }
        for (var i = 0; i < selectors.length; i++) {
            var selector = selectors[i];
            var value = $(selector).val();
            if (value && String(value).trim()) return selector;
        }
        return fallbackSelector;
    }

    function betaGetDmTemplates(selectors) {
        var templates = [];
        (selectors || []).forEach(function(selector) {
            var text = String($(selector).val() || '').trim();
            if (!text) return;
            if (templates.indexOf(text) === -1) templates.push(text);
        });
        return templates.slice(0, 3);
    }

    function betaUpdateDmCharCount() {
        var templates = betaGetDmTemplates(betaMassDmTemplateSelectors);
        var activeSelector = betaResolveActiveTextarea(betaMassDmTemplateSelectors, '#txtMassDM');
        var activeLength = String($(activeSelector).val() || '').length;
        var suffix = templates.length > 1 ? (' | ' + templates.length + ' variacoes') : '';
        $('#charCount').text(activeLength + suffix);
    }

    function betaBuildFinalDmMessage(nextUser) {
        var templates = betaGetDmTemplates(betaMassDmTemplateSelectors);
        if (!templates.length) return '';
        var chosen = templates[Math.floor(Math.random() * templates.length)] || templates[0] || '';
        var username = nextUser && nextUser.username ? nextUser.username : '';
        return String(chosen).replace(/{username}/g, username);
    }

function betaGetRandomMassDmDelayMs() {
    var minSec = 10;
    var maxSec = 30;
    return (minSec + Math.floor(Math.random() * (maxSec - minSec + 1))) * 1000;
}

function betaFormatRandomDelayStatus(delayMs, remainingSec) {
    var sortedSec = Math.ceil((parseInt(delayMs || 0, 10) || 0) / 1000);
    var currentRemaining = typeof remainingSec === 'number' ? remainingSec : sortedSec;
    return "Proximo envio sorteado: " + sortedSec + "s | aguardando " + currentRemaining + "s...";
}

    function betaInsertAtTextarea(textareaSelector, valueToInsert) {
        var txt = $(textareaSelector);
        if (!txt || !txt.length) return;
        var node = txt[0];
        var val = txt.val() || '';
        
        // Evita duplicar se ja existir {username} no texto ao clicar no botao
        if (valueToInsert === '{username}' && val.indexOf('{username}') > -1) {
            node.focus();
            return;
        }

        var start = typeof node.selectionStart === 'number' ? node.selectionStart : val.length;
        var end = typeof node.selectionEnd === 'number' ? node.selectionEnd : val.length;

        // Se o cursor estiver no inicio (0) e ja houver texto digitado
        if (start === 0 && val.length > 0) {
            var greetingMatch = val.match(/^(olá|ola|oi|hey|bom dia|boa tarde|boa noite)[,\s!]*/i);
            if (greetingMatch) {
                var greeting = greetingMatch[0].trim().replace(/[,\s!]/g, '');
                var rest = val.substring(greetingMatch[0].length);
                var newVal = greeting + ' {username}, ' + rest.trimLeft();
                txt.val(newVal).trigger('input');
                node.focus();
                return;
            } else {
                var prefix = val.endsWith(' ') ? '' : ' ';
                txt.val(val + prefix + valueToInsert).trigger('input');
                node.focus();
                return;
            }
        }

        var before = val.substring(0, start);
        var after = val.substring(end);
        var needSpaceBefore = before.length > 0 && !before.endsWith(' ') && !before.endsWith('\n');
        var needSpaceAfter = after.length > 0 && !after.startsWith(' ') && !after.startsWith(',') && !after.startsWith('.') && !after.startsWith('!') && !after.startsWith('?');
        
        var inserted = (needSpaceBefore ? ' ' : '') + valueToInsert + (needSpaceAfter ? ' ' : '');
        txt.val(before + inserted + after).trigger('input');
        
        var newCaretPos = start + inserted.length;
        try {
            node.setSelectionRange(newCaretPos, newCaretPos);
        } catch (e) {}
        node.focus();
    }

    function localAiTransform(text, mode) {
        if (!text) return '';
        var result = text.trim();

        if (mode === 'improve') {
            if (/^(olá|ola|oi|hey|bom dia|boa tarde|boa noite)/i.test(result)) {
                result = result.replace(/^(olá|ola|oi|hey|bom dia|boa tarde|boa noite)[,\s!]*/i, function(m) {
                    var cleanM = m.trim().replace(/[,\s!]/g, '');
                    return cleanM + ' {username}! ';
                });
            } else if (result.indexOf('{username}') === -1) {
                result = 'Olá {username}! ' + result;
            }

            if (result.indexOf('?') === -1 && result.indexOf('!') === -1) {
                result += ' 😊';
            }
            if (!result.toLowerCase().includes('abraço') && !result.toLowerCase().includes('disposição') && !result.toLowerCase().includes('aguardo')) {
                result += '\n\nSe tiver qualquer dúvida, estou à disposição por aqui! 😉';
            }
        } else if (mode === 'correct') {
            result = result
                .replace(/\bvc\b/gi, 'você')
                .replace(/\bvcs\b/gi, 'vocês')
                .replace(/\btbm\b/gi, 'também')
                .replace(/\bconcom\b/gi, 'com')
                .replace(/\bquei\b/gi, 'que')
                .replace(/\bpq\b/gi, 'porque')
                .replace(/\bnao\b/gi, 'não')
                .replace(/\beh\b/gi, 'é')
                .replace(/\bja\b/gi, 'já')
                .replace(/\bvoce\b/gi, 'você')
                .replace(/\bso\b/gi, 'só')
                .replace(/\bate\b/gi, 'até')
                .replace(/\besta\b/gi, 'está')
                .replace(/\btao\b/gi, 'tão')
                .replace(/\bduvida\b/gi, 'dúvida')
                .replace(/\botimo\b/gi, 'ótimo')
                .replace(/\botima\b/gi, 'ótima');
        } else if (mode === 'emojify') {
            var emojiRules = [
                { rx: /\b(olá|ola|oi|hey|bom dia|boa tarde)\b/gi, emoji: '$1 👋' },
                { rx: /\b(tudo bem|como vai)\b/gi, emoji: '$1 😊' },
                { rx: /\b(proposta|oportunidade|novidade)\b/gi, emoji: '$1 🚀' },
                { rx: /\b(negócio|trabalho|projeto)\b/gi, emoji: '$1 💼' },
                { rx: /\b(desconto|promoção|oferta)\b/gi, emoji: '$1 🏷️' },
                { rx: /\b(link|site|página)\b/gi, emoji: '$1 🔗' },
                { rx: /\b(direct|mensagem|chat)\b/gi, emoji: '$1 📥' },
                { rx: /\b(instagram|perfil|feed)\b/gi, emoji: '$1 📸' },
                { rx: /\b(sucesso|resultado|crescer)\b/gi, emoji: '$1 🌟' }
            ];
            for (var i = 0; i < emojiRules.length; i++) {
                result = result.replace(emojiRules[i].rx, emojiRules[i].emoji);
            }
            if (!/[\u{1F300}-\u{1F9FF}]/u.test(result)) {
                result = '✨ ' + result + ' 🚀';
            }
        } else if (mode === 'persuasive') {
            var hasGreeting = /^(olá|ola|oi|hey|bom dia|boa tarde|boa noite)/i.test(result);
            var lead = hasGreeting ? result : ('Olá {username}! ' + result);
            result = '🔥 ' + lead + '\n\n💡 Pensei em algo exclusivo para o seu perfil. Se quiser saber mais, me dá um toque por aqui! 🚀';
        }

        result = result.replace(/  +/g, ' ').trim();
        return result;
    }

    function handleAiImprove(targetSelector) {
        var text = $(targetSelector).val();
        if (!text) { alert("Digite um texto primeiro."); return; }

        var prompt = "Melhore a mensagem abaixo para direct do Instagram em portugues do Brasil. Deixe mais clara, natural, humana e envolvente, sem exagerar nem parecer robo. Mantenha a intencao original, preserve a variavel {username} intacta e entregue somente a mensagem final:\n\n" + text;

        callOpenAI(prompt, function(suggested) {
            showAiModal(text, suggested, targetSelector);
        }, ['#btnAiImprove', '#btnAssistantAiImprove', '#btnChainAiImprove'], 'improve');
    }

    function handleAiCorrection(targetSelector) {
        var text = $(targetSelector).val();
        if (!text) { alert("Digite um texto primeiro."); return; }
        
        var prompt = "Corrija a gramática e ortografia do seguinte texto em português, mantendo o tom natural e informal para uma mensagem de Instagram. Mantenha as variáveis como {username} intactas:\n\n" + text;
        
        callOpenAI(prompt, function(suggested) {
            showAiModal(text, suggested, targetSelector);
        }, ['#btnAiCorrect', '#btnAssistantAiCorrect', '#btnChainAiCorrect'], 'correct');
    }

    function handleAiEmojify(targetSelector) {
        var text = $(targetSelector).val();
        if (!text) { alert("Digite um texto primeiro."); return; }

        var prompt = "Reescreva o seguinte texto adicionando emojis relevantes e tornando-o mais engajador para o Instagram. Mantenha o tom amigável. Mantenha as variáveis como {username} intactas:\n\n" + text;

        callOpenAI(prompt, function(suggested) {
            showAiModal(text, suggested, targetSelector);
        }, ['#btnAiEmojify', '#btnAssistantAiEmojify', '#btnChainAiEmojify'], 'emojify');
    }

    function handleAiPersuasive(targetSelector) {
        var text = $(targetSelector).val();
        if (!text) { alert("Digite um texto primeiro."); return; }

        var prompt = "Atue como um especialista em Copywriting para Instagram. Reescreva a mensagem abaixo para torná-la altamente persuasiva, profissional e focada em conversão/vendas, mas mantendo um tom pessoal e natural (sem parecer robô). Mantenha as variáveis como {username} intactas:\n\n" + text;

        callOpenAI(prompt, function(suggested) {
            showAiModal(text, suggested, targetSelector);
        }, ['#btnAiPersuasive', '#btnAssistantAiPersuasive', '#btnChainAiPersuasive'], 'persuasive');
    }

    function showAiModal(original, suggested, targetSelector) {
        betaAiSuggestionTargetSelector = targetSelector || '#txtMassDM';
        $('#aiOriginalText').text(original);
        $('#aiSuggestedText').text(suggested);
        $('#aiConfirmModal').show();
    }

    function betaFetchRemoteAiToken(callback) {
        callback('local_active');
    }

    function callOpenAI(prompt, callback, buttonSelectors, mode) {
        var selectors = buttonSelectors && buttonSelectors.length ? buttonSelectors : ['#btnAiImprove', '#btnAiCorrect', '#btnAiEmojify', '#btnAiPersuasive'];
        betaSetAiButtonsLoading(selectors, true);
        
        chrome.runtime.sendMessage({
            action: 'rdgCallAiApi',
            prompt: prompt,
            mode: mode || 'improve'
        }, function(resp) {
            betaSetAiButtonsLoading(selectors, false);
            if (!chrome.runtime.lastError && resp && resp.suggested) {
                callback(resp.suggested);
            } else {
                var text = prompt.split('\n\n').slice(1).join('\n\n') || prompt;
                var localResult = localAiTransform(text, mode || 'improve');
                callback(localResult);
            }
        });
    }

    // Run init if document is already ready, or wait
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        setTimeout(initBeta, 1000); // Wait a bit for HTML to be injected
    } else {
        $(document).ready(function() { setTimeout(initBeta, 1000); });
    }
})();

function handleDMSenderMode() {
    // Only run if we have a pending task
    chrome.storage.local.get(['pending_dm_task'], function(result) {
        var task = result.pending_dm_task;
        if (!task || task.status !== 'pending') return;
        try {
            var createdAt = task.createdAt || task.timestamp || 0;
            if (createdAt && Date.now() - createdAt > 120000) return;
        } catch (e) {}

        // Check if URL matches target
        if (window.location.href.indexOf(task.targetId) === -1) return;

        console.log("[Beta] Modo Envio Ativado. Aguardando campo de mensagem...");

        var attempts = 0;
        var interval = setInterval(function() {
            // Try to find the contenteditable div
            var input = document.querySelector('div[contenteditable="true"][role="textbox"]');

            if (!input && attempts >= 6) {
                try {
                    var retryKey = 'rdg_dm_direct_retry_' + String(task.targetId);
                    if (!sessionStorage.getItem(retryKey)) {
                        var hasYourMessages = false;
                        var hasSendMessageButton = false;

                        var bodyText = (document.body && document.body.innerText) ? document.body.innerText : '';
                        if (bodyText.indexOf('Suas mensagens') > -1 || bodyText.indexOf('Your messages') > -1) {
                            hasYourMessages = true;
                        }

                        var buttons = document.querySelectorAll('button');
                        for (var b = 0; b < buttons.length; b++) {
                            var t = (buttons[b].innerText || '').trim();
                            if (t === 'Enviar mensagem' || t === 'Send message') {
                                hasSendMessageButton = true;
                                break;
                            }
                        }

                        if (hasYourMessages && hasSendMessageButton) {
                            sessionStorage.setItem(retryKey, '1');
                            clearInterval(interval);
                            setTimeout(function() { window.location.reload(); }, 150);
                            return;
                        }
                    }
                } catch (e) {}
            }
            
            if (input) {
                clearInterval(interval);
                
                // Focus and simulate typing
                input.focus();
                
                // 1. Clear existing content (safety)
                document.execCommand('selectAll', false, null);
                document.execCommand('delete', false, null);

                // 2. Insert text handling newlines
                // Instagram Direct expects newlines to be actual line breaks or Shift+Enter
                var lines = task.message.split('\n');
                
                for (var i = 0; i < lines.length; i++) {
                    var line = lines[i];
                    if (line) {
                        document.execCommand('insertText', false, line);
                    }
                    
                    // If not the last line, insert a newline
                    if (i < lines.length - 1) {
                         // Try Shift+Enter simulation for newline
                         var shiftEnter = new KeyboardEvent('keydown', {
                            key: 'Enter',
                            code: 'Enter',
                            keyCode: 13,
                            which: 13,
                            shiftKey: true,
                            bubbles: true,
                            cancelable: true,
                            view: window
                         });
                         input.dispatchEvent(shiftEnter);
                         
                         // Also try inserting a literal newline character if Shift+Enter doesn't create a visual break
                         // But usually Shift+Enter event + insertText is the combo. 
                         // Alternatively, insertText with '\n' might work better if we do it line by line?
                         // Let's force a break element or newline char via execCommand if the event isn't enough.
                         // Actually, sticking to just the event might be weak if the app ignores it.
                         // Let's try execCommand('insertText', false, '\n') as well.
                         document.execCommand('insertText', false, '\n');
                    }
                }
                
                // Dispatch Input event to trigger framework listeners
                input.dispatchEvent(new Event('input', { bubbles: true }));
                input.dispatchEvent(new Event('change', { bubbles: true }));
                
                // Simulate key presses to ensure "Send" button enables
                input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Space', code: 'Space', keyCode: 32, bubbles: true }));
                input.dispatchEvent(new KeyboardEvent('keyup', { key: 'Space', code: 'Space', keyCode: 32, bubbles: true }));

                // Wait a moment for UI to update then try sending
                // Reduced delay as per user request (was 1000ms)
                setTimeout(function() {
                    attemptSend(input, task);
                }, 300); 
            }
            
            attempts++;
            if (attempts > 60) { // 30s timeout (60 * 500ms) - Reduced from 60s to be more responsive
                clearInterval(interval);
                
                // Retry logic for page load failure
                var retryCount = task.retryCount || 0;
                if (retryCount < 3) {
                    console.log("[Beta] Timeout aguardando chat. Tentando recarregar página... Tentativa " + (retryCount + 1));
                    chrome.storage.local.set({
                        'pending_dm_task': { ...task, retryCount: retryCount + 1 }
                    }, function() {
                        window.location.reload();
                    });
                } else {
                    chrome.storage.local.set({
                        'pending_dm_task': { ...task, status: 'error', error: 'Input not found after retries' }
                    }, function() {
                        window.close();
                    });
                }
            }
        }, 500);
    });
}

function attemptSend(input, task, retries = 15) {
    // Try to find Send button
    var btn = findSendButton();
    
    if (btn) {
        // Check if button is disabled
        if (btn.disabled || btn.getAttribute('aria-disabled') === 'true' || btn.style.opacity === '0.3') {
            console.log("[Beta] Botão Enviar encontrado mas desabilitado. Aguardando...");
            if (retries > 0) {
                setTimeout(function() { attemptSend(input, task, retries - 1); }, 1000);
            } else {
                // Last resort: try clicking anyway or Enter
                simulateClick(btn);
                setTimeout(function() { finishTask(task); }, 2000);
            }
            return;
        }

        console.log("[Beta] Botão Enviar encontrado. Clicando...");
        simulateClick(btn);
        
        // Wait for send confirmation via polling
        var checkAttempts = 0;
        var checkInterval = setInterval(function() {
            var currentInput = document.querySelector('div[contenteditable="true"][role="textbox"]');
            
            // Success condition: Input is gone or empty
            if (!currentInput || currentInput.innerText.trim() === "") {
                 clearInterval(checkInterval);
                 console.log("[Beta] Mensagem enviada (input limpo). Aguardando confirmação final...");
                 
                 // Wait extra 2s to ensure request completes before closing
                 setTimeout(function() { 
                     finishTask(task); 
                 }, 2000);
                 return;
            }
            
            checkAttempts++;
            if (checkAttempts > 10) { // 5 seconds wait per click attempt
                clearInterval(checkInterval);
                console.log("[Beta] Input ainda tem texto. Clique falhou? Tentando novamente...");
                
                if (retries > 0) {
                    attemptSend(input, task, retries - 1);
                } else {
                    // Force Enter as last resort
                    triggerEnter(input);
                    setTimeout(function() { finishTask(task); }, 3000);
                }
            }
        }, 500);

    } else {
        console.log("[Beta] Botão Enviar não encontrado. Tentando Enter... Restam: " + retries);
        
        // Try to trigger Enter
        triggerEnter(input);

        // Polling for Enter success
        var checkAttempts = 0;
        var checkInterval = setInterval(function() {
            var currentInput = document.querySelector('div[contenteditable="true"][role="textbox"]');
            
            // Success condition
            if (!currentInput || currentInput.innerText.trim() === "") {
                 clearInterval(checkInterval);
                 finishTask(task);
                 return;
            }
            
            checkAttempts++;
            if (checkAttempts > 6) { // 3 seconds wait per Enter attempt
                clearInterval(checkInterval);
                
                if (retries > 0) {
                    attemptSend(input, task, retries - 1);
                } else {
                    console.log("[Beta] Desistindo de encontrar botão. Verificando status...");
                    // Mark as error
                    chrome.storage.local.set({
                        'pending_dm_task': { ...task, status: 'error', error: 'Falha ao enviar: botão não encontrado' }
                    }, function() {
                        window.close();
                    });
                }
            }
        }, 500);
    }
}

function triggerEnter(input) {
    var eventOptions = {
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        which: 13,
        bubbles: true,
        cancelable: true,
        view: window
    };
    input.dispatchEvent(new KeyboardEvent('keydown', eventOptions));
    input.dispatchEvent(new KeyboardEvent('keypress', eventOptions));
    input.dispatchEvent(new KeyboardEvent('keyup', eventOptions));
}

function finishTask(task) {
    chrome.storage.local.set({
        'pending_dm_task': { ...task, status: 'sent' }
    }, function() {
        window.close();
    });
}

function simulateClick(element) {
    if (!element) return;
    
    // Simulate full click sequence for React/Angular with PointerEvents
    var opts = { bubbles: true, cancelable: true, view: window };
    
    // Modern frameworks often track pointer events
    try {
        element.dispatchEvent(new PointerEvent('pointerdown', opts));
        element.dispatchEvent(new MouseEvent('mousedown', opts));
        element.dispatchEvent(new PointerEvent('pointerup', opts));
        element.dispatchEvent(new MouseEvent('mouseup', opts));
        element.dispatchEvent(new MouseEvent('click', opts));
    } catch (e) {
        // Fallback for older browsers if PointerEvent is missing
        element.dispatchEvent(new MouseEvent('mousedown', opts));
        element.dispatchEvent(new MouseEvent('mouseup', opts));
        element.dispatchEvent(new MouseEvent('click', opts));
    }
}

function findSendButton() {
    // 1. Text Match (Most Reliable for "Enviar")
    // Look for div/button with exact text "Enviar" or "Send"
    // Usually has role="button" and tabindex="0"
    var candidates = document.querySelectorAll('div[role="button"][tabindex="0"], button');
    for (var i = 0; i < candidates.length; i++) {
        var el = candidates[i];
        
        // Skip hidden elements
        if (el.offsetParent === null) continue;
        
        var txt = (el.innerText || "").trim();
        
        // Exact match is best
        if (txt === 'Enviar' || txt === 'Send') {
            console.log("[Beta] Botão 'Enviar' encontrado por texto exato:", el);
            return el;
        }
    }
    
    // 2. Aria Match
    for (var i = 0; i < candidates.length; i++) {
        var el = candidates[i];
        if (el.offsetParent === null) continue; // Skip hidden
        
        var aria = (el.getAttribute('aria-label') || "").toLowerCase();
        if (aria === 'enviar' || aria === 'send') {
            console.log("[Beta] Botão encontrado por aria-label:", el);
            return el;
        }
    }
    
    // 3. SVG Path Match (Paper Plane) - Fallback
    var svgs = document.querySelectorAll('svg');
    for (var i = 0; i < svgs.length; i++) {
        var svg = svgs[i];
        if (svg.offsetParent === null) continue; // Skip hidden
        
        var aria = (svg.getAttribute('aria-label') || "").toLowerCase();
        if (aria === 'enviar' || aria === 'send' || aria === 'share' || aria === 'compartilhar') {
             var parent = svg.closest('div[role="button"], button');
             if (parent) {
                 console.log("[Beta] Botão encontrado por ícone SVG:", parent);
                 return parent;
             }
        }
    }
    
    return null;
}

function logBeta(msg) {
    console.log("[Beta] " + msg);
    if (typeof logConsole !== 'undefined') {
        try { logConsole("[Beta] " + msg); } catch(e){}
    }
}

function clearNewFollowers() {
    massDMQueue = [];
    $('#tblNewFollowers tbody').empty();
    $('#newFollowersCount').text('0 usuários encontrados');
    logBeta("Lista limpa.");
}

function checkNewFollowers() {
    var source = $('input[name="dmSource"]:checked').val();
    logBeta("Verificando novos seguidores. Fonte: " + source);
    
    $('#btnCheckNewFollowers').text('Carregando...').addClass('inactive');

    if (source === 'customList') {
        var rawText = $('#txtCustomDmList').val() || '';
        var items = rawText.split(/[\r\n,;]+/);
        clearNewFollowers();
        var count = 0;
        var tbody = $('#tblNewFollowers tbody');
        items.forEach(function(item) {
            var clean = item.trim().replace(/^@/, '');
            if (clean.length > 0) {
                var fakeId = 'custom_' + clean;
                massDMQueue.push({
                    id: fakeId,
                    username: clean,
                    full_name: clean,
                    profile_pic_url: '',
                    processed: false,
                    status: "Pendente (Resolver ID)"
                });
                var row = `
                    <tr id="row-${fakeId}">
                        <td><input type="checkbox" class="user-checkbox" value="${fakeId}" checked></td>
                        <td><a href="https://instagram.com/${clean}" target="_blank">@${clean}</a></td>
                        <td>Pendente...</td>
                        <td class="status-cell">Pendente (Resolver ID)</td>
                    </tr>
                `;
                tbody.append(row);
                count++;
            }
        });
        $('#newFollowersCount').text(count + ' usuários carregados na lista personalizada');
        $('#btnCheckNewFollowers').text(betaGetCheckFollowersButtonLabel(source)).removeClass('inactive');
        if (count === 0) {
            alert('Por favor, cole pelo menos 1 @usuário na caixa de texto da Lista Personalizada!');
        } else {
            alert('✓ ' + count + ' perfis carregados da Lista Personalizada com sucesso! Agora clique em "Iniciar Direct em Massa". O robô resolverá o ID numérico e enviará com escudo anti-bloqueio!');
        }
        return;
    }

    var onIdFound = function(targetId) {
        if (!targetId) {
             logBeta("Erro: ID de destino não identificado.");
             alert(source === 'targetProfile' ? 
                 "Erro: Não foi possível identificar o perfil atual. Certifique-se de estar na página de um perfil." :
                 "Erro: Não foi possível identificar o usuário logado.");
             $('#btnCheckNewFollowers').text(betaGetCheckFollowersButtonLabel(source)).removeClass('inactive');
             return;
        }

        if (source === 'interacted') {
            proceedWithFollowerCheck(source, 0, targetId);
            return;
        }

        var $modal = $('#followerOffsetModal');
        if (!$modal || $modal.length === 0) {
            $('#newFollowersCount').text('Carregando seguidores...');
            proceedWithFollowerCheck(source, 0, targetId);
            return;
        }

        var limit = parseInt($('#txtFollowersLimit').val()) || 50;
        if (limit > 200) limit = 200;

        $('#txtFollowerOffset').val(0);
        $('#followerOffsetTotalText').text('Carregando total de seguidores...');
        $modal.show();

        $('#btnConfirmOffset').off('click').on('click', function() {
            var offset = parseInt($('#txtFollowerOffset').val()) || 0;
            if (offset < 0) offset = 0;
            $modal.hide();
            $('#newFollowersCount').text('Carregando seguidores...');
            proceedWithFollowerCheck(source, offset, targetId);
        });

        $('#btnCancelOffset').off('click').on('click', function() {
            $modal.hide();
            $('#btnCheckNewFollowers').text(betaGetCheckFollowersButtonLabel(source)).removeClass('inactive');
        });

        fetchUserInfo(targetId, function(userInfo) {
            var totalFollowers = (userInfo && typeof userInfo.follower_count === 'number') ? userInfo.follower_count : null;
            if (totalFollowers !== null) {
                $('#followerOffsetTotalText').text(
                    `Total: ${totalFollowers.toLocaleString()} seguidores. Limite atual: ${limit}.`
                );
                $('#txtFollowerOffset').attr('max', totalFollowers);
            } else {
                $('#followerOffsetTotalText').text(`Total de seguidores indisponível. Limite atual: ${limit}.`);
                $('#txtFollowerOffset').removeAttr('max');
            }
        });
    };

    if (source === 'targetProfile') {
        getTargetProfileIdFromPage(onIdFound);
    } else {
        var loggedId = getLoggedUserId();
        // Async wrapper
        setTimeout(() => onIdFound(loggedId), 10);
    }
}

function proceedWithFollowerCheck(source, offset, targetUserId) {
    // 1. Get Interacted History
    betaLoadAttemptedHistory(function(interacted) {
        
        var interactedMap = new Map(); // Store ID -> Date
        // Handle potentially different structures of acctsAttempted
        if (Array.isArray(interacted)) {
            interacted.forEach(function(item) {
                var idStr = null;
                var dateStr = "-";
                
                if (typeof item === 'string') idStr = item;
                else if (item && item.id) {
                    idStr = String(item.id);
                    if (item.followAttemptDate) {
                        try {
                            dateStr = new Date(parseInt(item.followAttemptDate)).toLocaleDateString();
                        } catch(e) {}
                    }
                }
                else if (item && item.pk) idStr = String(item.pk);
                
                if (idStr) interactedMap.set(idStr, { dateStr: dateStr, timestamp: parseInt(item.followAttemptDate) || 0 });
            });
        }

        logBeta("Histórico de interações carregado: " + interactedMap.size + " contas.");
        $('#newFollowersCount').text(interactedMap.size + ' interações salvas (Memória)');

        // 2. Fetch Recent Followers
        var limit = parseInt($('#txtFollowersLimit').val()) || 50;
        if (limit > 200) limit = 200; // Hard limit 200 as requested
        
        var timeLimitHours = parseInt($('#selTimeFilter').val()) || 24;
        var timeLimitMs = timeLimitHours * 60 * 60 * 1000;
        
        var sortOrder = $('input[name="dmSortOrder"]:checked').val();
        var now = Date.now();

        // Use targetUserId passed from checkNewFollowers
        fetchRecentFollowers(targetUserId, limit, offset, function(followers) {
            // Apply sorting before filtering if needed, or after. 
            // Usually followers come most recent first from IG API.
            // Only apply sorting if not in Interacted mode (where we hide the sort controls)
            if (source !== 'interacted' && sortOrder === 'oldest') {
                followers.reverse();
            }

            var filtered = [];
            
            if (source === 'interacted') {
                logBeta("Verificando " + followers.length + " seguidores recentes contra " + interactedMap.size + " contas interagidas...");
                
                // Filter: Must be in followers AND in interactedMap
                followers.forEach(function(f) {
                    var id = String(f.id);
                    if (interactedMap.has(id)) {
                        var info = interactedMap.get(id);
                        
                        // Check time filter
                        if (now - info.timestamp > timeLimitMs) return;
                        
                        f.interactionDate = info.dateStr; // Attach date
                        filtered.push(f);
                    }
                });
                
                if (filtered.length === 0 && followers.length > 0 && interactedMap.size > 0) {
                    logBeta("Nenhum seguidor recente corresponde à lista de interagidos (" + timeLimitHours + "h).");
                    logBeta("Dica: Aumente o 'Limite' para buscar mais seguidores antigos.");
                }
            } else if (source === 'myFollowers' || source === 'targetProfile') {
                logBeta("Carregando " + followers.length + " seguidores...");
                filtered = followers;
                // Still attach interaction date if available
                filtered.forEach(function(f) {
                    var id = String(f.id);
                    if (interactedMap.has(id)) {
                        f.interactionDate = interactedMap.get(id).dateStr;
                    }
                });
                
                // For targetProfile, maybe we want to filter out those already interacted?
                // The user didn't specify, but "Carregar Lista de Alvos" implies targets for DM.
                // Usually we want new people. But "Meus Seguidores" logic just loads them.
                // I'll keep it same as "Meus Seguidores" - load all found.

            } else {
                // All recent followers (Recentes Geral)
                logBeta("Carregando " + followers.length + " seguidores recentes...");
                filtered = followers;
                // Still attach interaction date if available
                filtered.forEach(function(f) {
                    var id = String(f.id);
                    if (interactedMap.has(id)) {
                        f.interactionDate = interactedMap.get(id).dateStr;
                    }
                });
            }

            // Load DM history before rendering
            loadDMHistory(function(history) {
                 renderTableWithHistory(filtered, history);
                 $('#btnCheckNewFollowers').text(betaGetCheckFollowersButtonLabel(source)).removeClass('inactive');
                 
                 // Check for duplicates immediately
                 var duplicates = filtered.filter(u => history[u.id]);
                 
                 if (duplicates.length > 0) {
                     // Show confirmation modal
                     $('#duplicateConfirmText').text(
                        `Encontramos ${duplicates.length} usuários que JÁ RECEBERAM mensagens anteriormente.\n` +
                        `Deseja removê-los da lista AGORA para evitar carregar IDs desnecessários?`
                     );
                     
                     // Update button texts for this context
                     $('#btnSkipDuplicates').text('Remover Repetidos (Recomendado)');
                     $('#btnSendAllDuplicates').text('Manter Todos');
                     $('#btnCancelDuplicates').text('Cancelar Carregamento');
                     
                     $('#duplicateConfirmModal').show();
                     
                     // Setup handlers
                     $('#btnSkipDuplicates').off('click').on('click', function() {
                         $('#duplicateConfirmModal').hide();
                         
                         // Filter out duplicates
                         var newFiltered = filtered.filter(u => !history[u.id]);
                         
                         // Re-render table with reduced list
                         renderTableWithHistory(newFiltered, history);
                         logBeta("Removidos " + duplicates.length + " usuários repetidos.");
                         
                         // Proceed: No longer auto-fetching IDs here.
                         // They will be fetched on-demand in processNextDM.
                     });
                     
                     $('#btnSendAllDuplicates').off('click').on('click', function() {
                         $('#duplicateConfirmModal').hide();
                         // Proceed with full list: No longer auto-fetching IDs here.
                     });
                     
                     $('#btnCancelDuplicates').off('click').on('click', function() {
                         $('#duplicateConfirmModal').hide();
                         logBeta("Carregamento cancelado pelo usuário.");
                     });
                     
                 } else {
                     // No duplicates, proceed directly: No longer auto-fetching IDs here.
                 }
            });
        });
    });
}

function getLoggedUserId() {
    var userId = null;
    try {
        var match = document.cookie.match(/(?:^|;\s*)ds_user_id=([\d]+)(?:;|$)/);
        if (match) userId = match[1];
        if (!userId) {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var c = cookies[i].trim();
                if (c.indexOf('ds_user_id=') === 0) {
                    userId = c.substring('ds_user_id='.length);
                    break;
                }
            }
        }
        if (!userId) {
            userId = localStorage.getItem('ds_user_id') || localStorage.getItem('IG_USER_ID');
        }
    } catch(e) {}
    return userId;
}

function betaGetSelectedSendMethod() {
    try {
        var el = document.querySelector('input[name="dmSendMethod"]:checked');
        var v = el && el.value ? String(el.value) : '';
        if (v === 'legacy_tab') return v;
    } catch (e) {}
    return 'legacy_tab';
}

function betaDockApply(active) {
    try {
        var id = 'rdgDmDockStyle';
        var existing = document.getElementById(id);
        if (existing) existing.remove();
        document.body && document.body.classList && document.body.classList.remove('rdgDmDockActive');
    } catch (e) {}
}

function betaDockLoad(callback) {
    chrome.storage.local.get(['rdg_dm_dock_state'], function(res) {
        callback(res && res.rdg_dm_dock_state ? res.rdg_dm_dock_state : null);
    });
}

function betaDockSave(state, callback) {
    chrome.storage.local.set({ rdg_dm_dock_state: state }, function() {
        if (callback) callback();
    });
}

function betaDockClear(callback) {
    chrome.storage.local.remove(['rdg_dm_dock_state'], function() {
        if (callback) callback();
    });
}

function betaDockMarkProcessed(state, task, status) {
    try {
        if (!state || !state.queue || !task) return;
        for (var i = 0; i < state.queue.length; i++) {
            var u = state.queue[i];
            if (!u) continue;
            if (String(u.id) === String(task.id) || String(u.interop_messaging_user_fbid) === String(task.targetId) || String(u.username) === String(task.username)) {
                u.processed = true;
                u._dockStatus = status;
                u._dockAt = Date.now();
                break;
            }
        }
    } catch (e) {}
}

function betaDockGetNextUser(state) {
    if (!state || !state.queue) return null;
    for (var i = 0; i < state.queue.length; i++) {
        if (!state.queue[i].processed) return state.queue[i];
    }
    return null;
}

function betaDockProcessNext() {
    betaDockLoad(function(state) {
        if (!state || !state.running) return;
        var nextUser = betaDockGetNextUser(state);
        if (!nextUser) {
            state.running = false;
            betaDockSave(state, function() {});
            isMassDMRunning = false;
            $('#btnStartMassDM').show();
            $('#btnStopMassDM').hide();
            $('#massDMStatus').text("Envio concluído!");
            return;
        }

        if (!nextUser.interop_messaging_user_fbid) {
            updateStatus(nextUser.id, "Buscando ID... 🔍");
            $('#massDMStatus').text("Buscando ID para " + nextUser.username + "...");
            fetchInteropId(nextUser.id, function(interopId) {
                if (!interopId) {
                    updateStatus(nextUser.id, "Falha ao buscar ID ❌");
                    nextUser.processed = true;
                    betaDockSave(state, function() {
                        setTimeout(betaDockProcessNext, 1200);
                    });
                    return;
                }
                nextUser.interop_messaging_user_fbid = interopId;
                updateInteropCell(nextUser.id, interopId);
                betaDockSave(state, function() {
                    setTimeout(betaDockProcessNext, 600);
                });
            });
            return;
        }

        var finalMsg = betaBuildFinalDmMessage(nextUser);
        var task = {
            id: nextUser.id,
            targetId: nextUser.interop_messaging_user_fbid,
            username: nextUser.username,
            message: finalMsg,
            mode: 'same_tab_dock',
            status: 'pending',
            timestamp: Date.now()
        };

        chrome.storage.local.set({ pending_dm_task: task }, function() {
            updateStatus(nextUser.id, "Abrindo chat... 📲");
            $('#massDMStatus').text("Abrindo chat de " + nextUser.username + "...");
            var url = 'https://www.instagram.com/direct/t/' + task.targetId + '/';
            betaDockSetResumePayload(task);
            betaDockRegisterLifecycle('start');
            window.location.href = url;
        });
    });
}

function betaDockFinishTask(task, status) {
    betaDockLoad(function(state) {
        if (!state || !state.running) {
            return;
        }
        betaDockMarkProcessed(state, task, status);
        betaDockSave(state, function() {
            var delayMs = betaGetRandomMassDmDelayMs();
            $('#massDMStatus').text(betaFormatRandomDelayStatus(delayMs));
            setTimeout(function() {
                betaDockProcessNext();
            }, delayMs);
        });
    });
}

function betaOpenFixedDirectWindow(url) {
    var width = 420;
    var height = 820;
    var left = null;
    var top = null;
    try {
        if (window && window.screenX != null && window.outerWidth != null) {
            left = Math.max(0, Math.floor(window.screenX + window.outerWidth - width - 20));
            top = Math.max(0, Math.floor(window.screenY + 80));
        }
    } catch (e) {}

    var features = [
        'popup=yes',
        'toolbar=no',
        'location=no',
        'menubar=no',
        'status=no',
        'resizable=yes',
        'scrollbars=yes',
        'width=' + width,
        'height=' + height
    ];
    if (typeof left === 'number') features.push('left=' + left);
    if (typeof top === 'number') features.push('top=' + top);

    var w = null;
    try {
        w = window.open(url, 'rdgDirectMobile', features.join(','));
    } catch (e2) {
        w = null;
    }
    return w;
}

function betaEnsureDirectPopup(url, callback) {
    try {
        chrome.runtime.sendMessage({
            rdgEnsureDirectPopup: {
                url: url,
                width: 420,
                height: 820
            }
        }, function(resp) {
            if (chrome.runtime.lastError) {
                callback({ ok: false, error: chrome.runtime.lastError.message || 'runtime_last_error' });
                return;
            }
            callback(resp || { ok: false, error: 'no_response' });
        });
    } catch (e) {
        callback({ ok: false, error: 'send_message_failed' });
    }
}

function betaNavigateDirectPopup(windowId, tabId, url, callback) {
    try {
        chrome.runtime.sendMessage({
            rdgNavigateDirectPopup: {
                windowId: windowId,
                tabId: tabId,
                url: url
            }
        }, function(resp) {
            if (chrome.runtime.lastError) {
                callback({ ok: false, error: chrome.runtime.lastError.message || 'runtime_last_error' });
                return;
            }
            callback(resp || { ok: false, error: 'no_response' });
        });
    } catch (e) {
        callback({ ok: false, error: 'send_message_failed' });
    }
}

function betaClosePopupWindow(windowId) {
    try {
        chrome.runtime.sendMessage({ rdgCloseWindow: { windowId: windowId } }, function() {});
    } catch (e) {}
}

function betaIsPopupWindowOpen(windowId, callback) {
    try {
        chrome.runtime.sendMessage({ rdgIsWindowOpen: { windowId: windowId } }, function(resp) {
            if (chrome.runtime.lastError) {
                callback(false);
                return;
            }
            callback(resp && resp.ok ? !!resp.isOpen : false);
        });
    } catch (e) {
        callback(false);
    }
}

// #region debug-point A:direct-endpoint-report
function betaDebugReport(hypothesisId, location, msg, data) {
    return;
}
// #endregion

function betaExtractTokenFromDom(tokenName) {
    try {
        var el = document.querySelector('input[name="' + tokenName + '"]');
        if (el && el.value) return String(el.value);
    } catch (e) {}
    try {
        var html = document.documentElement ? document.documentElement.innerHTML : '';
        if (!html) return '';

        if (tokenName === 'lsd') {
            var l1 = html.match(/"LSD"\s*,\s*\[\]\s*,\s*\{\s*"token"\s*:\s*"([^"]+)"/);
            if (l1 && l1[1]) return l1[1];
            var l2 = html.match(/"lsd"\s*:\s*"([^"]+)"/);
            if (l2 && l2[1]) return l2[1];
        }

        if (tokenName === 'fb_dtsg') {
            var d1 = html.match(/"DTSGInitialData"\s*,\s*\[\]\s*,\s*\{\s*"token"\s*:\s*"([^"]+)"/);
            if (d1 && d1[1]) return d1[1];
            var d2 = html.match(/"fb_dtsg"\s*:\s*\{\s*"token"\s*:\s*"([^"]+)"/);
            if (d2 && d2[1]) return d2[1];
            var d3 = html.match(/"fb_dtsg"\s*:\s*"([^"]+)"/);
            if (d3 && d3[1]) return d3[1];
        }
    } catch (e2) {}
    return '';
}

function betaComputeJazoest(fbDtsg) {
    if (!fbDtsg) return '';
    var sum = 0;
    for (var i = 0; i < fbDtsg.length; i++) {
        sum += fbDtsg.charCodeAt(i);
    }
    return '2' + String(sum);
}

function betaGetDirectTokens() {
    var actorId = String(getLoggedUserId() || '');
    var fbDtsg = betaExtractTokenFromDom('fb_dtsg');
    var lsd = betaExtractTokenFromDom('lsd');
    if (!actorId || !fbDtsg || !lsd) return null;
    return {
        actorId: actorId,
        fbDtsg: fbDtsg,
        lsd: lsd,
        jazoest: betaComputeJazoest(fbDtsg)
    };
}

function betaNextReqId() {
    betaDmRequestCounter += 1;
    return betaDmRequestCounter.toString(36);
}

function betaBuildRelayPayload(tokens, friendlyName, docId, variables) {
    return {
        av: String(tokens.actorId),
        __d: 'www',
        __user: '0',
        __a: '1',
        __req: betaNextReqId(),
        dpr: '1',
        __ccg: 'EXCELLENT',
        __comet_req: '7',
        fb_dtsg: tokens.fbDtsg,
        jazoest: tokens.jazoest,
        lsd: tokens.lsd,
        fb_api_caller_class: 'RelayModern',
        fb_api_req_friendly_name: friendlyName,
        server_timestamps: 'true',
        variables: JSON.stringify(variables),
        doc_id: docId
    };
}

function betaAjaxInstagramText(options, callback) {
    $.ajax({
        url: options.url,
        method: options.method || 'POST',
        timeout: options.timeout || 15000,
        dataType: 'text',
        data: options.data,
        beforeSend: function(xhr) {
            xhr.setRequestHeader('X-Csrftoken', getCsrfToken() || '');
            xhr.setRequestHeader('x-asbd-id', '359341');
            xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            if (options.friendlyName) xhr.setRequestHeader('x-fb-friendly-name', options.friendlyName);
            if (options.lsd) xhr.setRequestHeader('x-fb-lsd', options.lsd);
            if (options.beforeSend) options.beforeSend(xhr);
        },
        xhrFields: { withCredentials: true },
        success: function(resp, _textStatus, xhr) {
            callback(null, resp, xhr);
        },
        error: function(xhr, textStatus) {
            callback({ xhr: xhr, status: xhr && xhr.status ? xhr.status : 0, textStatus: textStatus || 'error' });
        }
    });
}

function betaParseInstagramPayload(raw) {
    if (!raw) return null;
    if (typeof raw === 'object') return raw;
    if (typeof raw !== 'string') return null;

    var trimmed = raw.trim();
    if (!trimmed) return null;

    // Some Instagram responses may arrive base64-encoded in certain contexts.
    // Detect and decode cautiously.
    if (trimmed.length > 80 && /^[A-Za-z0-9+\/=_-]+$/.test(trimmed) && trimmed.indexOf('{') !== 0 && trimmed.indexOf('[') !== 0) {
        try {
            var b64 = trimmed.replace(/-/g, '+').replace(/_/g, '/');
            while (b64.length % 4 !== 0) b64 += '=';
            var decoded = atob(b64);
            if (decoded && (decoded.trim().indexOf('{') === 0 || decoded.trim().indexOf('for (;;);') === 0)) {
                trimmed = decoded.trim();
            }
        } catch (e0) {}
    }

    if (trimmed.indexOf('for (;;);') === 0) {
        trimmed = trimmed.replace(/^for \(;;\);\s*/, '');
    }

    try {
        return JSON.parse(trimmed);
    } catch (e) {}

    var parts = trimmed.split(/\r?\n/);
    for (var i = 0; i < parts.length; i++) {
        var part = parts[i].trim();
        if (!part) continue;
        if (part.indexOf('for (;;);') === 0) {
            part = part.replace(/^for \(;;\);\s*/, '');
        }
        try {
            return JSON.parse(part);
        } catch (e2) {}
    }

    return null;
}

function betaDeepCollectNumericCandidates(input, bucket) {
    if (!bucket) bucket = [];
    if (input == null) return bucket;

    if (typeof input === 'string') {
        if (/^\d{10,25}$/.test(input)) bucket.push(input);
        return bucket;
    }

    if (typeof input === 'number') {
        var asString = String(input);
        if (/^\d{10,25}$/.test(asString)) bucket.push(asString);
        return bucket;
    }

    if (Array.isArray(input)) {
        for (var i = 0; i < input.length; i++) betaDeepCollectNumericCandidates(input[i], bucket);
        return bucket;
    }

    if (typeof input === 'object') {
        Object.keys(input).forEach(function(key) {
            var value = input[key];
            var lower = String(key).toLowerCase();
            if ((lower.indexOf('thread') > -1 || lower.indexOf('igid') > -1 || lower.indexOf('id') > -1) && (typeof value === 'string' || typeof value === 'number')) {
                var candidate = String(value);
                if (/^\d{10,25}$/.test(candidate)) bucket.push(candidate);
            }
            betaDeepCollectNumericCandidates(value, bucket);
        });
    }

    return bucket;
}

function betaDeepCollectNamedNumericValues(input, targetKeys, bucket) {
    if (!input || !bucket || !targetKeys || !targetKeys.length) return;

    if (Array.isArray(input)) {
        input.forEach(function(item) {
            betaDeepCollectNamedNumericValues(item, targetKeys, bucket);
        });
        return;
    }

    if (typeof input !== 'object') return;

    Object.keys(input).forEach(function(key) {
        var value = input[key];
        if (targetKeys.indexOf(String(key)) > -1 && (typeof value === 'string' || typeof value === 'number')) {
            var candidate = String(value);
            if (/^\d{10,25}$/.test(candidate)) bucket.push(candidate);
        }
        betaDeepCollectNamedNumericValues(value, targetKeys, bucket);
    });
}

function betaParseAllInstagramPayloads(raw) {
    if (!raw) return [];
    if (typeof raw === 'object') return [raw];
    if (typeof raw !== 'string') return [];
    var trimmed = raw.trim();
    if (!trimmed) return [];
    trimmed = trimmed.replace(/\r\n/g, '\n');
    var parts = trimmed.split(/for \(;;\);\s*/).filter(function(p) { return p && p.trim(); });
    var results = [];
    for (var i = 0; i < parts.length; i++) {
        var part = parts[i].trim();
        try {
            results.push(JSON.parse(part));
        } catch (e) {}
    }
    return results;
}

function betaExtractIgThreadIgidFromRouteDefinition(routeResp, threadKey) {
    var keyNoSlash = '/direct/t/' + String(threadKey);
    var keyWithSlash = keyNoSlash + '/';
    var parsedList = betaParseAllInstagramPayloads(routeResp);
    for (var i = 0; i < parsedList.length; i++) {
        var obj = parsedList[i];
        try {
            var payloads = obj && obj.payload && obj.payload.payloads;
            var node = payloads ? (payloads[keyNoSlash] || payloads[keyWithSlash]) : null;
            var v = node && node.result && node.result.exports && node.result.exports.rootView && node.result.exports.rootView.props && node.result.exports.rootView.props.thread_fbid;
            if (v && /^\d{10,25}$/.test(String(v))) return String(v);
        } catch (e) {}
        try {
            var node2 = obj && obj.payload && obj.payload.payload && obj.payload.payload.result;
            var v2 = node2 && node2.exports && node2.exports.rootView && node2.exports.rootView.props && node2.exports.rootView.props.thread_fbid;
            if (v2 && /^\d{10,25}$/.test(String(v2))) return String(v2);
        } catch (e2) {}
    }
    return '';
}

function betaResolveThreadFbidFromDirectHtml(threadKey, callback) {
    var url = 'https://www.instagram.com/direct/t/' + String(threadKey) + '/';
    betaAjaxInstagramText({
        url: url,
        method: 'GET',
        timeout: 15000,
        data: null,
        beforeSend: function(xhr) {
            xhr.setRequestHeader('x-requested-with', 'XMLHttpRequest');
        }
    }, function(err, respText) {
        if (err) {
            var snippet = err && err.xhr && typeof err.xhr.responseText === 'string' ? err.xhr.responseText.slice(0, 180) : '';
            logBeta("Debug direct html erro status=" + (err.status || 0) + " snippet=" + snippet);
            callback('', { ok: false, status: err.status || 0, reason: 'direct_html_failed' });
            return;
        }

        var text = String(respText || '');
        var key = String(threadKey || '');
        logBeta("Debug direct html ok len=" + text.length + " hasFor=" + (text.indexOf('for (;;);') > -1 ? 'sim' : 'nao'));

        var idx = text.indexOf('"thread_key":"' + key + '"');
        if (idx < 0) idx = text.indexOf('"thread_key":"\\u002Fdirect\\u002Ft\\u002F' + key);
        if (idx < 0) idx = text.indexOf(key);
        var start = Math.max(0, idx - 4000);
        var end = Math.min(text.length, idx + 4000);
        var windowText = text.slice(start, end);

        var candidates = [];
        var m;
        var r1 = /"thread_fbid"\s*:\s*"(\d{10,25})"/ig;
        while ((m = r1.exec(windowText))) candidates.push(m[1]);
        var r2 = /thread_fbid\\":\\"(\d{10,25})\\"/ig;
        while ((m = r2.exec(windowText))) candidates.push(m[1]);
        var r3 = /thread_fbid\\\":\\\"(\d{10,25})\\\"/ig;
        while ((m = r3.exec(windowText))) candidates.push(m[1]);

        var uniq = [];
        candidates.forEach(function(c) {
            c = String(c || '').replace(/[^\d]/g, '');
            if (!/^\d{10,25}$/.test(c)) return;
            if (uniq.indexOf(c) === -1) uniq.push(c);
        });

        var threadFbid = '';
        for (var i = 0; i < uniq.length; i++) {
            if (uniq[i] !== key) { threadFbid = uniq[i]; break; }
        }
        if (!threadFbid && uniq.length) threadFbid = uniq[0];

        if (threadFbid) {
            logBeta("Debug direct html thread @" + key + " -> threadFbid=" + threadFbid);
            callback(threadFbid, { ok: true, status: 200 });
            return;
        }

        logBeta("Debug direct html sem thread_fbid. key=" + key + " candidatos=" + uniq.slice(0, 6).join(', '));
        callback('', { ok: false, status: 200, reason: 'direct_html_missing_thread_fbid' });
    });
}

function betaExtractPreferredThreadIdFromPayload(payload, fallbackThreadFbid) {
    var rawText = '';
    var parsed = betaParseInstagramPayload(payload);
    var explicitThreadFbids = [];
    var explicitMutationIds = [];
    var rawThreadFbids = [];
    var rawMutationIds = [];
    var fallback = String(fallbackThreadFbid || '');

    try {
        rawText = typeof payload === 'string' ? payload : JSON.stringify(payload);
    } catch (e) {}

    if (parsed) {
        betaDeepCollectNamedNumericValues(parsed, ['thread_fbid'], explicitThreadFbids);
        betaDeepCollectNamedNumericValues(parsed, ['ig_thread_igid', 'thread_v2_id'], explicitMutationIds);
    }

    var match;
    var threadFbidRegex = /"thread_fbid"\s*:\s*"?(\\d{10,25}|\d{10,25})"?/ig;
    while ((match = threadFbidRegex.exec(rawText))) {
        rawThreadFbids.push(String(match[1] || '').replace(/[^\d]/g, ''));
    }

    var mutationIdRegex = /"(ig_thread_igid|thread_v2_id)"\s*:\s*"?(\\d{10,25}|\d{10,25})"?/ig;
    while ((match = mutationIdRegex.exec(rawText))) {
        rawMutationIds.push(String(match[2] || '').replace(/[^\d]/g, ''));
    }

    var ordered = [];
    [fallback].concat(explicitThreadFbids, rawThreadFbids, explicitMutationIds, rawMutationIds).forEach(function(candidate) {
        candidate = String(candidate || '').replace(/[^\d]/g, '');
        if (!/^\d{10,25}$/.test(candidate)) return;
        if (ordered.indexOf(candidate) === -1) ordered.push(candidate);
    });

    // #region debug-point A:thread-candidates
    betaDebugReport('A', 'beta_logic.js:1143', 'thread candidates extracted', {
        threadFbid: fallback,
        preferred: ordered.length ? ordered[0] : '',
        candidates: ordered.slice(0, 12)
    });
    // #endregion
    logBeta("Debug thread_fbid=" + fallback + " candidatos=" + ordered.slice(0, 6).join(', '));

    return ordered.length ? ordered[0] : null;
}

function betaGenerateOfflineThreadingId() {
    return String(Date.now()) + String(Math.floor(Math.random() * 1000000)).padStart(6, '0');
}

function betaFormatDirectEndpointFailure(meta) {
    var status = meta && typeof meta.status === 'number' ? meta.status : 0;
    if (status === 429) return 'Limitado pelo Instagram (429) ❌';
    if (status === 403) return 'Sem permissão no Direct (403) ❌';
    if (status === 404) return 'Thread não encontrada (404) ❌';
    if (status >= 500) return 'Erro do Instagram no Direct (' + status + ') ❌';
    if (meta && meta.reason === 'missing_tokens') return 'Tokens do Direct indisponíveis ❌';
    if (meta && meta.reason === 'missing_thread') return 'Thread IG não encontrada ❌';
    if (meta && meta.reason === 'direct_html_failed') return 'Falha ao carregar conversa (Direct) ❌';
    if (meta && meta.reason === 'direct_html_missing_thread_fbid') return 'Conversa sem thread_fbid (Direct) ❌';
    if (meta && meta.reason === 'chat_tab_query_failed') return 'Falha ao consultar Direct (GraphQL) ❌';
    if (meta && meta.reason === 'chat_tab_missing_thread_fbid') return 'Thread IG não encontrada (GraphQL) ❌';
    if (meta && meta.reason === 'parse_error') return 'Resposta inválida do Direct ❌';
    if (meta && meta.reason === 'graphql_errors') return 'GraphQL retornou erro ❌';
    return 'Falha no envio por endpoint ❌';
}

function betaResolveDirectThread(threadFbid, tokens, callback) {
    var threadKey = String(threadFbid || '');
    var chatTabVariables = {
        min_uq_seq_id: "0",
        thread_fbid: String(threadKey),
        __relay_internal__pv__IGDEnableOffMsysChatThemesQErelayprovider: false,
        __relay_internal__pv__IGDInitialMessagePageCountrelayprovider: 20,
        __relay_internal__pv__PolarisAIGMAccountLabelEnabledrelayprovider: false,
        __relay_internal__pv__IGDMaxUnreadMessagesCountrelayprovider: 5,
        __relay_internal__pv__IGDMarkReadSelfAuthoredLatestEnabledGKrelayprovider: true
    };
    var payload = betaBuildRelayPayload(tokens, 'IGDChatTabRootOffMsysQuery', '28063881199881531', chatTabVariables);
    payload.__crn = 'comet.igweb.PolarisFeedRoute';

    betaAjaxInstagramText({
        url: 'https://www.instagram.com/api/graphql',
        method: 'POST',
        data: payload,
        friendlyName: 'IGDChatTabRootOffMsysQuery',
        lsd: tokens.lsd,
        timeout: 15000
    }, function(err, respText) {
        if (err) {
            callback({ ok: false, status: err.status || 0, reason: 'chat_tab_query_failed' });
            return;
        }

        var raw = typeof respText === 'string' ? respText : JSON.stringify(respText || {});
        logBeta("Debug chat tab resp prefix=" + raw.slice(0, 18) + " len=" + raw.length + " has_thread_fbid_txt=" + (raw.indexOf('thread_fbid') > -1 ? 'sim' : 'nao') + " has_errors_txt=" + (raw.indexOf('errors') > -1 ? 'sim' : 'nao'));

        var parsed = betaParseInstagramPayload(respText);
        if (!parsed) {
            logBeta("Debug chat tab parse falhou. prefix=" + raw.slice(0, 80));
            callback({ ok: false, status: 200, reason: 'parse_error' });
            return;
        }
        if (parsed && parsed.errors && parsed.errors.length) {
            logBeta("Debug chat tab graphql errors=" + JSON.stringify(parsed.errors).slice(0, 260));
        }

        var candidates = [];
        betaDeepCollectNamedNumericValues(parsed, ['thread_fbid'], candidates);
        var m;
        var r = /"thread_fbid"\s*:\s*"(\d{10,25})"/ig;
        while ((m = r.exec(raw))) candidates.push(m[1]);

        var uniq = [];
        candidates.forEach(function(c) {
            c = String(c || '').replace(/[^\d]/g, '');
            if (!/^\d{10,25}$/.test(c)) return;
            if (uniq.indexOf(c) === -1) uniq.push(c);
        });

        var resolved = '';
        for (var i = 0; i < uniq.length; i++) {
            var c = uniq[i];
            if (c === threadKey) continue;
            if (c.length >= 15) { resolved = c; break; }
        }
        if (!resolved) {
            for (var j = 0; j < uniq.length; j++) {
                if (uniq[j] !== threadKey) { resolved = uniq[j]; break; }
            }
        }

        logBeta("Debug chat tab thread @" + threadKey + " -> threadFbid=" + (resolved || 'vazio') + " candidatos=" + uniq.slice(0, 6).join(', '));

        if (!resolved) {
            callback({ ok: false, status: 200, reason: 'chat_tab_missing_thread_fbid' });
            return;
        }

        callback({ ok: true, threadIgid: String(resolved), threadFbid: String(resolved) });
    });
}

function betaSendDirectText(threadIgid, message, tokens, callback) {
    var variables = {
        ig_thread_igid: String(threadIgid),
        offline_threading_id: betaGenerateOfflineThreadingId(),
        recipient_igids: null,
        replied_to_client_context: null,
        replied_to_item_id: null,
        reply_to_message_id: null,
        sampled: null,
        text: { sensitive_string_value: String(message) },
        mentions: [],
        mentioned_user_ids: [],
        commands: null,
        forwarded_from_thread_id: null,
        is_forwarded_from_own_message: null,
        send_attribution: 'igd_web_chat_tab:in_thread'
    };
    var relayPayload = betaBuildRelayPayload(tokens, 'IGDirectTextSendMutation', '26911679871773184', variables);
    relayPayload.__crn = 'comet.igweb.PolarisDirectInboxRoute';
    relayPayload.qpl_active_flow_ids = '25313175,354954279';
    relayPayload.fb_api_analytics_tags = JSON.stringify(['qpl_active_flow_ids=25313175,354954279']);

    // #region debug-point B:send-mutation-payload
    betaDebugReport('B', 'beta_logic.js:1241', 'sending direct text mutation', {
        actorId: String(tokens && tokens.actorId || ''),
        threadIgid: String(threadIgid),
        messageLength: String(message || '').length,
        sendAttribution: variables.send_attribution,
        offlineThreadingId: String(variables.offline_threading_id),
        hasQplFlowIds: relayPayload.qpl_active_flow_ids,
        hasAnalyticsTags: relayPayload.fb_api_analytics_tags
    });
    // #endregion
    logBeta("Debug send mutation threadIgid=" + String(threadIgid) + " msgLen=" + String(message || '').length);

    betaAjaxInstagramText({
        url: 'https://www.instagram.com/api/graphql',
        method: 'POST',
        data: relayPayload,
        friendlyName: 'IGDirectTextSendMutation',
        lsd: tokens.lsd,
        timeout: 15000
    }, function(err, respText) {
        if (err) {
            // #region debug-point C:send-mutation-http-error
            betaDebugReport('C', 'beta_logic.js:1258', 'direct text mutation http error', {
                threadIgid: String(threadIgid),
                status: err.status || 0,
                textStatus: err.textStatus || '',
                responseSnippet: err && err.xhr && typeof err.xhr.responseText === 'string' ? err.xhr.responseText.slice(0, 900) : ''
            });
            // #endregion
            logBeta("Debug mutation http error status=" + (err.status || 0) + " snippet=" + (err && err.xhr && typeof err.xhr.responseText === 'string' ? err.xhr.responseText.slice(0, 220) : ''));
            callback({ ok: false, status: err.status, reason: 'mutation_failed' });
            return;
        }

        var parsed = betaParseInstagramPayload(respText);
        if (parsed && parsed.errors && parsed.errors.length) {
            // #region debug-point C:send-mutation-graphql-error
            betaDebugReport('C', 'beta_logic.js:1269', 'direct text mutation graphql error', {
                threadIgid: String(threadIgid),
                errors: parsed.errors,
                responseSnippet: String(respText || '').slice(0, 1200)
            });
            // #endregion
            logBeta("Debug graphql error threadIgid=" + String(threadIgid) + " errors=" + JSON.stringify(parsed.errors).slice(0, 320));
            callback({ ok: false, status: 200, reason: 'graphql_errors', payload: parsed });
            return;
        }

        var rawText = typeof respText === 'string' ? respText : JSON.stringify(respText || {});
        // #region debug-point B:send-mutation-success-shape
        betaDebugReport('B', 'beta_logic.js:1280', 'direct text mutation response shape', {
            threadIgid: String(threadIgid),
            hasMessageId: rawText.indexOf('"message_id"') > -1,
            hasTimestampMs: rawText.indexOf('"timestamp_ms"') > -1,
            responseSnippet: rawText.slice(0, 1200)
        });
        // #endregion
        logBeta("Debug mutation response threadIgid=" + String(threadIgid) + " hasMessageId=" + (rawText.indexOf('"message_id"') > -1 ? 'sim' : 'nao'));
        if (rawText.indexOf('"message_id"') > -1 || rawText.indexOf('"timestamp_ms"') > -1) {
            callback({ ok: true });
            return;
        }

        if (parsed && parsed.data) {
            callback({ ok: true });
            return;
        }

        callback({ ok: false, status: 200, reason: 'parse_error' });
    });
}

function finishEndpointTask(nextUser, nextIndex, finalMsg) {
    updateStatus(nextUser.id, "Enviado Endpoint ✅");
    massDMQueue[nextIndex].processed = true;
    saveDMHistory({ id: nextUser.id, username: nextUser.username }, finalMsg);
    scheduleNextDM();
}

function failEndpointTask(nextUser, nextIndex, meta) {
    var failureText = betaFormatDirectEndpointFailure(meta);
    updateStatus(nextUser.id, failureText);
    massDMQueue[nextIndex].processed = true;

    if (meta && meta.status === 429) {
        stopMassDM();
        $('#massDMStatus').text("Pausado por limitação do Instagram.");
        betaShowInstagramLimitedPopup();
        return;
    }

    scheduleNextDM();
}

function sendEndpointDM(nextUser, nextIndex) {
    if (!isMassDMRunning) return;

    var finalMsg = betaBuildFinalDmMessage(nextUser);
    var threadFbid = String(nextUser.interop_messaging_user_fbid || '');
    var tokens = betaGetDirectTokens();

    if (!threadFbid) {
        failEndpointTask(nextUser, nextIndex, { status: 0, reason: 'missing_thread' });
        return;
    }

    if (!tokens) {
        failEndpointTask(nextUser, nextIndex, { status: 0, reason: 'missing_tokens' });
        return;
    }

    updateStatus(nextUser.id, "Resolvendo thread...");
    $('#massDMStatus').text("Resolvendo thread de " + nextUser.username + "...");
    logBeta("Direct endpoint: resolvendo thread para @" + nextUser.username);

    betaResolveDirectThread(threadFbid, tokens, function(resolveResult) {
        if (!resolveResult || !resolveResult.ok) {
            logBeta("Direct endpoint falhou ao resolver thread de @" + nextUser.username + " (" + (resolveResult && resolveResult.reason ? resolveResult.reason : 'sem_motivo') + ")");
            failEndpointTask(nextUser, nextIndex, resolveResult || { status: 0, reason: 'missing_thread' });
            return;
        }

        updateStatus(nextUser.id, "Enviando endpoint...");
        $('#massDMStatus').text("Enviando para " + nextUser.username + " via endpoint...");
        logBeta("Direct endpoint: thread IG " + resolveResult.threadIgid + " resolvida para @" + nextUser.username);

        betaSendDirectText(resolveResult.threadIgid, finalMsg, tokens, function(sendResult) {
            if (!sendResult || !sendResult.ok) {
                logBeta("Direct endpoint falhou no envio para @" + nextUser.username);
                failEndpointTask(nextUser, nextIndex, sendResult || { status: 0, reason: 'mutation_failed' });
                return;
            }

            logBeta("Direct endpoint enviado com sucesso para @" + nextUser.username);
            finishEndpointTask(nextUser, nextIndex, finalMsg);
        });
    });
}

function fetchUserInfo(userId, callback) {
    var csrftoken = getCsrfToken();
    if (!csrftoken) { callback(null); return; }

    var completed = false;
    var safetyTimeout = setTimeout(function() {
        if (completed) return;
        completed = true;
        callback(null);
    }, 8000);

    $.ajax({
        url: 'https://www.instagram.com/api/v1/users/' + userId + '/info/',
        method: 'GET',
        timeout: 7000,
        beforeSend: function(xhr) {
            xhr.setRequestHeader('x-csrftoken', csrftoken);
            xhr.setRequestHeader('x-instagram-ajax', '1010212815');
            xhr.setRequestHeader('x-asbd-id', '129477');
            xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            xhr.setRequestHeader('x-requested-with', 'XMLHttpRequest');
        },
        xhrFields: {
            withCredentials: true
        },
        success: function(resp) {
            if (completed) return;
            completed = true;
            clearTimeout(safetyTimeout);
            if (resp && resp.user) callback(resp.user);
            else callback(null);
        },
        error: function() {
            if (completed) return;
            completed = true;
            clearTimeout(safetyTimeout);
            callback(null);
        }
    });
}

function fetchInteropIdsForQueue(users) {
        logBeta("Iniciando busca de Interop IDs para " + users.length + " usuários...");
        
        // Disable Start Button
        $('#btnStartMassDM').prop('disabled', true).addClass('inactive').text('Aguarde IDs...');

        var index = 0;
        var total = users.length;
        
        function next() {
            if (index >= users.length) {
                logBeta("Busca de Interop IDs concluída.");
                // Enable Start Button
                $('#btnStartMassDM').prop('disabled', false).removeClass('inactive').text('Iniciar Envio em Massa');
                return;
            }
            
            var user = users[index];
            // Skip if already has it (though unlikely from initial fetch)
            if (user.interop_messaging_user_fbid) {
                updateInteropCell(user.id, user.interop_messaging_user_fbid);
                index++;
                setTimeout(next, 100);
                return;
            }

            updateInteropCell(user.id, "...");
            
            fetchInteropId(user.id, function(interopId) {
                if (interopId) {
                    user.interop_messaging_user_fbid = interopId;
                    // Also update in massDMQueue if it matches
                    var qItem = massDMQueue.find(u => u.id == user.id);
                    if (qItem) qItem.interop_messaging_user_fbid = interopId;
                    
                    updateInteropCell(user.id, interopId);
                } else {
                    updateInteropCell(user.id, "N/A");
                }
                
                index++;
                
                // Update button text progress
                $('#btnStartMassDM').text(`Aguarde IDs (${index}/${total})...`);

                // Random delay 1.5-3s to be safe
                setTimeout(next, 1500 + Math.random() * 1500);
            });
        }
        
        next();
    }

function updateInteropCell(userId, text) {
    var cell = $(`.interop-cell[data-id="${userId}"]`);
    if (cell.length) {
        cell.text(text);
        // Also update the full ID display if we merged them
        var parent = cell.parent();
        // Optional: Make it clearer if we want
    }
}

function fetchInteropId(userId, callback) {
    var csrftoken = getCsrfToken();
    if (!csrftoken) { callback(null); return; }

    var completed = false;
    var safetyTimeout = setTimeout(function() {
        if (completed) return;
        completed = true;
        callback(null, { ok: false, status: 0, reason: 'timeout' });
    }, 9000);

    $.ajax({
        url: 'https://www.instagram.com/api/v1/users/' + userId + '/info/',
        method: 'GET',
        timeout: 8000,
        beforeSend: function(xhr) {
            xhr.setRequestHeader('x-csrftoken', csrftoken);
            xhr.setRequestHeader('x-instagram-ajax', '1010212815');
            xhr.setRequestHeader('x-asbd-id', '129477');
            xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            xhr.setRequestHeader('x-requested-with', 'XMLHttpRequest');
        },
        xhrFields: {
            withCredentials: true
        },
        success: function(resp) {
            if (completed) return;
            completed = true;
            clearTimeout(safetyTimeout);
            if (resp && resp.user && resp.user.interop_messaging_user_fbid) callback(resp.user.interop_messaging_user_fbid, { ok: true, status: 200 });
            else callback(null, { ok: false, status: 200, reason: 'missing_interop' });
        },
        error: function(xhr) {
            if (completed) return;
            completed = true;
            clearTimeout(safetyTimeout);
            var status = xhr && xhr.status ? xhr.status : 0;
            if (status === 429) logBeta("Rate limit (429) ao buscar info do usuário " + userId);
            callback(null, { ok: false, status: status, reason: 'http_error' });
        }
    });
}

function betaFormatInteropLookupFailure(meta) {
    var status = meta && typeof meta.status === 'number' ? meta.status : 0;
    if (status === 429) return "Limitado pelo Instagram (429). Pause e tente mais tarde ❌";
    if (status === 403) return "Sem permissão (403) ❌";
    if (status === 404) return "Conta indisponível (404) ❌";
    if (status >= 500) return "Erro do Instagram (" + status + ") ❌";
    if (meta && meta.reason === 'timeout') return "Timeout ao buscar Interop ID ❌";
    if (meta && meta.reason === 'missing_interop') return "Interop ID não retornou (não é limitação) ⚠️";
    return "Falha ao buscar Interop ID ⚠️";
}

function betaShowInstagramLimitedPopup() {
    try {
        if (window._rdgBetaLimitedPopupShown) return;
        window._rdgBetaLimitedPopupShown = true;

        var existing = document.getElementById('rdg-beta-limited-popup');
        if (existing) return;

        var overlay = document.createElement('div');
        overlay.id = 'rdg-beta-limited-popup';
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.background = 'rgba(0,0,0,0.75)';
        overlay.style.zIndex = '2147483647';
        overlay.style.display = 'flex';
        overlay.style.alignItems = 'center';
        overlay.style.justifyContent = 'center';
        overlay.style.padding = '20px';

        var card = document.createElement('div');
        card.style.background = '#ffffff';
        card.style.borderRadius = '16px';
        card.style.maxWidth = '520px';
        card.style.width = '100%';
        card.style.boxShadow = '0 25px 60px rgba(0,0,0,0.5)';
        card.style.border = '8px solid #FFD700';
        card.style.fontFamily = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';
        card.style.overflow = 'hidden';

        var body = document.createElement('div');
        body.style.padding = '22px 22px 18px 22px';

        var title = document.createElement('div');
        title.style.fontSize = '18px';
        title.style.fontWeight = '800';
        title.style.color = '#111827';
        title.style.marginBottom = '10px';
        title.innerText = 'Atenção';

        var msg = document.createElement('div');
        msg.style.fontSize = '14px';
        msg.style.lineHeight = '1.6';
        msg.style.color = '#374151';
        msg.innerText = 'Esta conta do Instagram está um pouco sobrecarregada. Será necessário aguardar algumas horas ou rodar no próximo dia. Assim você dá um descanso na conta para garantir 100% do funcionamento.';

        var actions = document.createElement('div');
        actions.style.padding = '0 22px 22px 22px';

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.innerText = 'Entendi';
        btn.style.width = '100%';
        btn.style.padding = '12px';
        btn.style.border = '0';
        btn.style.borderRadius = '10px';
        btn.style.cursor = 'pointer';
        btn.style.background = '#006400';
        btn.style.color = '#ffffff';
        btn.style.fontWeight = '800';
        btn.style.fontSize = '14px';

        btn.addEventListener('click', function() {
            try { overlay.remove(); } catch (e) {}
        });

        body.appendChild(title);
        body.appendChild(msg);
        actions.appendChild(btn);
        card.appendChild(body);
        card.appendChild(actions);
        overlay.appendChild(card);

        overlay.addEventListener('click', function(e) {
            if (e.target === overlay) {
                try { overlay.remove(); } catch (e2) {}
            }
        });

        document.body.appendChild(overlay);
    } catch (e) {}
}

function getCsrfToken() {
    var token = null;
    try {
        var parts = document.cookie.split(';');
        for (var i = 0; i < parts.length; i++) {
            var part = parts[i].trim();
            if (!part) continue;
            if (part.indexOf('csrftoken=') === 0) {
                token = part.substring('csrftoken='.length);
                break;
            }
        }
    } catch (e) {}
    if (token) return token;
    try {
        var match = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/);
        return match ? match[1] : null;
    } catch (e2) {}
    return null;
}
window.betaResolveNumericIdByUsername = function(username, callback) {
    if (!username) { if (typeof callback === 'function') callback(null); return; }
    var cleanUsername = String(username).trim().replace(/^@/, '');
    var csrftoken = typeof getCsrfToken === 'function' ? getCsrfToken() : '';
    var completed = false;
    
    var finish = function(resId) {
        if (completed) return;
        completed = true;
        clearTimeout(safetyTimeout);
        if (typeof callback === 'function') callback(resId || null);
    };

    var safetyTimeout = setTimeout(function() {
        finish(null);
    }, 8000);

    // Estratégia 1: REST API com X-IG-App-ID
    $.ajax({
        url: 'https://www.instagram.com/api/v1/users/web_profile_info/?username=' + cleanUsername,
        method: 'GET',
        timeout: 4000,
        headers: (function() {
            var h = {
                'x-ig-app-id': '936619743392459',
                'x-asbd-id': '129477',
                'x-requested-with': 'XMLHttpRequest',
                'x-instagram-ajax': '1010212815'
            };
            if (csrftoken) h['x-csrftoken'] = csrftoken;
            return h;
        })(),
        xhrFields: { withCredentials: true },
        success: function(resp) {
            if (resp && resp.data && resp.data.user && resp.data.user.id) {
                finish(String(resp.data.user.id));
            } else {
                tryHtmlProfile();
            }
        },
        error: function() {
            tryHtmlProfile();
        }
    });

    // Estratégia 2: Requisição ao perfil HTML e extração via Regex
    function tryHtmlProfile() {
        if (completed) return;
        $.ajax({
            url: 'https://www.instagram.com/' + cleanUsername + '/',
            method: 'GET',
            timeout: 4000,
            success: function(htmlText) {
                if (completed) return;
                if (htmlText) {
                    var m1 = htmlText.match(/"profile_id":"(\d+)"/);
                    var m2 = htmlText.match(/"target_user_id":"(\d+)"/);
                    var m3 = htmlText.match(/"owner":\s*\{\s*"id":\s*"(\d+)"/);
                    var m4 = htmlText.match(new RegExp('"username":"' + cleanUsername + '"[^}]*?"id":"(\\d+)"', 'i'));
                    var m5 = htmlText.match(new RegExp('"id":"(\\d+)"[^}]*?"username":"' + cleanUsername + '"', 'i'));
                    var idFound = (m1 && m1[1]) || (m2 && m2[1]) || (m3 && m3[1]) || (m4 && m4[1]) || (m5 && m5[1]);
                    if (idFound) {
                        finish(String(idFound));
                        return;
                    }
                }
                finish(null);
            },
            error: function() {
                finish(null);
            }
        });
    }
};

function getTargetProfileIdFromPage(callback) {
    var path = window.location.pathname;
    var parts = path.split('/').filter(p => p.length > 0);
    var username = parts[0];

    logBeta("getTargetProfileIdFromPage iniciado. Path: " + path + " | Username: " + username);

    // 1. Meta tag (instapp:owner_user_id)
    var meta = document.querySelector('meta[property="instapp:owner_user_id"]');
    if (meta && meta.content) {
        logBeta("ID encontrado via meta tag: " + meta.content);
        callback(meta.content);
        return;
    }

    // 2. window._sharedData
    try {
        if (window._sharedData && window._sharedData.entry_data && window._sharedData.entry_data.ProfilePage) {
            var uId = window._sharedData.entry_data.ProfilePage[0].graphql.user.id;
            if (uId) {
                logBeta("ID encontrado via _sharedData: " + uId);
                callback(String(uId));
                return;
            }
        }
    } catch(e) {}

    // 3. Inspeção direta de Script Tags do DOM
    try {
        var scripts = document.querySelectorAll('script');
        for (var i = 0; i < scripts.length; i++) {
            var txt = scripts[i].textContent || '';
            if (txt.length > 0) {
                var m = txt.match(/"profile_id":"(\d+)"/) || 
                        txt.match(/"target_user_id":"(\d+)"/) || 
                        txt.match(/"owner":\s*\{\s*"id":\s*"(\d+)"/);
                if (m && m[1]) {
                    logBeta("ID encontrado em script tag (" + m[0] + "): " + m[1]);
                    callback(m[1]);
                    return;
                }
            }
        }
    } catch(e) {}

    // 4. Inspeção por correspondência de Username nos Scripts
    if (username && !['direct', 'explore', 'reels', 'stories', 'accounts', 'p', 'tv'].includes(username)) {
        try {
            var scripts = document.querySelectorAll('script');
            var clean = username.toLowerCase();
            for (var i = 0; i < scripts.length; i++) {
                var txt = scripts[i].textContent || '';
                if (txt.toLowerCase().includes(clean)) {
                    var m1 = txt.match(new RegExp('"username":"' + clean + '"[^}]*?"id":"(\\d+)"', 'i'));
                    var m2 = txt.match(new RegExp('"id":"(\\d+)"[^}]*?"username":"' + clean + '"', 'i'));
                    var m3 = txt.match(new RegExp('"username":"' + clean + '"[^}]*?"pk":"?(\\d+)"?', 'i'));
                    var m4 = txt.match(new RegExp('"pk":"?(\\d+)"?[^}]*?"username":"' + clean + '"', 'i'));
                    var found = (m1 && m1[1]) || (m2 && m2[1]) || (m3 && m3[1]) || (m4 && m4[1]);
                    if (found) {
                        logBeta("ID encontrado no DOM do perfil para @" + clean + ": " + found);
                        callback(found);
                        return;
                    }
                }
            }
        } catch(e) {}
    }

    // 5. Meta tag ios:url (e.g. instagram://user?id=xxx ou instagram://user?username=xxx)
    try {
        var iosMeta = document.querySelector('meta[property="al:ios:url"]');
        if (iosMeta && iosMeta.content) {
            var mId = iosMeta.content.match(/id=(\d+)/) || iosMeta.content.match(/user\?id=(\d+)/);
            if (mId && mId[1]) {
                logBeta("ID encontrado via ios:url meta: " + mId[1]);
                callback(mId[1]);
                return;
            }
        }
    } catch(e) {}

    // 6. Resolução via API / HTTP Fallback
    if (username && !['direct', 'explore', 'reels', 'stories', 'accounts', 'p', 'tv'].includes(username)) {
        logBeta("Buscando ID via API para @" + username + "...");
        betaResolveNumericIdByUsername(username, function(apiId) {
            if (apiId) {
                logBeta("ID retornado pela API: " + apiId);
                callback(String(apiId));
            } else {
                logBeta("Falha na resolução do ID.");
                callback(null);
            }
        });
    } else {
        logBeta("Não está na página de um perfil válido.");
        callback(null);
    }
}

function fetchRecentFollowers(targetUserId, limit, offset, callback) {
    var userId = targetUserId || getLoggedUserId();
    if (!userId) {
        logBeta("Erro Crítico: ID de usuário não encontrado (nem alvo nem logado).");
        alert("Erro: Não foi possível identificar o usuário. Recarregue a página.");
        betaUpdateCheckFollowersButtonLabel();
        $('#btnCheckNewFollowers').removeClass('inactive');
        return;
    }

    var allFollowers = [];
    var csrftoken = (typeof getCsrfToken === 'function' ? getCsrfToken() : null) || '1';
    var totalToFetch = limit + offset;

    var fetchNextPage = function(maxId) {
        var remaining = totalToFetch - allFollowers.length;
        if (remaining <= 0) {
            logBeta("Limite atingido: " + allFollowers.length + " seguidores.");
            callback(allFollowers.slice(offset, totalToFetch));
            return;
        }

        var count = Math.min(remaining, 50);
        var url = `https://www.instagram.com/api/v1/friendships/${userId}/followers/?count=${count}&search_surface=follow_list_page`;
        if (maxId) url += `&max_id=${maxId}`;

        var headersObj = {
            'x-ig-app-id': '936619743392459',
            'x-asbd-id': '129477',
            'x-requested-with': 'XMLHttpRequest',
            'x-instagram-ajax': '1010212815'
        };
        if (csrftoken) headersObj['x-csrftoken'] = csrftoken;

        var tryGraphQLFollowers = function() {
            var queryHash = "c76146de99bb02f6415203be841dd25a";
            var variables = JSON.stringify({
                id: userId,
                first: count,
                after: maxId || null
            });
            var gqlUrl = `https://www.instagram.com/graphql/query/?query_hash=${queryHash}&variables=${encodeURIComponent(variables)}`;

            $.ajax({
                url: gqlUrl,
                method: 'GET',
                timeout: 10000,
                headers: headersObj,
                xhrFields: { withCredentials: true },
                success: function(gqlResp) {
                    if (gqlResp && gqlResp.data && gqlResp.data.user && gqlResp.data.user.edge_followed_by) {
                        var edges = gqlResp.data.user.edge_followed_by.edges || [];
                        var pageInfo = gqlResp.data.user.edge_followed_by.page_info || {};
                        var normalized = edges.map(e => ({
                            id: String(e.node.id),
                            username: e.node.username,
                            profile_pic_url: e.node.profile_pic_url,
                            is_verified: e.node.is_verified,
                            full_name: e.node.full_name
                        }));

                        allFollowers = allFollowers.concat(normalized);
                        logBeta(`GraphQL: ${allFollowers.length} de ${totalToFetch}`);

                        if (allFollowers.length < totalToFetch && pageInfo.has_next_page && pageInfo.end_cursor) {
                            setTimeout(() => fetchNextPage(pageInfo.end_cursor), 600);
                        } else {
                            callback(allFollowers.slice(offset, totalToFetch));
                        }
                    } else {
                        callback(allFollowers.slice(offset));
                    }
                },
                error: function() {
                    callback(allFollowers.slice(offset));
                }
            });
        };

        $.ajax({
            url: url,
            method: 'GET',
            timeout: 10000,
            headers: headersObj,
            xhrFields: { withCredentials: true },
            success: function(resp) {
                if (resp && resp.users && resp.users.length > 0) {
                    var normalized = resp.users.map(u => ({
                        id: String(u.pk || u.id),
                        username: u.username,
                        profile_pic_url: u.profile_pic_url,
                        is_verified: u.is_verified,
                        full_name: u.full_name
                    }));
                    
                    allFollowers = allFollowers.concat(normalized);
                    logBeta(`Buscando seguidores: ${allFollowers.length} de ${totalToFetch} (Pular: ${offset})`);

                    if (allFollowers.length < totalToFetch && resp.next_max_id) {
                        var delay = (allFollowers.length % 2500 < 50 && allFollowers.length > 2000) ? 2000 : 500;
                        setTimeout(() => fetchNextPage(resp.next_max_id), delay);
                    } else if (allFollowers.length < totalToFetch && allFollowers.length > 0 && maxId !== allFollowers[allFollowers.length - 1].id) {
                        var lastId = allFollowers[allFollowers.length - 1].id;
                        logBeta(`🔄 Continuando busca avançada no seguidor #${allFollowers.length} (ID: ${lastId})...`);
                        setTimeout(() => fetchNextPage(lastId), 1200);
                    } else {
                        logBeta("Finalizado: " + allFollowers.length + " seguidores encontrados.");
                        callback(allFollowers.slice(offset, totalToFetch));
                    }
                } else if (allFollowers.length < totalToFetch && allFollowers.length > 0 && maxId !== allFollowers[allFollowers.length - 1].id) {
                    var lastId = allFollowers[allFollowers.length - 1].id;
                    logBeta(`🔄 Alternando método no seguidor #${allFollowers.length} (ID: ${lastId})...`);
                    setTimeout(() => fetchNextPage(lastId), 1500);
                } else {
                    logBeta("REST endpoint sem resultados. Tentando GraphQL fallback...");
                    tryGraphQLFollowers();
                }
            },
            error: function(err) {
                logBeta("Erro no REST endpoint. Tentando GraphQL fallback...");
                tryGraphQLFollowers();
            }
        });
    };

    fetchNextPage();
}

function renderTableWithHistory(users, history) {
    massDMQueue = users; // Sync global queue
    betaSaveMassDmRuntime(function() {}, {
        running: isMassDMRunning === true,
        statusText: $('#massDMStatus').text() || 'Interessados carregados.'
    });
    var tbody = $('#tblNewFollowers tbody');
    tbody.empty();

    if (users.length === 0) {
        tbody.append('<tr><td colspan="6" style="text-align:center; padding: 10px;">Nenhum usuário encontrado.</td></tr>');
    } else {
        users.forEach(function(u) {
            var h = history[u.id];
            var ts = h ? (h.timestamp || h) : null;
            var historyDate = ts ? new Date(ts).toLocaleString() : "-";
            
            // Highlight if history exists
            var rowStyle = h ? 'background-color: #fff3e0;' : '';
            
            var row = `<tr style="${rowStyle}">
                <td><input type="checkbox" class="user-checkbox" data-id="${u.id}"></td>
                <td><img src="${u.profile_pic_url}" style="width: 30px; height: 30px; border-radius: 50%;"></td>
                <td>${u.username}</td>
                <td>
                    <div>${u.id}</div>
                    <div class="interop-cell" data-id="${u.id}" style="font-size: 10px; color: #777;">${u.interop_messaging_user_fbid || (u.processed ? '-' : '...')}</div>
                </td>
                <td class="history-cell">${historyDate}</td>
                <td class="interaction-cell" style="font-size: 11px;">${u.interactionDate || '-'}</td>
                <td class="status-cell" data-id="${u.id}">${u.processed ? (u.status || 'Processado') : 'Pendente'}</td>
            </tr>`;
            tbody.append(row);
        });
    }
    $('#newFollowersCount').text(users.length + " usuários encontrados");
    $('#cbSelectAllFollowers').prop('checked', false);
}

function startMassDM() {
    if (massDMQueue.length === 0) {
        alert("A lista está vazia!");
        return;
    }

    var templates = betaGetDmTemplates(betaMassDmTemplateSelectors);
    if (!templates.length) {
        alert("Digite uma mensagem!");
        return;
    }

    // Check history overlap
    loadDMHistory(function(history) {
        var repeatCount = 0;
        massDMQueue.forEach(u => {
            if (history[u.id] && !u.processed) repeatCount++;
        });
        
        if (repeatCount > 0) {
            // Show custom modal
            $('#duplicateConfirmText').text(
                `Encontramos ${repeatCount} usuários que JÁ RECEBERAM mensagens anteriormente.\n` +
                `Total na fila: ${massDMQueue.length}`
            );
            
            // Restore button texts for Sending context
            $('#btnSkipDuplicates').text('Pular Repetidos (Recomendado)');
            $('#btnSendAllDuplicates').text('Enviar para TODOS (Mesmo Repetidos)');
            $('#btnCancelDuplicates').text('Cancelar');

            $('#duplicateConfirmModal').show();
            
            // Setup handlers (one-off)
            $('#btnSkipDuplicates').off('click').on('click', function() {
                $('#duplicateConfirmModal').hide();
                continueMassDM(true, history);
            });
            
            $('#btnSendAllDuplicates').off('click').on('click', function() {
                $('#duplicateConfirmModal').hide();
                continueMassDM(false, history);
            });
            
            $('#btnCancelDuplicates').off('click').on('click', function() {
                $('#duplicateConfirmModal').hide();
            });
            
            return;
        }

        continueMassDM(false, history);
    });
}

function betaNotifyAssistantDmProgress(statusText, extra) {
    if (typeof window.rdgAssistantHandleMassDmProgress !== 'function') return;
    var total = Array.isArray(massDMQueue) ? massDMQueue.length : 0;
    var processed = 0;
    for (var i = 0; i < total; i++) {
        if (massDMQueue[i] && massDMQueue[i].processed) processed++;
    }
    var payload = $.extend({
        running: isMassDMRunning === true,
        total: total,
        processed: processed,
        remaining: Math.max(0, total - processed),
        statusText: statusText || ($('#massDMStatus').text() || '')
    }, extra || {});
    try {
        window.rdgAssistantHandleMassDmProgress(payload);
    } catch (e) {}
}

function continueMassDM(skipDuplicates, history) {
    if (skipDuplicates && history) {
        var skippedCount = 0;
        massDMQueue.forEach(u => {
            if (history[u.id] && !u.processed) {
                u.processed = true;
                u.status = "Pulado (Já Enviado)";
                updateStatus(u.id, "Pulado ⏩");
                skippedCount++;
            }
        });
        console.log("[Beta] Pulados " + skippedCount + " usuários repetidos.");
    }

    isMassDMRunning = true;
    $('#btnStartMassDM').hide();
    $('#btnStopMassDM').show();
    $('#massDMStatus').text("Iniciando envio...");
    betaNotifyAssistantDmProgress("Iniciando envio em massa de mensagens...");
    betaSaveMassDmRuntime(function() {
        processNextDM();
    }, {
        running: true,
        statusText: 'Iniciando envio em massa de mensagens...'
    });
}

function stopMassDM() {
    isMassDMRunning = false;
    if (massDMTimer) clearInterval(massDMTimer);
    $('#btnStartMassDM').show();
    $('#btnStopMassDM').hide();
    $('#massDMStatus').text("Parado.");
    betaNotifyAssistantDmProgress("Envio em massa parado.", { running: false });
    chrome.storage.local.remove(['pending_dm_task'], function() {});
    betaDockClear(function() {});
    betaDockApply(false);
    betaSaveMassDmRuntime(function() {}, {
        running: false,
        statusText: 'Envio em massa parado.'
    });
    if (currentDMWindow && currentDMWindow.close) {
        try { currentDMWindow.close(); } catch (e) {}
    }
    currentDMWindow = null;
}

function processNextDM() {
    if (!isMassDMRunning) return;

    var nextUser = null;
    var nextIndex = -1;
    
    for (var i = 0; i < massDMQueue.length; i++) {
        if (!massDMQueue[i].processed) {
            nextUser = massDMQueue[i];
            nextIndex = i;
            break;
        }
    }

    if (!nextUser) {
        stopMassDM();
        $('#massDMStatus').text("Envio concluído!");
        betaNotifyAssistantDmProgress("Envio em massa concluido!", {
            running: false,
            completed: true,
            processed: massDMQueue.length,
            total: massDMQueue.length
        });
        betaClearMassDmRuntime(function() {});
        if (!(typeof window.rdgAssistantShouldSuppressMassDmAlert === 'function' && window.rdgAssistantShouldSuppressMassDmAlert())) {
            alert("Envio em massa concluído!");
        }
        return;
    }

    // If ID is a custom string placeholder (e.g. custom_username), resolve numeric ID first
    if (String(nextUser.id).indexOf('custom_') === 0 || !/^\d+$/.test(String(nextUser.id))) {
        var oldId = nextUser.id;
        updateStatus(oldId, "Resolvendo ID numérico... 🔍");
        $('#massDMStatus').text("Resolvendo ID para @" + nextUser.username + "...");
        betaResolveNumericIdByUsername(nextUser.username, function(numericId) {
            if (numericId) {
                nextUser.id = numericId;
                nextUser.real_ig_id = numericId;
                var row = $('#row-' + oldId);
                if (row && row.length) {
                    row.attr('id', 'row-' + numericId);
                    row.find('.user-checkbox').val(numericId);
                }
                updateStatus(numericId, "ID Resolvido: " + numericId);
                setTimeout(processNextDM, 800);
            } else {
                updateStatus(oldId, "❌ Perfil não encontrado ou privado");
                nextUser.processed = true;
                nextUser.status = "Falha ao resolver perfil";
                setTimeout(processNextDM, 1500);
            }
        });
        return;
    }

    // Fetch Interop ID on-demand if missing
    if (!nextUser.interop_messaging_user_fbid) {
        updateStatus(nextUser.id, "Buscando ID... 🔍");
        $('#massDMStatus').text("Buscando ID para " + nextUser.username + "...");
        betaNotifyAssistantDmProgress("Buscando ID para @" + nextUser.username + "...", { currentUsername: nextUser.username });
        betaSaveMassDmRuntime(function() {}, {
            running: true,
            statusText: "Buscando ID para @" + nextUser.username + "..."
        });
        
        fetchInteropId(nextUser.id, function(interopId) {
            if (interopId) {
                nextUser.interop_messaging_user_fbid = interopId;
                nextUser._interopTries = 0;
                updateInteropCell(nextUser.id, interopId);
                // Proceed to send after a small delay
                setTimeout(processNextDM, 1000);
            } else {
                var meta = arguments[1];
                var failureText = betaFormatInteropLookupFailure(meta);
                if (meta && meta.status === 429) {
                    updateStatus(nextUser.id, failureText);
                    betaScheduleRetryForUser(nextUser, nextIndex, "Instagram limitou a busca de ID.", { delayMs: 15 * 60 * 1000 });
                    betaShowInstagramLimitedPopup();
                    return;
                }

                var status = meta && typeof meta.status === 'number' ? meta.status : 0;
                var retryable = status === 0 || status >= 500 || (meta && meta.reason === 'missing_interop');
                var tries = nextUser._interopTries || 0;
                if (retryable && tries < 3) {
                    nextUser._interopTries = tries + 1;
                    updateStatus(nextUser.id, "Tentando buscar ID novamente (" + (tries + 1) + "/3)...");
                    setTimeout(processNextDM, 2500 + tries * 2500);
                    return;
                }

                updateStatus(nextUser.id, failureText);
                betaScheduleRetryForUser(nextUser, nextIndex, "Nao foi possivel obter o ID do direct.", { delayMs: 2 * 60 * 1000 });
            }
        });
        return;
    }

    sendActualDM(nextUser, nextIndex);
}

function sendActualDM(nextUser, nextIndex) {
    if (!isMassDMRunning) return;

    updateStatus(nextUser.id, "Abrindo janela...");
    $('#massDMStatus').text("Abrindo conversa individual para " + nextUser.username + "...");
    betaNotifyAssistantDmProgress("Abrindo uma conversa por vez para @" + nextUser.username + "...", { currentUsername: nextUser.username });
    betaSaveMassDmRuntime(function() {}, {
        running: true,
        statusText: "Abrindo uma conversa por vez para @" + nextUser.username + "..."
    });

    var finalMsg = betaBuildFinalDmMessage(nextUser);

    // Prepare Task
    var task = {
        id: nextUser.id,
        targetId: nextUser.interop_messaging_user_fbid,
        username: nextUser.username,
        message: finalMsg,
        mode: 'legacy_tab',
        status: 'pending',
        timestamp: Date.now(),
        createdAt: Date.now()
    };

    chrome.storage.local.set({ 'pending_dm_task': task }, function() {
        var url = 'https://www.instagram.com/direct/t/' + task.targetId + '/';
        if (currentDMWindow && currentDMWindow.close && !currentDMWindow.closed) {
            try { currentDMWindow.close(); } catch (e) {}
        }
        currentDMWindow = null;
        currentDMWindow = window.open(url, '_blank');
        
        // Start Monitoring
        monitorDMTask(nextIndex, nextUser.id);
    });
}

function monitorDMTask(queueIndex, userId) {
    var checks = 0;
    var maxChecks = 120; // 120 seconds timeout
    
    var interval = setInterval(function() {
        if (!isMassDMRunning) {
            clearInterval(interval);
            if (currentDMWindow && currentDMWindow.type !== 'fixed_window') {
                try { currentDMWindow.close(); } catch(e){}
            }
            return;
        }
        
        chrome.storage.local.get(['pending_dm_task'], function(result) {
            var task = result.pending_dm_task;
            
            if (!task) {
                clearInterval(interval);
                updateStatus(userId, "Sem confirmacao ❌");
                betaScheduleRetryForUser(massDMQueue[queueIndex], queueIndex, "A confirmacao do envio nao foi encontrada.", { delayMs: 90 * 1000 });
            } else if (task.status === 'sent') {
                clearInterval(interval);
                updateStatus(userId, "Enviado ✅");
                massDMQueue[queueIndex].processed = true;
                
                // Save to history
                var userObj = { id: userId, username: task.username || "Desconhecido" };
                saveDMHistory(userObj, task.message);
                betaNotifyAssistantDmProgress("Mensagem enviada para @" + (userObj.username || 'usuario') + ".", { currentUsername: userObj.username || '' });
                betaSaveMassDmRuntime(function() {}, {
                    running: true,
                    statusText: "Mensagem enviada para @" + (userObj.username || 'usuario') + ". Fechando e voltando para preparar o proximo envio."
                });
                
                if (currentDMWindow && currentDMWindow.type === 'fixed_window') {
                    // keep the fixed window open
                } else if (currentDMWindow && currentDMWindow.close && !currentDMWindow.closed) {
                    try { currentDMWindow.close(); } catch(e){}
                }
                currentDMWindow = null;
                scheduleNextDM();
            } else if (task.status === 'error') {
                clearInterval(interval);
                updateStatus(userId, "Erro Tab ❌");
                betaScheduleRetryForUser(massDMQueue[queueIndex], queueIndex, "Falha temporaria ao enviar a mensagem.", { delayMs: 90 * 1000 });
            } else if (
                currentDMWindow &&
                (
                    (currentDMWindow.type === 'fixed_window' && currentDMWindow.mode === 'js_window' && currentDMWindow.ref && currentDMWindow.ref.closed) ||
                    (currentDMWindow.close && currentDMWindow.closed)
                )
            ) {
                 // Window closed prematurely
                 if (task && task.status === 'pending') {
                     clearInterval(interval);
                     updateStatus(userId, "Janela Fechada ❌");
                     betaScheduleRetryForUser(massDMQueue[queueIndex], queueIndex, "A janela do direct fechou antes do envio.", { delayMs: 60 * 1000 });
                 }
            }
            
            checks++;
            if (checks > maxChecks) {
                clearInterval(interval);
                updateStatus(userId, "Timeout ❌");
                betaScheduleRetryForUser(massDMQueue[queueIndex], queueIndex, "Tempo limite atingido antes da confirmacao do envio.", { delayMs: 2 * 60 * 1000 });
            }
        });
    }, 1000);
}

function scheduleNextDM() {
    var delayMs = betaGetRandomMassDmDelayMs();
    if (delayMs < 5000) delayMs = 5000;

    var endTime = Date.now() + delayMs;
    $('#massDMStatus').text(betaFormatRandomDelayStatus(delayMs));
    betaNotifyAssistantDmProgress(betaFormatRandomDelayStatus(delayMs));
    betaSaveMassDmRuntime(function() {}, {
        running: true,
        statusText: betaFormatRandomDelayStatus(delayMs)
    });
    
    if (massDMTimer) clearInterval(massDMTimer);
    
    massDMTimer = setInterval(function() {
        if (!isMassDMRunning) {
            clearInterval(massDMTimer);
            return;
        }
        
        var remaining = Math.ceil((endTime - Date.now()) / 1000);
        if (remaining <= 0) {
            clearInterval(massDMTimer);
            processNextDM();
        } else {
            $('#massDMStatus').text(betaFormatRandomDelayStatus(delayMs, remaining));
            betaNotifyAssistantDmProgress(betaFormatRandomDelayStatus(delayMs, remaining));
            betaSaveMassDmRuntime(function() {}, {
                running: true,
                statusText: betaFormatRandomDelayStatus(delayMs, remaining)
            });
        }
    }, 1000);
}

function updateStatus(userId, text) {
    $(`.status-cell[data-id="${userId}"]`).text(text);
}
