/** 
 * Copyright (C) RDG Soluções Digitais 2026 - Todos os Direitos Reservados
 *
 * A cópia não autorizada deste arquivo, por qualquer meio, é estritamente proibida
 * Proprietário e confidencial
 * Desenvolvido por RDG Soluções Digitais <suporte@rdgsolucoes.com.br>, 2026
 */


var guidCookie = localStorage['gbUserGuid'];

function showErrorPopup(message) {
    // Create overlay
    var overlay = document.createElement('div');
    overlay.id = 'errorPopupOverlay';
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'rgba(0,0,0,0.85)';
    overlay.style.zIndex = '999999';
    overlay.style.display = 'flex';
    overlay.style.justifyContent = 'center';
    overlay.style.alignItems = 'center';

    // Create popup box
    var popup = document.createElement('div');
    popup.style.backgroundColor = '#0f172a';
    popup.style.padding = '30px';
    popup.style.borderRadius = '12px';
    popup.style.boxShadow = '0 10px 30px rgba(0,220,255,0.15)';
    popup.style.textAlign = 'center';
    popup.style.maxWidth = '450px';
    popup.style.border = '1px solid rgba(0,220,255,0.3)';

    // Logo
    var img = document.createElement('img');
    img.src = chrome.runtime.getURL('Logo.png');
    img.style.maxHeight = '140px';
    img.style.maxWidth = '100%';
    img.style.objectFit = 'contain';
    img.style.marginBottom = '25px';
    img.style.filter = 'drop-shadow(0 4px 15px rgba(0, 220, 255, 0.45))';
    popup.appendChild(img);

    // Message
    var msg = document.createElement('p');
    msg.innerText = message;
    msg.style.marginBottom = '25px';
    msg.style.color = '#f1f5f9';
    msg.style.fontSize = '16px';
    msg.style.lineHeight = '1.5';
    popup.appendChild(msg);

    // Buttons Container
    var btnContainer = document.createElement('div');
    btnContainer.style.display = 'flex';
    btnContainer.style.justifyContent = 'center';
    btnContainer.style.gap = '15px';

    // Cancel Button
    var okBtn = document.createElement('button');
    okBtn.innerText = 'FECHAR';
    okBtn.style.padding = '10px 20px';
    okBtn.style.cursor = 'pointer';
    okBtn.style.backgroundColor = 'transparent';
    okBtn.style.border = '1px solid #475569';
    okBtn.style.color = '#cbd5e1';
    okBtn.style.borderRadius = '6px';
    okBtn.style.fontWeight = 'bold';
    okBtn.onclick = function() {
        document.body.removeChild(overlay);
    };
    btnContainer.appendChild(okBtn);

    // Support Button
    var supportBtn = document.createElement('button');
    supportBtn.innerText = 'SUPORTE WHATSAPP';
    supportBtn.style.padding = '10px 20px';
    supportBtn.style.cursor = 'pointer';
    supportBtn.style.backgroundColor = '#10b981';
    supportBtn.style.border = 'none';
    supportBtn.style.color = 'white';
    supportBtn.style.borderRadius = '6px';
    supportBtn.style.fontWeight = 'bold';
    supportBtn.style.boxShadow = '0 4px 15px rgba(16, 185, 129, 0.4)';
    supportBtn.onclick = function() {
        document.body.removeChild(overlay);
        window.open("https://wa.me/5521920078469?text=Ol%C3%A1%2C%20preciso%20de%20ajuda%20com%20a%20minha%20licen%C3%A7a%20do%20RDG%20instaPRO.", "_blank");
    };
    btnContainer.appendChild(supportBtn);

    popup.appendChild(btnContainer);
    overlay.appendChild(popup);
    document.body.appendChild(overlay);
}

function showProfileRequiredPopup() {
    // Create overlay
    var overlay = document.createElement('div');
    overlay.id = 'profileRequiredPopupOverlay';
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'rgba(0,0,0,0.5)';
    overlay.style.zIndex = '9999999'; // High z-index to be on top of everything
    overlay.style.display = 'flex';
    overlay.style.justifyContent = 'center';
    overlay.style.alignItems = 'center';

    // Create popup box
    var popup = document.createElement('div');
    popup.style.backgroundColor = 'white';
    popup.style.padding = '30px';
    popup.style.borderRadius = '12px';
    popup.style.boxShadow = '0 10px 25px rgba(0,0,0,0.5)';
    popup.style.textAlign = 'center';
    popup.style.maxWidth = '450px';
    popup.style.width = '90%';
    popup.style.fontFamily = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';
    popup.style.animation = 'popIn 0.3s ease-out';

    // Add animation keyframes style if not exists
    if (!document.getElementById('rdg-popup-style')) {
        var style = document.createElement('style');
        style.id = 'rdg-popup-style';
        style.innerHTML = '@keyframes popIn { from { transform: scale(0.8); opacity: 0; } to { transform: scale(1); opacity: 1; } }';
        document.head.appendChild(style);
    }

    // Icon
    var icon = document.createElement('div');
    icon.innerHTML = '⚠️';
    icon.style.fontSize = '48px';
    icon.style.marginBottom = '20px';
    popup.appendChild(icon);

    // Title
    var title = document.createElement('h3');
    title.innerText = 'Ação Necessária';
    title.style.margin = '0 0 15px 0';
    title.style.color = '#333';
    title.style.fontSize = '22px';
    popup.appendChild(title);

    // Message
    var msg = document.createElement('p');
    msg.innerText = 'Para conseguir rastrear o público você precisa estar em cima de uma página/perfil. Pesquise uma página e volte aqui nessa tela.';
    msg.style.marginBottom = '25px';
    msg.style.color = '#555';
    msg.style.fontSize = '16px';
    msg.style.lineHeight = '1.6';
    popup.appendChild(msg);

    // OK Button
    var okBtn = document.createElement('button');
    okBtn.innerText = 'OK, ENTENDI';
    okBtn.style.padding = '12px 25px';
    okBtn.style.cursor = 'pointer';
    okBtn.style.backgroundColor = '#0095f6';
    okBtn.style.color = 'white';
    okBtn.style.border = 'none';
    okBtn.style.borderRadius = '8px';
    okBtn.style.fontSize = '14px';
    okBtn.style.fontWeight = '600';
    okBtn.style.transition = 'background-color 0.2s';
    
    okBtn.onclick = function() {
        document.body.removeChild(overlay);
    };
    
    okBtn.onmouseover = function() { okBtn.style.backgroundColor = '#1877f2'; };
    okBtn.onmouseout = function() { okBtn.style.backgroundColor = '#0095f6'; };

    popup.appendChild(okBtn);
    overlay.appendChild(popup);
    document.body.appendChild(overlay);
}

function showRateLimitPopup() {
    var existing = document.getElementById('rateLimitPopupOverlay');
    if (existing && existing.parentNode) {
        existing.parentNode.removeChild(existing);
    }

    // Create overlay
    var overlay = document.createElement('div');
    overlay.id = 'rateLimitPopupOverlay';
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100%';
    overlay.style.height = '100%';
    overlay.style.backgroundColor = 'rgba(0,0,0,0.5)';
    overlay.style.zIndex = '999999';
    overlay.style.display = 'flex';
    overlay.style.justifyContent = 'center';
    overlay.style.alignItems = 'center';

    function closeRateLimitPopup() {
        if (overlay && overlay.parentNode) {
            overlay.parentNode.removeChild(overlay);
        }
    }

    // Create popup box
    var popup = document.createElement('div');
    popup.style.backgroundColor = 'white';
    popup.style.padding = '20px';
    popup.style.borderRadius = '5px';
    popup.style.boxShadow = '0 0 10px rgba(0,0,0,0.5)';
    popup.style.textAlign = 'center';
    popup.style.maxWidth = '400px';

    // Reassuring Header
    var header = document.createElement('h3');
    header.innerText = 'Não se preocupe, não precisa fazer nada, apenas continue ligado!';
    header.style.color = '#28a745';
    header.style.marginBottom = '15px';
    header.style.fontSize = '18px';
    popup.appendChild(header);

    // Message
    var msg = document.createElement('p');
    msg.innerText = 'Limitado pelo instagram para seguir contas vamos aguardar 1 hora e vamos tentar novamente.';
    msg.style.marginBottom = '20px';
    msg.style.color = 'black';
    popup.appendChild(msg);

    // Buttons Container
    var btnContainer = document.createElement('div');
    btnContainer.style.display = 'flex';
    btnContainer.style.justifyContent = 'space-around';
    btnContainer.style.gap = '10px';
    btnContainer.style.flexDirection = 'column';

    // Button: Falar com suporte sobre este bloqueio
    var understandBtn = document.createElement('button');
    understandBtn.innerText = 'Falar com suporte sobre este bloqueio (WhatsApp)';
    understandBtn.style.padding = '10px 20px';
    understandBtn.style.cursor = 'pointer';
    understandBtn.onclick = function() {
        window.open('https://api.whatsapp.com/send?phone=5521970028469', "_blank");
    };
    btnContainer.appendChild(understandBtn);

    // Button: fechar
    var closeBtn = document.createElement('button');
    closeBtn.innerText = 'Fechar / Continuar (Automático)';
    closeBtn.style.padding = '10px 20px';
    closeBtn.style.cursor = 'pointer';
    closeBtn.onclick = function() {
        closeRateLimitPopup();
    };
    btnContainer.appendChild(closeBtn);

    popup.appendChild(btnContainer);

    // Explanatory Text
    var autoContinueMsg = document.createElement('p');
    autoContinueMsg.innerText = 'O sistema vai aguardar 1 hora sozinho e vai continuar, não precisa fazer nada.';
    autoContinueMsg.style.marginTop = '15px';
    autoContinueMsg.style.fontSize = '14px';
    autoContinueMsg.style.color = '#666';
    autoContinueMsg.style.fontWeight = 'bold';
    popup.appendChild(autoContinueMsg);

    overlay.appendChild(popup);
    document.body.appendChild(overlay);

    setTimeout(function() {
        closeRateLimitPopup();
    }, 20000);
}

var urlAcctInfo = 'https://i.instagram.com/api/v1/users/web_profile_info/?username=';
var urlAcctInfo3 = 'https://i.instagram.com/api/v1/users/${userid}/info/'; //has public_email

/*

SAVE USERNAME AND IP TO METADATA WHEN LOADING SUBSCRIPTION

Button hover states

- FILTERS
    connected_fb_page
    has_channel
    business_category_name
    highlight_reel_count
    last post date** - handle private accounts
    first post date**
    average posts per day?

- option to block client events

1) auto like when people comment your images
2) auto reply to comments (not sure if this is a must have feature tho).

make tour
video tour?  ttsreader.com

Add Google analytics

auto unfollow
schedule unfollowing
    - background page messaging

progress bars!
https://loading.io/progress/
https://kimmobrunfeldt.github.io/progressbar.js/

<meter
  min="0"
  max="100"
  low="25"
  high="75"
  optimum="80"
  value="50"
></meter>


6) Could you integrate a location based filtering system? For an example google coordinate paste + radius

button to clear already attempted or load as queue

Make quick "Unlike" or make sure to show user info for each pic.

Anyway you can randomize the post likes
My guess IG would spot you liking 1 post on every follow.
It would be nice if you could randomize likes and randomize frequency on this option.
For example every 3 to 10 (Random) follows like (1-5 posts) Random.

https://stackoverflow.com/questions/16758316/where-do-i-find-the-instagram-media-id-of-a-image

*/


var gblActionsQueue = [];

function prettyDate(dataString) {

    if (dataString == false) return '-';

    var d = new Date(dataString);
    //var datePart = d.toISOString().slice(0, 10);

    var year = d.getFullYear();
    var month = String(d.getMonth() + 1).padStart(2, '0');
    var day = String(d.getDate()).padStart(2, '0');

    var datePart = year + '-' + month + '-' + day;

    // var timePart = d.toLocaleString([], {
    //     hour: '2-digit',
    //     minute: '2-digit'
    // });


    var timePart = d.getHours() + ':' + d.getMinutes();

    dataString = datePart + ' ' + timePart;
    return dataString;
}

function loadActionsQueue() {
    chrome.storage.local.get("gblActionsQueue", function(data) {
        if (typeof data.gblActionsQueue != 'undefined') {
            gblActionsQueue = data.gblActionsQueue;

            $('#tblScheduledActions').hide();
            $('#tblScheduledActions tbody').html('');


            for (var i = 0; i < gblActionsQueue.length; i++) {

                var tr = '<tr>';
                tr = tr + '<td>' + i + '</td>';
                tr = tr + '<td>' + gblActionsQueue[i].functionAlias + '</td>';
                tr = tr + '<td>' + gblActionsQueue[i].scheduledTime.replace('T', ' ') + '</td>';
                tr = tr + '<td>' + prettyDate(gblActionsQueue[i].ranAt) + '</td>';
                tr = tr + '<td>' + gblActionsQueue[i].repeatDaily + '</td>';
                tr = tr + '<td style="text-align: center;"><span class="minus-sign" data-scheduled-action="' + i + '">&minus;</span></td>';
                tr = tr + '</tr>';

                $('#tblScheduledActions tbody').append(tr);
                $('#tblScheduledActions').show();

            }


            $('#tblScheduledActions .minus-sign').click(function() {
                var pos = $(this).attr('data-scheduled-action');
                gblActionsQueue.splice(pos, 1);
                saveActionsQueue();
                setTimeout(loadActionsQueue, 100);
            })


        }
    });
}


function rdgActionRunner() {
    if (window.rdgUiLayoutUnlocked === false || localStorage.getItem('rdgAuthenticated') !== 'true') {
        return;
    }

    var nowTime = new Date().getTime();
    var nowDate = new Date().getDate();
    var yesterday = new Date(new Date().getTime() - (24 * 59 * 60 * 1000));
    var oneMinuteAgo = new Date(Date.now() - 1000 * 60);

    $('#currentTime').html('Current Time: ' + prettyDate(nowTime));

    for (var i = 0; i < gblActionsQueue.length; i++) {


        if (gblActionsQueue[i].enabled == true) {

            var shouldRunNow = false;
            var ranToday = true;
            var scheduledTime = new Date(gblActionsQueue[i].scheduledTime).getTime();
            var scheduledDate = new Date(gblActionsQueue[i].scheduledTime).getDate();


            // hack the scheduled time to be today if the scheduled time date has past and it's a daily repeater
            if (scheduledDate < nowDate && gblActionsQueue[i].repeatDaily == true) {
                var daysAgo = nowDate - scheduledDate;
                scheduledTime = new Date(scheduledTime + (daysAgo * 86400000));
            }

            if (gblActionsQueue[i].ranAt < yesterday && gblActionsQueue[i].repeatDaily == true) {
                // it ran, but that was more than 24 hours ago
                ranToday = false;
            }

            if (gblActionsQueue[i].ranAt == false) {
                // it never ran
                ranToday = false;
            }

            // the scheduled time has past
            if (scheduledTime < nowTime && ranToday == false) {
                shouldRunNow = true;
            }

            // it's stale, rdg wasn't running when the time came
            if (scheduledTime < oneMinuteAgo) {
                shouldRunNow = false;
            }


            if (shouldRunNow == true) {

                window[gblActionsQueue[i].functionName](arguments);
                gblActionsQueue[i].ranAt = nowTime;

                saveActionsQueue();
                setTimeout(loadActionsQueue, 100);
            }

        }
    }



}

function saveActionsQueue() {
    chrome.storage.local.set({
        gblActionsQueue: gblActionsQueue
    });
}

function btnAddScheduledAction() {

    // targetAccount
    // targetMedia
    // api endpoint
    // api method
    // nextfunction / callback

    // on failure delay all actions?


    // - result status code
    // - depends on other action?

    var yesterday = new Date(new Date().getTime() - (24 * 60 * 60 * 1000)).getTime();


    var action = {
        functionName: $('#scheduled_action_function_name').val(),
        functionAlias: $('#scheduled_action_function_name option:selected').text(),
        scheduledTime: $('#scheduled_action_scheduled_time').val(),
        ranAt: false,
        repeatDaily: $('#scheduled_action_repeat')[0].checked,
        enabled: true
    }


    gblActionsQueue.push(action);

    saveActionsQueue();

    setTimeout(loadActionsQueue, 100);
}

function rdgStoriesStorageSet(callback) {
    var payload = {};
    var key = rdgResolveStoriesScheduleStorageKey();
    payload[key] = rdgStoriesSchedule;
    try {
        var scopeId = rdgResolveStoriesStorageScopeId();
        var backupKey = scopeId ? ('rdgStoriesSchedule:backup:' + scopeId) : 'rdgStoriesSchedule:backup';
        payload[backupKey] = rdgStoriesSchedule;
    } catch (e) {}
    chrome.storage.local.set(payload, function() {
        if (callback) callback();
    });
}

function rdgStoriesStorageGet(keys) {
    return new Promise(function(resolve) {
        chrome.storage.local.get(keys, function(data) {
            resolve(data || {});
        });
    });
}

function rdgStoriesStorageSetAsync(payload) {
    return new Promise(function(resolve) {
        chrome.storage.local.set(payload || {}, function() {
            resolve();
        });
    });
}

function rdgStoriesStorageRemoveAsync(keys) {
    return new Promise(function(resolve) {
        chrome.storage.local.remove(keys, function() {
            resolve();
        });
    });
}

var rdgStoriesMediaDbPromise = null;
var RDG_STORIES_MEDIA_DB_NAME = 'rdgStoriesMediaDb';
var RDG_STORIES_MEDIA_STORE = 'storyMedia';
var RDG_STORIES_MAX_ITEMS = 10;
var RDG_STORIES_VIDEO_MAX_BYTES = 100 * 1024 * 1024;
var RDG_STORIES_VIDEO_RECOMMENDED_BYTES = 30 * 1024 * 1024;
var RDG_STORIES_VIDEO_MAX_DURATION_SEC = 60;

function rdgResolveStoriesStorageScopeId() {
    try {
        if (typeof rdgAssistantGetStorageScopeId === 'function') {
            var scopeId = rdgAssistantGetStorageScopeId();
            if (scopeId) return String(scopeId);
        }
    } catch (e) {}
    try {
        if (typeof rdgAssistantGetViewerUsername === 'function') {
            var viewer = rdgAssistantGetViewerUsername();
            if (viewer) return 'ig:' + String(viewer).toLowerCase();
        }
    } catch (e2) {}
    return '';
}

function rdgResolveStoriesScheduleStorageKey() {
    var scopeId = rdgResolveStoriesStorageScopeId();
    if (!scopeId) return 'rdgStoriesSchedule';
    return 'rdgStoriesSchedule:' + scopeId;
}

function rdgResolveStoriesScheduleStorageKeyCandidates() {
    var keys = [];
    var scoped = rdgResolveStoriesScheduleStorageKey();
    if (scoped) keys.push(scoped);
    var scopeId = rdgResolveStoriesStorageScopeId();
    if (scopeId) keys.push('rdgStoriesSchedule:backup:' + scopeId);
    keys.push('rdgStoriesSchedule');
    return keys;
}

function rdgIsVideoStoryItem(item) {
    return !!(item && item.mediaKind === 'video');
}

function rdgGetStoryMediaLabel(item) {
    return rdgIsVideoStoryItem(item) ? 'Video' : 'Imagem';
}

function rdgOpenStoriesMediaDb() {
    if (rdgStoriesMediaDbPromise) return rdgStoriesMediaDbPromise;
    rdgStoriesMediaDbPromise = new Promise(function(resolve, reject) {
        if (typeof indexedDB === 'undefined') {
            reject(new Error('O navegador nao disponibilizou IndexedDB para salvar os videos dos stories'));
            return;
        }
        var request = indexedDB.open(RDG_STORIES_MEDIA_DB_NAME, 1);
        request.onupgradeneeded = function(event) {
            var db = event.target.result;
            if (!db.objectStoreNames.contains(RDG_STORIES_MEDIA_STORE)) {
                db.createObjectStore(RDG_STORIES_MEDIA_STORE, { keyPath: 'id' });
            }
        };
        request.onsuccess = function() {
            resolve(request.result);
        };
        request.onerror = function() {
            reject(request.error || new Error('Falha ao abrir o banco de midias dos stories'));
        };
    });
    return rdgStoriesMediaDbPromise;
}

async function rdgStoriesMediaPut(id, payload) {
    var db = await rdgOpenStoriesMediaDb();
    return new Promise(function(resolve, reject) {
        var tx = db.transaction(RDG_STORIES_MEDIA_STORE, 'readwrite');
        tx.objectStore(RDG_STORIES_MEDIA_STORE).put($.extend({ id: id }, payload || {}));
        tx.oncomplete = function() { resolve(true); };
        tx.onerror = function() { reject(tx.error || new Error('Falha ao salvar a midia do story')); };
    });
}

async function rdgStoriesMediaGet(id) {
    var db = await rdgOpenStoriesMediaDb();
    return new Promise(function(resolve, reject) {
        var tx = db.transaction(RDG_STORIES_MEDIA_STORE, 'readonly');
        var request = tx.objectStore(RDG_STORIES_MEDIA_STORE).get(id);
        request.onsuccess = function() {
            resolve(request.result || null);
        };
        request.onerror = function() {
            reject(request.error || new Error('Falha ao ler a midia do story'));
        };
    });
}

async function rdgStoriesMediaDelete(id) {
    if (!id) return false;
    var db = await rdgOpenStoriesMediaDb();
    return new Promise(function(resolve, reject) {
        var tx = db.transaction(RDG_STORIES_MEDIA_STORE, 'readwrite');
        tx.objectStore(RDG_STORIES_MEDIA_STORE).delete(id);
        tx.oncomplete = function() { resolve(true); };
        tx.onerror = function() { reject(tx.error || new Error('Falha ao remover a midia do story')); };
    });
}

async function rdgStoriesMediaDeleteForItem(item) {
    if (!rdgIsVideoStoryItem(item)) return false;
    return rdgStoriesMediaDelete(item.mediaStorageKey || item.id);
}

function rdgXhrBinaryRequest(url, options) {
    options = options || {};
    return new Promise(function(resolve, reject) {
        var xhr = new XMLHttpRequest();
        xhr.open(options.method || 'POST', url, true);
        xhr.withCredentials = options.withCredentials !== false;
        xhr.timeout = parseInt(options.timeout || 0, 10) || 0;
        var headers = options.headers || {};
        Object.keys(headers).forEach(function(key) {
            if (typeof headers[key] != 'undefined' && headers[key] !== null) {
                xhr.setRequestHeader(key, String(headers[key]));
            }
        });
        xhr.onload = function() {
            resolve({
                ok: xhr.status >= 200 && xhr.status < 300,
                status: xhr.status,
                text: xhr.responseText || ''
            });
        };
        xhr.onerror = function() {
            reject(new Error('XMLHttpRequest network error'));
        };
        xhr.ontimeout = function() {
            reject(new Error('XMLHttpRequest timeout'));
        };
        xhr.send(typeof options.body == 'undefined' ? null : options.body);
    });
}

function rdgRuntimeSendMessageAsync(payload) {
    return new Promise(function(resolve, reject) {
        try {
            chrome.runtime.sendMessage(payload, function(response) {
                var lastError = chrome.runtime.lastError;
                if (lastError) {
                    reject(new Error(lastError.message || 'Falha ao comunicar com o background'));
                    return;
                }
                resolve(response);
            });
        } catch (err) {
            reject(err);
        }
    });
}

function rdgBlobChunkToBase64(blobChunk) {
    return new Promise(function(resolve, reject) {
        var reader = new FileReader();
        reader.onload = function(e) {
            var dataUrl = String((e && e.target && e.target.result) || '');
            resolve(dataUrl.split(',')[1] || '');
        };
        reader.onerror = function() {
            reject(new Error('Falha ao preparar um bloco do video para o background'));
        };
        reader.readAsDataURL(blobChunk);
    });
}

async function rdgUploadStoryVideoBinaryViaBackground(entityName, blob, headers) {
    var transferId = 'story_video_transfer_' + Date.now() + '_' + Math.random().toString(36).slice(2, 10);
    var chunkSize = 2 * 1024 * 1024;
    try {
        await rdgRuntimeSendMessageAsync({
            action: 'rdgStoryVideoUploadBufferInit',
            transferId: transferId,
            mimeType: 'video/mp4',
            totalBytes: blob.size
        });
        for (var offset = 0; offset < blob.size; offset += chunkSize) {
            var chunkBase64 = await rdgBlobChunkToBase64(blob.slice(offset, Math.min(offset + chunkSize, blob.size)));
            await rdgRuntimeSendMessageAsync({
                action: 'rdgStoryVideoUploadBufferChunk',
                transferId: transferId,
                chunk: chunkBase64
            });
        }
        var response = await rdgRuntimeSendMessageAsync({
            action: 'rdgStoryVideoUploadBufferCommit',
            transferId: transferId,
            url: 'https://i.instagram.com/rupload_igvideo/' + entityName,
            method: 'POST',
            headers: headers || {}
        });
        if (!response) {
            throw new Error('background nao retornou resposta do upload de video');
        }
        if (response.networkError) {
            throw new Error(response.message || 'background falhou ao enviar o video');
        }
        return {
            ok: !!response.ok,
            status: parseInt(response.status || 0, 10) || 0,
            text: response.text || ''
        };
    } catch (err) {
        rdgRuntimeSendMessageAsync({
            action: 'rdgStoryVideoUploadBufferCleanup',
            transferId: transferId
        }).catch(function() {});
        throw err;
    }
}

async function rdgRemoveStoryFromSchedule(storyId) {
    if (!storyId) return false;
    var removedItems = rdgStoriesSchedule.filter(function(item) {
        return item.id == storyId;
    });
    if (!removedItems.length) return false;
    rdgStoriesSchedule = rdgStoriesSchedule.filter(function(item) {
        return item.id != storyId;
    });
    await Promise.all(removedItems.map(function(item) {
        return rdgStoriesMediaDeleteForItem(item).catch(function() { return false; });
    }));
    await rdgSaveStoriesSchedulePromise();
    return true;
}

function rdgGetVideoMetadata(file) {
    return new Promise(function(resolve, reject) {
        var video = document.createElement('video');
        var objectUrl = URL.createObjectURL(file);
        var resolved = false;

        function cleanup() {
            try { URL.revokeObjectURL(objectUrl); } catch (e) {}
            video.removeAttribute('src');
            try { video.load(); } catch (e) {}
        }

        function fail(err) {
            if (resolved) return;
            resolved = true;
            cleanup();
            reject(err instanceof Error ? err : new Error(String(err || 'Falha ao ler o video')));
        }

        video.preload = 'metadata';
        video.muted = true;
        video.playsInline = true;

        video.onerror = function() {
            fail(new Error('Falha ao ler os metadados do video ' + (file && file.name ? file.name : '')));
        };

        video.onloadedmetadata = function() {
            var width = Math.round(video.videoWidth || 1080);
            var height = Math.round(video.videoHeight || 1920);
            var duration = Number(video.duration) || 0;
            var captureAt = Math.min(Math.max(duration > 0.25 ? 0.25 : 0, 0), Math.max(duration - 0.05, 0));

            if (!isFinite(duration) || duration <= 0) {
                fail(new Error('Nao foi possivel identificar a duracao do video ' + (file && file.name ? file.name : '')));
                return;
            }

            video.onseeked = function() {
                if (resolved) return;
                try {
                    var canvas = document.createElement('canvas');
                    canvas.width = width;
                    canvas.height = height;
                    var ctx = canvas.getContext('2d');
                    ctx.drawImage(video, 0, 0, width, height);
                    var posterDataUrl = canvas.toDataURL('image/jpeg', 0.9);
                    resolved = true;
                    cleanup();
                    resolve({
                        width: width,
                        height: height,
                        durationSec: duration,
                        posterDataUrl: posterDataUrl
                    });
                } catch (e) {
                    fail(new Error('Falha ao gerar a miniatura do video ' + (file && file.name ? file.name : '')));
                }
            };

            try {
                video.currentTime = captureAt;
            } catch (e) {
                video.onseeked();
            }
        };

        video.src = objectUrl;
    });
}

function rdgCreateStoryTextOverlay(base) {
    base = base || {};
    return {
        id: base.id || ('story_text_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8)),
        textContent: String(base.textContent || '').trim(),
        textColor: (base.textColor || '#FFFFFF').trim ? (base.textColor || '#FFFFFF').trim() : '#FFFFFF',
        textFontSize: rdgClamp(typeof base.textFontSize != 'undefined' ? base.textFontSize : 36, 12, 96),
        textFontFamily: base.textFontFamily || 'Arial',
        textPosX: rdgClamp(typeof base.textPosX != 'undefined' ? base.textPosX : 0.5, 0, 1),
        textPosY: rdgClamp(typeof base.textPosY != 'undefined' ? base.textPosY : 0.62, 0, 1)
    };
}

function rdgNormalizeStoryTextOverlays(item) {
    var overlays = Array.isArray(item && item.textOverlays) ? item.textOverlays : [];

    if (!overlays.length && item && (
        item.textContent ||
        typeof item.textColor != 'undefined' ||
        typeof item.textFontSize != 'undefined' ||
        typeof item.textFontFamily != 'undefined' ||
        typeof item.textPosX != 'undefined' ||
        typeof item.textPosY != 'undefined'
    )) {
        overlays = [rdgCreateStoryTextOverlay({
            textContent: item.textContent || '',
            textColor: item.textColor || '#FFFFFF',
            textFontSize: typeof item.textFontSize != 'undefined' ? item.textFontSize : 36,
            textFontFamily: item.textFontFamily || 'Arial',
            textPosX: typeof item.textPosX != 'undefined' ? item.textPosX : 0.5,
            textPosY: typeof item.textPosY != 'undefined' ? item.textPosY : 0.62
        })];
    }

    return overlays.map(function(overlay) {
        return rdgCreateStoryTextOverlay(overlay);
    });
}

function rdgSyncLegacyStoryTextFields(item) {
    var firstOverlay = Array.isArray(item.textOverlays) && item.textOverlays.length ? item.textOverlays[0] : null;
    item.textContent = firstOverlay ? firstOverlay.textContent : '';
    item.textColor = firstOverlay ? firstOverlay.textColor : '#FFFFFF';
    item.textFontSize = firstOverlay ? firstOverlay.textFontSize : 36;
    item.textFontFamily = firstOverlay ? firstOverlay.textFontFamily : 'Arial';
    item.textPosX = firstOverlay ? firstOverlay.textPosX : 0.5;
    item.textPosY = firstOverlay ? firstOverlay.textPosY : 0.62;
}

function rdgNormalizeStoriesSchedule(schedule) {
    if (!Array.isArray(schedule)) return [];

    schedule = schedule.filter(function(item) {
        return item && item.id && item.scheduledTime;
    }).map(function(item) {
        if (typeof item.enabled == 'undefined') item.enabled = true;
        if (typeof item.mediaKind == 'undefined') item.mediaKind = 'image';
        item.mediaKind = item.mediaKind === 'video' ? 'video' : 'image';
        item.mediaStorageKey = item.mediaStorageKey || item.id;
        item.videoDurationSec = Number(item.videoDurationSec || 0) || 0;
        item.fileSizeBytes = parseInt(item.fileSizeBytes || 0, 10) || 0;
        item.posterDataUrl = item.posterDataUrl || '';
        item.repeatDaily = item.repeatDaily === true;
        item.postedAt = parseInt(item.postedAt || 0, 10) || 0;
        item.lastPublishedAt = parseInt(item.lastPublishedAt || item.postedAt || 0, 10) || 0;
        item.postingStartedAt = parseInt(item.postingStartedAt || 0, 10) || 0;
        if (item.mediaKind === 'video') {
            item.imageFit = 'cover';
            item.imageScale = 1;
            item.imagePosX = 0.5;
            item.imagePosY = 0.5;
            item.textOverlays = [];
        }
        item.textOverlays = rdgNormalizeStoryTextOverlays(item);
        if (typeof item.locationName != 'undefined') delete item.locationName;
        if (typeof item.imageFit == 'undefined') item.imageFit = 'cover';
        if (typeof item.imageScale == 'undefined') item.imageScale = 1;
        if (typeof item.imagePosX == 'undefined') item.imagePosX = 0.5;
        if (typeof item.imagePosY == 'undefined') item.imagePosY = 0.5;
        rdgSyncLegacyStoryTextFields(item);
        return item;
    });

    schedule.sort(function(a, b) {
        return new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime();
    });

    return schedule;
}

function rdgLoadStoriesSchedule(callback) {
    var keys = rdgResolveStoriesScheduleStorageKeyCandidates();
    var scopedKey = rdgResolveStoriesScheduleStorageKey();
    chrome.storage.local.get(keys, function(data) {
        data = data || {};
        var chosenKey = '';
        var raw = null;
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            if (typeof data[key] === 'undefined') continue;
            raw = data[key];
            chosenKey = key;
            break;
        }
        rdgStoriesSchedule = rdgNormalizeStoriesSchedule(raw);
        if (chosenKey && scopedKey && chosenKey !== scopedKey) {
            rdgStoriesStorageSet(function() {
                rdgRenderStoriesSchedule();
                if (callback) callback(rdgStoriesSchedule);
            });
            return;
        }
        rdgRenderStoriesSchedule();
        if (callback) callback(rdgStoriesSchedule);
    });
}

function rdgSaveStoriesSchedule(callback) {
    rdgStoriesSchedule = rdgNormalizeStoriesSchedule(rdgStoriesSchedule);
    rdgStoriesStorageSet(function() {
        rdgRenderStoriesSchedule();
        if (callback) callback();
    });
}

function rdgLoadStoriesSchedulePromise() {
    return new Promise(function(resolve) {
        rdgLoadStoriesSchedule(function(schedule) {
            resolve(schedule || []);
        });
    });
}

function rdgSaveStoriesSchedulePromise() {
    return new Promise(function(resolve) {
        rdgSaveStoriesSchedule(function() {
            resolve();
        });
    });
}

function rdgEscapeHtml(txt) {
    return String(txt || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function rdgStoryStatusLabel(status) {
    if (status == 'posted') return 'Publicado';
    if (status == 'posting') return 'Publicando';
    if (status == 'error') return 'Erro';
    return 'Pendente';
}

function rdgParseSupabaseDate(dateStr) {
    if (!dateStr) return null;
    if (typeof dateStr === 'string') {
        let matchBR = dateStr.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})(?:\s+|T)?(?:(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/);
        if (matchBR && matchBR[3].length === 4) {
            let day = parseInt(matchBR[1], 10);
            let month = parseInt(matchBR[2], 10) - 1;
            let year = parseInt(matchBR[3], 10);
            let hours = matchBR[4] ? parseInt(matchBR[4], 10) : 0;
            let minutes = matchBR[5] ? parseInt(matchBR[5], 10) : 0;
            let seconds = matchBR[6] ? parseInt(matchBR[6], 10) : 0;
            let d = new Date(year, month, day, hours, minutes, seconds);
            if (!isNaN(d.getTime())) return d;
        }
    }
    let d = new Date(dateStr);
    if (!isNaN(d.getTime())) return d;
    return null;
}

function rdgEnforceLicenseExpiration() {
    if (localStorage.getItem('rdgAuthenticated') !== 'true') return false;
    let licenseDataStr = localStorage.getItem('rdgLicenseData');
    if (!licenseDataStr) return false;
    try {
        let licenseData = JSON.parse(licenseDataStr);
        if (licenseData && licenseData.expires_at) {
            let expirationDate = rdgParseSupabaseDate(licenseData.expires_at);
            if (expirationDate && !isNaN(expirationDate.getTime()) && expirationDate < new Date()) {
                console.warn("🚫 [RDG] Licença expirada:", licenseData.expires_at);
                localStorage.removeItem('rdgAuthenticated');
                localStorage.removeItem('rdgLicenseData');
                window.rdgUiLayoutUnlocked = false;
                $('#mainSection').hide();
                $('#divLoginWrapper').removeClass('rdg-hidden').attr('style', 'display: flex !important;');
                if (typeof showErrorPopup === 'function') {
                    showErrorPopup('Sua licença expirou em ' + rdgFormatDateTimePT(expirationDate, licenseData.expires_at) + '. Por favor, renove sua assinatura.');
                }
                return true;
            }
        }
    } catch(e) {}
    return false;
}

function rdgUpdateHeaderLicenseUI(licenseData) {
    if (!licenseData) return;
    if (licenseData.expires_at) {
        let d = rdgParseSupabaseDate(licenseData.expires_at);
        if (d && !isNaN(d.getTime()) && d < new Date()) {
            rdgEnforceLicenseExpiration();
            return;
        }
    }
    let clientPrefix = '';
    if (licenseData.cliente && licenseData.cliente.trim()) {
        clientPrefix = 'Bem-vindo(a), ' + licenseData.cliente.trim() + '  •  ';
    }
    let validityText = clientPrefix + 'Acesso Ativo e Validado';
    if (licenseData.expires_at) {
        let d = rdgParseSupabaseDate(licenseData.expires_at);
        if (d && !isNaN(d.getTime())) {
            validityText = clientPrefix + 'Sua licença é válida até ' + rdgFormatDateTimePT(d, licenseData.expires_at);
        }
    } else if (licenseData.status === 'lifetime' || licenseData.is_lifetime) {
        validityText = clientPrefix + 'Acesso Vitalício';
    }
    $('#h2FreeTrialTimeLeft').text(validityText).show();
}

function rdgFormatDateTimePT(d, originalStr) {
    if (!d || isNaN(d.getTime())) return '';
    let dateStr = d.toLocaleDateString('pt-BR');
    let hasExplicitTime = false;
    if (originalStr && typeof originalStr === 'string') {
        if (originalStr.includes(':') && !originalStr.includes('00:00:00') && !originalStr.includes('T00:00:00')) {
            hasExplicitTime = true;
        }
    } else if (d.getHours() !== 0 || d.getMinutes() !== 0) {
        hasExplicitTime = true;
    }
    if (hasExplicitTime) {
        let timeStr = d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
        if (timeStr !== '00:00') {
            return dateStr + ' às ' + timeStr;
        }
    }
    return dateStr;
}

function rdgFormatDatetimeLocalValue(date) {
    var d = date instanceof Date ? date : new Date(date);
    if (isNaN(d.getTime())) d = new Date();

    var year = d.getFullYear();
    var month = String(d.getMonth() + 1).padStart(2, '0');
    var day = String(d.getDate()).padStart(2, '0');
    var hours = String(d.getHours()).padStart(2, '0');
    var minutes = String(d.getMinutes()).padStart(2, '0');

    return year + '-' + month + '-' + day + 'T' + hours + ':' + minutes;
}

function rdgFormatScheduleDisplay(datetimeValue) {
    if (!datetimeValue) return '-';
    return datetimeValue.replace('T', ' ');
}

function rdgParseScheduleMs(datetimeValue) {
    var value = new Date(datetimeValue).getTime();
    return isFinite(value) ? value : 0;
}

function rdgStoryGetRepeatModeLabel(item) {
    return item && item.repeatDaily === true ? 'Todos os dias' : 'Apenas hoje';
}

function rdgBuildStoryPublishLockKey() {
    return 'rdgStoriesPublishLock';
}

function rdgResolveStoryPublishLockOwnerId() {
    var fallback = 'stories_lock_' + Date.now() + '_' + Math.random().toString(36).slice(2, 10);
    try {
        var storageKey = 'rdgStoriesPublishLockOwnerId';
        var stored = sessionStorage.getItem(storageKey);
        if (stored) return stored;
        sessionStorage.setItem(storageKey, fallback);
    } catch (e) {}
    return fallback;
}

async function rdgIsStoryPublishLockStale(currentLock) {
    if (!currentLock) return true;
    if (currentLock.expiresAt <= Date.now()) return true;
    var scheduleKey = rdgResolveStoriesScheduleStorageKey();
    var data = await rdgStoriesStorageGet(scheduleKey);
    var schedule = rdgNormalizeStoriesSchedule(data[scheduleKey]);
    var lockedStory = schedule.find(function(item) {
        return item && item.id == currentLock.storyId;
    });
    if (!lockedStory) return true;
    if (lockedStory.status !== 'posting') return true;
    if (!lockedStory.postingStartedAt) return true;
    return (Date.now() - lockedStory.postingStartedAt) >= (20 * 60 * 1000);
}

async function rdgAcquireStoryPublishLock(storyId) {
    var lockKey = rdgBuildStoryPublishLockKey();
    var now = Date.now();
    var data = await rdgStoriesStorageGet(lockKey);
    var currentLock = data[lockKey];
    if (currentLock && currentLock.owner !== rdgStoryPublishLockOwnerId && await rdgIsStoryPublishLockStale(currentLock)) {
        await rdgStoriesStorageRemoveAsync(lockKey);
        currentLock = null;
    }
    if (currentLock && currentLock.expiresAt > now && currentLock.owner !== rdgStoryPublishLockOwnerId) {
        return false;
    }
    var payload = {};
    payload[lockKey] = {
        owner: rdgStoryPublishLockOwnerId,
        storyId: storyId || '',
        acquiredAt: now,
        expiresAt: now + (10 * 60 * 1000)
    };
    await rdgStoriesStorageSetAsync(payload);
    var confirmData = await rdgStoriesStorageGet(lockKey);
    var confirmedLock = confirmData[lockKey];
    return !!(confirmedLock && confirmedLock.owner === rdgStoryPublishLockOwnerId);
}

async function rdgReleaseStoryPublishLock() {
    var lockKey = rdgBuildStoryPublishLockKey();
    var data = await rdgStoriesStorageGet(lockKey);
    var currentLock = data[lockKey];
    if (!currentLock || currentLock.owner === rdgStoryPublishLockOwnerId || currentLock.expiresAt <= Date.now()) {
        await rdgStoriesStorageRemoveAsync(lockKey);
    }
}

async function rdgHasForeignStoryPublishLock() {
    var lockKey = rdgBuildStoryPublishLockKey();
    var data = await rdgStoriesStorageGet(lockKey);
    var currentLock = data[lockKey];
    if (!currentLock) return false;
    if (await rdgIsStoryPublishLockStale(currentLock)) {
        await rdgStoriesStorageRemoveAsync(lockKey);
        return false;
    }
    return currentLock.owner !== rdgStoryPublishLockOwnerId;
}

function rdgComputeNextDailyStoryTime(item, nowMs) {
    var scheduledMs = rdgParseScheduleMs(item && item.scheduledTime);
    if (!scheduledMs) return '';
    var base = new Date(scheduledMs);
    var next = new Date(nowMs || Date.now());
    next.setSeconds(0, 0);
    next.setHours(base.getHours(), base.getMinutes(), 0, 0);
    if (next.getTime() <= (nowMs || Date.now())) {
        next.setDate(next.getDate() + 1);
    }
    return rdgFormatDatetimeLocalValue(next);
}

function rdgStoriesGetPublishGraceMs() {
    return 3 * 60 * 1000;
}

function rdgRescheduleMissedStories(now) {
    var changed = false;
    var graceMs = rdgStoriesGetPublishGraceMs();
    var cutoff = now - graceMs;

    for (var i = 0; i < rdgStoriesSchedule.length; i++) {
        var item = rdgStoriesSchedule[i];
        if (!item) continue;
        if (item.enabled === false) continue;
        if (item.status == 'posted') continue;
        if (item.status == 'posting' && item.postingStartedAt && (now - item.postingStartedAt) < (20 * 60 * 1000)) continue;

        var scheduledTime = rdgParseScheduleMs(item.scheduledTime);
        if (!scheduledTime) continue;
        if (scheduledTime > cutoff) continue;

        if (item.repeatDaily === true) {
            var nextTime = rdgComputeNextDailyStoryTime(item, now);
            if (nextTime && nextTime !== item.scheduledTime) {
                item.scheduledTime = nextTime;
                item.status = 'pending';
                item.postingStartedAt = 0;
                item.errorMessage = '';
                changed = true;
            }
            continue;
        }

        if (item.status !== 'error') {
            item.status = 'error';
            item.postingStartedAt = 0;
            item.errorMessage = 'Horario expirou. Ajuste o horario ou clique em Publicar Agora.';
            changed = true;
        }
    }

    return changed;
}

function rdgFindNextDueStoryItem(now, forceRun) {
    var nextItem = null;
    var graceMs = rdgStoriesGetPublishGraceMs();
    var cutoff = now - graceMs;
    for (var i = 0; i < rdgStoriesSchedule.length; i++) {
        var item = rdgStoriesSchedule[i];
        var scheduledTime = rdgParseScheduleMs(item.scheduledTime);
        if (item.enabled === false) continue;
        if (item.status == 'posted') continue;
        if (item.status == 'posting' && item.postingStartedAt && (now - item.postingStartedAt) < (20 * 60 * 1000)) continue;
        if (forceRun === true || (scheduledTime <= now && scheduledTime >= cutoff)) {
            if (!nextItem || scheduledTime < rdgParseScheduleMs(nextItem.scheduledTime)) {
                nextItem = item;
            }
        }
    }
    return nextItem;
}

function rdgReserveStoryScheduleSlot(baseTimeMs, intervalMs, occupiedSlots) {
    var safeBase = Math.max(Date.now(), parseInt(baseTimeMs || 0, 10) || 0);
    var safeInterval = Math.max(60000, parseInt(intervalMs || 0, 10) || 60000);
    var slot = safeBase;
    while (occupiedSlots[slot]) {
        slot += safeInterval;
    }
    occupiedSlots[slot] = true;
    return slot;
}

function rdgGetStoryById(storyId) {
    return rdgStoriesSchedule.find(function(entry) {
        return entry.id == storyId;
    }) || null;
}

function rdgSetDefaultStoriesStartTime() {
    var input = document.getElementById('storiesPlusStartAt');
    if (!input) return;

    if (!input.value) {
        var now = new Date(Date.now() + (2 * 60 * 1000));
        input.value = rdgFormatDatetimeLocalValue(now);
    }
}

function rdgReadFileAsDataUrl(file) {
    return new Promise(function(resolve, reject) {
        var reader = new FileReader();

        reader.onload = function(e) {
            resolve(e.target.result);
        };

        reader.onerror = function() {
            reject(new Error('Falha ao ler o arquivo ' + file.name));
        };

        reader.readAsDataURL(file);
    });
}

function rdgGetImageDimensions(dataUrl) {
    return new Promise(function(resolve, reject) {
        var img = new Image();

        img.onload = function() {
            resolve({
                width: img.naturalWidth || img.width || 1080,
                height: img.naturalHeight || img.height || 1920
            });
        };

        img.onerror = function() {
            reject(new Error('Falha ao ler as dimensoes da imagem'));
        };

        img.src = dataUrl;
    });
}

function rdgDataUrlToBlob(dataUrl) {
    var pieces = dataUrl.split(',');
    var header = pieces[0] || '';
    var data = pieces[1] || '';
    var mimeMatch = header.match(/data:([^;]+);base64/);
    var mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
    var byteString = atob(data);
    var array = new Uint8Array(byteString.length);

    for (var i = 0; i < byteString.length; i++) {
        array[i] = byteString.charCodeAt(i);
    }

    return new Blob([array], {
        type: mimeType
    });
}

function rdgGetStoryIntervalHours() {
    var value = parseFloat($('#storiesPlusIntervalHours').val() || '1');
    if (!isFinite(value) || value <= 0) value = 1;
    return value;
}

function rdgTruncate(txt, maxLength) {
    txt = String(txt || '');
    if (txt.length <= maxLength) return txt;
    return txt.slice(0, maxLength - 1) + '...';
}

function rdgFormatBytes(bytes) {
    var value = Number(bytes) || 0;
    if (value <= 0) return '0 B';
    if (value >= 1024 * 1024) return (value / (1024 * 1024)).toFixed(1) + ' MB';
    if (value >= 1024) return Math.round(value / 1024) + ' KB';
    return Math.round(value) + ' B';
}

function rdgStoryMetaText(item) {
    var parts = [];
    parts.push(rdgGetStoryMediaLabel(item));
    if (rdgIsVideoStoryItem(item)) {
        if (item.videoDurationSec) parts.push((Math.round(item.videoDurationSec * 10) / 10) + 's');
        if (item.fileSizeBytes) parts.push(rdgFormatBytes(item.fileSizeBytes));
        return parts.join(' | ');
    }
    var overlayCount = Array.isArray(item.textOverlays) ? item.textOverlays.filter(function(overlay) {
        return overlay && overlay.textContent;
    }).length : 0;
    if (overlayCount > 0) parts.push(overlayCount + ' texto(s)');
    return parts.length ? parts.join(' | ') : 'Sem elementos extras';
}

function rdgBuildStoryGalleryThumbHtml(item) {
    if (rdgIsVideoStoryItem(item) && item.posterDataUrl) {
        return '<div style="position:relative;">' +
            '<img class="storiesPlusGalleryThumb" src="' + item.posterDataUrl + '" alt="preview do video">' +
            '<div class="storiesPlusGalleryBadge" style="position:absolute;left:8px;top:8px;">VIDEO</div>' +
            '</div>';
    }
    return item.dataUrl ? '<img class="storiesPlusGalleryThumb" src="' + item.dataUrl + '" alt="story preview">' : '';
}

function rdgRenderStoriesSchedule() {
    var summary = $('#storiesPlusSummary');
    var gallery = $('#storiesPlusGallery');

    if (gallery.length === 0) return;

    gallery.html('');

    if (rdgStoriesSchedule.length === 0) {
        summary.text('Nenhum story carregado.');
        gallery.html('<div class="storiesPlusGalleryEmpty">Nenhuma imagem adicionada na galeria.</div>');
        return;
    }

    var pendingCount = 0;
    var postedCount = 0;
    var errorCount = 0;
    var enabledCount = 0;

    for (var i = 0; i < rdgStoriesSchedule.length; i++) {
        var item = rdgStoriesSchedule[i];
        var statusClass = item.status || 'pending';
        var details = item.errorMessage || (item.postedAt ? ('Publicado em ' + prettyDate(item.postedAt)) : 'Pronto para publicar');
        var galleryThumbHtml = rdgBuildStoryGalleryThumbHtml(item);
        var enabledChecked = item.enabled !== false ? 'checked="checked"' : '';

        if (statusClass == 'pending') pendingCount++;
        if (statusClass == 'posted') postedCount++;
        if (statusClass == 'error') errorCount++;
        if (item.enabled !== false) enabledCount++;

        gallery.append(
            '<div class="storiesPlusGalleryItem">' +
            '<div class="storiesPlusGalleryTop">' +
            galleryThumbHtml +
            '<div class="storiesPlusGalleryMeta">' +
            '<strong>' + rdgEscapeHtml(item.fileName) + '</strong>' +
            '<span class="storiesPlusStatus ' + rdgEscapeHtml(statusClass) + '">' + rdgEscapeHtml(rdgStoryStatusLabel(statusClass)) + '</span>' +
            '<div class="storiesPlusGalleryBadge">Story ' + (i + 1) + '</div>' +
            '<div class="storiesPlusMetaList">' +
            '<div><b>Horario:</b> ' + rdgEscapeHtml(rdgFormatScheduleDisplay(item.scheduledTime)) + '</div>' +
            '<div><b>Repeticao:</b> ' + rdgEscapeHtml(rdgStoryGetRepeatModeLabel(item)) + '</div>' +
            '<div><b>Elementos:</b> ' + rdgEscapeHtml(rdgStoryMetaText(item)) + '</div>' +
            '<div><b>Detalhes:</b> ' + rdgEscapeHtml(rdgTruncate(details, 64)) + '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '<div class="storiesPlusGalleryFooter">' +
            '<label class="storiesPlusToggle"><input type="checkbox" class="storiesFieldEnabled" data-story-id="' + rdgEscapeHtml(item.id) + '" ' + enabledChecked + '> Ativo na fila</label>' +
            '<div class="storiesPlusCardActions">' +
            '<span class="storiesPlusMiniBtn btnStoriesEdit" data-story-id="' + rdgEscapeHtml(item.id) + '">Editar Story</span>' +
            '<span class="storiesPlusMiniBtn btnStoriesRunOne" data-story-id="' + rdgEscapeHtml(item.id) + '">Publicar Agora</span>' +
            '<span class="storiesPlusMiniBtn btnStoriesDelete" data-story-id="' + rdgEscapeHtml(item.id) + '">Remover</span>' +
            '</div>' +
            '</div>' +
            '</div>'
        );
    }

    summary.text('Total: ' + rdgStoriesSchedule.length + ' | Ativos: ' + enabledCount + ' | Pendentes: ' + pendingCount + ' | Publicados: ' + postedCount + ' | Com erro: ' + errorCount);

    $('.btnStoriesDelete').off('click.storiesDelete').on('click.storiesDelete', function() {
        var storyId = $(this).attr('data-story-id');
        var removedItems = rdgStoriesSchedule.filter(function(item) {
            return item.id == storyId;
        });
        rdgStoriesSchedule = rdgStoriesSchedule.filter(function(item) {
            return item.id != storyId;
        });
        Promise.all(removedItems.map(function(item) {
            return rdgStoriesMediaDeleteForItem(item).catch(function() { return false; });
        })).finally(function() {
            rdgSaveStoriesSchedule();
        });
    });

    $('.storiesFieldEnabled').off('change.storiesEnabled').on('change.storiesEnabled', function() {
        var item = rdgGetStoryById($(this).attr('data-story-id'));
        if (!item) return;
        item.enabled = $(this).is(':checked');
        rdgSaveStoriesSchedule();
    });

    $('.btnStoriesRunOne').off('click.storiesRunOne').on('click.storiesRunOne', function() {
        var item = rdgGetStoryById($(this).attr('data-story-id'));
        if (!item) return;

        item.enabled = true;
        item.status = 'pending';
        item.errorMessage = '';
        item.scheduledTime = rdgFormatDatetimeLocalValue(new Date());
        rdgSaveStoriesSchedule(function() {
            rdgStorySchedulerTick(true);
        });
    });

    $('.btnStoriesEdit').off('click.storiesEdit').on('click.storiesEdit', function() {
        rdgOpenStoryEditor($(this).attr('data-story-id'));
    });
}

async function rdgQueueStoriesFromInput() {
    var input = document.getElementById('storiesPlusFiles');
    if (!input || !input.files || input.files.length === 0) {
        outputMessage('Stories +: selecione pelo menos uma imagem ou video.');
        return;
    }

    var startValue = $('#storiesPlusStartAt').val();
    var startTime = startValue ? new Date(startValue) : new Date(Date.now() + (2 * 60 * 1000));
    if (isNaN(startTime.getTime())) startTime = new Date(Date.now() + (2 * 60 * 1000));

    var intervalHours = rdgGetStoryIntervalHours();
    var repeatDaily = ($('#storiesPlusRepeatMode').val() || 'today') == 'daily';
    var files = Array.from(input.files);
    var remainingSlots = Math.max(0, RDG_STORIES_MAX_ITEMS - rdgStoriesSchedule.length);
    if (remainingSlots <= 0) {
        outputMessage('Stories +: limite maximo de ' + RDG_STORIES_MAX_ITEMS + ' stories na fila atingido.');
        return;
    }
    if (files.length > remainingSlots) {
        outputMessage('Stories +: voce pode adicionar no maximo ' + remainingSlots + ' story(s) agora. O limite total da fila e ' + RDG_STORIES_MAX_ITEMS + '.');
        return;
    }
    var queuedItems = [];
    var occupiedSlots = {};

    rdgStoriesSchedule.forEach(function(item) {
        if (!item || item.enabled === false) return;
        var slot = rdgParseScheduleMs(item.scheduledTime);
        if (!slot) return;
        if (item.status == 'posted' && item.repeatDaily !== true) return;
        occupiedSlots[slot] = true;
    });

    $('#btnStoriesPlusQueue').addClass('pulsing');

    try {
        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            var mimeType = String(file.type || '').toLowerCase();
            var isVideo = mimeType.indexOf('video/') === 0;
            if (isVideo && mimeType !== 'video/mp4' && mimeType !== 'video/quicktime') {
                throw new Error('Video "' + file.name + '" fora do formato aceito. Use MP4 ou MOV');
            }
            if (isVideo && file.size > RDG_STORIES_VIDEO_MAX_BYTES) {
                throw new Error('Video "' + file.name + '" excede o limite de 100 MB');
            }
            var requestedTimeMs = startTime.getTime() + (i * intervalHours * 60 * 60 * 1000);
            var reservedTimeMs = rdgReserveStoryScheduleSlot(requestedTimeMs, intervalHours * 60 * 60 * 1000, occupiedSlots);
            var scheduleDate = new Date(reservedTimeMs);
            var item = {
                id: 'story_' + Date.now() + '_' + i + '_' + Math.random().toString(36).slice(2, 8),
                fileName: file.name,
                mimeType: file.type || (isVideo ? 'video/mp4' : 'image/jpeg'),
                scheduledTime: rdgFormatDatetimeLocalValue(scheduleDate),
                status: 'pending',
                errorMessage: '',
                createdAt: Date.now(),
                postedAt: false,
                lastPublishedAt: 0,
                postingStartedAt: 0,
                enabled: true,
                repeatDaily: repeatDaily,
                textOverlays: [],
                textContent: '',
                textColor: '#FFFFFF',
                textFontSize: 36,
                textFontFamily: 'Arial',
                textPosX: 0.5,
                textPosY: 0.62,
                imageFit: 'cover',
                imageScale: 1,
                imagePosX: 0.5,
                imagePosY: 0.5,
                mediaKind: isVideo ? 'video' : 'image',
                mediaStorageKey: '',
                posterDataUrl: '',
                videoDurationSec: 0,
                fileSizeBytes: parseInt(file.size || 0, 10) || 0,
                width: 1080,
                height: 1920
            };

            if (isVideo) {
                var videoMeta = await rdgGetVideoMetadata(file);
                if (videoMeta.durationSec > RDG_STORIES_VIDEO_MAX_DURATION_SEC) {
                    throw new Error('Video "' + file.name + '" excede o limite de 60 segundos');
                }
                item.width = videoMeta.width;
                item.height = videoMeta.height;
                item.videoDurationSec = videoMeta.durationSec;
                item.posterDataUrl = videoMeta.posterDataUrl || '';
                item.mediaStorageKey = item.id;
                await rdgStoriesMediaPut(item.mediaStorageKey, {
                    kind: 'video',
                    blob: file,
                    mimeType: item.mimeType,
                    fileName: file.name,
                    savedAt: Date.now()
                });
                if (file.size > RDG_STORIES_VIDEO_RECOMMENDED_BYTES) {
                    outputMessage('Stories +: aviso - o video "' + file.name + '" esta acima do ideal de 30 MB e pode demorar mais para subir.');
                }
            } else {
                var dataUrl = await rdgReadFileAsDataUrl(file);
                var dimensions = await rdgGetImageDimensions(dataUrl);
                item.dataUrl = dataUrl;
                item.width = dimensions.width;
                item.height = dimensions.height;
            }

            queuedItems.push(item);
        }

        rdgStoriesSchedule = rdgStoriesSchedule.concat(queuedItems);
        rdgSaveStoriesSchedule(function() {
            outputMessage('Stories +: ' + queuedItems.length + ' story(s) agendado(s) com intervalo de ' + intervalHours + ' hora(s) em modo "' + (repeatDaily ? 'todos os dias' : 'apenas hoje') + '".');
            $('#storiesPlusFiles').val('');
            rdgSetDefaultStoriesStartTime();
        });
    } catch (err) {
        outputMessage('Stories +: erro ao preparar midias - ' + err.message);
    } finally {
        $('#btnStoriesPlusQueue').removeClass('pulsing');
    }
}

function rdgWrapCanvasText(ctx, text, maxWidth) {
    var words = String(text || '').split(/\s+/).filter(Boolean);
    var lines = [];
    var line = '';

    for (var i = 0; i < words.length; i++) {
        var testLine = line ? (line + ' ' + words[i]) : words[i];
        if (ctx.measureText(testLine).width > maxWidth && line) {
            lines.push(line);
            line = words[i];
        } else {
            line = testLine;
        }
    }

    if (line) lines.push(line);
    return lines;
}

function rdgCanvasRoundRect(ctx, x, y, width, height, radius) {
    var r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + width, y, x + width, y + height, r);
    ctx.arcTo(x + width, y + height, x, y + height, r);
    ctx.arcTo(x, y + height, x, y, r);
    ctx.arcTo(x, y, x + width, y, r);
    ctx.closePath();
}

function rdgClamp(value, min, max) {
    value = Number(value);
    if (!isFinite(value)) value = min;
    return Math.min(max, Math.max(min, value));
}

function rdgDrawImageWithLayout(ctx, img, canvasWidth, canvasHeight, layout) {
    var fit = layout.imageFit == 'contain' ? 'contain' : 'cover';
    var scale = Math.max(0.2, Number(layout.imageScale) || 1);
    var posX = rdgClamp(layout.imagePosX, 0, 1);
    var posY = rdgClamp(layout.imagePosY, 0, 1);
    var ratioBase = fit == 'contain'
        ? Math.min(canvasWidth / img.naturalWidth, canvasHeight / img.naturalHeight)
        : Math.max(canvasWidth / img.naturalWidth, canvasHeight / img.naturalHeight);
    var ratio = ratioBase * scale;
    var drawWidth = img.naturalWidth * ratio;
    var drawHeight = img.naturalHeight * ratio;
    var centerX = posX * canvasWidth;
    var centerY = posY * canvasHeight;
    var drawX = centerX - (drawWidth / 2);
    var drawY = centerY - (drawHeight / 2);

    ctx.drawImage(img, drawX, drawY, drawWidth, drawHeight);
}

async function rdgComposeStoryAsset(item) {
    return new Promise(function(resolve, reject) {
        var img = new Image();
        img.onload = function() {
            var canvas = document.createElement('canvas');
            var width = 1080;
            var height = 1920;
            canvas.width = width;
            canvas.height = height;
            var ctx = canvas.getContext('2d');

            rdgDrawImageWithLayout(ctx, img, width, height, item);

            var overlays = rdgNormalizeStoryTextOverlays(item).filter(function(overlay) {
                return overlay && overlay.textContent;
            });
            for (var overlayIndex = 0; overlayIndex < overlays.length; overlayIndex++) {
                var overlay = overlays[overlayIndex];
                var textColor = overlay.textColor || '#FFFFFF';
                var previewBaseWidth = 360;
                var scaleFactor = width / previewBaseWidth;
                var fontSize = Math.max(12, Math.round((Number(overlay.textFontSize) || 36) * scaleFactor));
                var textFontFamily = overlay.textFontFamily || 'Arial';
                var textX = rdgClamp(overlay.textPosX, 0, 1) * width;
                var textY = rdgClamp(overlay.textPosY, 0, 1) * height;
                ctx.font = '800 ' + fontSize + 'px "' + textFontFamily + '"';
                ctx.fillStyle = textColor;
                ctx.textAlign = 'center';
                ctx.shadowColor = 'rgba(0,0,0,0.45)';
                ctx.shadowBlur = Math.round(18 * scaleFactor);
                ctx.shadowOffsetX = 0;
                ctx.shadowOffsetY = Math.round(3 * scaleFactor);
                var lineHeight = 1.12;
                var textLines = rdgWrapCanvasText(ctx, overlay.textContent, width * 0.78);
                var startY = textY - (((textLines.length - 1) * fontSize * lineHeight) / 2);
                for (var j = 0; j < textLines.length; j++) {
                    ctx.fillText(textLines[j], textX, startY + (j * fontSize * lineHeight));
                }
                ctx.shadowBlur = 0;
                ctx.shadowOffsetX = 0;
                ctx.shadowOffsetY = 0;
            }

            canvas.toBlob(function(blob) {
                if (!blob) {
                    reject(new Error('Nao foi possivel compor a imagem do story'));
                    return;
                }

                resolve({
                    blob: blob,
                    mimeType: 'image/jpeg',
                    width: width,
                    height: height
                });
            }, 'image/jpeg', 0.92);
        };

        img.onerror = function() {
            reject(new Error('Falha ao preparar a imagem para o story'));
        };

        img.src = item.dataUrl;
    });
}

async function rdgUploadStoryPhoto(item) {
    var uploadId = String(Date.now()) + String(Math.floor(Math.random() * 1000)).padStart(3, '0');
    var entityName = 'story_' + uploadId;
    var composedAsset = await rdgComposeStoryAsset(item);
    var blob = composedAsset.blob;
    var uploadParams = {
        upload_id: uploadId,
        media_type: 1,
        upload_media_width: composedAsset.width || item.width || 1080,
        upload_media_height: composedAsset.height || item.height || 1920
    };

    var response = await fetch('https://i.instagram.com/rupload_igphoto/' + entityName, {
        method: 'POST',
        credentials: 'include',
        headers: {
            'content-type': composedAsset.mimeType || item.mimeType || 'image/jpeg',
            'offset': '0',
            'x-entity-length': String(blob.size),
            'x-entity-name': entityName,
            'x-ig-app-id': '936619743392459',
            'x-instagram-rupload-params': JSON.stringify(uploadParams)
        },
        body: blob
    });

    var text = await response.text();
    var json = {};

    try {
        json = JSON.parse(text);
    } catch (e) {}

    if (!response.ok) {
        throw new Error('upload falhou (' + response.status + '): ' + text.slice(0, 200));
    }

    if (json.status && json.status != 'ok') {
        throw new Error('upload retornou status invalido: ' + json.status);
    }

    return json.upload_id || uploadId;
}

async function rdgUploadStoryVideoThumbnail(uploadId, item) {
    var thumbnailDataUrl = item.posterDataUrl || '';
    if (!thumbnailDataUrl) {
        throw new Error('Nao foi possivel gerar a miniatura do video para o story');
    }

    var entityName = 'story_thumb_' + uploadId;
    var blob = rdgDataUrlToBlob(thumbnailDataUrl);
    var uploadParams = {
        upload_id: uploadId,
        media_type: 2,
        xsharing_user_ids: '[]',
        image_compression: JSON.stringify({ lib_name: 'moz', lib_version: '3.1.m', quality: '80' })
    };
    // #region debug-point D:video-thumbnail-start
    fetch("http://127.0.0.1:7778/event",{method:"POST",body:JSON.stringify({sessionId:"story-video-upload",runId:"post-fix",hypothesisId:"D",location:"contentscript.js:rdgUploadStoryVideoThumbnail:start",msg:"[DEBUG] inicio thumbnail video",data:{uploadId:uploadId,fileName:item&&item.fileName?item.fileName:"",thumbBytes:blob&&blob.size?blob.size:0},ts:Date.now()})}).catch(()=>{});
    // #endregion

    var response = await fetch('https://i.instagram.com/rupload_igphoto/' + entityName, {
        method: 'POST',
        credentials: 'include',
        headers: {
            'content-type': 'application/octet-stream',
            'offset': '0',
            'x-entity-length': String(blob.size),
            'x-entity-name': entityName,
            'x-entity-type': 'image/jpeg',
            'x-ig-app-id': '936619743392459',
            'x-instagram-rupload-params': JSON.stringify(uploadParams)
        },
        body: blob
    });

    var text = await response.text();
    var json = {};

    try {
        json = JSON.parse(text);
    } catch (e) {}
    // #region debug-point D:video-thumbnail-response
    fetch("http://127.0.0.1:7778/event",{method:"POST",body:JSON.stringify({sessionId:"story-video-upload",runId:"post-fix",hypothesisId:"D",location:"contentscript.js:rdgUploadStoryVideoThumbnail:response",msg:"[DEBUG] resposta thumbnail video",data:{status:response.status,ok:response.ok,textSample:String(text||"").slice(0,180)},ts:Date.now()})}).catch(()=>{});
    // #endregion

    if (!response.ok) {
        throw new Error('thumbnail do video falhou (' + response.status + '): ' + text.slice(0, 200));
    }
    if (json.status && json.status != 'ok') {
        throw new Error('thumbnail do video retornou status invalido: ' + json.status);
    }
    return true;
}

async function rdgUploadStoryVideo(item) {
    var mediaRecord = await rdgStoriesMediaGet(item.mediaStorageKey || item.id);
    if (!mediaRecord || !mediaRecord.blob) {
        throw new Error('O arquivo de video nao foi encontrado no armazenamento local do navegador');
    }

    var uploadId = String(Date.now()) + String(Math.floor(Math.random() * 1000)).padStart(3, '0');
    var entityName = uploadId + '_0_' + Math.floor(1000000000 + Math.random() * 8999999999);
    var waterfallId = 'story_video_' + Date.now() + '_' + Math.random().toString(36).slice(2, 12);
    var blob = mediaRecord.blob;
    var ruploadParams = {
        retry_context: '{"num_step_auto_retry":0,"num_reupload":0,"num_step_manual_retry":0}',
        media_type: '2',
        xsharing_user_ids: '[]',
        upload_id: uploadId,
        upload_media_duration_ms: String(Math.round((Number(item.videoDurationSec) || 0) * 1000)),
        upload_media_width: String(parseInt(item.width || 1080, 10) || 1080),
        upload_media_height: String(parseInt(item.height || 1920, 10) || 1920),
        extract_cover_frame: '1',
        content_tags: 'has-overlay',
        for_album: '1'
    };
    // #region debug-point A:video-upload-start
    fetch("http://127.0.0.1:7778/event",{method:"POST",body:JSON.stringify({sessionId:"story-video-upload",runId:"post-fix",hypothesisId:"A",location:"contentscript.js:rdgUploadStoryVideo:start",msg:"[DEBUG] inicio upload video story",data:{fileName:item&&item.fileName?item.fileName:"",mimeType:item&&item.mimeType?item.mimeType:"",blobType:blob&&blob.type?blob.type:"",blobSize:blob&&blob.size?blob.size:0,width:item&&item.width?item.width:0,height:item&&item.height?item.height:0,duration:item&&item.videoDurationSec?item.videoDurationSec:0,hasStorageKey:!!(item&&item.mediaStorageKey)},ts:Date.now()})}).catch(()=>{});
    // #endregion
    var response;
    try {
        // #region debug-point B:video-upload-request
        fetch("http://127.0.0.1:7778/event",{method:"POST",body:JSON.stringify({sessionId:"story-video-upload",runId:"post-fix",hypothesisId:"B",location:"contentscript.js:rdgUploadStoryVideo:request",msg:"[DEBUG] enviando binario video story",data:{transport:"background-chunked",url:"https://i.instagram.com/rupload_igvideo/"+entityName,headers:{offset:"0",entityName:entityName,entityLength:String(blob.size),entityType:"video/mp4",waterfallId:waterfallId},ruploadParams:ruploadParams},ts:Date.now()})}).catch(()=>{});
        // #endregion
        response = await rdgUploadStoryVideoBinaryViaBackground(entityName, blob, {
            'offset': '0',
            'x-entity-name': entityName,
            'x-entity-length': String(blob.size),
            'content-type': 'application/octet-stream',
            'x-entity-type': 'video/mp4',
            'x-instagram-rupload-params': JSON.stringify(ruploadParams),
            'x-fb-video-waterfall-id': waterfallId,
            'x-ig-app-id': '936619743392459'
        });
    } catch (err) {
        // #region debug-point C:video-upload-fetch-error
        fetch("http://127.0.0.1:7778/event",{method:"POST",body:JSON.stringify({sessionId:"story-video-upload",runId:"post-fix",hypothesisId:"C",location:"contentscript.js:rdgUploadStoryVideo:fetch-error",msg:"[DEBUG] transporte falhou no upload de video",data:{transport:"background-chunked",name:err&&err.name?err.name:"",message:err&&err.message?err.message:String(err||""),stack:err&&err.stack?String(err.stack).slice(0,500):""},ts:Date.now()})}).catch(()=>{});
        // #endregion
        throw new Error('falha de rede ao enviar o video. Tente MP4 mais leve, ideal ate 30 MB');
    }

    var text = response.text || '';
    var json = {};

    try {
        json = JSON.parse(text);
    } catch (e) {}
    // #region debug-point B:video-upload-response
    fetch("http://127.0.0.1:7778/event",{method:"POST",body:JSON.stringify({sessionId:"story-video-upload",runId:"post-fix",hypothesisId:"B",location:"contentscript.js:rdgUploadStoryVideo:response",msg:"[DEBUG] resposta upload video story",data:{transport:"background-chunked",status:response.status,ok:response.ok,textSample:String(text||"").slice(0,240)},ts:Date.now()})}).catch(()=>{});
    // #endregion

    if (!response.ok) {
        throw new Error('upload de video falhou (' + response.status + '): ' + text.slice(0, 240));
    }
    if (json.status && json.status != 'ok') {
        throw new Error('upload de video retornou status invalido: ' + json.status);
    }

    await rdgUploadStoryVideoThumbnail(uploadId, item);
    return json.upload_id || uploadId;
}

async function rdgConfigureStoryUpload(uploadId, item) {
    var body = new URLSearchParams();
    body.set('upload_id', uploadId);
    body.set('reel_mentions', '[]');
    if (rdgIsVideoStoryItem(item)) {
        body.set('length', String(Number(item.videoDurationSec || 0)));
        body.set('width', String(parseInt(item.width || 1080, 10) || 1080));
        body.set('height', String(parseInt(item.height || 1920, 10) || 1920));
        // #region debug-point E:video-configure-start
        fetch("http://127.0.0.1:7778/event",{method:"POST",body:JSON.stringify({sessionId:"story-video-upload",runId:"post-fix",hypothesisId:"E",location:"contentscript.js:rdgConfigureStoryUpload:start",msg:"[DEBUG] inicio configure story video",data:{uploadId:uploadId,fileName:item&&item.fileName?item.fileName:"",length:Number(item.videoDurationSec||0),width:parseInt(item.width||1080,10)||1080,height:parseInt(item.height||1920,10)||1920},ts:Date.now()})}).catch(()=>{});
        // #endregion
    }

    var response;
    var text = '';
    var json = {};
    var maxVideoConfigureAttempts = rdgIsVideoStoryItem(item) ? 8 : 1;
    for (var attempt = 1; attempt <= maxVideoConfigureAttempts; attempt++) {
        response = await fetch('https://www.instagram.com/api/v1/web/create/configure_to_story/' + (rdgIsVideoStoryItem(item) ? '?video=1' : ''), {
            method: 'POST',
            credentials: 'include',
            headers: {
                'content-type': 'application/x-www-form-urlencoded',
                'x-csrftoken': getCsrfFromCookie(),
                'x-ig-app-id': '936619743392459'
            },
            body: body.toString()
        });

        text = await response.text();
        json = {};

        try {
            json = JSON.parse(text);
        } catch (e) {}
        if (rdgIsVideoStoryItem(item)) {
            // #region debug-point E:video-configure-response
            fetch("http://127.0.0.1:7778/event",{method:"POST",body:JSON.stringify({sessionId:"story-video-upload",runId:"post-fix",hypothesisId:"E",location:"contentscript.js:rdgConfigureStoryUpload:response",msg:"[DEBUG] resposta configure story video",data:{attempt:attempt,status:response.status,ok:response.ok,textSample:String(text||"").slice(0,240)},ts:Date.now()})}).catch(()=>{});
            // #endregion
        }
        var needsTranscodeRetry = rdgIsVideoStoryItem(item) && response.status === 202 && String(text || '').toLowerCase().indexOf('transcode not finished yet') >= 0;
        if (!needsTranscodeRetry || attempt === maxVideoConfigureAttempts) {
            break;
        }
        await new Promise(function(resolve) { setTimeout(resolve, 4000); });
    }

    if (!response.ok) {
        var responseLowerText = String(text || '').toLowerCase();
        if (responseLowerText.indexOf('compartilhar links') >= 0 || responseLowerText.indexOf('share links') >= 0) {
            throw new Error('o Instagram bloqueou compartilhamento de links nesta conta; mantenha apenas o botao visual no story');
        }
        throw new Error('configure_to_story falhou (' + response.status + '): ' + text.slice(0, 250));
    }

    if (json.status && json.status != 'ok') {
        throw new Error('configure_to_story retornou status invalido: ' + json.status);
    }

    return json;
}

function rdgEditorGetGeneralFieldValues() {
    return {
        scheduledTime: $('#storiesEditorScheduledTime').val(),
        enabled: $('#storiesEditorEnabled').val() == '1',
        repeatDaily: ($('#storiesEditorRepeatMode').val() || 'today') == 'daily',
        imageFit: $('#storiesEditorImageFit').val() || 'cover',
        imageScale: rdgClamp($('#storiesEditorImageScale').val(), 0.2, 3),
        imagePosX: rdgClamp($('#storiesEditorImagePosX').val(), 0, 1),
        imagePosY: rdgClamp($('#storiesEditorImagePosY').val(), 0, 1)
    };
}

function rdgEditorGetTextFieldValues() {
    return {
        textContent: ($('#storiesEditorTextContent').val() || '').trim(),
        textColor: String($('#storiesEditorTextColor').val() || '#FFFFFF').trim() || '#FFFFFF',
        textFontSize: rdgClamp($('#storiesEditorTextFontSize').val(), 12, 96),
        textFontFamily: $('#storiesEditorTextFontFamily').val() || 'Arial',
        textPosX: rdgClamp($('#storiesEditorTextPosX').val(), 0, 1),
        textPosY: rdgClamp($('#storiesEditorTextPosY').val(), 0, 1)
    };
}

function rdgStoryEditorSetTextFieldsDisabled(disabled) {
    $('#storiesEditorTextContent, #storiesEditorTextColor, #storiesEditorTextFontSize, #storiesEditorTextFontFamily, #storiesEditorTextPosX, #storiesEditorTextPosY')
        .prop('disabled', !!disabled);
    $('#storiesEditorRemoveText').prop('disabled', !!disabled);
}

function rdgStoryEditorSetVideoMode(isVideo) {
    var disabled = !!isVideo;
    $('#storiesEditorImageFit, #storiesEditorImageScale, #storiesEditorImagePosX, #storiesEditorImagePosY')
        .prop('disabled', disabled);
    $('#storiesEditorAddText').prop('disabled', disabled);
    rdgStoryEditorSetTextFieldsDisabled(disabled);
}

function rdgStoryEditorClearTextFields() {
    $('#storiesEditorTextContent').val('');
    $('#storiesEditorTextColor').val('#ffffff');
    $('#storiesEditorTextFontSize').val(36);
    $('#storiesEditorTextFontFamily').val('Arial');
    $('#storiesEditorTextPosX').val(0.5);
    $('#storiesEditorTextPosY').val(0.62);
}

function rdgStoryEditorSyncActiveTextFromFields() {
    if (!Array.isArray(rdgStoryEditorDraftTexts)) rdgStoryEditorDraftTexts = [];
    if (rdgStoryEditorActiveTextIndex < 0 || rdgStoryEditorActiveTextIndex >= rdgStoryEditorDraftTexts.length) return;
    var current = rdgStoryEditorDraftTexts[rdgStoryEditorActiveTextIndex] || rdgCreateStoryTextOverlay();
    var values = rdgEditorGetTextFieldValues();
    current.textContent = values.textContent;
    current.textColor = values.textColor;
    current.textFontSize = values.textFontSize;
    current.textFontFamily = values.textFontFamily;
    current.textPosX = values.textPosX;
    current.textPosY = values.textPosY;
    rdgStoryEditorDraftTexts[rdgStoryEditorActiveTextIndex] = rdgCreateStoryTextOverlay(current);
}

function rdgStoryEditorLoadActiveTextFields() {
    if (!Array.isArray(rdgStoryEditorDraftTexts) || rdgStoryEditorActiveTextIndex < 0 || rdgStoryEditorActiveTextIndex >= rdgStoryEditorDraftTexts.length) {
        rdgStoryEditorClearTextFields();
        rdgStoryEditorSetTextFieldsDisabled(true);
        return;
    }

    var overlay = rdgCreateStoryTextOverlay(rdgStoryEditorDraftTexts[rdgStoryEditorActiveTextIndex]);
    $('#storiesEditorTextContent').val(overlay.textContent || '');
    $('#storiesEditorTextColor').val((overlay.textColor || '#ffffff').toLowerCase());
    $('#storiesEditorTextFontSize').val(typeof overlay.textFontSize != 'undefined' ? overlay.textFontSize : 36);
    $('#storiesEditorTextFontFamily').val(overlay.textFontFamily || 'Arial');
    $('#storiesEditorTextPosX').val(typeof overlay.textPosX != 'undefined' ? overlay.textPosX : 0.5);
    $('#storiesEditorTextPosY').val(typeof overlay.textPosY != 'undefined' ? overlay.textPosY : 0.62);
    rdgStoryEditorSetTextFieldsDisabled(false);
}

function rdgStoryEditorRenderTextBlocks() {
    var wrapper = $('#storiesEditorTextBlocks');
    if (wrapper.length === 0) return;

    if (!Array.isArray(rdgStoryEditorDraftTexts) || rdgStoryEditorDraftTexts.length === 0) {
        wrapper.html('<div class="storiesEditorEmptyTextList">Nenhum texto adicionado ainda. Clique em "Adicionar texto" para criar outro bloco na mesma imagem.</div>');
        return;
    }

    var html = '';
    for (var i = 0; i < rdgStoryEditorDraftTexts.length; i++) {
        var overlay = rdgStoryEditorDraftTexts[i] || {};
        var isActive = i === rdgStoryEditorActiveTextIndex ? ' active' : '';
        var preview = rdgEscapeHtml(rdgTruncate(overlay.textContent || 'Sem conteudo ainda', 52));
        html += '<div class="storiesEditorTextCard' + isActive + '" data-story-text-index="' + i + '">';
        html += '<div class="storiesEditorTextCardTitle">Texto ' + (i + 1) + '</div>';
        html += '<div class="storiesEditorTextCardBody">' + preview + '</div>';
        html += '</div>';
    }
    wrapper.html(html);
}

function rdgStoryEditorSelectText(index) {
    if (!Array.isArray(rdgStoryEditorDraftTexts)) rdgStoryEditorDraftTexts = [];
    if (rdgStoryEditorActiveTextIndex >= 0) rdgStoryEditorSyncActiveTextFromFields();

    if (typeof index != 'number' || index < 0 || index >= rdgStoryEditorDraftTexts.length) {
        rdgStoryEditorActiveTextIndex = -1;
    } else {
        rdgStoryEditorActiveTextIndex = index;
    }

    rdgStoryEditorRenderTextBlocks();
    rdgStoryEditorLoadActiveTextFields();
    rdgUpdateStoryEditorPreview();
}

function rdgStoryEditorAddTextBlock() {
    if (!Array.isArray(rdgStoryEditorDraftTexts)) rdgStoryEditorDraftTexts = [];
    if (rdgStoryEditorActiveTextIndex >= 0) rdgStoryEditorSyncActiveTextFromFields();
    rdgStoryEditorDraftTexts.push(rdgCreateStoryTextOverlay());
    rdgStoryEditorSelectText(rdgStoryEditorDraftTexts.length - 1);
}

function rdgStoryEditorRemoveActiveTextBlock() {
    if (!Array.isArray(rdgStoryEditorDraftTexts) || rdgStoryEditorActiveTextIndex < 0 || rdgStoryEditorActiveTextIndex >= rdgStoryEditorDraftTexts.length) return;
    rdgStoryEditorDraftTexts.splice(rdgStoryEditorActiveTextIndex, 1);
    var nextIndex = rdgStoryEditorDraftTexts.length ? Math.min(rdgStoryEditorActiveTextIndex, rdgStoryEditorDraftTexts.length - 1) : -1;
    rdgStoryEditorActiveTextIndex = -1;
    rdgStoryEditorSelectText(nextIndex);
}

function rdgApplyPreviewImageLayout(values) {
    var preview = document.getElementById('storiesEditorPreview');
    var img = document.getElementById('storiesEditorPreviewImage');
    if (!preview || !img) return;

    var previewRect = preview.getBoundingClientRect();
    var previewW = previewRect.width || 360;
    var previewH = previewRect.height || 640;
    var naturalW = Number(img.naturalWidth) || previewW;
    var naturalH = Number(img.naturalHeight) || previewH;
    var fit = values.imageFit == 'contain' ? 'contain' : 'cover';
    var baseRatio = fit == 'contain'
        ? Math.min(previewW / naturalW, previewH / naturalH)
        : Math.max(previewW / naturalW, previewH / naturalH);
    var ratio = baseRatio * (Number(values.imageScale) || 1);
    var drawW = naturalW * ratio;
    var drawH = naturalH * ratio;
    var centerX = rdgClamp(values.imagePosX, 0, 1) * previewW;
    var centerY = rdgClamp(values.imagePosY, 0, 1) * previewH;

    img.style.width = drawW + 'px';
    img.style.height = drawH + 'px';
    img.style.left = centerX + 'px';
    img.style.top = centerY + 'px';
    img.style.transform = 'translate(-50%, -50%)';
}

function rdgUpdateStoryEditorPreview() {
    var preview = $('#storiesEditorPreview');
    if (preview.length === 0) return;

    var item = rdgGetStoryById(rdgStoryEditorCurrentId);
    if (!item) return;

    var values = rdgEditorGetGeneralFieldValues();
    rdgStoryEditorSyncActiveTextFromFields();
    $('#storiesEditorPreviewVideo').hide().removeAttr('src');
    $('#storiesEditorPreviewImage').show().attr('src', rdgIsVideoStoryItem(item) ? (item.posterDataUrl || '') : (item.dataUrl || ''));
    rdgApplyPreviewImageLayout(values);
    var textLayer = $('#storiesEditorPreviewTextLayer');
    var html = '';
    var overlays = rdgIsVideoStoryItem(item) ? [] : (Array.isArray(rdgStoryEditorDraftTexts) ? rdgStoryEditorDraftTexts : []);

    for (var i = 0; i < overlays.length; i++) {
        var overlay = overlays[i];
        if (!overlay || !overlay.textContent) continue;
        var activeClass = i === rdgStoryEditorActiveTextIndex ? ' active' : '';
        html += '<div class="storiesEditorOverlayText' + activeClass + '" data-story-preview-text-index="' + i + '" style="' +
            'color:' + rdgEscapeHtml(overlay.textColor || '#FFFFFF') + ';' +
            'left:' + (rdgClamp(overlay.textPosX, 0, 1) * 100) + '%;' +
            'top:' + (rdgClamp(overlay.textPosY, 0, 1) * 100) + '%;' +
            'font-size:' + rdgClamp(overlay.textFontSize, 12, 96) + 'px;' +
            'font-family:&quot;' + rdgEscapeHtml(overlay.textFontFamily || 'Arial') + '&quot;;' +
        '">' + rdgEscapeHtml(overlay.textContent).replace(/\n/g, '<br>') + '</div>';
    }
    textLayer.html(html);
    rdgStoryEditorRenderTextBlocks();
}

function rdgOpenStoryEditor(storyId) {
    var item = rdgGetStoryById(storyId);
    if (!item) return;

    rdgStoryEditorCurrentId = storyId;
    rdgStoryEditorDraftTexts = rdgIsVideoStoryItem(item) ? [] : rdgNormalizeStoryTextOverlays(item);
    rdgStoryEditorActiveTextIndex = rdgStoryEditorDraftTexts.length ? 0 : -1;
    $('#storiesEditorScheduledTime').val(item.scheduledTime || rdgFormatDatetimeLocalValue(new Date()));
    $('#storiesEditorEnabled').val(item.enabled !== false ? '1' : '0');
    $('#storiesEditorRepeatMode').val(item.repeatDaily === true ? 'daily' : 'today');
    $('#storiesEditorImageFit').val(item.imageFit || 'cover');
    $('#storiesEditorImageScale').val(typeof item.imageScale != 'undefined' ? item.imageScale : 1);
    $('#storiesEditorImagePosX').val(typeof item.imagePosX != 'undefined' ? item.imagePosX : 0.5);
    $('#storiesEditorImagePosY').val(typeof item.imagePosY != 'undefined' ? item.imagePosY : 0.5);
    rdgStoryEditorSetVideoMode(rdgIsVideoStoryItem(item));
    rdgStoryEditorLoadActiveTextFields();

    $('.storiesEditorTabBtn').removeClass('active');
    $('.storiesEditorTabBtn[data-tab="general"]').addClass('active');
    $('.storiesEditorSection').removeClass('active');
    $('.storiesEditorSection[data-section="general"]').addClass('active');

    rdgUpdateStoryEditorPreview();
    $('#storiesEditorModal').css('display', 'flex');
}

function rdgCloseStoryEditor() {
    rdgStopStoryEditorDrag();
    rdgStoryEditorCurrentId = null;
    rdgStoryEditorDraftTexts = [];
    rdgStoryEditorActiveTextIndex = -1;
    $('#storiesEditorModal').hide();
}

function rdgSaveStoryEditor(runNow) {
    var item = rdgGetStoryById(rdgStoryEditorCurrentId);
    if (!item) return;

    var values = rdgEditorGetGeneralFieldValues();
    rdgStoryEditorSyncActiveTextFromFields();
    item.scheduledTime = values.scheduledTime || item.scheduledTime;
    item.enabled = values.enabled;
    item.repeatDaily = values.repeatDaily === true;
    if (!rdgIsVideoStoryItem(item)) {
        item.imageFit = values.imageFit;
        item.imageScale = values.imageScale;
        item.imagePosX = values.imagePosX;
        item.imagePosY = values.imagePosY;
        item.textOverlays = (Array.isArray(rdgStoryEditorDraftTexts) ? rdgStoryEditorDraftTexts : []).filter(function(overlay) {
            return overlay && String(overlay.textContent || '').trim();
        }).map(function(overlay) {
            return rdgCreateStoryTextOverlay(overlay);
        });
    } else {
        item.textOverlays = [];
    }
    rdgSyncLegacyStoryTextFields(item);

    if (runNow === true) {
        item.status = 'pending';
        item.errorMessage = '';
        item.scheduledTime = rdgFormatDatetimeLocalValue(new Date());
    }

    rdgSaveStoriesSchedule(function() {
        outputMessage('Stories +: story atualizado para ' + item.fileName);
        rdgCloseStoryEditor();
        if (runNow === true) rdgStorySchedulerTick(true);
    });
}

function rdgStartStoryEditorDrag(type, event, textIndex) {
    var preview = document.getElementById('storiesEditorPreview');
    if (!preview || !rdgStoryEditorCurrentId) return;

    event.preventDefault();
    if (type == 'text') {
        rdgStoryEditorSelectText(textIndex);
    }
    var previewRect = preview.getBoundingClientRect();
    var startValues = type == 'text' && Array.isArray(rdgStoryEditorDraftTexts) && rdgStoryEditorDraftTexts[textIndex]
        ? {
            textPosX: rdgStoryEditorDraftTexts[textIndex].textPosX,
            textPosY: rdgStoryEditorDraftTexts[textIndex].textPosY
        }
        : rdgEditorGetGeneralFieldValues();
    rdgStoryEditorDragState = {
        type: type,
        textIndex: typeof textIndex == 'number' ? textIndex : -1,
        previewRect: previewRect,
        startX: event.clientX,
        startY: event.clientY,
        startValues: startValues
    };

    $(event.currentTarget).addClass('dragging storiesEditorDraggableActive');
    $(document).on('mousemove.storiesEditorDrag', rdgHandleStoryEditorDragMove);
    $(document).on('mouseup.storiesEditorDrag', rdgStopStoryEditorDrag);
}

function rdgHandleStoryEditorDragMove(event) {
    if (!rdgStoryEditorDragState) return;

    var state = rdgStoryEditorDragState;
    var dx = event.clientX - state.startX;
    var dy = event.clientY - state.startY;
    var previewW = state.previewRect.width || 360;
    var previewH = state.previewRect.height || 640;

    if (state.type == 'text') {
        if (!Array.isArray(rdgStoryEditorDraftTexts) || state.textIndex < 0 || state.textIndex >= rdgStoryEditorDraftTexts.length) return;
        var nextTextPosX = rdgClamp(state.startValues.textPosX + (dx / previewW), 0, 1);
        var nextTextPosY = rdgClamp(state.startValues.textPosY + (dy / previewH), 0, 1);
        rdgStoryEditorDraftTexts[state.textIndex].textPosX = nextTextPosX;
        rdgStoryEditorDraftTexts[state.textIndex].textPosY = nextTextPosY;
        if (rdgStoryEditorActiveTextIndex === state.textIndex) {
            $('#storiesEditorTextPosX').val(nextTextPosX.toFixed(2));
            $('#storiesEditorTextPosY').val(nextTextPosY.toFixed(2));
        }
    } else if (state.type == 'image') {
        $('#storiesEditorImagePosX').val(rdgClamp(state.startValues.imagePosX + (dx / previewW), 0, 1).toFixed(2));
        $('#storiesEditorImagePosY').val(rdgClamp(state.startValues.imagePosY + (dy / previewH), 0, 1).toFixed(2));
    }

    rdgUpdateStoryEditorPreview();
}

function rdgStopStoryEditorDrag() {
    rdgStoryEditorDragState = null;
    $('#storiesEditorPreviewImage, .storiesEditorOverlayText').removeClass('dragging storiesEditorDraggableActive');
    $(document).off('mousemove.storiesEditorDrag mouseup.storiesEditorDrag');
}

function rdgAssistantPauseForStoriesPublishing(waitMs, reason) {
    if (!rdgAssistantState || !rdgAssistantState.run) return false;
    var run = rdgAssistantState.run;
    if (['running', 'waiting_instagram'].indexOf(run.status) === -1) return false;
    var now = Date.now();
    var delayMs = Math.max(5000, parseInt(waitMs || 0, 10) || 0);
    var resumePhase = run.phase && run.phase !== 'waiting_instagram' ? run.phase : (run.resumePhase || 'collecting');
    run.status = 'waiting_instagram';
    run.resumePhase = resumePhase;
    run.waitReason = reason || 'stories_publish';
    run.waitUntil = Math.max(parseInt(run.waitUntil || 0, 10) || 0, now + delayMs);
    run.updatedAt = now;
    rdgAssistantSetAccountWorkLastTickAt(0);
    rdgAssistantSetLiveProgress('Stories publicados. Aguardando para retomar a campanha.', '', run.waitUntil, 'Retomada automatica');
    try {
        rdgStopAllPendingActions('Aguardando apos postagem de stories.');
    } catch (e) {}
    rdgAssistantEnsureWaitResumeTimer();
    try { rdgAssistantSaveState(); } catch (e2) {}
    try { rdgAssistantRender(); } catch (e3) {}
    return true;
}

async function rdgPublishStoryItem(storyId) {
    if (!storyId || rdgStoryPublishInProgress === true) return false;
    rdgStoryPublishInProgress = true;
    var lockAcquired = false;

    try {
        lockAcquired = await rdgAcquireStoryPublishLock(storyId);
        if (!lockAcquired) return false;

        await rdgLoadStoriesSchedulePromise();
        var item = rdgGetStoryById(storyId);
        if (!item || item.enabled === false) return false;
        if (item.status == 'posted') return false;

        item.status = 'posting';
        item.postingStartedAt = Date.now();
        item.errorMessage = '';
        await rdgSaveStoriesSchedulePromise();

        rdgAssistantPauseForStoriesPublishing(20000, 'stories_publish_start');
        outputMessage('Stories +: iniciando publicacao de ' + item.fileName);

        var uploadId = rdgIsVideoStoryItem(item)
            ? await rdgUploadStoryVideo(item)
            : await rdgUploadStoryPhoto(item);
        var result = await rdgConfigureStoryUpload(uploadId, item);
        var finishedAt = Date.now();

        if (item.repeatDaily === true) {
            item.status = 'pending';
            item.scheduledTime = rdgComputeNextDailyStoryTime(item, finishedAt);
            item.postedAt = finishedAt;
            item.lastPublishedAt = finishedAt;
            item.postingStartedAt = 0;
            item.errorMessage = '';
            item.mediaPk = result && result.media ? (result.media.pk || result.media.id || '') : '';
            await rdgSaveStoriesSchedulePromise();
            outputMessage('Stories +: story publicado com sucesso para ' + item.fileName + ' | proximo disparo em ' + rdgFormatScheduleDisplay(item.scheduledTime));
            rdgAssistantPauseForStoriesPublishing(20000, 'stories_publish_done');
            return true;
        }

        var publishedFileName = item.fileName;
        await rdgRemoveStoryFromSchedule(storyId);
        outputMessage('Stories +: story publicado com sucesso para ' + publishedFileName + ' e removido da lista por estar marcado como "Apenas hoje".');
        rdgAssistantPauseForStoriesPublishing(20000, 'stories_publish_done');
        return true;
    } catch (err) {
        await rdgLoadStoriesSchedulePromise();
        var failedItem = rdgGetStoryById(storyId);
        if (failedItem) {
            failedItem.status = 'error';
            failedItem.postingStartedAt = 0;
            failedItem.errorMessage = err && err.message ? err.message : String(err || 'erro desconhecido');
            await rdgSaveStoriesSchedulePromise();
            outputMessage('Stories +: erro ao publicar ' + failedItem.fileName + ' - ' + failedItem.errorMessage);
        }
        rdgAssistantPauseForStoriesPublishing(20000, 'stories_publish_error');
        return false;
    } finally {
        if (lockAcquired) await rdgReleaseStoryPublishLock();
        rdgStoryPublishInProgress = false;
    }
}

function rdgRunNextStoryNow() {
    rdgLoadStoriesSchedule(function() {
        var nextItem = rdgStoriesSchedule.find(function(item) {
            return item.enabled !== false && (item.status == 'pending' || item.status == 'error');
        });

        if (!nextItem) {
            outputMessage('Stories +: nenhum story pendente para publicar agora.');
            return;
        }

        nextItem.status = 'pending';
        nextItem.errorMessage = '';
        nextItem.scheduledTime = rdgFormatDatetimeLocalValue(new Date());
        rdgSaveStoriesSchedule(function() {
            rdgStorySchedulerTick(true);
        });
    });
}

async function rdgStorySchedulerTick(forceRun) {
    if (rdgStoryPublishInProgress === true) {
        rdgAssistantPauseForStoriesPublishing(20000, 'stories_publish_in_progress');
        return;
    }
    if (await rdgHasForeignStoryPublishLock()) {
        if (forceRun === true) {
            outputMessage('Stories +: existe outra publicacao de story em andamento ou um lock ainda ativo. Aguarde alguns instantes e tente novamente.');
        }
        return;
    }

    await rdgLoadStoriesSchedulePromise();
    var now = Date.now();
    if (forceRun !== true) {
        var changed = rdgRescheduleMissedStories(now);
        if (changed) {
            await rdgSaveStoriesSchedulePromise();
        }
    }
    var nextItem = rdgFindNextDueStoryItem(now, forceRun === true);

    if (nextItem) {
        rdgAssistantPauseForStoriesPublishing(20000, 'stories_publish_due');
        await rdgPublishStoryItem(nextItem.id);
    }
}

function rdgStartStoriesScheduler() {
    if (rdgStorySchedulerIntervalId) {
        clearInterval(rdgStorySchedulerIntervalId);
    }

    rdgStorySchedulerIntervalId = setInterval(function() {
        rdgStorySchedulerTick(false);
    }, 15000);

    setTimeout(function() {
        rdgStorySchedulerTick(false);
    }, 3000);
}

function initStoriesPlusUi() {
    return;
}

const igExternalVars = {
    "emptyProfilePicUrl": "44884218_345707102882519_2446069589734326272_n",
    "qsForConvenienceButtons": "._aacl._aaco._aacw._aacx._aad6._aade",
    "qsForProfilePageUsername": "a.x1i10hfl h2.x1lliihq"
}

var gblAcctsQueueGrid;
var gblCheckboxPlugin;

var instabot_install_date = 0; // set from background page
var instabot_free_trial_time = 0; // set from background page
var instabot_has_license = false;

var defaultFilterOptions = {
    applyFiltersAutomatically: true,
    followers: [300, 20000],
    following: [0, 10000],
    followRatio: [-10000, 10000000],
    mutualFollowedBy: [0, 10000000],
    posts: [0, 100000],
    lastPosted: [0, 5000],
    private: true,
    non_private: true,
    verified: true,
    non_verified: true,
    follows_me: false,
    non_follows_me: true,
    followed_by_me: false,
    non_followed_by_me: true,
    external_url_contains: false,
    external_url_not_contains: false,
    external_url_contains_text: '',
    external_url_not_contains_text: '',
    is_business_account: true,
    non_is_business_account: true,
    is_joined_recently: true,
    non_is_joined_recently: true,
    connected_fb_page: true,
    non_connected_fb_page: true,
    bio_contains: false,
    bio_not_contains: false,
    bio_contains_text: '',
    bio_not_contains_text: '',
    no_profile_pic: true,
    profile_pic: true,
    business_category_name_contains: false,
    business_category_name_contains_text: '',
    business_category_name_not_contains: false,
    business_category_name_not_contains_text: ''
};


var gbDefaultColumns = [{
    "name": '✓',
    "data": 'id',
    "width": '40px',
    "formatter": '<input type="checkbox" id="cb_${cell}" value="${cell}" />',
    "visible": true,
}, {
    "name": 'Pic',
        "data": 'profile_pic_url',
        "formatter": '<label class="igBotQueueAcctLabel" for="cb_${ig_id}"><img data-ig-userid="${ig_id}" data-src="${cell}" class="igBotQueueAcctProfilePicture"/></label>',
        "sort": false,
        "width": '110px',
        "visible": true
    }, {
    "name": '@username',
    "data": 'username',
    "formatter": '<a href="https://www.instagram.com/${cell}" target="_blank">@${cell}</a>',
    "width": '165px',
    "visible": true
}, {
    "name": 'Full Name',
    "data": 'full_name',
    "width": '150px',
    "visible": true
}, {
    "name": 'Bio',
    "data": 'biography',
    "width": '300px',
    "visible": false
}, {
    "name": 'Clips',
    "data": 'has_clips',
    "width": '95px',
    "visible": false
}, {
    "name": 'Highlights',
    "data": 'highlight_reel_count',
    "width": '95px',
    "visible": false
}, {
    "name": 'Posts',
    "data": 'edge_owner_to_timeline_media.count',
    "width": '65px',
    "visible": false
}, {
    "name": 'Link In Bio',
    "data": 'external_url',
    "formatter": '<a href="${cell}" title="${cell}" target="_blank">${cell}</a>',
    "width": '250px',
    "visible": false
}, {
    "name": 'Followers',
    "data": 'edge_followed_by.count',
    "width": '90px',
    "visible": false
}, {
    "name": 'Following',
    "data": 'edge_follow.count',
    "width": '90px',
    "visible": false
}, {
    "name": 'Ratio',
    "data": 'followRatio',
    "width": '65px',
    "visible": false
}, {
    "name": 'Mutual',
    "data": 'edge_mutual_followed_by.count',
    "width": '70px',
    "visible": false,
    "numeric": true
}, {
    "name": 'Followed By Me',
    "data": 'followed_by_viewer',
    "width": '120px',
    "visible": false,
    "bool": true
}, {
    "name": 'Follows Me',
    "data": 'follows_viewer',
    "width": '95px',
    "visible": false,
    "bool": true
}, {
    "name": 'Requested',
    "data": 'requested_by_viewer',
    "width": '95px',
    "visible": false,
    "bool": true
}, {
    "name": 'Joined Recently',
    "data": 'is_joined_recently',
    "width": '100px',
    "visible": false,
    "bool": true
}, {
    "name": 'Private',
    "data": 'is_private',
    "width": '70px',
    "visible": false,
    "bool": true
}, {
    "name": 'Verified',
    "data": 'is_verified',
    "width": '70px',
    "visible": false,
    "bool": true
}, {
    "name": 'Business Category',
    "data": 'business_category_name',
    "width": '150px',
    "visible": false
}, {
    "name": 'Pronouns',
    "data": 'pronouns',
    "width": '90px',
    "visible": false
}, {
    "name": 'Last Posted',
    "data": 'lastPostDateInDays',
    "width": '100px',
    "visible": false
}, {
    "name": "Contact Phone Number",
    "data": "contact_phone_number",
    "visible": false
}, {
    "name": "Public Email",
    "data": "public_email",
    "visible": false
}, {
    "name": "Address Street",
    "data": "address_street",
    "visible": false
}, {
    "name": "City Name",
    "data": "city_name",
    "visible": false
}, {
    "name": "Zip",
    "data": "zip",
    "visible": false
}, {
    "name": "Latitude",
    "data": "latitude",
    "visible": false
}, {
    "name": "Longitude",
    "data": "longitude",
    "visible": false
}, {
    "name": "Primary Profile Link Type",
    "data": "primary_profile_link_type",
    "visible": false
}, {
    "name": "Show Fb Link On Profile",
    "data": "show_fb_link_on_profile",
    "visible": false
}, {
    "name": "Show Fb Page Link On Profile",
    "data": "show_fb_page_link_on_profile",
    "visible": false
}, {
    "name": "Can Hide Category",
    "data": "can_hide_category",
    "visible": false,
    "bool": true
}, {
    "name": "Smb Support Partner",
    "data": "smb_support_partner",
    "visible": false
}, {
    "name": "Current Catalog Id",
    "data": "current_catalog_id",
    "visible": false
}, {
    "name": "Mini Shop Seller Onboarding Status",
    "data": "mini_shop_seller_onboarding_status",
    "visible": false
}, {
    "name": "Account Category",
    "data": "account_category",
    "visible": false
}, {
    "name": "Can Add Fb Group Link On Profile",
    "data": "can_add_fb_group_link_on_profile",
    "visible": false,
    "bool": true
}, {
    "name": "Can Use Affiliate Partnership Messaging As Creator",
    "data": "can_use_affiliate_partnership_messaging_as_creator",
    "visible": false,
    "bool": true
}, {
    "name": "Can Use Affiliate Partnership Messaging As Brand",
    "data": "can_use_affiliate_partnership_messaging_as_brand",
    "visible": false
}, {
    "name": "Existing User Age Collection Enabled",
    "data": "existing_user_age_collection_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Feed Post Reshare Disabled",
    "data": "feed_post_reshare_disabled",
    "visible": false,
    "bool": true
}, {
    "name": "Has Public Tab Threads",
    "data": "has_public_tab_threads",
    "visible": false,
    "bool": true
}, {
    "name": "Highlight Reshare Disabled",
    "data": "highlight_reshare_disabled",
    "visible": false,
    "bool": true
}, {
    "name": "Include Direct Blacklist Status",
    "data": "include_direct_blacklist_status",
    "visible": false,
    "bool": true
}, {
    "name": "Is Direct Roll Call Enabled",
    "data": "is_direct_roll_call_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Pk",
    "data": "pk",
    "visible": false
}, {
    "name": "Pk Id",
    "data": "pk_id",
    "visible": false
}, {
    "name": "Profile Type",
    "data": "profile_type",
    "visible": false
}, {
    "name": "Show Ig App Switcher Badge",
    "data": "show_ig_app_switcher_badge",
    "visible": false,
    "bool": true
}, {
    "name": "Show Post Insights Entry Point",
    "data": "show_post_insights_entry_point",
    "visible": false,
    "bool": true
}, {
    "name": "Show Text Post App Badge",
    "data": "show_text_post_app_badge",
    "visible": false,
    "bool": true
}, {
    "name": "Show Text Post App Switcher Badge",
    "data": "show_text_post_app_switcher_badge",
    "visible": false,
    "bool": true
}, {
    "name": "Text Post App Joiner Number Label",
    "data": "text_post_app_joiner_number_label",
    "visible": false
}, {
    "name": "Third Party Downloads Enabled",
    "data": "third_party_downloads_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Is Profile Picture Expansion Enabled",
    "data": "is_profile_picture_expansion_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Is Opal Enabled",
    "data": "is_opal_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Can Hide Public Contacts",
    "data": "can_hide_public_contacts",
    "visible": false,
    "bool": true
}, {
    "name": "Is Category Tappable",
    "data": "is_category_tappable",
    "visible": false,
    "bool": true
}, {
    "name": "Is Eligible For Smb Support Flow",
    "data": "is_eligible_for_smb_support_flow",
    "visible": false,
    "bool": true
}, {
    "name": "Is Eligible For Lead Center",
    "data": "is_eligible_for_lead_center",
    "visible": false,
    "bool": true
}, {
    "name": "Lead Details App Id",
    "data": "lead_details_app_id",
    "visible": false,
    "bool": true
}, {
    "name": "Direct Messaging",
    "data": "direct_messaging",
    "visible": false
}, {
    "name": "Fb Page Call To Action Id",
    "data": "fb_page_call_to_action_id",
    "visible": false
}, {
    "name": "Displayed Action Button Partner",
    "data": "displayed_action_button_partner",
    "visible": false
}, {
    "name": "Smb Delivery Partner",
    "data": "smb_delivery_partner",
    "visible": false
}, {
    "name": "Smb Support Delivery Partner",
    "data": "smb_support_delivery_partner",
    "visible": false
}, {
    "name": "Displayed Action Button Type",
    "data": "displayed_action_button_type",
    "visible": false
}, {
    "name": "Is Call To Action Enabled",
    "data": "is_call_to_action_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Shopping Post Onboard Nux Type",
    "data": "shopping_post_onboard_nux_type",
    "visible": false
}, {
    "name": "Ads Incentive Expiration Date",
    "data": "ads_incentive_expiration_date",
    "visible": false
}, {
    "name": "Account Badges",
    "data": "account_badges",
    "visible": false
}, {
    "name": "Auto Expand Chaining",
    "data": "auto_expand_chaining",
    "visible": false
}, {
    "name": "Birthday Today Visibility For Viewer",
    "data": "birthday_today_visibility_for_viewer",
    "visible": false
}, {
    "name": "Can Use Branded Content Discovery As Brand",
    "data": "can_use_branded_content_discovery_as_brand",
    "visible": false
}, {
    "name": "Can Use Branded Content Discovery As Creator",
    "data": "can_use_branded_content_discovery_as_creator",
    "visible": false
}, {
    "name": "Remove Message Entrypoint",
    "data": "remove_message_entrypoint",
    "visible": false
}, {
    "name": "Is Eligible For Request Message",
    "data": "is_eligible_for_request_message",
    "visible": false,
    "bool": true
}, {
    "name": "Transparency Product Enabled",
    "data": "transparency_product_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Whatsapp Number",
    "data": "whatsapp_number",
    "visible": false
}, {
    "name": "Merchant Checkout Style",
    "data": "merchant_checkout_style",
    "visible": false
}, {
    "name": "Mutual Followers Count",
    "data": "mutual_followers_count",
    "visible": false
}, {
    "name": "Nametag",
    "data": "nametag",
    "visible": false
}, {
    "name": "Open External Url With In App Browser",
    "data": "open_external_url_with_in_app_browser",
    "visible": false,
    "bool": true
}, {
    "name": "Pinned Channels Info",
    "data": "pinned_channels_info",
    "visible": false
}, {
    "name": "Profile Context",
    "data": "profile_context",
    "visible": false
}, {
    "name": "Profile Context Facepile Users",
    "data": "profile_context_facepile_users",
    "visible": false
}, {
    "name": "Profile Context Links With User Ids",
    "data": "profile_context_links_with_user_ids",
    "visible": false
}, {
    "name": "Profile Context Mutual Follow Ids",
    "data": "profile_context_mutual_follow_ids",
    "visible": false
}, {
    "name": "Profile Pic Id",
    "data": "profile_pic_id",
    "visible": false
}, {
    "name": "Recon Features",
    "data": "recon_features",
    "visible": false
}, {
    "name": "Relevant News Regulation Locations",
    "data": "relevant_news_regulation_locations",
    "visible": false
}, {
    "name": "Seller Shoppable Feed Type",
    "data": "seller_shoppable_feed_type",
    "visible": false
}, {
    "name": "Show Shoppable Feed",
    "data": "show_shoppable_feed",
    "visible": false,
    "bool": true
}, {
    "name": "Text Post App Badge Label",
    "data": "text_post_app_badge_label",
    "visible": false
}, {
    "name": "Total Ar Effects",
    "data": "total_ar_effects",
    "visible": false
}, {
    "name": "Is Memorialized",
    "data": "is_memorialized",
    "visible": false
}, {
    "name": "Is Potential Business",
    "data": "is_potential_business",
    "visible": false,
    "bool": true
}, {
    "name": "Is Profile Broadcast Sharing Enabled",
    "data": "is_profile_broadcast_sharing_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Is Recon Ad Cta On Profile Eligible With Viewer",
    "data": "is_recon_ad_cta_on_profile_eligible_with_viewer",
    "visible": false,
    "bool": true
}, {
    "name": "Is Supervision Features Enabled",
    "data": "is_supervision_features_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Is Whatsapp Linked",
    "data": "is_whatsapp_linked",
    "visible": false,
    "bool": true
}, {
    "name": "Latest Besties Reel Media",
    "data": "latest_besties_reel_media",
    "visible": false
}, {
    "name": "Num Of Admined Pages",
    "data": "num_of_admined_pages",
    "visible": false
}, {
    "name": "Page Id",
    "data": "page_id",
    "visible": false
}, {
    "name": "Page Name",
    "data": "page_name",
    "visible": false
}, {
    "name": "Ads Page Id",
    "data": "ads_page_id",
    "visible": false
}, {
    "name": "Ads Page Name",
    "data": "ads_page_name",
    "visible": false
}, {
    "name": "Charity Profile Fundraiser Info",
    "data": "charity_profile_fundraiser_info",
    "visible": false
}, {
    "name": "Creator Shopping Info",
    "data": "creator_shopping_info",
    "visible": false
}, {
    "name": "Fan Club Info",
    "data": "fan_club_info",
    "visible": false
}, {
    "name": "Follow Friction Type",
    "data": "follow_friction_type",
    "visible": false
}, {
    "name": "Follower Count",
    "data": "follower_count",
    "visible": false
}, {
    "name": "Following Count",
    "data": "following_count",
    "visible": false
}, {
    "name": "Has Active Charity Business Profile Fundraiser",
    "data": "has_active_charity_business_profile_fundraiser",
    "visible": false,
    "bool": true
}, {
    "name": "Has Anonymous Profile Picture",
    "data": "has_anonymous_profile_picture",
    "visible": false,
    "bool": true
}, {
    "name": "Has Collab Collections",
    "data": "has_collab_collections",
    "visible": false,
    "bool": true
}, {
    "name": "Has Exclusive Feed Content",
    "data": "has_exclusive_feed_content",
    "visible": false,
    "bool": true
}, {
    "name": "Has Fan Club Subscriptions",
    "data": "has_fan_club_subscriptions",
    "visible": false,
    "bool": true
}, {
    "name": "Has Highlight Reels",
    "data": "has_highlight_reels",
    "visible": false,
    "bool": true
}, {
    "name": "Has Igtv Series",
    "data": "has_igtv_series",
    "visible": false,
    "bool": true
}, {
    "name": "Has Music On Profile",
    "data": "has_music_on_profile",
    "visible": false,
    "bool": true
}, {
    "name": "Has Private Collections",
    "data": "has_private_collections",
    "visible": false,
    "bool": true
}, {
    "name": "Has Videos",
    "data": "has_videos",
    "visible": false,
    "bool": true
}, {
    "name": "Hd Profile Pic Url Info",
    "data": "hd_profile_pic_url_info",
    "visible": false
}, {
    "name": "Hd Profile Pic Versions",
    "data": "hd_profile_pic_versions",
    "visible": false
}, {
    "name": "Interop Messaging User Fbid",
    "data": "interop_messaging_user_fbid",
    "visible": false
}, {
    "name": "Is Bestie",
    "data": "is_bestie",
    "visible": false,
    "bool": true
}, {
    "name": "Is Eligible For Diverse Owned Business Info",
    "data": "is_eligible_for_diverse_owned_business_info",
    "visible": false,
    "bool": true
}, {
    "name": "Is Eligible For Meta Verified Links In Reels",
    "data": "is_eligible_for_meta_verified_links_in_reels",
    "visible": false,
    "bool": true
}, {
    "name": "Is Eligible For Meta Verified Enhanced Link Sheet",
    "data": "is_eligible_for_meta_verified_enhanced_link_sheet",
    "visible": false,
    "bool": true
}, {
    "name": "Is Eligible To Display Diverse Owned Business Info",
    "data": "is_eligible_to_display_diverse_owned_business_info",
    "visible": false,
    "bool": true
}, {
    "name": "Is Facebook Onboarded Charity",
    "data": "is_facebook_onboarded_charity",
    "visible": false,
    "bool": true
}, {
    "name": "Is Favorite",
    "data": "is_favorite",
    "visible": false,
    "bool": true
}, {
    "name": "Is In Canada",
    "data": "is_in_canada",
    "visible": false,
    "bool": true
}, {
    "name": "Strong Id  ",
    "data": "strong_id__",
    "visible": false
}, {
    "name": "External Lynx Url",
    "data": "external_lynx_url",
    "visible": false
}, {
    "name": "Is Interest Account",
    "data": "is_interest_account",
    "visible": false,
    "bool": true
}, {
    "name": "Latest Reel Media",
    "data": "latest_reel_media",
    "visible": false
}, {
    "name": "Media Count",
    "data": "media_count",
    "visible": false
}, {
    "name": "Total Clips Count",
    "data": "total_clips_count",
    "visible": false
}, {
    "name": "Total Igtv Videos",
    "data": "total_igtv_videos",
    "visible": false
}, {
    "name": "Recs From Friends",
    "data": "recs_from_friends",
    "visible": false
}, {
    "name": "City Id",
    "data": "city_id",
    "visible": false
}, {
    "name": "Public Phone Country Code",
    "data": "public_phone_country_code",
    "visible": false
}, {
    "name": "Public Phone Number",
    "data": "public_phone_number",
    "visible": false
}, {
    "name": "Professional Conversion Suggested Account Type",
    "data": "professional_conversion_suggested_account_type",
    "visible": false
}, {
    "name": "Account Type",
    "data": "account_type",
    "visible": false
}, {
    "name": "Fbid V2",
    "data": "fbid_v2",
    "visible": false
}, {
    "name": "Is Profile Audio Call Enabled",
    "data": "is_profile_audio_call_enabled",
    "visible": false,
    "bool": true
}, {
    "name": "Instagram Location Id",
    "data": "instagram_location_id",
    "visible": false
}, {
    "name": "Is New To Instagram",
    "data": "is_new_to_instagram",
    "visible": false,
    "bool": true
}, {
    "name": "Is New To Instagram 30d",
    "data": "is_new_to_instagram_30d",
    "visible": false,
    "bool": true
}, {
    "name": "Is Secondary Account Creation",
    "data": "is_secondary_account_creation",
    "visible": false,
    "bool": true
}, {
    "name": "Category",
    "data": "category",
    "visible": false
}, {
    "name": "Category Id",
    "data": "category_id",
    "visible": false
}, {
    "name": "Is Business",
    "data": "is_business",
    "visible": false
}, {
    "name": "Language Code",
    "data": "languageCode",
    "visible": false
}, {
    "name": "Language %",
    "data": "languagePercentage",
    "visible": false
}, {
    "name": "Language #",
    "data": "languageCount",
    "visible": false
}, {
    "name": "Language",
    "data": "languageName",
    "visible": false
}];


var defaultOptions = {
    timeDelay: 180000,
    timeDelayAfterSoftRateLimit: 600000,
    timeDelayAfterHardRateLimit: 3600000,
    timeDelayAfter429RateLimit: 60000,
    timeDelayAfterAdditionalInfo: 2000,
    useTimeDelayAfterAdditionalInfo: false,
    retriesAfterAdditionalInfo404: 10,
    timeDelayAfterSkip: 0.5,
    useRandomTimeDelay: true,
    percentRandomTimeDelay: 0.5,
    followPrivateAccounts: true,
    limitQueue: true,
    maxAcctQueueLength: 50,
    maxMediaQueueLength: 50,
    paginationLimit: 100,
    mediapaginationLimit: 100,
    truncateStart: 0,
    dontUnFollowFollowers: true,
    dontUnFollowFilters: false,
    dontRemoveOrBlockFilters: false,
    dontUnFollowNonRdg: true,
    unFollowFresh: false,
    unFollowIfOld: true,
    unFollowDelay: 259200000, // 259200000 = 3 days
    unFollowIfOlderThan: 2592000000, // 2592000000 = 30 days
    followLikeLatestPics: false,
    numberFollowLikeLatestPics: 1,
    numberLikeOnlyLatestPics: 1,
    filterOptions: defaultFilterOptions,
    ui: [],
    cbShowQueueOnScreen: true,
    cbRemoveUnusedColumns: false,
    showFollowingInQueue: true,
    showLikesInQueue: true,
    removeAccountsFromQueue: false,
    autoSaveQueue: true,
    showStamps: true,
    showProfilePicInQueue: true,
    showConvenienceButtons: true,
    loadQueueOnStartup: true,
    clickNotNow: false,
    followPeopleAlreadyAttempted: false,
    maxPerEnabled: false,
    maxPerActions: 50,
    maxPerPeriod: 86400000,
    getExtendedData: false,
    getLastPostDate: false,
    endcursors: [],
    queueColumns: gbDefaultColumns,
    MediaIncludeLikersCommentersTagged: false,
    SaveWhenWatchingReel: true,
    LikeWhenWatchingReel: true,
    lastTab: 'tab5',
    includePinnedPostForLikes: true,
    includePinnedPostForComments: true
};

var gblOptions = defaultOptions;

var gbl404attempt = 0;

var acctsQueue = [];
var theirFollowings = [];
var myFollowers = [];
var timeoutsQueue = [];
var alreadyLiking = false;

var acctsProcessed = [];
var acctsPreviouslyAttempted = [];
var acctsWhiteList = [];
var freeTrialInterval;

var scrollIntervalId;
var totalAvailableForQueue;

var loadedTheirFollowers = false;
var loadedTheirFollowings = false;
var loadedMyFollowers = false;
var loadedMyFollowings = false;

var user;
var currentProfilePage = false;

var todaysdate = new Date();
var today = todaysdate.getTime();

var mediaToLike = [];
var previousLikes = [];
var rdgLikeDebugAttempts = {};
var rdgLikeRetryQueueState = {};
var rdgLikeVerificationDone = false;
var rdgDebugSequence = 0;
var rdgLikeOnlyMode = false;
var rdgLikeOnlyCurrentAccount = null;
var rdgLikeOnlyCurrentBatchTotal = 0;
var rdgLikeOnlyCurrentBatchDone = 0;
var rdgStoriesSchedule = [];
var rdgStorySchedulerIntervalId = null;
var rdgStoryPublishInProgress = false;
var rdgStoryPublishLockOwnerId = rdgResolveStoryPublishLockOwnerId();
var rdgStoryEditorCurrentId = null;
var rdgStoryEditorDragState = null;
var rdgStoryEditorDraftTexts = [];
var rdgStoryEditorActiveTextIndex = -1;
var RDG_ASSISTANT_STORAGE_KEY = 'rdgAssistantState';
var RDG_LOG_STORAGE_KEY = 'rdgLog';
var RDG_ACCOUNT_RUNTIME_STORAGE_KEY = 'rdgAssistantAccountRuntime';
var RDG_LOG_MAX_LINES = 4000;
var RDG_LOG_MAX_CHARS = 220000;
var rdgAssistantState = null;
var rdgAssistantBusy = false;
var rdgAssistantEngineInterval = null;
var rdgAssistantProfileButtonInterval = null;
var rdgAssistantAddProfileBusy = false;
var rdgAssistantAvatarRefreshMap = {};
var rdgAssistantUiBound = false;
var rdgAssistantLastRateLimitAt = 0;
var rdgAssistantExpandedCycleId = null;
var rdgAssistantDmExpanded = false;
var rdgAssistantRunPopupTimer = null;
var rdgAssistantRunPopupKey = '';
var rdgAssistantRunPopupDismissedKey = '';
var rdgAssistantLiveLogInterval = null;
var rdgStatusCountdownTimer = null;
var rdgStatusCountdownState = null;
var rdgAssistantWaitResumeTimer = null;
var rdgAssistantWaitResumeTargetAt = 0;
var rdgAssistantLoadedStorageKey = '';
var rdgLoadedLogStorageKey = '';
var rdgLogPersistTimer = null;

function rdgAssistantNormalizeStorageScopePart(value) {
    return String(value || '')
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9._-]+/g, '_');
}

function rdgAssistantGetViewerUsername() {
    try {
        if (user && user.viewer && user.viewer.username) {
            return String(user.viewer.username).trim().toLowerCase();
        }
    } catch (e) {}
    try {
        if (extractUserInfoFromScriptTags() === true && user && user.viewer && user.viewer.username) {
            return String(user.viewer.username).trim().toLowerCase();
        }
    } catch (e2) {}
    return '';
}

function rdgAssistantGetViewerId() {
    try {
        var fromCookie = getCookie('ds_user_id');
        if (fromCookie) return String(fromCookie).trim();
    } catch (eCookie) {}
    try {
        if (user && user.viewer && (user.viewer.id || user.viewer.pk)) {
            return String(user.viewer.id || user.viewer.pk).trim();
        }
    } catch (e) {}
    return '';
}

function rdgAssistantGetStorageScopeIds() {
    var out = [];
    var viewerId = rdgAssistantNormalizeStorageScopePart(rdgAssistantGetViewerId());
    var username = rdgAssistantNormalizeStorageScopePart(rdgAssistantGetViewerUsername());
    if (viewerId) out.push('id_' + viewerId);
    if (username && out.indexOf('user_' + username) === -1) out.push('user_' + username);
    return out;
}

function rdgAssistantGetStorageScopeId() {
    var scopeIds = rdgAssistantGetStorageScopeIds();
    if (scopeIds.length) return scopeIds[0];
    var username = rdgAssistantNormalizeStorageScopePart(rdgAssistantGetViewerUsername());
    if (username) return 'user_' + username;
    return '';
}

function rdgAssistantResolveStorageKey() {
    var scopeId = rdgAssistantGetStorageScopeId();
    if (!scopeId) return RDG_ASSISTANT_STORAGE_KEY;
    return RDG_ASSISTANT_STORAGE_KEY + ':' + scopeId;
}

function rdgAssistantResolveStorageKeyCandidates() {
    var keys = [];
    var scopeIds = rdgAssistantGetStorageScopeIds();
    if (!scopeIds.length) return [RDG_ASSISTANT_STORAGE_KEY];
    for (var i = 0; i < scopeIds.length; i++) {
        var scopedKey = RDG_ASSISTANT_STORAGE_KEY + ':' + scopeIds[i];
        if (keys.indexOf(scopedKey) === -1) keys.push(scopedKey);
    }
    keys.push(RDG_ASSISTANT_STORAGE_KEY);
    return keys;
}

function rdgAssistantSessionKey() {
    var scopeId = rdgAssistantGetStorageScopeId();
    return scopeId ? ('rdgAssistantSessionActive:' + scopeId) : 'rdgAssistantSessionActive';
}

function rdgAssistantExpandedCycleKey() {
    var scopeId = rdgAssistantGetStorageScopeId();
    return scopeId ? ('rdgAssistantExpandedCycleId:' + scopeId) : 'rdgAssistantExpandedCycleId';
}

function rdgResolveLogStorageKey() {
    var scopeId = rdgAssistantGetStorageScopeId();
    if (!scopeId) return RDG_LOG_STORAGE_KEY;
    return RDG_LOG_STORAGE_KEY + ':' + scopeId;
}

function rdgResolveLogStorageKeyCandidates() {
    var keys = [];
    var scopeIds = rdgAssistantGetStorageScopeIds();
    if (!scopeIds.length) return [RDG_LOG_STORAGE_KEY];
    for (var i = 0; i < scopeIds.length; i++) {
        var scopedKey = RDG_LOG_STORAGE_KEY + ':' + scopeIds[i];
        if (keys.indexOf(scopedKey) === -1) keys.push(scopedKey);
    }
    keys.push(RDG_LOG_STORAGE_KEY);
    return keys;
}

function rdgResolveAccountRuntimeStorageKey() {
    var scopeId = rdgAssistantGetStorageScopeId();
    if (!scopeId) return RDG_ACCOUNT_RUNTIME_STORAGE_KEY;
    return RDG_ACCOUNT_RUNTIME_STORAGE_KEY + ':' + scopeId;
}

function rdgResolveAccountRuntimeStorageKeyCandidates() {
    var keys = [];
    var scopeIds = rdgAssistantGetStorageScopeIds();
    if (!scopeIds.length) return [RDG_ACCOUNT_RUNTIME_STORAGE_KEY];
    for (var i = 0; i < scopeIds.length; i++) {
        var scopedKey = RDG_ACCOUNT_RUNTIME_STORAGE_KEY + ':' + scopeIds[i];
        if (keys.indexOf(scopedKey) === -1) keys.push(scopedKey);
    }
    keys.push(RDG_ACCOUNT_RUNTIME_STORAGE_KEY);
    return keys;
}

function rdgResolveAttemptedStorageKey() {
    var scopeId = rdgAssistantGetStorageScopeId();
    if (!scopeId) return 'acctsAttempted';
    return 'acctsAttempted:' + scopeId;
}

function rdgResolveAttemptedStorageKeyCandidates() {
    var keys = [];
    var scopeIds = rdgAssistantGetStorageScopeIds();
    if (!scopeIds.length) return ['acctsAttempted'];
    for (var i = 0; i < scopeIds.length; i++) {
        var scopedKey = 'acctsAttempted:' + scopeIds[i];
        if (keys.indexOf(scopedKey) === -1) keys.push(scopedKey);
    }
    keys.push('acctsAttempted');
    return keys;
}

function rdgNormalizeAttemptedAcctForStorage(acct) {
    var acctCopy = $.extend(true, {}, acct || {});
    var acctId = acctCopy.id || acctCopy.pk || acctCopy.user_id || '';
    acctId = acctId ? String(acctId) : '';
    if (acctId) {
        acctCopy.id = acctId;
        acctCopy.pk = acctId;
    }
    var scopeId = rdgAssistantGetStorageScopeId();
    var username = rdgAssistantGetViewerUsername();
    var viewerId = rdgAssistantGetViewerId();
    if (scopeId) acctCopy.rdgAccountScopeId = String(scopeId);
    if (username) acctCopy.rdgAccountUsername = String(username);
    if (viewerId) acctCopy.rdgAccountViewerId = String(viewerId);
    return acctCopy;
}

function rdgAttemptedAcctMatchesCurrentScope(acct) {
    if (!acct || typeof acct !== 'object') return false;
    var scopeId = rdgAssistantGetStorageScopeId();
    var username = rdgAssistantGetViewerUsername();
    var viewerId = rdgAssistantGetViewerId();
    if (acct.rdgAccountViewerId && viewerId && String(acct.rdgAccountViewerId) === String(viewerId)) return true;
    if (acct.rdgAccountScopeId && scopeId && String(acct.rdgAccountScopeId) === String(scopeId)) return true;
    if (acct.rdgAccountUsername && username && String(acct.rdgAccountUsername).toLowerCase() === String(username).toLowerCase()) return true;
    return false;
}

function rdgSanitizeAttemptedAcctsForScope(list, restrictToCurrentScope) {
    var sanitized = [];
    var seen = {};
    var source = Array.isArray(list) ? list : [];
    for (var i = 0; i < source.length; i++) {
        var acct = source[i];
        var normalized = rdgNormalizeAttemptedAcctForStorage(acct);
        var acctId = normalized.id || normalized.pk || normalized.user_id || '';
        acctId = acctId ? String(acctId) : '';
        if (!acctId || seen[acctId]) continue;
        var hasScopeMeta = !!(normalized.rdgAccountScopeId || normalized.rdgAccountUsername || normalized.rdgAccountViewerId);
        if (restrictToCurrentScope === true && hasScopeMeta && !rdgAttemptedAcctMatchesCurrentScope(normalized)) continue;
        seen[acctId] = true;
        sanitized.push(normalized);
    }
    return sanitized;
}

function rdgPersistAttemptedHistory(callback) {
    acctsPreviouslyAttempted = cleanAcctsForStorage(rdgSanitizeAttemptedAcctsForScope(acctsPreviouslyAttempted, false));
    var storageKey = rdgResolveAttemptedStorageKey();
    var payload = {};
    payload[storageKey] = acctsPreviouslyAttempted;
    chrome.storage.local.set(payload, function() {
        if (typeof callback === 'function') callback(acctsPreviouslyAttempted);
    });
}

function rdgGetCurrentAccountLabel() {
    var username = rdgAssistantGetViewerUsername();
    if (username) return '@' + username;
    var viewerId = rdgAssistantGetViewerId();
    if (viewerId) return 'id ' + viewerId;
    return 'conta atual';
}

function rdgNormalizeLogText(text) {
    var normalized = String(text || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    var lines = normalized.split('\n').map(function(line) {
        return String(line || '').trimEnd();
    }).filter(function(line) {
        return line !== '';
    });
    if (lines.length > RDG_LOG_MAX_LINES) lines = lines.slice(lines.length - RDG_LOG_MAX_LINES);
    normalized = lines.join('\n');
    if (normalized.length > RDG_LOG_MAX_CHARS) normalized = normalized.slice(normalized.length - RDG_LOG_MAX_CHARS);
    return normalized;
}

function rdgRenderLogScopeBanner() {
    var banner = document.getElementById('rdgLogScopeBanner');
    if (!banner) return;
    banner.textContent = 'Registro separado por conta: ' + rdgGetCurrentAccountLabel() + ' | Retencao automatica: ultimas ' + RDG_LOG_MAX_LINES + ' linhas';
}

function rdgPersistCurrentLogTextNow(callback) {
    var fakeConsole = document.getElementById('txtConsole');
    if (!fakeConsole) {
        if (typeof callback === 'function') callback('');
        return;
    }
    var normalized = rdgNormalizeLogText(fakeConsole.textContent || '');
    fakeConsole.textContent = normalized ? (normalized + '\n') : '';
    var storageKey = rdgResolveLogStorageKey();
    var payload = {};
    payload[storageKey] = normalized;
    chrome.storage.local.set(payload, function() {
        rdgLoadedLogStorageKey = storageKey;
        rdgRenderLogScopeBanner();
        if (typeof callback === 'function') callback(normalized);
    });
}

function rdgSchedulePersistCurrentLog() {
    if (rdgLogPersistTimer) clearTimeout(rdgLogPersistTimer);
    rdgLogPersistTimer = setTimeout(function() {
        rdgLogPersistTimer = null;
        rdgPersistCurrentLogTextNow();
    }, 800);
}

function rdgLoadScopedLogIntoConsole(callback) {
    var storageKey = rdgResolveLogStorageKey();
    var storageKeys = rdgResolveLogStorageKeyCandidates();
    chrome.storage.local.get(storageKeys, function(data) {
        var chosenKey = storageKey;
        var logText = '';
        if (typeof data[storageKey] !== 'undefined') {
            logText = String(data[storageKey] || '');
            chosenKey = storageKey;
        } else {
            for (var i = 0; i < storageKeys.length; i++) {
                var candidateKey = storageKeys[i];
                if (!candidateKey || candidateKey === storageKey || candidateKey === RDG_LOG_STORAGE_KEY) continue;
                if (typeof data[candidateKey] === 'undefined') continue;
                logText = String(data[candidateKey] || '');
                chosenKey = candidateKey;
                break;
            }
        }
        logText = rdgNormalizeLogText(logText);
        var fakeConsole = document.getElementById('txtConsole');
        if (fakeConsole) {
            fakeConsole.textContent = logText ? (logText + '\n') : '';
            fakeConsole.scrollTop = fakeConsole.scrollHeight;
        }
        includeLogInMailToLinks();
        rdgLoadedLogStorageKey = chosenKey;
        rdgRenderLogScopeBanner();
        if (chosenKey && chosenKey !== storageKey && chosenKey !== RDG_LOG_STORAGE_KEY && logText) {
            var payload = {};
            payload[storageKey] = logText;
            chrome.storage.local.set(payload, function() {
                chrome.storage.local.remove(chosenKey, function() {});
                rdgLoadedLogStorageKey = storageKey;
                if (typeof callback === 'function') callback(logText);
            });
            return;
        }
        if (typeof callback === 'function') callback(logText);
    });
}

function rdgReadScopedLogText(callback) {
    var storageKey = rdgResolveLogStorageKey();
    var storageKeys = rdgResolveLogStorageKeyCandidates();
    chrome.storage.local.get(storageKeys, function(data) {
        var logText = '';
        if (typeof data[storageKey] !== 'undefined') {
            logText = String(data[storageKey] || '');
        } else {
            for (var i = 0; i < storageKeys.length; i++) {
                var candidateKey = storageKeys[i];
                if (!candidateKey || candidateKey === RDG_LOG_STORAGE_KEY) continue;
                if (typeof data[candidateKey] === 'undefined') continue;
                logText = String(data[candidateKey] || '');
                break;
            }
        }
        if (typeof callback === 'function') callback(rdgNormalizeLogText(logText));
    });
}

function rdgSaveCurrentLogToFile() {
    var fakeConsole = document.getElementById('txtConsole');
    var text = rdgNormalizeLogText(fakeConsole ? fakeConsole.textContent : '');
    if (!text) {
        outputMessage('Registro vazio para salvar.');
        return;
    }
    var stamp = new Date().toISOString().replace(/[:T]/g, '-').replace(/\..+$/, '');
    var fileName = 'registro-' + rdgGetCurrentAccountLabel().replace(/[^a-z0-9@._-]+/gi, '_').replace(/^@+/, '') + '-' + stamp + '.txt';
    var blob = new Blob([text + '\n'], { type: 'text/plain;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(function() {
        URL.revokeObjectURL(url);
        if (a.parentNode) a.parentNode.removeChild(a);
    }, 0);
    outputMessage('Registro salvo: ' + fileName);
}

function rdgAssistantGetExpandedCycleId() {
    if (rdgAssistantExpandedCycleId) return String(rdgAssistantExpandedCycleId);
    try {
        var v = sessionStorage.getItem(rdgAssistantExpandedCycleKey());
        if (v) {
            rdgAssistantExpandedCycleId = String(v);
            return String(v);
        }
    } catch (e) {}
    return null;
}

function rdgAssistantSetExpandedCycleId(cycleId) {
    var v = cycleId ? String(cycleId) : '';
    rdgAssistantExpandedCycleId = v || null;
    try {
        if (!v) sessionStorage.removeItem(rdgAssistantExpandedCycleKey());
        else sessionStorage.setItem(rdgAssistantExpandedCycleKey(), v);
    } catch (e) {}
}

function rdgAssistantHasSession() {
    try {
        return sessionStorage.getItem(rdgAssistantSessionKey()) === '1';
    } catch (e) {
        return false;
    }
}

function rdgAssistantMarkSessionActive() {
    try {
        sessionStorage.setItem(rdgAssistantSessionKey(), '1');
    } catch (e) {}
}

function rdgAssistantHasActiveRunStatus() {
    return !!(rdgAssistantState &&
        rdgAssistantState.run &&
        ['running', 'waiting_instagram', 'resting', 'paused'].indexOf(rdgAssistantState.run.status) > -1);
}

function rdgHasAuthenticatedRuntime() {
    try {
        if (localStorage.getItem('rdgAuthenticated') === 'true') return true;
    } catch (e) {}
    try {
        if (typeof user !== 'undefined' && user && user.viewer && user.viewer.username) return true;
    } catch (e2) {}
    try {
        if (document.cookie && (document.cookie.indexOf('sessionid=') > -1 || document.cookie.indexOf('ds_user_id=') > -1)) return true;
    } catch (e3) {}
    return false;
}

function rdgAssistantKeepUiSessionAlive() {
    if (!rdgAssistantHasActiveRunStatus()) return false;
    rdgAssistantMarkSessionActive();
    try {
        localStorage.setItem('rdgAuthenticated', 'true');
    } catch (e) {}
    return true;
}

function rdgIsUiUnlockedOnThisPage() {
    try {
        if (localStorage.getItem('rdgAuthenticated') === 'true') {
            let licenseDataStr = localStorage.getItem('rdgLicenseData');
            if (licenseDataStr) {
                let licenseData = JSON.parse(licenseDataStr);
                if (licenseData.expires_at) {
                    let exp = new Date(licenseData.expires_at);
                    if (!isNaN(exp.getTime()) && exp < new Date()) {
                        localStorage.removeItem('rdgAuthenticated');
                        window.rdgUiLayoutUnlocked = false;
                        return false;
                    }
                }
            } else {
                // Force re-login to fetch new expiration date format
                localStorage.removeItem('rdgAuthenticated');
                window.rdgUiLayoutUnlocked = false;
                return false;
            }
            window.rdgUiLayoutUnlocked = true;
            return true;
        }
    } catch (e) {}
    
    if (window.rdgUiLayoutUnlocked === true) return true;
    return false;
}

function rdgCanShowUnlockedAutomationUi() {
    return rdgIsUiUnlockedOnThisPage() === true;
}

var currentList = false;

var queueSplit = false;

var usernameCheckInterval;

var maxActionsDelayStartTime = 0;
var actionsTaken = 0;

let mediaForComments = [];
let accountIdsThatCommented = [];


let mediaForLikes = [];
let accountIdsThatLiked = [];

function waitForWinVars() {

    var sharedData = JSON.parse(localStorage.getItem('winvars'));

    if (sharedData) {

        if (sharedData.config && sharedData.config.viewer != null) {
            user = sharedData.config;
            gbInit();
        } else {
            waitForElement('script[type="application/json"]', document, gbInit, false);
        }

    } else {
        setTimeout(waitForWinVars, 10);
    }

}

function gbInit() {

    if (shouldLoadRdgOnThisPage() == false) return false;

    localStorage.clear('winvars');


    injectControlsDiv();

    if (getBackgroundInfo() === false) {
        return false;
    }

    startUserNameFreshnessInterval();

    setInterval(monitorButtonConditions, 600);

    setInterval(rdgActionRunner, 1000);
    setInterval(rdgEnforceLicenseExpiration, 3000);
    setTimeout(rdgVerifyAndRefreshLicenseFromSupabase, 500);
    setInterval(rdgVerifyAndRefreshLicenseFromSupabase, 60000);
}

function getCookie(name) {
    let cookie = {};
    document.cookie.split(';').forEach(function(el) {
        let split = el.split('=');
        cookie[split[0].trim()] = split.slice(1).join("=");
    })
    return cookie[name];
}

function getCsrfFromCookie() {
    return getCookie('csrftoken');
}

function displayFreeTrialTimeLeft() {
    var datenow = new Date();
    var timenow = datenow.getTime();

    if (timenow - instabot_install_date < instabot_free_trial_time && instabot_has_license == false) {
        var timeLeft = millisecondsToHumanReadable(instabot_free_trial_time - (timenow - instabot_install_date), true);
        $('#h2FreeTrialTimeLeft').show().html(timeLeft + ' left in trial. <a href="" id="linkBuyNow">Subscribe Now</a>');
        $('#linkBuyNow').click(function(e) {
            e.preventDefault();
            chrome.runtime.sendMessage({
                "fnc": "openBuyScreen"
            });
            setTimeout(function() {
                // bad practice hack to clear ending the free trial if someone clicks the link
                localStorage.removeItem('gbFTover');
            }, 3000);
            return false;
        });
    } else if (instabot_has_license == true) {
        if (rdgEnforceLicenseExpiration()) {
            return;
        }
        let licenseDataStr = localStorage.getItem('rdgLicenseData');
        let validityText = 'Acesso Ativo e Validado';
        if (licenseDataStr) {
            try {
                let licenseData = JSON.parse(licenseDataStr);
                rdgUpdateHeaderLicenseUI(licenseData);
            } catch(e) {}
        }
        $('#relinkSubscription').hide();
        clearInterval(freeTrialInterval);
    } else {
        $('#h2FreeTrialTimeLeft').hide();
        clearInterval(freeTrialInterval);
    }
}

function timeToDate(t) {
    var date = new Date(parseInt(t));
    return date.toString();
}

function printMessage(txt) {
    outputMessage(txt);
}

function rdgAppendLogLine(txt, updateStatusLine) {
    var statusDiv = document.getElementById('igBotStatusDiv');
    var fakeConsole = document.getElementById('txtConsole');
    var line = String(txt || '');

    if (line.trim() === '') return '';
    if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} - /.test(line)) {
        line = getTimeStamp() + ' - ' + line;
    }

    if (updateStatusLine !== false && statusDiv) {
        let cleanLine = line.replace(/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} - /, '').trim();
        cleanLine = cleanLine.replace(/\n/g, ' ').replace(/\s+/g, ' ');
        statusDiv.textContent = cleanLine;
        statusDiv.title = line;
        displayWaitTimeHacky();
    }
    if (fakeConsole) {
        var currentKey = rdgResolveLogStorageKey();
        if (rdgLoadedLogStorageKey && currentKey && rdgLoadedLogStorageKey !== currentKey) {
            fakeConsole.textContent = '';
            rdgLoadedLogStorageKey = currentKey;
        }
        fakeConsole.textContent = rdgNormalizeLogText((fakeConsole.textContent || '') + '\n' + line) + '\n';
    }
    rdgSchedulePersistCurrentLog();

    scrollLog();

    includeLogInMailToLinks();
    rdgAssistantHandleOutputMessage(line);
    return line;
}

function outputMessage(txt) {
    rdgAppendLogLine(txt, true);
}

function rdgAssistantConsoleMessage(txt) {
    rdgAppendLogLine('[Assistente] ' + txt, false);

}

// #region debug-point A:debug-reporter
function rdgDebugReport(hypothesisId, location, msg, data, runId) {
    try {
        fetch('http://127.0.0.1:7777/event', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                sessionId: 'assistant-stall-skip',
                runId: runId || 'pre-fix',
                hypothesisId: hypothesisId,
                location: location,
                msg: '[DEBUG] ' + msg,
                data: data || {},
                traceId: 'dbg-' + (++rdgDebugSequence) + '-' + Date.now(),
                ts: Date.now()
            })
        }).catch(function() {});
    } catch (e) {}
}
// #endregion

function rdgGetNextEligibleMediaToLike() {
    if (mediaToLike.length === 0) {
        return {
            media: null,
            waitMs: 0
        };
    }

    var now = Date.now();
    var earliestRetryAt = Infinity;

    for (var i = 0; i < mediaToLike.length; i++) {
        var media = mediaToLike[i];
        var state = rdgLikeRetryQueueState[media.id];
        var retryAt = state && state.retryAt ? state.retryAt : 0;

        if (retryAt <= now) {
            return {
                media: mediaToLike.splice(i, 1)[0],
                waitMs: 0
            };
        }

        if (retryAt < earliestRetryAt) {
            earliestRetryAt = retryAt;
        }
    }

    return {
        media: null,
        waitMs: Math.max(1000, earliestRetryAt - now)
    };
}

function scrollLog() {
    setTimeout(function() {
        var fakeConsole = document.getElementById('txtConsole');
        if (document.activeElement.id !== 'txtConsole') {
            fakeConsole.scrollTop = fakeConsole.scrollHeight;
        }
    }, 100);
}

function includeLogInMailToLinks() {
    $('.rdgEmailLink').attr('target', '_blank').attr('href', 'mailto:suporte@rdgsolucoes.com.br?body=' + encodeURIComponent('\n\n------------------------------------------------------------------------------------------------------------------------------------\nPor favor digite sua mensagem acima desta linha, incluindo o log abaixo para análise técnica:\n------------------------------------------------------------------------------------------------------------------------------------\n' + document.getElementById('txtConsole').textContent.slice(-20000)));
}

function trimLog() {
    var fakeConsole = document.getElementById('txtConsole');
    //fakeConsole.textContent = fakeConsole.textContent.slice(-100);

    var arrLines = fakeConsole.textContent.split('\n');
    arrLines = arrLines.slice(arrLines.length - Math.min(1000, RDG_LOG_MAX_LINES), arrLines.length);

    fakeConsole.textContent = rdgNormalizeLogText(arrLines.join('\n')) + '\n';
    rdgSchedulePersistCurrentLog();

    outputMessage('Log trimmed');
}

function rdgStopStatusCountdown() {
    if (rdgStatusCountdownTimer) {
        clearTimeout(rdgStatusCountdownTimer);
        rdgStatusCountdownTimer = null;
    }
    rdgStatusCountdownState = null;
}

function rdgRenderStatusCountdownTick() {
    var statusDiv = document.getElementById('igBotStatusDiv');
    if (!statusDiv || !rdgStatusCountdownState) {
        rdgStopStatusCountdown();
        return false;
    }

    var remainingMs = rdgStatusCountdownState.deadlineAt - Date.now();
    var remainingSeconds = Math.max(0, remainingMs / 1000);
    var renderedSeconds = remainingSeconds > 0 ? remainingSeconds.toFixed(3) : '0.000';
    statusDiv.textContent = rdgStatusCountdownState.prefix + renderedSeconds + rdgStatusCountdownState.suffix;

    if (remainingMs <= 0) {
        rdgStatusCountdownTimer = null;
        return false;
    }

    rdgStatusCountdownTimer = setTimeout(rdgRenderStatusCountdownTick, 1000);
    return true;
}

function displayWaitTimeHacky() {
    var statusDiv = document.getElementById('igBotStatusDiv');
    if (!statusDiv) return false;

    var statusText = statusDiv.textContent;

    if (statusText.indexOf('Max actions exceeded') > -1) {
        if (rdgStatusCountdownTimer) clearTimeout(rdgStatusCountdownTimer);
        rdgStatusCountdownState = {
            prefix: getTimeStamp() + ' - Max actions exceeded, waiting ',
            suffix: ' seconds',
            deadlineAt: Date.now() + Math.max(0, maxActionsDelayRemaining())
        };
        return rdgRenderStatusCountdownTick();
    }

    var patterns = [
        { regex: /(.*waiting\s+)(\d+(?:\.\d+)?)(\s+seconds.*)/i, multiplierMs: 1000 },
        { regex: /(.*waiting\s+)(\d+(?:\.\d+)?)(\s+minutes.*)/i, multiplierMs: 60000 },
        { regex: /(.*proximo follow em\s+)(\d+(?:\.\d+)?)(\s+segundos.*)/i, multiplierMs: 1000 },
        { regex: /(.*proxima curtida em\s+)(\d+(?:\.\d+)?)(\s+segundos.*)/i, multiplierMs: 1000 },
        { regex: /(.*retomada automatica em\s+)(\d+(?:\.\d+)?)(\s+segundos.*)/i, multiplierMs: 1000 }
    ];

    for (var i = 0; i < patterns.length; i++) {
        var match = statusText.match(patterns[i].regex);
        if (!match) continue;
        var value = parseFloat(match[2]);
        if (isNaN(value) || value <= 0) {
            rdgStopStatusCountdown();
            return false;
        }
        if (rdgStatusCountdownTimer) clearTimeout(rdgStatusCountdownTimer);
        rdgStatusCountdownState = {
            prefix: match[1],
            suffix: match[3],
            deadlineAt: Date.now() + (value * patterns[i].multiplierMs)
        };
        return rdgRenderStatusCountdownTick();
    }

    rdgStopStatusCountdown();
    return false;
}

function millisecondsToHumanReadable(ms, formatAsString) {

    var obj = {};
    var x = ms / 1000;
    obj.seconds = parseInt(x % 60);
    x /= 60;
    obj.minutes = parseInt(x % 60);
    x /= 60;
    obj.hours = parseInt(x % 24);
    x /= 24;
    obj.days = parseInt(x);

    if (formatAsString == false) {
        return obj;
    }

    return obj.days + ' days, ' + obj.hours + ' hours, ' + obj.minutes + ' minutes, ' + obj.seconds + ' seconds';

}

function zeroPad(digitcount, num) {
    for (var i = 0; i < digitcount; i++) {
        num = "0" + num;
    }

    return num.substr(-digitcount, digitcount);
}

function getTimeStamp() {
    var d = new Date();
    var meridium = '';
    var hours = d.getHours();

    // if (hours > 11) {
    //     meridium = ' pm';
    //     hours = hours - 12;
    // } else {
    //     meridium = ' am';
    // }

    // if (hours == 0) {
    //     meridium = ' pm';
    //     hours = 12;
    // }

    return (d.getFullYear() + '-' + zeroPad(2, d.getMonth() + 1)) + '-' + zeroPad(2, d.getDate()) + ' ' + zeroPad(2, d.getHours()) + ':' + zeroPad(2, d.getMinutes()) + ':' + zeroPad(2, d.getSeconds()) + meridium;
}

function containsObject(obj, list) {
    var i;
    for (i = 0; i < list.length; i++) {
        if (list[i].id === obj.id) {
            return true;
        }
    }

    return false;
}

function findAcctById(id, list, returnIndexOnly) {
    if (returnIndexOnly !== true) returnIndexOnly = false;
    var i;
    for (i = 0; i < list.length; i++) {
        if (list[i].id === id) {
            if (returnIndexOnly === true) return i;
            return list[i];
        }
    }
    return false;
}


function addNewConvenienceLinks(element) {

    if (gblOptions.showConvenienceButtons == false) return false;

    var $$this = $(element);

    if ($$this.children('div').length > 0) return false;
    if ($$this.parents('.Mr508').length > 0) return false;
    if ($$this.parents('.XQXOT').length > 0) return false;

    var username = $$this.text();

    $$this.after('<a class="igBotInjectedLinkWhitelist" href="javascript:void(0);" data-username="' + username + '">Whitelist</a> <a class="igBotInjectedLinkUnfollow" href="javascript:void(0);" data-username="' + username + '">Unfollow</a>');
    $$this.parents('.RqtMr').css({
        'max-width': 'initial'
    });

}


async function convenienceLinkUnfollowAcct(userName) {
    var acct = await getAdditionalDataForAcct({
        username: userName
    });
    quickUnfollowAcct(acct);
}

async function convenienceLinkWhitelistAcct(userName) {
    var acct = await getAdditionalDataForAcct({
        username: userName
    });
    if (addAcctToWhiteList(acct) === true) saveWhiteListToStorage();
    $('.igBotInjectedLinkWhitelist[data-username="' + acct.username + '"]').fadeOut();
    $('.igBotInjectedLinkUnfollow[data-username="' + acct.username + '"]').fadeOut();
}

function waitForTrue(variableNames, callback, args) {
    var allTrue = true;
    var waitingFor = 'waiting for ';
    for (var i = 0; i < variableNames.length; i++) {
        if (window[variableNames[i]] === false) {
            allTrue = false;
            waitingFor = waitingFor + variableNames[i] + ' ';
        } else {
            waitingFor = waitingFor.replace(variableNames[i], '');
        }
    }

    if (allTrue === true) {
        printMessage(chrome.i18n.getMessage('Done'));
        callback.apply(this, args);
    } else {
        timeoutsQueue.push(setTimeout(function() {
            waitForTrue(variableNames, callback, args);
        }, 1000));
    }

}

function waitForElement(query, parent, callback, reenable) {
    var elementToObserve = document.querySelectorAll(query)[0];
    if (elementToObserve) {
        callback();
        return;
    }
    const observer = new MutationObserver((mutations, obs) => {
        var elementToObserve = document.querySelectorAll(query)[0];
        if (elementToObserve) {
            callback();

            if (reenable == true) {
                setTimeout(function() {
                    obs.observe(parent, {
                        childList: true,
                        subtree: true
                    });
                }, 1000);
            }

            obs.disconnect();
            return;
        }
    });

    observer.observe(parent, {
        childList: true,
        subtree: true
    });

}

function loadOptions() {
    chrome.storage.local.get("gblOptions", function(data) {
        if (typeof data.gblOptions != 'undefined') {
            gblOptions = data.gblOptions;
            gblOptions.queueColumns = JSON.parse(JSON.stringify(gbDefaultColumns));

            if (typeof gblOptions.filterOptions == 'undefined') {
                gblOptions.filterOptions = defaultFilterOptions;
            }

            // for newly added options: set gblOptions.xxxx to default option if .xxxx wasn't in previously saved options
            for (var key in defaultOptions) {
                if (gblOptions.hasOwnProperty(key) === false) {
                    gblOptions[key] = defaultOptions[key];
                }
            }

            // for newly added filter options: set gblOptions.filterOptions.xxxx to default option if .xxxx wasn't in previously saved options
            for (var key in defaultFilterOptions) {
                if (gblOptions.filterOptions.hasOwnProperty(key) === false) {
                    gblOptions.filterOptions[key] = defaultFilterOptions[key];
                }
            }

            document.getElementById('textSecondsBetweenActions').value = gblOptions.timeDelay / 1000;
            document.getElementById('textSecondsAfterSkip').value = gblOptions.timeDelayAfterSkip / 1000;
            document.getElementById('textMinutesAfterSoftRateLimit').value = gblOptions.timeDelayAfterSoftRateLimit / 60000;
            document.getElementById('textMinutesAfter429RateLimit').value = gblOptions.timeDelayAfter429RateLimit / 60000;
            document.getElementById('textHoursAfterHardRateLimit').value = gblOptions.timeDelayAfterHardRateLimit / 3600000;
            document.getElementById('texttimeDelayAfterAdditionalInfo').value = gblOptions.timeDelayAfterAdditionalInfo / 1000;
            document.getElementById('textRetryAfterAdditionalInfo404').value = Number(gblOptions.retriesAfterAdditionalInfo404);
            document.getElementById('cbuseTimeDelayAfterAdditionalInfo').checked = gblOptions.useTimeDelayAfterAdditionalInfo;
            document.getElementById('cbRandomizeTimeDelay').checked = gblOptions.useRandomTimeDelay;
            document.getElementById('cbFollowPrivateAccounts').checked = gblOptions.followPrivateAccounts;
            document.getElementById('cbFilterNonPrivate').checked = gblOptions.filterOptions.non_private;
            document.getElementById('cbFilterVerified').checked = gblOptions.filterOptions.verified;
            document.getElementById('cbFilterNonVerified').checked = gblOptions.filterOptions.non_verified;
            document.getElementById('cbFilterBusiness').checked = gblOptions.filterOptions.is_business_account;
            document.getElementById('cbFilterNonBusiness').checked = gblOptions.filterOptions.non_is_business_account;
            document.getElementById('cbFilterJoinedRecently').checked = gblOptions.filterOptions.is_joined_recently;
            document.getElementById('cbFilterNonJoinedRecently').checked = gblOptions.filterOptions.non_is_joined_recently;
            document.getElementById('cbFollowsMe').checked = gblOptions.filterOptions.follows_me;
            document.getElementById('cbNonFollowsMe').checked = gblOptions.filterOptions.non_follows_me;
            document.getElementById('cbFollowedByMe').checked = gblOptions.filterOptions.followed_by_me;
            document.getElementById('cbNonFollowedByMe').checked = gblOptions.filterOptions.non_followed_by_me;
            document.getElementById('cbFilterNoProfilePic').checked = gblOptions.filterOptions.no_profile_pic;
            document.getElementById('cbFilterProfilePic').checked = gblOptions.filterOptions.profile_pic;
            document.getElementById('cbApplyFilterAutomatically').checked = gblOptions.filterOptions.applyFiltersAutomatically;
            document.getElementById('igBotPercentRandomTimeDelay').value = gblOptions.percentRandomTimeDelay * 200;
            document.getElementById('cbDontUnfollowFollowers').checked = gblOptions.dontUnFollowFollowers;
            // document.getElementById('cbdontUnFollowNonRdg').checked = gblOptions.dontUnFollowNonRdg;
            // document.getElementById('cbDontUnfollowFilters').checked = gblOptions.dontUnFollowFilters;
            document.getElementById('cbDontRemoveOrBlockFilters').checked = gblOptions.dontRemoveOrBlockFilters;
            // document.getElementById('cbDontUnfollowFresh').checked = !gblOptions.unFollowFresh;
            // document.getElementById('cbUnfollowOld').checked = gblOptions.unFollowIfOld;
            // document.getElementById('textUnfollowNew').value = gblOptions.unFollowDelay / 86400000;
            // document.getElementById('textUnfollowOld').value = gblOptions.unFollowIfOlderThan / 86400000;
            document.getElementById('cbLimitQueueSize').checked = true;
            document.getElementById('txtLimitQueueSize').value = gblOptions.maxAcctQueueLength;
            document.getElementById('cbLimitMediaQueueSize').checked = gblOptions.limitMediaQueue;
            document.getElementById('txtLimitMediaQueueSize').value = gblOptions.maxMediaQueueLength;
            document.getElementById('numberFollowLikeLatestPics').value = gblOptions.numberFollowLikeLatestPics || 1;
            var likeOnlyPicsCount = parseInt(gblOptions.numberLikeOnlyLatestPics || 1);
            var likeOnlyRadio = document.querySelector('input[name="likeOnlyLatestPicsCount"][value="' + likeOnlyPicsCount + '"]');
            if (!likeOnlyRadio) {
                likeOnlyRadio = document.querySelector('input[name="likeOnlyLatestPicsCount"][value="1"]');
            }
            if (likeOnlyRadio) likeOnlyRadio.checked = true;
            document.getElementById('cbRemoveFromQueue').checked = gblOptions.removeAccountsFromQueue;
            document.getElementById('cbAutoSaveQueue').checked = gblOptions.autoSaveQueue;
            document.getElementById('cbShowStamps').checked = gblOptions.showStamps;
            document.getElementById('cbShowProfilePicInQueue').checked = gblOptions.showProfilePicInQueue;
            document.getElementById('cbConvenienceLinks').checked = gblOptions.showConvenienceButtons;
            document.getElementById('cbFollowAlreadyAttempted').checked = gblOptions.followPeopleAlreadyAttempted;
            document.getElementById('cbShowLikesInQueue').checked = gblOptions.showLikesInQueue;
            document.getElementById('cbShowQueueOnScreen').checked = gblOptions.cbShowQueueOnScreen;
            document.getElementById('cbRemoveUnusedColumns').checked = gblOptions.cbRemoveUnusedColumns;
            document.getElementById('cbClickNotNow').checked = gblOptions.clickNotNow;
            document.getElementById('cbLoadQueueOnStartup').checked = gblOptions.loadQueueOnStartup;
            document.getElementById('cbLimitActions').checked = gblOptions.maxPerEnabled;
            document.getElementById('textLimitActionsPer').value = gblOptions.maxPerActions;
            document.getElementById('textLimitActionsPerTime').value = gblOptions.maxPerPeriod / 3600000;
            document.getElementById('cbGetExtendedData').checked = gblOptions.getExtendedData;
            document.getElementById('cbGetLastPostDate').checked = gblOptions.getLastPostDate;
            document.getElementById('cbFilterBioContains').checked = gblOptions.filterOptions.bio_contains;
            document.getElementById('cbFilterBioNotContains').checked = gblOptions.filterOptions.bio_not_contains;
            document.getElementById('txtFilterBioContains').value = gblOptions.filterOptions.bio_contains_text;
            document.getElementById('txtFilterBioNotContains').value = gblOptions.filterOptions.bio_not_contains_text;
            document.getElementById('cbFilterExternalUrlContains').checked = gblOptions.filterOptions.external_url_contains;
            document.getElementById('cbFilterExternalUrlNotContains').checked = gblOptions.filterOptions.external_url_not_contains;
            document.getElementById('txtFilterExternalUrlContains').value = gblOptions.filterOptions.external_url_contains_text;
            document.getElementById('txtFilterExternalUrlNotContains').value = gblOptions.filterOptions.external_url_not_contains_text;
            document.getElementById('cbFilterBusinessCategoryNameContains').checked = gblOptions.filterOptions.business_category_name_contains;
            document.getElementById('cbFilterBusinessCategoryNameNotContains').checked = gblOptions.filterOptions.business_category_name_not_contains;
            document.getElementById('txtFilterBusinessCategoryNameContains').value = gblOptions.filterOptions.business_category_name_contains_text;
            document.getElementById('txtFilterBusinessCategoryNameNotContains').value = gblOptions.filterOptions.business_category_name_not_contains_text;
            document.getElementById('cbMediaIncludeLikersCommentersTagged').checked = gblOptions.MediaIncludeLikersCommentersTagged;
            document.getElementById('SaveWhenWatchingReel').checked = gblOptions.SaveWhenWatchingReel;
            document.getElementById('LikeWhenWatchingReel').checked = gblOptions.LikeWhenWatchingReel;
            document.getElementById('includeSuggestedPostsFromFeed').checked = gblOptions.includeSuggestedPostsFromFeed;
            document.getElementById('includePinnedPostForLikes').checked = gblOptions.includePinnedPostForLikes;
            document.getElementById('includePinnedPostForComments').checked = gblOptions.includePinnedPostForComments;

            $('#paginationLimit option:selected').attr("selected", null);
            $('#paginationLimit option[value="' + gblOptions.paginationLimit + '"]').attr("selected", "selected");
            $('#paginationLimit').trigger('change');

            gblOptions.lastTab = 'tab5';
            $('li.' + gblOptions.lastTab + ' label').click();

            if (typeof gblOptions.ui == 'undefined' || gblOptions.ui.length == 0) {
                [...document.getElementsByTagName('details')].forEach((detailsEl) => {
                    detailsEl.setAttribute('open', true)
                });
            } else {
                gblOptions.ui.forEach((detailsOpt) => {
                    if (detailsOpt.open == true) {
                        var el = document.getElementById(detailsOpt.id);
                        if (el) el.setAttribute('open', true);
                    }
                });
            }

        }

        if (typeof gblOptions.filterOptions == 'undefined') {
            gblOptions.filterOptions = defaultFilterOptions;
        }

        // Reset columns to default to enforce layout: Pic, Username, Full Name
        gblOptions.queueColumns = JSON.parse(JSON.stringify(gbDefaultColumns));

        /*
        if (typeof gblOptions.queueColumns == 'undefined') {
            gblOptions.queueColumns = gbDefaultColumns;
        }

        for (var i = 0; i < gbDefaultColumns.length; i++) {

            var hasObj = false;
            for (var j = 0; j < gblOptions.queueColumns.length; j++) {
                if (gblOptions.queueColumns[j].data == gbDefaultColumns[i].data) {
                    hasObj = true;

                    if (gbDefaultColumns[i].bool == true) {
                        gblOptions.queueColumns[j]["bool"] = true;
                    }

                }
            }

            if (hasObj == false) {
                gblOptions.queueColumns.push(gbDefaultColumns[i]);
            }

        }
        */


        if (rdgAssistantState && rdgAssistantState.settings) {
            if (document.getElementById('txtrdgCoffeeActions')) {
                document.getElementById('txtrdgCoffeeActions').value = rdgAssistantState.settings.assistantPauseEveryInteractions || 30;
            }
            if (document.getElementById('txtrdgCoffeeMinutes')) {
                document.getElementById('txtrdgCoffeeMinutes').value = rdgAssistantState.settings.assistantPauseMinutesAfterBatch || 10;
            }
        }

        loadOptionsColumns();

        bindFilterInputs();

        bindEvents();

    });
}


function loadOptionsColumns() {
    var queueColumnsOptions = document.getElementById('queueColumnsOptions');

    for (var i = 0; i < gblOptions.queueColumns.length; i++) {

        var qc = gblOptions.queueColumns[i];

        var vizString = '';
        var disabledString = '';

        if (qc.visible == true) vizString = ' checked="' + qc.visible + '"'
        if (qc.data == 'id' || qc.data == 'username') disabledString = ' disabled="disabled"'

        var columnCheckbox = elementFromString('<label for="cb_' + qc.data + '"><input type="checkbox" id="cb_' + qc.data + '"' + vizString + disabledString + '>' + qc.name + "</label>");

        queueColumnsOptions.appendChild(columnCheckbox);

    }
}

function elementFromString(string) {
    var div = document.createElement('DIV');
    div.innerHTML = string;
    return div.firstChild;
}


function setFilterIconOpacity() {
    if (gblOptions.filterOptions.applyFiltersAutomatically == true && $('#radioFollow').is(':checked') == true) {
        document.getElementById('iconFilter').style.opacity = 1;
    } else if (gblOptions.dontUnFollowFilters == true && $('#radioUnFollow').is(':checked') == true) {
        document.getElementById('iconFilter').style.opacity = 1;
    } else if (gblOptions.dontRemoveOrBlockFilters == true && ($('#radioRemoveFromFollowers').is(':checked') == true || $('#radioBlock').is(':checked') == true)) {
        document.getElementById('iconFilter').style.opacity = 1;
    } else {
        document.getElementById('iconFilter').style.opacity = 0.5;
    }
}

function saveOptions() {

    gblOptions.filterOptions.applyFiltersAutomatically = document.getElementById('cbApplyFilterAutomatically').checked;
    gblOptions.filterOptions.private = document.getElementById('cbFollowPrivateAccounts').checked;
    gblOptions.filterOptions.non_private = document.getElementById('cbFilterNonPrivate').checked;
    gblOptions.filterOptions.verified = document.getElementById('cbFilterVerified').checked;
    gblOptions.filterOptions.non_verified = document.getElementById('cbFilterNonVerified').checked;
    gblOptions.filterOptions.follows_me = document.getElementById('cbFollowsMe').checked;
    gblOptions.filterOptions.non_follows_me = document.getElementById('cbNonFollowsMe').checked;
    gblOptions.filterOptions.followed_by_me = document.getElementById('cbFollowedByMe').checked;
    gblOptions.filterOptions.non_followed_by_me = document.getElementById('cbNonFollowedByMe').checked;
    gblOptions.filterOptions.is_joined_recently = document.getElementById('cbFilterJoinedRecently').checked;
    gblOptions.filterOptions.non_is_joined_recently = document.getElementById('cbFilterNonJoinedRecently').checked;
    gblOptions.filterOptions.is_business_account = document.getElementById('cbFilterBusiness').checked;
    gblOptions.filterOptions.non_is_business_account = document.getElementById('cbFilterNonBusiness').checked;
    gblOptions.filterOptions.bio_contains = document.getElementById('cbFilterBioContains').checked;
    gblOptions.filterOptions.bio_not_contains = document.getElementById('cbFilterBioNotContains').checked;
    gblOptions.filterOptions.bio_contains_text = document.getElementById('txtFilterBioContains').value;
    gblOptions.filterOptions.bio_not_contains_text = document.getElementById('txtFilterBioNotContains').value;
    gblOptions.filterOptions.external_url_contains = document.getElementById('cbFilterExternalUrlContains').checked;
    gblOptions.filterOptions.external_url_not_contains = document.getElementById('cbFilterExternalUrlNotContains').checked;
    gblOptions.filterOptions.external_url_contains_text = document.getElementById('txtFilterExternalUrlContains').value;
    gblOptions.filterOptions.external_url_not_contains_text = document.getElementById('txtFilterExternalUrlNotContains').value;
    gblOptions.filterOptions.no_profile_pic = document.getElementById('cbFilterNoProfilePic').checked;
    gblOptions.filterOptions.profile_pic = document.getElementById('cbFilterProfilePic').checked;
    gblOptions.filterOptions.business_category_name_contains = document.getElementById('cbFilterBusinessCategoryNameContains').checked;
    gblOptions.filterOptions.business_category_name_not_contains = document.getElementById('cbFilterBusinessCategoryNameNotContains').checked;
    gblOptions.filterOptions.business_category_name_contains_text = document.getElementById('txtFilterBusinessCategoryNameContains').value;
    gblOptions.filterOptions.business_category_name_not_contains_text = document.getElementById('txtFilterBusinessCategoryNameNotContains').value;


    var uiOptions = [];

    [...document.getElementsByTagName('details')].forEach((detailsEl) => {
        uiOptions.push({
            'id': detailsEl.id,
            'open': detailsEl.open ? true : false
        });
    });

    var filterOptions = gblOptions.filterOptions;
    var endcursors = gblOptions.endcursors;

    gblOptions.dontUnFollowFollowers = document.getElementById('cbDontUnfollowFollowers').checked;
    gblOptions.dontUnFollowNonRdg = false; // document.getElementById('cbdontUnFollowNonRdg').checked;
    gblOptions.dontUnFollowFilters = false; // document.getElementById('cbDontUnfollowFilters').checked;
    gblOptions.dontRemoveOrBlockFilters = document.getElementById('cbDontRemoveOrBlockFilters').checked;
    gblOptions.filterOptions = filterOptions;
    gblOptions.followPeopleAlreadyAttempted = document.getElementById('cbFollowAlreadyAttempted').checked;
    gblOptions.followPrivateAccounts = document.getElementById('cbFollowPrivateAccounts').checked;
    gblOptions.limitQueue = true;
    gblOptions.limitMediaQueue = document.getElementById('cbLimitMediaQueueSize').checked;
    gblOptions.maxAcctQueueLength = parseInt(document.getElementById('txtLimitQueueSize').value);
    gblOptions.maxMediaQueueLength = parseInt(document.getElementById('txtLimitMediaQueueSize').value);
    gblOptions.numberFollowLikeLatestPics = document.getElementById('numberFollowLikeLatestPics').value;
    var likeOnlyCountInput = document.querySelector('input[name="likeOnlyLatestPicsCount"]:checked');
    gblOptions.numberLikeOnlyLatestPics = likeOnlyCountInput ? parseInt(likeOnlyCountInput.value) : 1;
    var assistantControlsDelays = false;
    try {
        assistantControlsDelays = !!(rdgAssistantState &&
            rdgAssistantState.run &&
            ['running', 'waiting_instagram', 'resting', 'paused'].indexOf(rdgAssistantState.run.status) > -1);
    } catch (e) {}

    if (!assistantControlsDelays) {
        gblOptions.percentRandomTimeDelay = document.getElementById('igBotPercentRandomTimeDelay').value / 200;
    }
    gblOptions.showLikesInQueue = document.getElementById('cbShowLikesInQueue').checked;
    gblOptions.clickNotNow = document.getElementById('cbClickNotNow').checked;
    gblOptions.loadQueueOnStartup = document.getElementById('cbLoadQueueOnStartup').checked;
    gblOptions.cbShowQueueOnScreen = document.getElementById('cbShowQueueOnScreen').checked;
    gblOptions.cbRemoveUnusedColumns = document.getElementById('cbRemoveUnusedColumns').checked;
    gblOptions.removeAccountsFromQueue = document.getElementById('cbRemoveFromQueue').checked;
    gblOptions.autoSaveQueue = document.getElementById('cbAutoSaveQueue').checked;
    gblOptions.showConvenienceButtons = document.getElementById('cbConvenienceLinks').checked;
    gblOptions.showStamps = document.getElementById('cbShowStamps').checked;
    gblOptions.showProfilePicInQueue = document.getElementById('cbShowProfilePicInQueue').checked;
    gblOptions.getExtendedData = document.getElementById('cbGetExtendedData').checked;
    gblOptions.getLastPostDate = document.getElementById('cbGetLastPostDate').checked;
    if (!assistantControlsDelays) {
        gblOptions.timeDelay = document.getElementById('textSecondsBetweenActions').value * 1000;
    }
    gblOptions.timeDelayAfterHardRateLimit = document.getElementById('textHoursAfterHardRateLimit').value * 3600000;
    if (!assistantControlsDelays) {
        gblOptions.timeDelayAfterSkip = document.getElementById('textSecondsAfterSkip').value * 1000;
    }
    gblOptions.timeDelayAfterSoftRateLimit = document.getElementById('textMinutesAfterSoftRateLimit').value * 60000;
    gblOptions.timeDelayAfter429RateLimit = document.getElementById('textMinutesAfter429RateLimit').value * 60000;
    gblOptions.timeDelayAfterAdditionalInfo = document.getElementById('texttimeDelayAfterAdditionalInfo').value * 1000;
    gblOptions.useTimeDelayAfterAdditionalInfo = document.getElementById('cbuseTimeDelayAfterAdditionalInfo').checked;
    gblOptions.retriesAfterAdditionalInfo404 = Number(document.getElementById('textRetryAfterAdditionalInfo404').value);
    gblOptions.ui = uiOptions;
    gblOptions.unFollowFresh = true; // !document.getElementById('cbDontUnfollowFresh').checked;
    gblOptions.unFollowIfOld = false; // document.getElementById('cbUnfollowOld').checked;
    gblOptions.unFollowDelay = 0; // parseInt(document.getElementById('textUnfollowNew').value) * 86400000;
    gblOptions.unFollowIfOlderThan = 0; // parseInt(document.getElementById('textUnfollowOld').value) * 86400000;
    if (!assistantControlsDelays) {
        gblOptions.useRandomTimeDelay = document.getElementById('cbRandomizeTimeDelay').checked;
    }
    gblOptions.maxPerEnabled = document.getElementById('cbLimitActions').checked;
    gblOptions.maxPerActions = document.getElementById('textLimitActionsPer').value;
    gblOptions.maxPerPeriod = document.getElementById('textLimitActionsPerTime').value * 3600000;
    gblOptions.paginationLimit = $('#paginationLimit').val();
    gblOptions.mediapaginationLimit = $('#mediapaginationLimit').val();
    gblOptions.endcursors = endcursors;
    gblOptions.MediaIncludeLikersCommentersTagged = document.getElementById('cbMediaIncludeLikersCommentersTagged').checked;
    gblOptions.SaveWhenWatchingReel = document.getElementById('SaveWhenWatchingReel').checked;
    gblOptions.LikeWhenWatchingReel = document.getElementById('LikeWhenWatchingReel').checked;
    gblOptions.includeSuggestedPostsFromFeed = document.getElementById('includeSuggestedPostsFromFeed').checked;
    gblOptions.includePinnedPostForLikes = document.getElementById('includePinnedPostForLikes').checked;
    gblOptions.includePinnedPostForComments = document.getElementById('includePinnedPostForComments').checked;


    document.querySelectorAll('#detailsQueueColumns input').forEach((cb) => {
        var columnDataName = cb.id.replace('cb_', '');
        var columnObjIndex = gblOptions.queueColumns.findIndex(item => item.data == columnDataName);

        gblOptions.queueColumns[columnObjIndex].visible = cb.checked;
    });

    chrome.storage.local.set({
        gblOptions: gblOptions
    });

    // setFilterIconOpacity();
}


function loadPreviousAttempts(callback) {
    var scopedKey = rdgResolveAttemptedStorageKey();
    var storageKeys = rdgResolveAttemptedStorageKeyCandidates();
    chrome.storage.local.get(storageKeys, function(data) {
        var chosenKey = scopedKey;
        var interacted = null;
        var shouldMigrate = false;

        if (Array.isArray(data[scopedKey])) {
            interacted = data[scopedKey];
            chosenKey = scopedKey;
        } else {
            for (var i = 0; i < storageKeys.length; i++) {
                var candidateKey = storageKeys[i];
                if (!candidateKey || candidateKey === scopedKey || candidateKey === 'acctsAttempted') continue;
                if (!Array.isArray(data[candidateKey])) continue;
                interacted = data[candidateKey];
                chosenKey = candidateKey;
                shouldMigrate = true;
                break;
            }
        }

        if (!interacted && Array.isArray(data.acctsAttempted)) {
            interacted = data.acctsAttempted;
            chosenKey = 'acctsAttempted';
            shouldMigrate = true;
        }

        if (Array.isArray(interacted)) {
            acctsPreviouslyAttempted = rdgSanitizeAttemptedAcctsForScope(interacted, chosenKey === 'acctsAttempted');
            printMessage(chrome.i18n.getMessage('PreviouslyAttempted', [acctsPreviouslyAttempted.length]));
            if (shouldMigrate === true || chosenKey !== scopedKey) {
                rdgPersistAttemptedHistory(callback);
                return;
            }
            acctsPreviouslyAttempted = cleanAcctsForStorage(acctsPreviouslyAttempted);
            if (typeof callback === 'function') callback(acctsPreviouslyAttempted);
            return;
        }

        acctsPreviouslyAttempted = [];
        if (typeof callback === 'function') callback(acctsPreviouslyAttempted);
    })
}



function cleanAcctsForStorage(queueToOptimize) {
    var previousBytes = bytesFromString(JSON.stringify(queueToOptimize));

    for (var i = 0; i < queueToOptimize.length; i++) {
        var a = queueToOptimize[i];
        if (a.edge_felix_video_timeline) delete queueToOptimize[i].edge_felix_video_timeline;
        if (a.edge_felix_combined_post_uploads) delete queueToOptimize[i].edge_felix_combined_post_uploads;
        if (a.edge_felix_combined_draft_uploads) delete queueToOptimize[i].edge_felix_combined_draft_uploads;
        if (a.edge_felix_drafts) delete queueToOptimize[i].edge_felix_drafts;
        if (a.edge_felix_pending_draft_uploads) delete queueToOptimize[i].edge_felix_pending_draft_uploads;
        if (a.edge_felix_pending_post_uploads) delete queueToOptimize[i].edge_felix_pending_post_uploads;
        if (a.edge_saved_media) delete queueToOptimize[i].edge_saved_media;
        if (a.edge_media_collections) delete queueToOptimize[i].edge_media_collections;
        if (a.edge_owner_to_timeline_media && a.edge_owner_to_timeline_media.edges) queueToOptimize[i].edge_owner_to_timeline_media.edges = [];
    }

    var nowBytes = bytesFromString(JSON.stringify(queueToOptimize));
    var savedBytes = previousBytes - nowBytes;

    if (savedBytes > 0) {
        printMessage('Cleaned up accounts for storage and performance (saved ' + formatBytes(savedBytes) + ')');
    }

    return queueToOptimize;
}

function bytesFromString(str) {
    var bytes = 0,
        len = str.length,
        codePoint, next, i;

    for (i = 0; i < len; i++) {
        codePoint = str.charCodeAt(i);

        // Lone surrogates cannot be passed to encodeURI
        if (codePoint >= 0xD800 && codePoint < 0xE000) {
            if (codePoint < 0xDC00 && i + 1 < len) {
                next = str.charCodeAt(i + 1);

                if (next >= 0xDC00 && next < 0xE000) {
                    bytes += 4;
                    i++;
                    continue;
                }
            }
        }

        bytes += (codePoint < 0x80 ? 1 : (codePoint < 0x800 ? 2 : 3));
    }

    return bytes;
}

function formatBytes(bytes, decimals) {
    if (bytes == 0) return '0 Bytes';
    var k = 1024,
        dm = decimals <= 0 ? 0 : decimals || 2,
        sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
        i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function loadPreviousLikes() {
    chrome.storage.local.get("previousLikes", function(data) {
        if (Array.isArray(data.previousLikes)) {
            previousLikes = data.previousLikes;
            printMessage(chrome.i18n.getMessage('PreviouslyLiked', [previousLikes.length]));
        }
    })
}

function savePreviousLikesToStorage() {
    chrome.storage.local.set({
        previousLikes: previousLikes
    });
}

function addAcctToWhiteList(acct) {
    var acctInWhiteList = findAcctById(acct.id, acctsWhiteList);
    if (acct !== false && acctInWhiteList == false) {
        acctsWhiteList.push(acct);
        printMessage(acct.username + chrome.i18n.getMessage('AddedToWhitelist'));
        return true;
    } else {
        printMessage(acct.username + chrome.i18n.getMessage('AlreadyOnWhitelist'));
        return false;
    }
}

function loadWhiteList() {
    chrome.storage.local.get("acctsWhiteList", function(data) {
        if (Array.isArray(data.acctsWhiteList)) {
            acctsWhiteList = data.acctsWhiteList;
            printMessage(chrome.i18n.getMessage('WhitelistLoaded', [acctsWhiteList.length]));
        }
    })
}

function saveWhiteListToStorage() {
    chrome.storage.local.set({
        acctsWhiteList: acctsWhiteList
    });
    printMessage(chrome.i18n.getMessage('WhitelistSavedLocal'));
}

function saveWhiteListToDisk() {
    saveText("RDG-whitelist.txt", JSON.stringify(acctsWhiteList));
    printMessage(chrome.i18n.getMessage('WhitelistSavedFile'));
}

function saveWhiteListToStorageAndDisk() {
    saveWhiteListToStorage();
    saveWhiteListToDisk();
}

function saveText(filename, text) {
    var blob = new Blob([text], {
        type: "text/plain;charset=utf-8"
    });
    saveAs(blob, filename);
}

function viewWhiteList() {
    if (acctsWhiteList.length > 0) {

        dialog({
                yes: chrome.i18n.getMessage('WhitelistLoadFile'),
                no: chrome.i18n.getMessage('WhitelistLoadLocal'),
                question: chrome.i18n.getMessage('WhitelistLoadQuestion')
            },
            function() {
                openWhiteListFile()
            },
            function() {
                currentList = 'acctsWhiteList';
                arrayOfUsersToDiv(acctsWhiteList, true);
                $('#btnSaveWhiteList').show();
            });

    } else {
        openWhiteListFile();
    }
}

function openWhiteListFile() {
    var input = document.createElement("input");
    input.setAttribute('type', 'file');
    input.setAttribute('accept', 'text/plain,text/json,application/JSON');

    input.addEventListener("change", function() {
        if (this.files && this.files[0]) {
            var myFile = this.files[0];
            var reader = new FileReader();

            reader.addEventListener('load', function(e) {
                acctsWhiteList = JSON.parse(e.target.result);
                currentList = 'acctsWhiteList';
                arrayOfUsersToDiv(acctsWhiteList, true);
            });

            reader.readAsText(myFile);
        }
    });

    input.click();
}



function openQueueFile() {
    var input = document.createElement("input");
    input.setAttribute('type', 'file');
    input.setAttribute('accept', 'text/plain,text/json,application/JSON');

    input.addEventListener("change", function() {
        if (this.files && this.files[0]) {
            var myFile = this.files[0];
            var reader = new FileReader();

            reader.addEventListener('load', function(e) {
                var fileData = e.target.result;

                if (fileData.indexOf('relationships_follow_requests_sent') > -1) {
                    var fileJSON = JSON.parse(e.target.result);
                    var pendingArray = fileJSON.relationships_follow_requests_sent;

                    for (var i = 0; i < pendingArray.length; i++) {

                        if (pendingArray[i].string_list_data &&
                            pendingArray[i].string_list_data.length > 0 &&
                            pendingArray[i].string_list_data[0].value) {

                            acctsQueue.push({
                                "username": pendingArray[i].string_list_data[0].value
                            });
                        }
                    }

                    alert('Fila parcial carregada da lista de usuários. Antes do RDG instaPRO poder usar essa fila, você precisará processar a fila com "Obter Mais Dados" selecionado.');

                } else if (fileData.indexOf('{') > -1) {
                    // JSON
                    acctsQueue = JSON.parse(e.target.result);
                    currentList = 'acctsQueue';

                    if (acctsQueue.length > gblOptions.maxAcctQueueLength &&
                        gblOptions.limitQueue == true &&
                        window.confirm('Saved queue has ' + acctsQueue.length + ' accounts, limit to first ' + gblOptions.maxAcctQueueLength + ' accounts?')) {

                        truncateQueue();
                    }

                    acctsQueue = cleanAcctsForStorage(acctsQueue);

                } else if (fileData.indexOf(',') > -1 || fileData.indexOf('\n') > -1 || fileData.indexOf('\r') > -1) {
                    // file has newlines or commas but not {
                    // clean windows newlines, double newlines, replace newlines with comma, parse as csv
                    fileData = fileData.replace(/\r/g, '\n');
                    fileData = fileData.replace(/\n\n/g, '\n');
                    fileData = fileData.replace(/\n/g, ',');
                    fileData = fileData.replace(/,,/g, ',');

                    var arrr = fileData.split(',');
                    for (var i = 0; i < arrr.length; i++) {
                        acctsQueue.push({
                            "username": arrr[i]
                        });
                    }

                    alert('Fila parcial carregada da lista de usuários. Antes do RDG instaPRO poder usar essa fila, você precisará processar a fila com "Obter Mais Dados" selecionado.');
                } else {
                    alert("Erro: Não foi possível carregar o arquivo de fila. Tem certeza de que é uma fila do RDG instaPRO?");
                }

                acctsQueue = fixAcctQueueCounts(acctsQueue);


                arrayOfUsersToDiv(acctsQueue, true);

            });

            reader.readAsText(myFile);
        }
    });

    input.click();
}



function loadSavedQueue() {
    chrome.storage.local.get("acctsQueue", function(data) {
        if (Array.isArray(data.acctsQueue)) {

            dialog({
                    no: chrome.i18n.getMessage('QueueLoadFile'),
                    yes: chrome.i18n.getMessage('QueueLoadLocal'),
                    question: chrome.i18n.getMessage('QueueLoadQuestion')
                },
                function() {
                    acctsQueue = data.acctsQueue;

                    if (acctsQueue.length > gblOptions.maxAcctQueueLength &&
                        gblOptions.limitQueue == true &&
                        window.confirm('Saved queue has ' + acctsQueue.length + ' accounts, limit to first ' + gblOptions.maxAcctQueueLength + ' accounts?')) {

                        truncateQueue();
                    }

                    arrayOfUsersToDiv(acctsQueue, true);

                    printMessage(chrome.i18n.getMessage('QueueLoaded', [acctsQueue.length]));
                },
                function() {
                    openQueueFile();
                })
        } else {
            openQueueFile();
        }
    });
}


function loadQueueFromLocal() {
    chrome.storage.local.get("acctsQueue", function(data) {
        if (Array.isArray(data.acctsQueue)) {

            acctsQueue = JSON.parse(JSON.stringify(data.acctsQueue));

            acctsQueue = fixAcctQueueCounts(acctsQueue);

            arrayOfUsersToDiv(acctsQueue, true, true);

            printMessage(chrome.i18n.getMessage('QueueLoaded', [acctsQueue.length]));
        }
    });
}


function fixAcctQueueCounts(q) {

    var newArr = [];

    for (var i = 0; i < q.length; i++) {

        var newq = q[i];

        // if (q[i]["edge_owner_to_timeline_media.count"]) {
        if (q[i]["edge_owner_to_timeline_media.count"]) {
            newq.edge_owner_to_timeline_media = {
                "count": q[i]["edge_owner_to_timeline_media.count"]
            }
            delete newq["edge_owner_to_timeline_media.count"];
        } else {
            newq.edge_owner_to_timeline_media = {
                "count": 0
            }

        }
        // }

        //  if (q[i]["edge_followed_by.count"]) {
        if (q[i]["edge_followed_by.count"]) {
            newq["edge_followed_by"] = {
                "count": q[i]["edge_followed_by.count"]
            }
            delete newq["edge_followed_by.count"]

        }
        //  }

        //   if (q[i]["edge_follow.count"]) {
        if (q[i]["edge_follow.count"]) {
            newq["edge_follow"] = {
                "count": q[i]["edge_follow.count"]
            }
            delete newq["edge_follow.count"]
        }
        //   }

        // if (q[i]["edge_mutual_followed_by.count"]) {
        if (q[i]["edge_mutual_followed_by.count"]) {
            newq["edge_mutual_followed_by"] = {
                "count": q[i]["edge_mutual_followed_by.count"]
            }
            delete newq["edge_mutual_followed_by.count"]
        } else {
            newq["edge_mutual_followed_by"] = {
                "count": 0
            }
        }
        // }

        newArr.push(JSON.parse(JSON.stringify(newq)))

    }


    return newArr;

}


function generateFileName() {
    var fileName = "rdg_instapro";

    var endCursorsForThisPage = gblOptions.endcursors;

    endCursorsForThisPage = endCursorsForThisPage.filter(e => e.id === currentProfilePage.id);

    if (endCursorsForThisPage.length > 0) {
        var p = endCursorsForThisPage[endCursorsForThisPage.length - 1];
        fileName = fileName + '-' + p.username;
        fileName = fileName + '-' + p.action.replace('load', '').toLowerCase();
    } else {
        fileName = fileName + '-' + 'queue';
    }


    return fileName;
}

function saveQueueToDisk() {
    saveText("RDG FILA.txt", JSON.stringify(acctsQueue));
    printMessage(chrome.i18n.getMessage('QueueSavedFile'));
}


function saveQueueToStorage() {
    chrome.storage.local.set({
        acctsQueue: acctsQueue
    }, function() {
        printMessage(chrome.i18n.getMessage('QueueSavedLocal'));
    });
}

function saveQueueToStorageAndDisk() {
    saveQueueToStorage();
    saveQueueToDisk();
}



function initUnfollowMyFollowers() {
    if (acctsQueue.length === 0 && window.confirm('Queue empty, load your following and begin unfollowing?') === true) {
        ajaxGetAllMyFollowing('');
        waitForTrue(['loadedMyFollowings'], ajaxUnfollowAll, []);
    } else {
        ajaxUnfollowAll();
    }
}


async function ajaxLoadUsersMedia(after, loadAllMedia, callback, acct) {

    if (!acct) acct = currentProfilePage;

    if (typeof after != 'string') {
        after = '';
    } else {
        after = '%22after%22%3A%22' + after + '%22%2C';
    }

    const fetchMedia = await fetch("https://www.instagram.com/graphql/query", {
        "headers": {
            "accept": "*/*",
            "content-type": "application/x-www-form-urlencoded",
            "priority": "u=1, i",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "x-asbd-id": "129477",
            "x-csrftoken": getCsrfFromCookie(),
            "x-fb-friendly-name": "PolarisProfilePostsQuery",
            "x-ig-app-id": "936619743392459"
        },
        "referrer": "https://www.instagram.com/" + acct.username + "/",
        "referrerPolicy": "strict-origin-when-cross-origin",
        "body": "av=17841400482242408&__d=www&__user=0&__a=1&__req=7&__hs=20028.HYP%3Ainstagram_web_pkg.2.1..0.1&dpr=1&__ccg=EXCELLENT&__rev=1017870321&__s=xc4v6e%3Api17z8%3Awisy8l&__hsi=7432327050990328368&__csr=&__comet_req=7&jazoest=26364&__spin_r=1017870321&__spin_b=trunk&__spin_t=1730473490&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=PolarisProfilePostsQuery&variables=%7B" + after + "%22data%22%3A%7B%22count%22%3A12%2C%22include_relationship_info%22%3Atrue%2C%22latest_besties_reel_media%22%3Atrue%2C%22latest_reel_media%22%3Atrue%7D%2C%22username%22%3A%22" + acct.username + "%22%2C%22__relay_internal__pv__PolarisIsLoggedInrelayprovider%22%3Atrue%2C%22__relay_internal__pv__PolarisFeedShareMenurelayprovider%22%3Atrue%7D&server_timestamps=true&doc_id=8633614153419931",
        "method": "POST",
        "mode": "cors",
        "credentials": "include"
    });

    var jsonData = await fetchMedia.json();
    var r = jsonData.data.xdt_api__v1__feed__user_timeline_graphql_connection;

    r.acct = acct;
    callback(r);
}


async function ajaxLoadAllUsersCommenters(after) {
    if (typeof currentProfilePage === 'undefined' || !currentProfilePage || !currentProfilePage.id) {
        var uname = getCurrentPageUsername();
        if (uname) {
            try {
                var fetchedUser = await getUserInfoFromGraphQL(uname);
                if (fetchedUser && fetchedUser.id) {
                    currentProfilePage = fetchedUser;
                } else {
                    currentProfilePage = { id: uname, username: uname, edge_followed_by: { count: 0 }, edge_follow: { count: 0 } };
                }
            } catch(eFetchUser) {
                currentProfilePage = { id: uname, username: uname, edge_followed_by: { count: 0 }, edge_follow: { count: 0 } };
            }
        }
    }



    if (typeof after != 'string') {
        after = '';
    } else {
        after = '%22after%22%3A%22' + after + '%22%2C';
    }

    const fetchMedia = await fetch("https://www.instagram.com/graphql/query", {
        "headers": {
            "accept": "*/*",
            "content-type": "application/x-www-form-urlencoded",
            "priority": "u=1, i",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "x-asbd-id": "129477",
            "x-csrftoken": getCsrfFromCookie(),
            "x-fb-friendly-name": "PolarisProfilePostsQuery",
            "x-ig-app-id": "936619743392459"
        },
        "referrer": "https://www.instagram.com/" + currentProfilePage.username + "/",
        "referrerPolicy": "strict-origin-when-cross-origin",
        "body": "av=17841400482242408&__d=www&__user=0&__a=1&__req=7&__hs=20028.HYP%3Ainstagram_web_pkg.2.1..0.1&dpr=1&__ccg=EXCELLENT&__rev=1017870321&__s=xc4v6e%3Api17z8%3Awisy8l&__hsi=7432327050990328368&__csr=&__comet_req=7&jazoest=26364&__spin_r=1017870321&__spin_b=trunk&__spin_t=1730473490&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=PolarisProfilePostsQuery&variables=%7B" + after + "%22data%22%3A%7B%22count%22%3A12%2C%22include_relationship_info%22%3Atrue%2C%22latest_besties_reel_media%22%3Atrue%2C%22latest_reel_media%22%3Atrue%7D%2C%22username%22%3A%22" + currentProfilePage.username + "%22%2C%22__relay_internal__pv__PolarisIsLoggedInrelayprovider%22%3Atrue%2C%22__relay_internal__pv__PolarisFeedShareMenurelayprovider%22%3Atrue%7D&server_timestamps=true&doc_id=8633614153419931",
        "method": "POST",
        "mode": "cors",
        "credentials": "include"
    });

    var jsonData = await fetchMedia.json();
    var r = jsonData.data.xdt_api__v1__feed__user_timeline_graphql_connection;

    loadCommentsForMedia(r);
}


async function loadMoreCommentsForMedia2(media, nextMinId) {

    return new Promise(async function(resolve, reject) {

        var url = "https://www.instagram.com/api/v1/media/" + media.id + "/comments/?can_support_threading=true&permalink_enabled=false";

        if (nextMinId && nextMinId !== 0) {
            url = url + '&min_id=' + encodeURIComponent(nextMinId);
        }

        const fetchComments = await fetch(url, {
            "headers": {
                "accept": "*/*",
                "accept-language": "en-US,en;q=0.9",
                "priority": "u=1, i",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
                "x-asbd-id": "129477",
                "x-csrftoken": getCsrfFromCookie(),
                "x-ig-app-id": "936619743392459",
                "x-requested-with": "XMLHttpRequest"
            },
            "referrer": "https://www.instagram.com/p/DB1UCFKuS8u/",
            "referrerPolicy": "strict-origin-when-cross-origin",
            "body": null,
            "method": "GET",
            "mode": "cors",
            "credentials": "include"
        });
        var jsonData = await fetchComments.json();
        var c = jsonData.comments;
        media.nextMinId = jsonData.next_min_id || 0;

        if (media.comments) {

        } else {
            media.comments = [];
        }

        for (var i = 0; i < c.length; i++) {
            media.comments.push(c[i]);
        }


        resolve(media);
    });

}

async function loadCommentsForMedia(r) {
    for (var i = 0; i < r.edges.length; i++) {

        var media = r.edges[i];

        if (gblOptions.includePinnedPostForComments == false && media.node.timeline_pinned_user_ids.length > 0) continue;

        var mediaWithComments = await loadMoreCommentsForMedia2(media.node);

        for (j = 0; j < (mediaWithComments.comment_count / 1); j++) {

            if (mediaWithComments.comment_count > 0 &&
                mediaWithComments.comments &&
                mediaWithComments.comments.length < mediaWithComments.comment_count &&
                mediaWithComments.nextMinId &&
                mediaWithComments.nextMinId !== 0) {

                mediaWithComments = await loadMoreCommentsForMedia2(mediaWithComments, mediaWithComments.nextMinId);

            } else {
                break;
            }

            var users = allNodes(mediaWithComments.comments, 'user');
            for (var k = 0; k < users.length; k++) {
                var u = users[k];
                acctsQueue.push(u);
            }

            acctsQueue = uniq(acctsQueue);

            mediaToLike.push(media.node);


            arrayOfUsersToDiv(acctsQueue, true);
            arrayOfMediaToDiv(mediaToLike, true);

            if ((gblOptions.limitQueue == true && acctsQueue.length > gblOptions.maxAcctQueueLength)) {
                printMessage(chrome.i18n.getMessage('Done') + chrome.i18n.getMessage('QueueLimitReached'));
                return false;
            }

        }

        outputMessage('Loaded ' + mediaWithComments.comments.length + '/' + mediaWithComments.comment_count + ' comments for post ' + (i + 1) + '/' + r.edges.length);

    }

    if ((gblOptions.limitQueue == true && acctsQueue.length > gblOptions.maxAcctQueueLength)) {
        arrayOfUsersToDiv(acctsQueue, true);
        printMessage(chrome.i18n.getMessage('Done') + chrome.i18n.getMessage('QueueLimitReached'));
        return false;
    }

    if (r.page_info.has_next_page == true) {
        outputMessage('waiting 2 seconds to load the next batch of posts for comments');
        timeoutsQueue.push(setTimeout(function() {
            ajaxLoadAllUsersCommenters(r.page_info.end_cursor);
        }, 2000));
    } else {
        printMessage(chrome.i18n.getMessage('Done'));
    }
}

async function ajaxLoadAllUsersLikers(after) {
    if (typeof currentProfilePage === 'undefined' || !currentProfilePage || !currentProfilePage.id) {
        var uname = getCurrentPageUsername();
        if (uname) {
            try {
                var fetchedUser = await getUserInfoFromGraphQL(uname);
                if (fetchedUser && fetchedUser.id) {
                    currentProfilePage = fetchedUser;
                } else {
                    currentProfilePage = { id: uname, username: uname, edge_followed_by: { count: 0 }, edge_follow: { count: 0 } };
                }
            } catch(eFetchUser) {
                currentProfilePage = { id: uname, username: uname, edge_followed_by: { count: 0 }, edge_follow: { count: 0 } };
            }
        }
    }

    if (typeof after != 'string') {
        after = '';
    } else {
        after = '%22after%22%3A%22' + after + '%22%2C';
    }


    const fetchMedia = await fetch("https://www.instagram.com/graphql/query", {
        "headers": {
            "accept": "*/*",
            "content-type": "application/x-www-form-urlencoded",
            "priority": "u=1, i",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "x-asbd-id": "129477",
            "x-csrftoken": getCsrfFromCookie(),
            "x-fb-friendly-name": "PolarisProfilePostsQuery",
            "x-ig-app-id": "936619743392459"
        },
        "referrer": "https://www.instagram.com/" + currentProfilePage.username + "/",
        "referrerPolicy": "strict-origin-when-cross-origin",
        "body": "av=17841400482242408&__d=www&__user=0&__a=1&__req=7&__hs=20028.HYP%3Ainstagram_web_pkg.2.1..0.1&dpr=1&__ccg=EXCELLENT&__rev=1017870321&__s=xc4v6e%3Api17z8%3Awisy8l&__hsi=7432327050990328368&__csr=&__comet_req=7&jazoest=26364&__spin_r=1017870321&__spin_b=trunk&__spin_t=1730473490&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=PolarisProfilePostsQuery&variables=%7B" + after + "%22data%22%3A%7B%22count%22%3A12%2C%22include_relationship_info%22%3Atrue%2C%22latest_besties_reel_media%22%3Atrue%2C%22latest_reel_media%22%3Atrue%7D%2C%22username%22%3A%22" + currentProfilePage.username + "%22%2C%22__relay_internal__pv__PolarisIsLoggedInrelayprovider%22%3Atrue%2C%22__relay_internal__pv__PolarisFeedShareMenurelayprovider%22%3Atrue%7D&server_timestamps=true&doc_id=8633614153419931",
        "method": "POST",
        "mode": "cors",
        "credentials": "include"
    });

    var jsonData = await fetchMedia.json();
    var r = jsonData.data.xdt_api__v1__feed__user_timeline_graphql_connection;

    beginLoadLikesForMedia(r);

}


async function loadLikesForQueueMedia() {
    for (var j = 0; j < likers.length; j++) {
        if ((gblOptions.limitQueue == true && acctsQueue.length < gblOptions.maxAcctQueueLength) || gblOptions.limitQueue == false) {
            if (findAcctById(likers[j].id, acctsQueue) === false) {
                acctsQueue.push(likers[j]);
            }
        } else {

            arrayOfUsersToDiv(acctsQueue, true);
            arrayOfMediaToDiv(mediaToLike, true);

            printMessage(chrome.i18n.getMessage('Done') + chrome.i18n.getMessage('QueueLimitReached'));
            return false;
        }
    }
}


async function beginLoadLikesForMedia(r) {

    for (var i = 0; i < r.edges.length; i++) {
        var media = r.edges[i];

        if (gblOptions.includePinnedPostForLikes == false && media.node.timeline_pinned_user_ids.length > 0) continue;

        mediaToLike.push(media.node);

        let likers = await loadLikesForMedia(media);

        for (var j = 0; j < likers.length; j++) {
            if ((gblOptions.limitQueue == true && acctsQueue.length < gblOptions.maxAcctQueueLength) || gblOptions.limitQueue == false) {
                if (findAcctById(likers[j].id, acctsQueue) === false) {
                    acctsQueue.push(likers[j]);
                }
            } else {

                arrayOfUsersToDiv(acctsQueue, true);
                arrayOfMediaToDiv(mediaToLike, true);

                printMessage(chrome.i18n.getMessage('Done') + chrome.i18n.getMessage('QueueLimitReached'));
                return false;
            }
        }

    }

    arrayOfUsersToDiv(acctsQueue, false);
    arrayOfMediaToDiv(mediaToLike, false);

    if (r.page_info.has_next_page == true) {
        outputMessage('waiting 2 seconds to load more media for likes');
        timeoutsQueue.push(setTimeout(function() {
            ajaxLoadAllUsersLikers(r.page_info.end_cursor);
        }, 2000));
    } else {
        printMessage(chrome.i18n.getMessage('Done'));
    }
}

function loadLikesForMedia(media) {

    return new Promise(function(resolve, reject) {

        let retMedia = media;

        $.ajax({
                url: 'https://www.instagram.com/api/v1/media/' + media.node.id + '/likers/',
                method: 'GET',
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                    xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                    xhr.setRequestHeader('x-asbd-id', '129477');
                    xhr.setRequestHeader('x-ig-app-id', '936619743392459');
                },
                xhrFields: {
                    withCredentials: true
                }
            })
            .done(function(r) {

                let retLikers = [];

                if (r.users) {
                    for (var i = 0; i < r.users.length; i++) {
                        var a = r.users[i];
                        a['id'] = a.pk;
                        retLikers.push(a);
                    }

                    resolve(retLikers);
                }

            }).fail(function(f) {
                if (f.status == 429) {
                    printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(function() {
                        resolve(loadLikesForMedia(media));
                    }, gblOptions.timeDelayAfter429RateLimit));
                }
            });

    });
}

var extensionId = chrome.i18n.getMessage("@@extension_id");

function getLikersFromMediaArray() {
    let accountsThatLiked = [];

    for (var i = 0; i < mediaForLikes.length; i++) {
        var media = mediaForLikes[i];

        for (var j = 0; j < media.data.shortcode_media.edge_liked_by.edges.length; j++) {
            var like = media.data.shortcode_media.edge_liked_by.edges[j].node;
            if (typeof like == 'undefined') {
                like = media.data.shortcode_media.edge_liked_by.edges[j];
            }
            if (accountIdsThatLiked.indexOf(like.id) == -1) {
                accountIdsThatLiked.push(like.id);
                accountsThatLiked.push(like);
            }
        }
    }

    if (acctsQueue.length == 0) {
        acctsQueue = accountsThatLiked;
    } else {
        for (var i = 0; i < accountsThatLiked.length; i++) {
            if ((gblOptions.limitQueue == true && acctsQueue.length < gblOptions.maxAcctQueueLength) || gblOptions.limitQueue == false) {
                if (findAcctById(accountsThatLiked[i].id, acctsQueue) === false) {
                    acctsQueue.push(accountsThatLiked[i]);
                }
            } else {
                arrayOfUsersToDiv(accountsThatLiked, false);
                return false;
            }
        }
    }

    arrayOfUsersToDiv(accountsThatLiked, false);
}


function ajaxGetPendingFollowRequests(after) {

    alert('Sorry, but Instagram has disabled this feature :(\n\nYou can download your data from:\n\nhttps://www.instagram.com/download/request');
    return false;

    $('#btnLoadPendingRequests').addClass('pulsing');

    if (typeof after != 'string') {
        acctsQueue = [];
        after = '';
    }

    var url = 'https://www.instagram.com/accounts/access_tool/current_follow_requests?__a=1';

    if (after != '') {
        url = url + '&cursor=' + after;
    }

    $.ajax(url)
        .done(function(r) {
            var tmpQueue = [];

            var promises = [];

            $(r.data.data).each(function(edge) {

                var u = {
                    username: $(this)[0].text
                }

                var promise = new Promise(async function(resolve, reject) {
                    u = await getAdditionalDataForAcct(u);
                    acctsQueue.push(u);
                    tmpQueue.push(u);
                    resolve(u);
                });
                promises.push(promise);

            });

            var result = Promise.all(promises);

            result.then(function(data) {
                arrayOfUsersToDiv(tmpQueue, false);

                if (r.data.cursor && (acctsQueue.length < parseInt(gblOptions.maxAcctQueueLength) || gblOptions.limitQueue != true)) {
                    printMessage(chrome.i18n.getMessage('AccountsLoaded', [tmpQueue.length.toString(), acctsQueue.length.toString()]));
                    ajaxGetPendingFollowRequests(r.data.cursor);
                } else {
                    $('#btnLoadPendingRequests').removeClass('pulsing');
                    printMessage(chrome.i18n.getMessage('Done'));
                }

            })


        }).fail(function(f) {
            if (f.status == 429) {
                printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                timeoutsQueue.push(setTimeout(function() {
                    ajaxGetPendingFollowRequests(after);
                }, gblOptions.timeDelayAfter429RateLimit));
            }
        });


}


async function ajaxGetAllUsersFollowers(after) {
    var uname = getCurrentPageUsername();

    if (typeof currentProfilePage === 'undefined' || !currentProfilePage || !currentProfilePage.id || !/^\d+$/.test(String(currentProfilePage.id))) {
        var resolvedId = await new Promise(function(resolve) {
            if (typeof getTargetProfileIdFromPage === 'function') {
                getTargetProfileIdFromPage(resolve);
            } else if (typeof window.betaResolveNumericIdByUsername === 'function') {
                window.betaResolveNumericIdByUsername(uname, resolve);
            } else {
                resolve(null);
            }
        });

        if (resolvedId) {
            currentProfilePage = { id: String(resolvedId), username: uname || 'perfil', edge_followed_by: { count: 1000 }, edge_follow: { count: 0 } };
        } else {
            currentProfilePage = { id: uname, username: uname, edge_followed_by: { count: 0 }, edge_follow: { count: 0 } };
        }
    }

    if (typeof after != 'string') {
        after = '';
        if (gblOptions.endcursors) {
            var endCursorsForThisPageAndAction = gblOptions.endcursors.filter(e => e.action === 'loadFollowers' && e.id === currentProfilePage.id);
            if (endCursorsForThisPageAndAction.length > 0) {
                if (window.confirm('Você gostaria de tentar continuar de onde parou?')) {
                    var objEndCursor = endCursorsForThisPageAndAction[endCursorsForThisPageAndAction.length - 1];
                    after = objEndCursor.endcursor;
                    gblOptions.truncateStart = 0;
                }
            }
        }
    }

    var limitToFetch = (gblOptions && gblOptions.limitQueue === true && gblOptions.maxAcctQueueLength) ? parseInt(gblOptions.maxAcctQueueLength, 10) : 99999999;

    // Estratégia Principal: Utilizar fetchRecentFollowers se ID numérico estiver disponível
    if (typeof fetchRecentFollowers === 'function' && /^\d+$/.test(String(currentProfilePage.id))) {
        printMessage("Buscando seguidores para @" + (currentProfilePage.username || uname) + "...");
        fetchRecentFollowers(String(currentProfilePage.id), limitToFetch, acctsQueue.length, function(users) {
            if (Array.isArray(users) && users.length > 0) {
                var tmpQueue = [];
                users.forEach(function(u) {
                    var normalizedUser = {
                        id: String(u.id || u.pk),
                        pk: String(u.id || u.pk),
                        username: u.username,
                        profile_pic_url: u.profile_pic_url || '',
                        full_name: u.full_name || u.username,
                        is_verified: !!u.is_verified
                    };
                    acctsQueue.push(normalizedUser);
                    tmpQueue.push(normalizedUser);
                });

                printMessage(chrome.i18n.getMessage('AccountsLoaded', [tmpQueue.length, acctsQueue.length]));
                truncateQueue(gblOptions.truncateStart || 0);
                $('#btnProcessQueue').removeClass('pulsing');
                arrayOfUsersToDiv(acctsQueue, true);
                printMessage(chrome.i18n.getMessage('Done'));
            } else {
                tryGraphQL();
            }
        });
        return;
    }

    tryGraphQL();

    function tryGraphQL() {
        var jsonvars = { id: currentProfilePage.id, first: 48 };
        if (after != '') jsonvars.after = after;
        var url = 'https://www.instagram.com/graphql/query/?query_hash=c76146de99bb02f6415203be841dd25a&variables=' + encodeURIComponent(JSON.stringify(jsonvars));

        $.ajax(url)
            .done(function(r) {
                var tmpQueue = [];
                if (r && r.data && r.data.user && r.data.user.edge_followed_by) {
                    $(r.data.user.edge_followed_by.edges).each(function() {
                        var u = $(this)[0].node;
                        acctsQueue.push(u);
                        tmpQueue.push(u);
                    });

                    printMessage(chrome.i18n.getMessage('AccountsLoaded', [tmpQueue.length, acctsQueue.length]));

                    if (r.data.user.edge_followed_by.page_info && r.data.user.edge_followed_by.page_info.has_next_page == true &&
                        (acctsQueue.length < (parseInt(gblOptions.truncateStart || 0) + parseInt(gblOptions.maxAcctQueueLength || 200)))
                    ) {
                        ajaxGetAllUsersFollowers(r.data.user.edge_followed_by.page_info.end_cursor);
                    } else {
                        truncateQueue(gblOptions.truncateStart || 0);
                        $('#btnProcessQueue').removeClass('pulsing');
                        arrayOfUsersToDiv(acctsQueue, true);
                        printMessage(chrome.i18n.getMessage('Done'));
                    }
                } else {
                    printMessage("Nenhum seguidor retornado.");
                }
            })
            .fail(function(f) {
                printMessage("Erro na busca de seguidores (" + (f && f.status ? f.status : '-') + ").");
            });
    }
}


async function ajaxLoadFollowing(after) {
    if (typeof currentProfilePage === 'undefined' || !currentProfilePage || !currentProfilePage.id) {
        var uname = getCurrentPageUsername();
        if (uname) {
            try {
                var fetchedUser = await getUserInfoFromGraphQL(uname);
                if (fetchedUser && fetchedUser.id) {
                    currentProfilePage = fetchedUser;
                } else {
                    currentProfilePage = { id: uname, username: uname, edge_followed_by: { count: 0 }, edge_follow: { count: 0 } };
                }
            } catch(eFetchUser) {
                currentProfilePage = { id: uname, username: uname, edge_followed_by: { count: 0 }, edge_follow: { count: 0 } };
            }
        }
    }


    if (typeof after != 'string') {
        // acctsQueue = [];
        after = '';


        if (gblOptions.endcursors) {

            var endCursorsForThisPageAndAction = gblOptions.endcursors;
            endCursorsForThisPageAndAction = endCursorsForThisPageAndAction.filter(e => e.action === 'loadFollowing' && e.id === currentProfilePage.id);

            if (endCursorsForThisPageAndAction.length > 0) {
                if (window.confirm('Deseja tentar continuar de onde parou?')) {
                    var objEndCursor = endCursorsForThisPageAndAction[endCursorsForThisPageAndAction.length - 1];
                    after = objEndCursor.endcursor;
                    gblOptions.truncateStart = 0;
                }
            }

        }

    }

    if (after == '' && currentProfilePage.edge_follow.count > gblOptions.maxAcctQueueLength && gblOptions.limitQueue == true) {
        var promptAfter = window.prompt("A conta está seguindo " + currentProfilePage.edge_follow.count + " perfis, mas seu limite de fila está definido como " + gblOptions.maxAcctQueueLength + ". \n\n Digite o número do seguindo para começar (0 é o mais recente).", gblOptions.truncateStart);
        if (!isNaN(parseInt(promptAfter))) {
            gblOptions.truncateStart = parseInt(promptAfter);
        }
    }

    var jsonvars = {
        id: currentProfilePage.id,
        first: 48
    }

    if (after != '') {
        jsonvars.after = after;
    }

    var urljsonvars = JSON.stringify(jsonvars);

    //58712303d941c6855d4e888c5f0cd22f
    var url = 'https://www.instagram.com/graphql/query/?query_hash=c56ee0ae1f89cdbd1c89e2bc6b8f3d18&variables=' + encodeURIComponent(urljsonvars);


    $.ajax(url)
        .done(function(r) {

            var tmpQueue = [];

            $(r.data.user.edge_follow.edges).each(function(edge) {
                var u = $(this)[0].node;
                acctsQueue.push(u);
                tmpQueue.push(u);
            });

            //arrayOfUsersToDiv(tmpQueue, false);

            printMessage(chrome.i18n.getMessage('AccountsLoaded', [tmpQueue.length, acctsQueue.length]));



            if (r.data.user.edge_follow.page_info.end_cursor) {
                var todaysdate = new Date();
                gblOptions.endcursors.push({
                    id: currentProfilePage.id,
                    username: currentProfilePage.username,
                    action: 'loadFollowing',
                    endcursor: r.data.user.edge_follow.page_info.end_cursor,
                    time: todaysdate.getTime()
                });
                saveOptions();
            }

            if (r.data.user.edge_follow.page_info.has_next_page == true &&
                (acctsQueue.length < (parseInt(gblOptions.truncateStart) + parseInt(gblOptions.maxAcctQueueLength)) ||
                    gblOptions.limitQueue != true ||
                    currentProfilePage.edge_follow.count < parseInt(gblOptions.maxAcctQueueLength))
            ) {
                ajaxLoadFollowing(r.data.user.edge_follow.page_info.end_cursor);

                if (!gblOptions.endcursors) gblOptions['endcursors'] = [];



            } else {
                truncateQueue(gblOptions.truncateStart);

                arrayOfUsersToDiv(acctsQueue, true);

                outputMessage(currentProfilePage.username + ' following loaded.  Count: ' + acctsQueue.length);
                printMessage(' ');

                loadedTheirFollowings = true;
            }

        });
}

function ajaxGetAllMyFollowing(after) {

    var jsonvars = {
        id: user.viewer.id,
        first: 48
    }

    if (after != '') {
        jsonvars.after = after;
    }

    var urljsonvars = JSON.stringify(jsonvars);

    var url = 'https://www.instagram.com/graphql/query/?query_hash=58712303d941c6855d4e888c5f0cd22f&variables=' + encodeURIComponent(urljsonvars);

    $.ajax(url)
        .done(function(r) {

            var tmpQueue = [];

            $(r.data.user.edge_follow.edges).each(function(edge) {
                var u = $(this)[0].node;
                acctsQueue.push(u);
                tmpQueue.push(u);
            });

            printMessage(chrome.i18n.getMessage('AccountsLoaded', [tmpQueue.length, acctsQueue.length]));

            if (r.data.user.edge_follow.page_info.has_next_page == true) {
                ajaxGetAllMyFollowing(r.data.user.edge_follow.page_info.end_cursor);
            } else {
                outputMessage('Your following loaded.  Count: ' + acctsQueue.length);
                printMessage(' ');

                loadedMyFollowings = true;
            }

        }).fail(function(f) {
            if (f.status == 429) {
                printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                timeoutsQueue.push(setTimeout(function() {
                    ajaxGetAllMyFollowing(after);
                }, gblOptions.timeDelayAfter429RateLimit));
            }
        });
}



function isAdditionalDataFullyLoaded(q) {
    for (var i = 0; i < q.length; i++) {
        if (!q[i].edge_followed_by) {
            return false;
        }
    }
    return true;
}


var extId = btoa('' + extensionId);

function sortQueue(q, property, asc) {

    var propertySplit = property.split('.');

    if (propertySplit.length === 1) {
        q.sort(function(a, b) {
            // non-numeric properties like username
            if (isNaN(a[property])) {
                if (asc == true) {
                    return a[property].localeCompare(b[property]);
                } else {
                    return b[property].localeCompare(a[property]);
                }
            }
            // numeric properties like followers
            if (asc == true) {
                return a[property] - b[property];
            } else {
                return b[property] - a[property];
            }
        });
    } else if (propertySplit.length === 2) {
        q.sort(function(a, b) {
            if (asc == true) {
                return a[propertySplit[0]][propertySplit[1]] - b[propertySplit[0]][propertySplit[1]];
            } else {
                return b[propertySplit[0]][propertySplit[1]] - a[propertySplit[0]][propertySplit[1]];
            }
        });
    }

    return q;
}



async function appendLastPostDateToAcct(a) {

    //  only hit server if filter is enabled or use is getting more data and wants it
    if (
        (gblOptions.filterOptions.lastPosted[0] < 1 && gblOptions.filterOptions.lastPosted[1] > 4999) ||
        (a.is_private == true && a.followed_by_viewer == false) ||
        (document.getElementById('radioGetMoreData').checked == true && gblOptions.getLastPostDate == false)
    ) {
        // a.lastPostDateInDays = 10;
        return a;
    }

    if (a.edge_owner_to_timeline_media.count > 0) {

        if (a.edge_owner_to_timeline_media.edges.length == 0) {
            a = await getTimelineForAcct(a);
        }

        var sortedMedia = sortQueue(a.edge_owner_to_timeline_media.edges, 'taken_at', false);
        var lastMediaDate = 0;
        if (sortedMedia.length > 0 && sortedMedia[0].taken_at != 'undefined') {
            lastMediaDate = sortedMedia[0].taken_at * 1000;
        }

        a.lastPostDate = lastMediaDate;

        var date1 = new Date(lastMediaDate);
        var date2 = new Date();
        var differenceInTime = date2.getTime() - date1.getTime();
        var differenceInDays = differenceInTime / (1000 * 3600 * 24);

        a.lastPostDateInDays = differenceInDays;


    } else {
        a.lastPostDateInDays = 6000;
    }

    return a;
}

function appendFollowersRatioToAcct(a) {
    if (a.edge_follow.count > 0 && a.edge_followed_by.count > 0) {
        a.followRatio = a.edge_followed_by.count / a.edge_follow.count;
    } else if (a.edge_followed_by.count > 0) {
        a.followRatio = a.edge_followed_by.count;
    } else {
        a.followRatio = 0;
    }

    return a;
}

function appendHasProfilePicToAcct(acct) {
    if (acct.profile_pic_url.indexOf(igExternalVars.emptyProfilePicUrl) > -1) {
        acct.has_profile_pic = 0;
    } else {
        acct.has_profile_pic = 1;
    }

    return acct;
}

function truncateQueue(start) {
    if (isNaN(parseInt(start))) start = 0;

    if (acctsQueue.length > gblOptions.maxAcctQueueLength && gblOptions.limitQueue != false) {
        var end = (start + gblOptions.maxAcctQueueLength);

        acctsQueue = acctsQueue.slice(start, end);

    }
}

async function arrayOfMediaToDiv(q, clearDiv) {

    if (typeof clearDiv == 'undefined') clearDiv = true;

    if (clearDiv === true) {
        $('#igBotMediaQueueContainer').children().remove();
    } else {
        $('#igBotMediaQueueContainer').children().not('.igBotQueueAcct').remove();
    }

    if (gblOptions.cbShowQueueOnScreen == false) {
        $('#igBotMediaQueueContainer').append('<div style="text-align:center;">You have turned off "Show queue on screen" in Settings.  Your queue is loaded in the background.</div>');
        return false;
    }


    $('#igBotMediaQueueContainer').append('<table id="gridjsMediaQueueWrapper"></table>');



    var columns = [{
        "name": '✓',
        "data": 'id',
        "width": '40px',
        "formatter": '<input type="checkbox" id="cb_${cell}" value="${cell}" />',
        "visible": true,
    }, {
        "name": "Media",
        "data": "image_versions2.candidates",
        "width": '150px',
        "visible": true
    }, {
        "name": '@username',
        "data": 'owner.username',
        "formatter": '<a href="https://www.instagram.com/${cell}" target="_blank">@${cell}</a>',
        "width": '125px',
        "visible": true
    }, {
        "name": "Caption",
        "data": "caption.text",
        "width": '200px',
        "visible": true
    }, {
        "name": "Date Taken",
        "data": "taken_at",
        "data2": "taken_at_timestamp",
        "width": '95px',
        "visible": true
    }, {
        "name": "Type",
        "data": "media_type",
        "data2": "__typename",
        "width": '95px',
        "visible": true
    }, {
        "name": "pk",
        "data": "pk",
        "width": '95px',
        "visible": false
    }, {
        "name": "id",
        "data": "id",
        "width": '95px',
        "visible": false
    }, {
        "name": "Comment Count",
        "data": "comment_count",
        "data2": "edge_media_preview_comment.count",
        "width": '95px',
        "visible": true
    }, {
        "name": "Like Count",
        "data": "like_count",
        "data2": "edge_media_preview_like.count",
        "width": '95px',
        "visible": true
    }];



    columns = columns.filter(e => e.visible !== false);


    var sb = '<thead><tr>';

    for (var i = 0; i < columns.length; i++) {
        sb = sb + '<th data-prop="' + columns[i].data + '" style="width:' + (columns[i].width || '60px') + ';">' + columns[i].name + '</th>';
    }

    sb = sb + '</tr></thead><tbody></tbody>';
    $('#gridjsMediaQueueWrapper').append(sb);

    for (var i = 0; i < q.length; i++) {
        sb = '<tr>';
        for (var j = 0; j < columns.length; j++) {


            if (columns[j].width) {
                sb = sb + '<td column-data="' + columns[j].data + '" style="width:' + columns[j].width + ';">';
            } else {
                sb = sb + '<td column-data="' + columns[j].data + '">';
            }

            if (columns[j].data) {

                var dataPropertyToUse = columns[j].data;

                if (columns[j].data2 && q[i].hasOwnProperty(columns[j].data2.split('.')[0])) {
                    dataPropertyToUse = columns[j].data2;

                }

                var props = dataPropertyToUse.split('.');

                if (props[1]) {
                    if (props[1] == 'candidates') {
                        if (q[i][props[0]] && q[i][props[0]][props[1]]) {
                            var candidates = q[i][props[0]][props[1]];
                            sb = sb + '<a href="https://www.instagram.com/p/' + (q[i].code || q[i].shortcode) + '" target="_blank"><img style="width:150px;" class="igBotMediaQueuePicture" data-img-id="' + q[i].id + '" src="' + candidates[0].url + '"></a></td>';
                        } else if (q[i].display_url) {
                            sb = sb + '<a href="https://www.instagram.com/p/' + (q[i].code || q[i].shortcode) + '" target="_blank"><img style="width:150px;" class="igBotMediaQueuePicture" data-img-id="' + q[i].id + '" src="' + q[i].display_url + '"></a></td>';
                        } else {
                            sb = sb + '</td>';
                        }
                    } else if (q[i][props[0]] && q[i][props[0]][props[1]]) {
                        if (columns[j].formatter) {
                            sb = sb + columns[j].formatter.replace(/\${ig_id}/g, q[i].id).replace(/\${cell}/g, q[i][props[0]][props[1]]) + '</td>';
                        } else {
                            sb = sb + q[i][props[0]][props[1]] + '</td>';
                        }
                    } else if (props[0] == 'caption') {
                        if (q[i].caption) {
                            sb = sb + q[i].caption + '</td>';
                        } else if (q[i].edge_media_to_caption && q[i].edge_media_to_caption.edges && q[i].edge_media_to_caption.edges.length > 0) {
                            sb = sb + q[i].edge_media_to_caption.edges[0].node.text + '</td>';
                        }

                    } else {
                        sb = sb + '-</td>';
                    }
                } else {
                    if (q[i][props[0]]) {
                        if (columns[j].formatter) {
                            sb = sb + columns[j].formatter.replace(/\${ig_id}/g, q[i].id).replace(/\${cell}/g, q[i][dataPropertyToUse]) + '</td>';
                        } else {

                            var dataString = (q[i][props[0]]);

                            if (props[0] == 'taken_at' || props[0] == 'taken_at_timestamp') {
                                var d = new Date(dataString * 1000);
                                var datePart = d.toISOString().slice(0, 10);
                                var timePart = d.toLocaleString([], {
                                    hour: '2-digit',
                                    minute: '2-digit'
                                });
                                dataString = datePart + ' ' + timePart;
                            }

                            if (props[0] == '__typename' || props[0] == 'media_type') {
                                dataString = dataString.toString().replace('Graph', '').replace('2', 'Video').replace('8', 'Sidecar').replace('1', 'Image').replace('Sidecar', 'Slideshow');
                            }



                            sb = sb + dataString.toString() + '</td>';
                        }
                    } else {
                        sb = sb + '-</td>';
                    }
                }


            }
        }
        sb = sb + '</tr>';
        $('#gridjsMediaQueueWrapper tbody').append(sb);
    }


    $('#gridjsMediaQueueWrapper').tablesorter({

        // *** APPEARANCE ***
        // Add a theme - 'blackice', 'blue', 'dark', 'default', 'dropbox',
        // 'green', 'grey' or 'ice' stylesheets have all been loaded
        // to use 'bootstrap' or 'jui', you'll need to include 'uitheme'
        // in the widgets option - To modify the class names, extend from
        // themes variable. Look for '$.extend($.tablesorter.themes.jui'
        // at the bottom of this window
        // this option only adds a table class name 'tablesorter-{theme}'
        theme: 'blue',

        // fix the column widths
        widthFixed: true,

        // Show an indeterminate timer icon in the header when the table
        // is sorted or filtered
        showProcessing: true,

        // header layout template (HTML ok); {content} = innerHTML,
        // {icon} = <i/> (class from cssIcon)
        headerTemplate: '{content}{icon}',

        // return the modified template string
        onRenderTemplate: null, // function(index, template){ return template; },

        // called after each header cell is rendered, use index to target the column
        // customize header HTML
        onRenderHeader: function(index) {
            // the span wrapper is added by default
            $(this).find('div.tablesorter-header-inner').addClass('roundedCorners');
        },

        // *** FUNCTIONALITY ***
        // prevent text selection in header
        cancelSelection: true,

        // add tabindex to header for keyboard accessibility
        tabIndex: true,

        // other options: 'ddmmyyyy' & 'yyyymmdd'
        dateFormat: 'yyyymmdd',

        // The key used to select more than one column for multi-column
        // sorting.
        sortMultiSortKey: 'shiftKey',

        // key used to remove sorting on a column
        sortResetKey: 'ctrlKey',

        // false for German '1.234.567,89' or French '1 234 567,89'
        usNumberFormat: true,

        // If true, parsing of all table cell data will be delayed
        // until the user initializes a sort
        delayInit: false,

        // if true, server-side sorting should be performed because
        // client-side sorting will be disabled, but the ui and events
        // will still be used.
        serverSideSorting: false,

        // default setting to trigger a resort after an 'update',
        // 'addRows', 'updateCell', etc has completed
        resort: true,

        // *** SORT OPTIONS ***
        // These are detected by default,
        // but you can change or disable them
        // these can also be set using data-attributes or class names
        headers: {
            // set 'sorter : false' (no quotes) to disable the column
            0: {
                sorter: 'text'
            },
            1: {
                sorter: false
            },
        },

        // ignore case while sorting
        ignoreCase: true,

        // forces the user to have this/these column(s) sorted first
        sortForce: null,
        // initial sort order of the columns, example sortList: [[0,0],[1,0]],
        // [[columnIndex, sortDirection], ... ]
        // sortList: [
        //     [0, 0],
        //     [1, 0],
        //     [2, 0]
        // ],
        sortList: [],
        // default sort that is added to the end of the users sort
        // selection.
        sortAppend: null,

        // when sorting two rows with exactly the same content,
        // the original sort order is maintained
        sortStable: false,

        // starting sort direction 'asc' or 'desc'
        sortInitialOrder: 'asc',

        // Replace equivalent character (accented characters) to allow
        // for alphanumeric sorting
        sortLocaleCompare: false,

        // third click on the header will reset column to default - unsorted
        sortReset: true,

        // restart sort to 'sortInitialOrder' when clicking on previously
        // unsorted columns
        sortRestart: false,

        // sort empty cell to bottom, top, none, zero, emptyMax, emptyMin
        emptyTo: 'bottom',

        // sort strings in numerical column as max, min, top, bottom, zero
        stringTo: 'zero',

        // extract text from the table
        textExtraction: {
            0: function(node, table) {
                // this is how it is done by default
                return $(node).attr(table.config.textAttribute) ||
                    node.textContent ||
                    node.innerText ||
                    $(node).text() ||
                    '';
            },
            1: function(node) {
                return $(node).text();
            }
        },

        // data-attribute that contains alternate cell text
        // (used in default textExtraction function)
        textAttribute: 'data-text',

        // use custom text sorter
        // function(a,b){ return a.sort(b); } // basic sort
        textSorter: null,

        // choose overall numeric sorter
        // function(a, b, direction, maxColumnValue)
        numberSorter: null,

        // *** WIDGETS ***
        // apply widgets on tablesorter initialization
        initWidgets: true,

        // table class name template to match to include a widget
        widgetClass: 'widget-{name}',

        // include zebra and any other widgets, options:
        // 'columns', 'filter', 'stickyHeaders' & 'resizable'
        // 'uitheme' is another widget, but requires loading
        // a different skin and a jQuery UI theme.
        widgets: ['pager', 'stickyHeaders', 'storage', 'zebra', 'columns', 'filter'],

        widgetOptions: {

            // zebra widget: adding zebra striping, using content and
            // default styles - the ui css removes the background
            // from default even and odd class names included for this
            // demo to allow switching themes
            // [ 'even', 'odd' ]
            zebra: [
                'ui-widget-content even',
                'ui-state-default odd'
            ],

            // columns widget: change the default column class names
            // primary is the 1st column sorted, secondary is the 2nd, etc
            columns: [
                'primary',
                'secondary',
                'tertiary'
            ],

            // columns widget: If true, the class names from the columns
            // option will also be added to the table tfoot.
            columns_tfoot: true,

            // columns widget: If true, the class names from the columns
            // option will also be added to the table thead.
            columns_thead: true,

            // filter widget: If there are child rows in the table (rows with
            // class name from 'cssChildRow' option) and this option is true
            // and a match is found anywhere in the child row, then it will make
            // that row visible; default is false
            filter_childRows: false,

            // filter widget: If true, a filter will be added to the top of
            // each table column.
            filter_columnFilters: true,

            // filter widget: css class name added to the filter cell
            // (string or array)
            filter_cellFilter: '',

            // filter widget: css class name added to the filter row & each
            // input in the row (tablesorter-filter is ALWAYS added)
            filter_cssFilter: '',

            // filter widget: add a default column filter type
            // '~{query}' to make fuzzy searches default;
            // '{q1} AND {q2}' to make all searches use a logical AND.
            filter_defaultFilter: {},

            // filter widget: filters to exclude, per column
            filter_excludeFilter: {},

            // filter widget: jQuery selector string (or jQuery object)
            // of external filters
            filter_external: '',

            // filter widget: class added to filtered rows;
            // needed by pager plugin
            filter_filteredRow: 'filtered',

            // filter widget: add custom filter elements to the filter row
            filter_formatter: null,

            // filter widget: Customize the filter widget by adding a select
            // dropdown with content, custom options or custom filter functions
            // see http://goo.gl/HQQLW for more details
            filter_functions: null,

            // filter widget: hide filter row when table is empty
            filter_hideEmpty: true,

            // filter widget: Set this option to true to hide the filter row
            // initially. The rows is revealed by hovering over the filter
            // row or giving any filter input/select focus.
            filter_hideFilters: false,

            // filter widget: Set this option to false to keep the searches
            // case sensitive
            filter_ignoreCase: true,

            // filter widget: if true, search column content while the user
            // types (with a delay)
            filter_liveSearch: true,

            // filter widget: a header with a select dropdown & this class name
            // will only show available (visible) options within the drop down
            filter_onlyAvail: 'filter-onlyAvail',

            // filter widget: default placeholder text
            // (overridden by any header 'data-placeholder' setting)
            filter_placeholder: {
                search: '',
                select: ''
            },

            // filter widget: jQuery selector string of an element used to
            // reset the filters.
            filter_reset: null,

            // filter widget: Use the $.tablesorter.storage utility to save
            // the most recent filters
            filter_saveFilters: false,

            // filter widget: Delay in milliseconds before the filter widget
            // starts searching; This option prevents searching for every character
            // while typing and should make searching large tables faster.
            filter_searchDelay: 300,

            // filter widget: allow searching through already filtered rows in
            // special circumstances; will speed up searching in large tables if true
            filter_searchFiltered: true,

            // filter widget: include a function to return an array of values to be
            // added to the column filter select
            filter_selectSource: null,

            // filter widget: Set this option to true if filtering is performed on
            // the server-side.
            filter_serversideFiltering: false,

            // filter widget: Set this option to true to use the filter to find
            // text from the start of the column. So typing in 'a' will find
            // 'albert' but not 'frank', both have a's; default is false
            filter_startsWith: false,

            // filter widget: If true, ALL filter searches will only use parsed
            // data. To only use parsed data in specific columns, set this option
            // to false and add class name 'filter-parsed' to the header
            filter_useParsedData: false,

            // filter widget: data attribute in the header cell that contains
            // the default filter value
            filter_defaultAttrib: 'data-value',

            // filter widget: filter_selectSource array text left of the separator
            // is added to the option value, right into the option text
            filter_selectSourceSeparator: '|',

            // starting page of the pager (zero based index)
            pager_startPage: 0,

            // Number of visible rows - default is 10
            pager_size: gblOptions.mediapaginationLimit,

            // reset pager after filtering; set to desired page #
            // set to false to not change page at filter start
            pager_pageReset: 0,

            // output string - default is '{page}/{totalPages}';
            // possible variables:
            // {page}, {totalPages}, {startRow}, {endRow} and {totalRows}
            // pager_output: '{startRow} to {endRow} ({totalRows})',
            pager_output: '{startRow} - {endRow} / {filteredRows} ({totalRows})',

            // apply disabled classname to the pager arrows when the rows at
            // either extreme is visible - default is true
            pager_updateArrows: true,

            // Number of options to include in the pager number selector
            pager_maxOptionSize: 20,

            // Save pager page & size if the storage script is loaded
            // (requires $.tablesorter.storage in jquery.tablesorter.widgets.js)
            pager_savePages: true,

            // defines custom storage key
            pager_storageKey: 'tablesorter-media-pager',

            // if true, the table will remain the same height no matter how many
            // records are displayed. The space is made up by an empty
            // table row set to a height to compensate; default is false
            pager_fixedHeight: false,

            // count child rows towards the set page size?
            // (set true if it is a visible table row within the pager)
            // if true, child row(s) may not appear to be attached to its
            // parent row, may be split across pages or
            // may distort the table if rowspan or cellspans are included.
            pager_countChildRows: false,

            // remove rows from the table to speed up the sort of large tables.
            // setting this to false, only hides the non-visible rows; needed
            // if you plan to add/remove rows with the pager enabled.
            pager_removeRows: false,

            // css class names used by pager elements
            pager_css: {
                // class added to pager container
                container: 'tablesorter-pager',
                // error information row (don't include period at beginning)
                errorRow: 'tablesorter-errorRow',
                // class added to arrows @ extremes
                // (i.e. prev/first arrows "disabled" on first page)
                disabled: 'disabled'
            },

            // jQuery selectors
            pager_selectors: {
                // target the pager markup
                container: '.mediapager',
                // go to first page arrow
                first: '.first',
                // previous page arrow
                prev: '.prev',
                // next page arrow
                next: '.next',
                // go to last page arrow
                last: '.last',
                // go to page selector - select dropdown that sets the current page
                gotoPage: '.gotoPage',
                // location of where the "output" is displayed
                pageDisplay: '.pagedisplay',
                // page size selector - select dropdown that sets the "size" option
                pageSize: '.pagesize'
            },

            // Resizable widget: If this option is set to false, resized column
            // widths will not be saved. Previous saved values will be restored
            // on page reload
            resizable: true,

            // Resizable widget: If this option is set to true, a resizing anchor
            // will be included in the last column of the table
            resizable_addLastColumn: false,

            // Resizable widget: Set this option to the starting & reset header widths
            resizable_widths: [],

            // Resizable widget: Set this option to throttle the resizable events
            // set to true (5ms) or any number 0-10 range
            resizable_throttle: false,

            // saveSort widget: If this option is set to false, new sorts will
            // not be saved. Any previous saved sort will be restored on page
            // reload.
            saveSort: false,

            // stickyHeaders widget: extra class name added to the sticky header row
            stickyHeaders: '',

            // jQuery selector or object to attach sticky header to
            stickyHeaders_attachTo: '#igBotMediaQueueContainer',

            // jQuery selector or object to monitor horizontal scroll position
            // (defaults: xScroll > attachTo > window)
            stickyHeaders_xScroll: null,

            // jQuery selector or object to monitor vertical scroll position
            // (defaults: yScroll > attachTo > window)
            stickyHeaders_yScroll: null,

            // number or jquery selector targeting the position:fixed element
            stickyHeaders_offset: 0,

            // scroll table top into view after filtering
            stickyHeaders_filteredToTop: true,

            // added to table ID, if it exists
            stickyHeaders_cloneId: '-sticky',

            // trigger 'resize' event on headers
            stickyHeaders_addResizeEvent: true,

            // if false and a caption exist, it won't be included in the
            // sticky header
            stickyHeaders_includeCaption: true,

            // The zIndex of the stickyHeaders, allows the user to adjust this
            // to their needs
            stickyHeaders_zIndex: 2

        },

        // *** CALLBACKS ***
        // function called after tablesorter has completed initialization
        initialized: function() {

        }, // function (table) {}

        // *** extra css class names
        tableClass: '',
        cssAsc: '',
        cssDesc: '',
        cssNone: '',
        cssHeader: '',
        cssHeaderRow: '',
        // processing icon applied to header during sort/filter
        cssProcessing: '',

        // class name indiciating that a row is to be attached to the its parent
        cssChildRow: 'tablesorter-childRow',
        // if this class does not exist, the {icon} will not be added from
        // the headerTemplate
        cssIcon: 'tablesorter-icon',
        // class name added to the icon when there is no column sort
        cssIconNone: '',
        // class name added to the icon when the column has an ascending sort
        cssIconAsc: '',
        // class name added to the icon when the column has a descending sort
        cssIconDesc: '',
        // don't sort tbody with this class name
        // (only one class name allowed here!)
        cssInfoBlock: 'tablesorter-infoOnly',
        // class name added to table header which allows clicks to bubble up
        cssAllowClicks: 'tablesorter-allowClicks',
        // header row to ignore; cells within this row will not be added
        // to table.config.$headers
        cssIgnoreRow: 'tablesorter-ignoreRow',

        // *** SELECTORS ***
        // jQuery selectors used to find the header cells.
        selectorHeaders: '> thead th, > thead td',

        // jQuery selector of content within selectorHeaders
        // that is clickable to trigger a sort.
        selectorSort: 'th, td',

        // rows with this class name will be removed automatically
        // before updating the table cache - used by 'update',
        // 'addRows' and 'appendCache'
        selectorRemove: '.remove-me',

        // *** DEBUGING ***
        // send messages to console
        debug: false

    }).bind("sortEnd", function(e, t) {
        sortMediaQueueByTableSort();
        handleMediaCheckBoxes();
    });

    handleMediaCheckBoxes();
    handleImagePreload();

    if (clearDiv == true) {
        $('#mediapaginationLimit option:selected').attr("selected", null);
        $('#mediapaginationLimit option[value="' + gblOptions.mediapaginationLimit + '"]').attr("selected", "selected");
        $('#gridjsMediaQueueWrapper').trigger('pageSize', gblOptions.mediapaginationLimit);
    }

    $('#mediaqueueQuantityRow').show();
}



function handleImagePreload() {
    const images = document.querySelectorAll('#igBotQueueContainer img,#igBotMediaQueueContainer img');
    const config = {
        rootMargin: '0px 0px 50px 0px',
        threshold: 0
    };
    let loaded = 0;

    let observer = new IntersectionObserver(function(entries, self) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                preloadImage(entry.target);
                // Stop watching and load the image
                self.unobserve(entry.target);
            }
        });
    }, config);

    images.forEach(image => {

        $(image).off('click.hideRdgOnOpenPost').on('click.hideRdgOnOpenPost', function() {
            saveHiddenStatus(true);
        });


        if (image.hasAttribute('data-src')) {
            observer.observe(image);
        }
    });

    function preloadImage(img) {
        const src = img.getAttribute('data-src');
        if (!src) {
            return;
        }
        img.src = src;
        img.removeAttribute('data-src');
    }

}

function handleCheckBoxes(q) {

    let lastChecked;
    let boxes = [];

    function displaySelectedCount() {
        let boxCheckedCount = 0;
        boxes.forEach(box => {
            if (box.checked == true) boxCheckedCount++;
        });
        document.getElementById('igBotQueueSelectedCount').textContent = '' + boxCheckedCount + ' selected';
    }

    function selectAllCheckBoxes() {
        boxes.forEach(box => {
            if (document.getElementById(box.id).closest('tr').classList.contains('filtered') == false) box.checked = true;
            //box.checked = true;
        });
        displaySelectedCount();
    }

    function selectNoneCheckBoxes() {
        boxes.forEach(box => {
            box.checked = false;
        });
        displaySelectedCount();
    }

    function invertCheckBoxes() {
        boxes.forEach(box => box.checked = !box.checked);
        displaySelectedCount();
    }

    function removeSelected() {
        var useDefaultList = true;

        if (currentList == 'acctsWhiteList') {
            useDefaultList = false;
        }

        boxes.forEach(box => {
            if (box.checked) {
                if (useDefaultList == true) {
                    acctsQueue = acctsQueue.filter(u => u.id !== box.value);
                } else if (currentList == 'acctsWhiteList') {
                    acctsWhiteList = acctsWhiteList.filter(u => u.id !== box.value);
                }

                $('#' + box.value + '_container').remove();
            }
        });
        refreshBoxes();
        updateCount();
        displaySelectedCount();

        if (useDefaultList == true) {
            arrayOfUsersToDiv(acctsQueue, true);
        } else if (currentList == 'acctsWhiteList') {
            arrayOfUsersToDiv(acctsWhiteList, true);
        }
    }

    function addAcctsToWhiteList() {
        boxes.forEach(box => {
            if (box.checked) {
                var acct = findAcctById(box.value, acctsQueue);
                addAcctToWhiteList(acct);
            }
        });

        setTimeout(saveWhiteListToStorage, 2000);

        return true;
    }

    function checkIntermediateBoxes(first, second) {
        if (boxes.indexOf(first) > boxes.indexOf(second)) {
            [second, first] = [first, second];
        }
        intermediateBoxes(first, second).forEach(box => box.checked = true);
        displaySelectedCount();
    }

    function intermediateBoxes(start, end) {
        return boxes.filter((item, key) => {
            return boxes.indexOf(start) < key && key < boxes.indexOf(end);
        });
    }

    function changeBox(event) {
        if (event.shiftKey && this != lastChecked) {
            checkIntermediateBoxes(lastChecked, this);
        }
        lastChecked = this;
        displaySelectedCount();
    }

    function refreshBoxes() {
        boxes = Array.from(document.querySelectorAll('#gridjsAcctsQueueWrapper [type="checkbox"]'));
    }


    refreshBoxes();

    boxes.forEach(item => {
        $(item).off('click.changeBox').on('click.changeBox', changeBox);
    });

    $('#btnSelectAll').off('click.selectAllCheckBoxes').on('click.selectAllCheckBoxes', selectAllCheckBoxes);
    $('#btnSelectNone').off('click.selectNoneCheckBoxes').on('click.selectNoneCheckBoxes', selectNoneCheckBoxes);
    $('#btnInvertSelection').off('click.invertCheckBoxes').on('click.invertCheckBoxes', invertCheckBoxes);
    $('#btnRemoveSelected').off('click.removeSelected').on('click.removeSelected', removeSelected);
    $('#btnAddToWhiteList').off('click.addAcctsToWhiteList').on('click.addAcctsToWhiteList', addAcctsToWhiteList);
    $('#btnSaveWhiteList').off('click.saveWhiteListToStorageAndDisk').on('click.saveWhiteListToStorageAndDisk', saveWhiteListToStorageAndDisk);
    $('.close-icon').off('click.filterQueue').on('click.filterQueue', function() {
        setTimeout(filterQueue, 1);
    });
    //$('.igBotInjectedButton').off('click.displaySelectedCount').on('click.displaySelectedCount', displaySelectedCount);

    updateCount();
    displaySelectedCount();
}



function handleMediaCheckBoxes(q) {

    let lastChecked;
    let boxes = [];

    function displaySelectedCount() {
        let boxCheckedCount = 0;
        boxes.forEach(box => {
            if (box.checked == true) boxCheckedCount++;
        });
        document.getElementById('igBotmediaQueueSelectedCount').textContent = '' + boxCheckedCount + ' selected';

    }

    function selectAllCheckBoxes() {
        boxes.forEach(box => {
            if (document.getElementById(box.id).closest('tr').classList.contains('filtered') == false) box.checked = true;
            //box.checked = true;
        });
        displaySelectedCount();
    }

    function selectNoneCheckBoxes() {
        boxes.forEach(box => {
            box.checked = false;
        });
        displaySelectedCount();
    }

    function invertCheckBoxes() {
        boxes.forEach(box => box.checked = !box.checked);
        displaySelectedCount();
    }

    function removeSelected() {
        boxes.forEach(box => {
            if (box.checked) {
                mediaToLike = mediaToLike.filter(m => m.id !== box.value);
            }
        });

        refreshBoxes();
        updateCount();
        displaySelectedCount();

        arrayOfMediaToDiv(mediaToLike, true);
    }

    function checkIntermediateBoxes(first, second) {
        if (boxes.indexOf(first) > boxes.indexOf(second)) {
            [second, first] = [first, second];
        }
        intermediateBoxes(first, second).forEach(box => box.checked = true);
        displaySelectedCount();
    }

    function intermediateBoxes(start, end) {
        return boxes.filter((item, key) => {
            return boxes.indexOf(start) < key && key < boxes.indexOf(end);
        });
    }

    function changeBox(event) {
        if (event.shiftKey && this != lastChecked) {
            checkIntermediateBoxes(lastChecked, this);
        }
        lastChecked = this;
        displaySelectedCount();
    }

    function refreshBoxes() {
        boxes = Array.from(document.querySelectorAll('#gridjsMediaQueueWrapper [type="checkbox"]'));
    }

    refreshBoxes();

    boxes.forEach(item => {
        $(item).off('click.changeBox').on('click.changeBox', changeBox);
    });

    $('#btnMediaSelectAll').off('click.selectAllCheckBoxes').on('click.selectAllCheckBoxes', selectAllCheckBoxes);
    $('#btnMediaSelectNone').off('click.selectNoneCheckBoxes').on('click.selectNoneCheckBoxes', selectNoneCheckBoxes);
    $('#btnMediaInvertSelection').off('click.invertCheckBoxes').on('click.invertCheckBoxes', invertCheckBoxes);
    $('#btnMediaRemoveSelected').off('click.removeSelected').on('click.removeSelected', removeSelected);
    $('.close-icon').off('click.filterQueue').on('click.filterQueue', function() {
        setTimeout(filterQueue, 1);
    });

    updateCount();
    displaySelectedCount();
}



function alreadyAttempted(acct) {

    if (typeof acct == 'undefined') return false;

    for (var i = 0; i < acctsPreviouslyAttempted.length; i++) {
        if (acctsPreviouslyAttempted[i].id && acctsPreviouslyAttempted[i].id == acct.id) {
            // #region debug-point E:already-attempted-hit
            rdgDebugReport('E', 'contentscript.js:alreadyAttempted', 'already attempted hit', {
                accountId: acct && acct.id ? String(acct.id) : null,
                accountUsername: acct && acct.username ? acct.username : null,
                attemptedLength: acctsPreviouslyAttempted.length,
                foundFollowAttemptDate: acctsPreviouslyAttempted[i].followAttemptDate || null
            });
            // #endregion
            return acctsPreviouslyAttempted[i];
        }
    }

    return false;
}

function addToAttempted(acct) {
    var acctCopy = rdgNormalizeAttemptedAcctForStorage(acct);

    var d = new Date();
    acctCopy["followAttemptDate"] = '' + d.getTime();

    acctsPreviouslyAttempted.push(acctCopy);
    // #region debug-point F:already-attempted-add
    rdgDebugReport('F', 'contentscript.js:addToAttempted', 'account added to attempted history', {
        accountId: acctCopy && acctCopy.id ? String(acctCopy.id) : null,
        accountUsername: acctCopy && acctCopy.username ? acctCopy.username : null,
        attemptedLengthAfterPush: acctsPreviouslyAttempted.length,
        followAttemptDate: acctCopy.followAttemptDate || null
    });
    // #endregion
    rdgPersistAttemptedHistory();
}

function ajaxFollowAllFollowings() {
    acctsQueue = theirFollowings;
    ajaxFollowAll();
}

function ajaxFollowAll() {
    if (!$('#btnProcessQueue').hasClass('pulsing')) return false;
    if (rdgAssistantIsLiveInteractionMode()) {
        var activeProfile = rdgAssistantGetProfileById(rdgAssistantState.run.activeProfileId);
        if (rdgAssistantStopFurtherFollowsForCompletedProfile(activeProfile) === true) {
            if ((document.getElementById('radioFollowAndLike').checked == true || rdgIsChainFunnelMode()) && mediaToLike.length > 0) {
                likeAllMedia();
            }
            return false;
        }
    }

    if (acctsQueue.length == 0) {
        printMessage(chrome.i18n.getMessage('QueueEmpty'));
        $('#btnProcessQueue').removeClass('pulsing');


        if ((document.getElementById('radioFollowAndLike').checked == true || rdgIsChainFunnelMode()) && mediaToLike.length > 0) {
            outputMessage('Loaded all media, beginning Likes...')
            likeAllMedia();
        }

        return false;
    }


    if (checkMaxActionsAndDelayIfNecessary(ajaxFollowAll) == false) {
        ajaxFollowUser(acctsQueue.shift());
    }
}

function removeAcctFromQueueDisplay(id, gray) {
    if (gray === true) {
        $('#igBotQueueContainer #' + id + '_container').css({
            'opacity': '.5'
        });
    } else {
        $('#igBotQueueContainer #' + id + '_container').fadeOut(300, function() {
            $(this).remove();
        });
    }
    updateCount();
}

function updateCount() {
    if (currentList === 'acctsWhiteList') {
        document.getElementById('igBotQueueCount').textContent = '' + acctsWhiteList.length + ' accounts';
    } else {
        document.getElementById('igBotQueueCount').textContent = '' + acctsQueue.length + ' accounts';
        document.getElementById('igBotmediaQueueCount').textContent = '' + mediaToLike.length + ' medias';
    }

    if (mediaToLike.length > 0) {
        $('#mediapaginationLimitDiv').show();
        $('#mediapaginationLimit option:selected').attr("selected", null);
        $('#mediapaginationLimit option[value="' + gblOptions.mediapaginationLimit + '"]').attr("selected", "selected");
    } else {
        $('#mediapaginationLimitDiv').hide();

    }

    if (acctsQueue.length > 0 || currentList == 'acctsWhiteList') {
        $('#paginationLimitDiv').show();
        $('#paginationLimit option:selected').attr("selected", null);
        $('#paginationLimit option[value="' + gblOptions.paginationLimit + '"]').attr("selected", "selected");

    } else {
        $('#paginationLimitDiv').hide();
    }
}

function addStamp(id, classname, text) {

    // if (gblOptions.removeAccountsFromQueue === true) {
    //     removeAcctFromQueueDisplay(id);
    //     return false;
    // }

    if (gblOptions.showStamps === true) {
        var $parent = $('img.igBotQueueAcctProfilePicture[data-ig-userid="' + id + '"],img.igBotMediaQueuePicture[data-img-id="' + id + '"]').parent();
        if ($parent.length) {
            var existingStamps = $parent.find('.stamp-div');
            if (existingStamps.length > 0) {
                var existingText = existingStamps.text().toUpperCase();
                // If a specific informative stamp already exists and the new one is generic 'FILTRADO', preserve the specific one
                if (text.toUpperCase() === 'FILTRADO' && (existingText.indexOf('SEGUE VOCÊ') > -1 || existingText.indexOf('LISTA BRANCA') > -1 || existingText.indexOf('EXTERNO') > -1 || existingText.indexOf('404') > -1 || existingText.indexOf('INVÁLIDO') > -1)) {
                    return true;
                }
                existingStamps.remove();
            }
            $parent.append('<div class="stamp-div ' + classname + '">' + text + '</div>');
            if ($parent[0]) $parent[0].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
        return true;
    }

    return false;

}

function getRandomizedTime(baseTime) {
    if (gblOptions.useRandomTimeDelay == true) {
        var minRandomTimeDelay = Math.max(0, baseTime - (baseTime * gblOptions.percentRandomTimeDelay));
        var maxRandomTimeDelay = baseTime + (baseTime * gblOptions.percentRandomTimeDelay);
        return getRandomInt(minRandomTimeDelay, maxRandomTimeDelay);
    }
    return baseTime;
}

function rdgAssistantIsLiveInteractionMode() {
    return !!(rdgAssistantState &&
        rdgAssistantState.run &&
        rdgAssistantState.run.status === 'running' &&
        rdgAssistantState.run.phase === 'interacting');
}

var rdgAssistantNextFollowTimerId = null;

function rdgIsChainFunnelMode() {
    var el = document.getElementById('radioFollowLikeAndDM');
    return el && el.checked === true;
}

// Global delegated handlers for Chain Funnel VIP Box
function rdgLoadChainDmConfigToUi() {
    chrome.storage.local.get(['rdgChainDmMessage', 'rdgChainDmMessage2', 'rdgChainDmMessage3', 'rdgChainDmUseTemplates'], function(data) {
        if (data.rdgChainDmMessage !== undefined && $('#txtChainDmMessage').length) {
            $('#txtChainDmMessage').val(data.rdgChainDmMessage);
        }
        if (data.rdgChainDmMessage2 !== undefined && $('#txtChainDmMessage2').length) {
            $('#txtChainDmMessage2').val(data.rdgChainDmMessage2);
        }
        if (data.rdgChainDmMessage3 !== undefined && $('#txtChainDmMessage3').length) {
            $('#txtChainDmMessage3').val(data.rdgChainDmMessage3);
        }
        if (data.rdgChainDmUseTemplates !== undefined && $('#cbUseMassDmTemplates').length) {
            $('#cbUseMassDmTemplates').prop('checked', !!data.rdgChainDmUseTemplates);
        }
    });
}

$(document).on('click', '#btnToggleChainDmBox', function(e) {
    e.preventDefault();
    e.stopPropagation();
    rdgLoadChainDmConfigToUi();
    $('#rdgChainDmConfigBox').slideToggle(250);
});
$(document).on('click', '#btnCloseChainDmBox', function(e) {
    e.preventDefault();
    $('#rdgChainDmConfigBox').slideUp(200);
});
$(document).on('click', '#btnPasteCustomQueueTab1', function(e) {
    e.preventDefault();
    e.stopPropagation();
    var input = prompt('📋 Cole aqui a sua lista personalizada de @usuários (um por linha ou separados por vírgula):');
    if (!input || !input.trim()) return;
    var items = input.split(/[\r\n,;]+/);
    var count = 0;
    var accts = [];
    items.forEach(function(u) {
        var clean = u.trim().replace(/^@/, '');
        if (clean.length > 0) {
            accts.push({
                id: 'custom_' + clean,
                username: clean,
                full_name: clean,
                profile_pic_url: '',
                is_private: false,
                is_verified: false
            });
            count++;
        }
    });
    if (count > 0) {
        if (!Array.isArray(acctsQueue)) {
            acctsQueue = [];
        }
        currentList = 'acctsQueue';
        accts.forEach(function(a) {
            acctsQueue.push(a);
        });
        if (typeof arrayOfUsersToDiv === 'function') {
            arrayOfUsersToDiv(acctsQueue, true);
        }
        if (typeof updateCount === 'function') {
            updateCount();
        }
        if (typeof monitorButtonConditions === 'function') {
            monitorButtonConditions();
        }
        alert('✓ ' + count + ' perfil(is) adicionado(s) à fila com sucesso!\n\nAgora selecione a ação desejada em "Processar Fila ↑" e clique para iniciar.');
    }
});
$(document).on('change', 'input[name="queueAction"]', function() {
    if ($('#radioFollowLikeAndDM').is(':checked')) {
        rdgLoadChainDmConfigToUi();
        $('#rdgChainDmConfigBox').slideDown(250);
    } else {
        $('#rdgChainDmConfigBox').slideUp(200);
    }
});
$(document).on('click', '#btnConfirmChainDmConfig', function(e) {
    e.preventDefault();
    var msg = $('#txtChainDmMessage').val() || '';
    var msg2 = $('#txtChainDmMessage2').val() || '';
    var msg3 = $('#txtChainDmMessage3').val() || '';
    var useTemplates = $('#cbUseMassDmTemplates').is(':checked');
    chrome.storage.local.set({
        'rdgChainDmMessage': msg,
        'rdgChainDmMessage2': msg2,
        'rdgChainDmMessage3': msg3,
        'rdgChainDmUseTemplates': useTemplates
    }, function() {
        $('#radioFollowLikeAndDM').prop('checked', true);
        alert('✓ Configuração das Variações do Direct salva e Funil em Cadeia ativado com sucesso!');
        $('#rdgChainDmConfigBox').slideUp(200);
    });
});

/* ═══════════════════════════════════════════════════════════════════════════
   MÁQUINA DE VENDAS & PROSPECÇÃO INTELIGENTE RDG — PASSO 5
   ═══════════════════════════════════════════════════════════════════════════ */

/* ── 1. PRODUTIVIDADE E CENTRAL ANALÍTICA DIÁRIA (RDG STATS TODAY) ── */
function rdgGetTodayKey() {
    return 'rdg_stats_' + new Date().toISOString().slice(0, 10);
}

function rdgLoadTodayStats() {
    var key = rdgGetTodayKey();
    var stored = localStorage.getItem(key);
    var stats = stored ? JSON.parse(stored) : {
        date: new Date().toISOString().slice(0, 10),
        analyzed: 0,
        qualified: 0,
        interactions: 0,
        newFollowers: 0,
        dmReplies: 0,
        sales: 0
    };
    $('#txtRdgTodayDate').text(stats.date.split('-').reverse().join('/'));
    $('#prodStatAnalyzed').text(stats.analyzed || 0);
    $('#prodStatQualified').text(stats.qualified || 0);
    $('#prodStatInteractions').text(stats.interactions || 0);
    $('#prodStatNewFollowers').text(stats.newFollowers || 0);
    $('#prodStatDmReplies').text(stats.dmReplies || 0);
    $('#prodStatSales').text(stats.sales || 0);
    return stats;
}

function rdgSaveTodayStats(stats) {
    var key = rdgGetTodayKey();
    localStorage.setItem(key, JSON.stringify(stats));
    rdgLoadTodayStats();
}

function rdgIncStat(field, amount = 1) {
    var stats = rdgLoadTodayStats();
    stats[field] = (stats[field] || 0) + amount;
    if (stats[field] < 0) stats[field] = 0;
    rdgSaveTodayStats(stats);
}

$(document).on('click', '#btnIncSale', function(e) {
    e.preventDefault();
    rdgIncStat('sales', 1);
});
$(document).on('click', '#btnDecSale', function(e) {
    e.preventDefault();
    rdgIncStat('sales', -1);
});

$(document).on('click', '#btnRdgExportReport', function(e) {
    e.preventDefault();
    var stats = rdgLoadTodayStats();
    var csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Relatorio Executivo RDG instaPRO - Desempenho Diario\r\n";
    csvContent += "Data," + stats.date + "\r\n\r\n";
    csvContent += "Metrica,Quantidade\r\n";
    csvContent += "Pessoas Analisadas pela IA," + stats.analyzed + "\r\n";
    csvContent += "Leads Qualificados (VIP/Ouro)," + stats.qualified + "\r\n";
    csvContent += "Interacoes Realizadas (Seguir/Curtir)," + stats.interactions + "\r\n";
    csvContent += "Seguidores Novos na Conta," + stats.newFollowers + "\r\n";
    csvContent += "Respostas ou Contatos Direct," + stats.dmReplies + "\r\n";
    csvContent += "Vendas Fechadas Hoje," + stats.sales + "\r\n\r\n";
    csvContent += "Listagem de Leads Qualificados na Fila (Amostra):\r\n";
    csvContent += "Username,Nome Completo,Score Ouro,Selo,Email,WhatsApp\r\n";
    if (Array.isArray(acctsQueue)) {
        acctsQueue.forEach(function(a) {
            if (a.goldScore >= 50) {
                csvContent += `${a.username || ''},"${a.full_name || ''}",${a.goldScore || 0},"${a.goldBadge || ''}",${a.public_email || ''},${a.contact_phone_number || ''}\r\n`;
            }
        });
    }
    var encodedUri = encodeURI(csvContent);
    var link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "Relatorio_Executivo_RDG_" + stats.date + ".csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
});

/* ── 2. REGRAS DE QUALIFICAÇÃO OURO MODULARES (SCORE += RULE()) ── */
function BusinessAccountRule(info, config) {
    if (!config.cbBusiness) return 0;
    if (info.is_business_account || info.is_professional_account || info.is_creator) return 15;
    return 0;
}

function ProfilePicRule(info, config) {
    if (!config.cbProfilePic) return 0;
    if (info.profile_pic_url && info.profile_pic_url.indexOf('default_user_profile_pic') === -1) return 10;
    return 0;
}

function WhatsappRule(info, config) {
    if (!config.cbWhatsapp) return 0;
    var bio = (info.biography || '').toLowerCase();
    if (info.whatsapp_number || info.public_phone_number || bio.indexOf('wa.me') > -1 || bio.indexOf('whatsapp') > -1 || bio.indexOf('api.whatsapp.com') > -1) return 20;
    return 0;
}

function EmailRule(info, config) {
    if (!config.cbEmail) return 0;
    var bio = (info.biography || '').toLowerCase();
    if (info.public_email || /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/.test(bio)) return 15;
    return 0;
}

function RecentPostsRule(info, config) {
    if (!config.cbRecentPosts) return 0;
    if (info.media_count && info.media_count >= 3) return 10;
    return 0;
}

function EngagedRule(info, config) {
    if (!config.cbEngaged) return 0;
    if (info.follower_count && info.follower_count >= 150) return 10;
    return 0;
}

function FollowersRatioRule(info, config) {
    if (!config.cbFollowRatio) return 0;
    var followers = info.follower_count || 0;
    var following = info.following_count || 1;
    if (followers >= 100 && (following / followers) < 5) return 10;
    return 0;
}

function BioKeywordRule(info, config) {
    if (!config.cbKeywords || !config.keywords || !config.keywords.length) return 0;
    var text = ((info.biography || '') + ' ' + (info.full_name || '') + ' ' + (info.username || '')).toLowerCase();
    for (var i = 0; i < config.keywords.length; i++) {
        var kw = config.keywords[i].trim().toLowerCase();
        if (kw && text.indexOf(kw) > -1) return 15;
    }
    return 0;
}

function CategoryRule(info, config) {
    if (!config.cbCategory) return 0;
    if (info.category_name || info.business_category_name) return 10;
    return 0;
}

function LocationRule(info, config) {
    if (!config.cbLocation) return 0;
    var loc = config.locationText ? config.locationText.toLowerCase() : '';
    var text = ((info.biography || '') + ' ' + (info.full_name || '')).toLowerCase();
    if (!loc || text.indexOf(loc) > -1 || info.public_phone_country_code == '55') return 10;
    return 0;
}

function rdgComputeGoldScore(info, config) {
    var score = 0;
    score += BusinessAccountRule(info, config);
    score += ProfilePicRule(info, config);
    score += WhatsappRule(info, config);
    score += EmailRule(info, config);
    score += RecentPostsRule(info, config);
    score += EngagedRule(info, config);
    score += FollowersRatioRule(info, config);
    score += BioKeywordRule(info, config);
    score += CategoryRule(info, config);
    score += LocationRule(info, config);

    var badge = '❌ Baixo (< 50)';
    if (score >= 75) badge = '🔥 Lead Quente (VIP)';
    else if (score >= 50) badge = '🟡 Lead Médio';

    return { score: score, badge: badge };
}

$(document).on('click', '#btnRunGoldScoring', async function(e) {
    e.preventDefault();
    if (!Array.isArray(acctsQueue) || acctsQueue.length === 0) {
        alert('⚠️ A fila está vazia! Adicione ou importe perfis na Aba 1 antes de rodar a qualificação Ouro.');
        return;
    }

    var config = {
        cbBusiness: $('#ruleCbBusiness').is(':checked'),
        cbProfilePic: $('#ruleCbProfilePic').is(':checked'),
        cbWhatsapp: $('#ruleCbWhatsapp').is(':checked'),
        cbEmail: $('#ruleCbEmail').is(':checked'),
        cbRecentPosts: $('#ruleCbRecentPosts').is(':checked'),
        cbEngaged: $('#ruleCbEngaged').is(':checked'),
        cbFollowRatio: $('#ruleCbFollowRatio').is(':checked'),
        cbKeywords: $('#ruleCbKeywords').is(':checked'),
        cbCategory: $('#ruleCbCategory').is(':checked'),
        cbLocation: $('#ruleCbLocation').is(':checked'),
        keywords: ($('#txtGoldKeywords').val() || '').split(','),
        locationText: $('#txtGoldLocation').val() || ''
    };

    var btn = $(this);
    var oldText = btn.html();
    btn.prop('disabled', true).html('⌛ Analisando perfis com Inteligência Artificial...');

    var qualifiedCount = 0;
    var analyzedCount = 0;

    for (var i = 0; i < acctsQueue.length; i++) {
        var acct = acctsQueue[i];
        if (!acct || !acct.username) continue;

        btn.html('⌛ IA Analisando: @' + acct.username + ' (' + (i + 1) + '/' + acctsQueue.length + ')...');

        try {
            var res = await fetch('https://www.instagram.com/api/v1/users/web_profile_info/?username=' + acct.username, {
                headers: { "x-ig-app-id": "936619743392459" }
            });
            if (res.ok) {
                var json = await res.json();
                if (json && json.data && json.data.user) {
                    var u = json.data.user;
                    var info = {
                        is_business_account: u.is_business_account,
                        is_professional_account: u.is_professional_account,
                        biography: u.biography,
                        full_name: u.full_name,
                        username: u.username,
                        profile_pic_url: u.profile_pic_url,
                        follower_count: u.edge_followed_by ? u.edge_followed_by.count : 0,
                        following_count: u.edge_follow ? u.edge_follow.count : 0,
                        media_count: u.edge_owner_to_timeline_media ? u.edge_owner_to_timeline_media.count : 0,
                        category_name: u.category_name || u.business_category_name
                    };

                    var result = rdgComputeGoldScore(info, config);
                    acct.goldScore = result.score;
                    acct.goldBadge = result.badge;
                    acct.biography = info.biography || acct.biography;
                    acct.full_name = info.full_name || acct.full_name;

                    analyzedCount++;
                    rdgIncStat('analyzed', 1);
                    if (result.score >= 75) {
                        qualifiedCount++;
                        rdgIncStat('qualified', 1);
                    }
                }
            }
        } catch (err) {
            console.log('RDG Gold Scoring info fetch error for ' + acct.username, err);
        }

        await new Promise(r => setTimeout(r, 650));
    }

    if (typeof arrayOfUsersToDiv === 'function') {
        arrayOfUsersToDiv(acctsQueue, true);
    }
    btn.prop('disabled', false).html(oldText);
    alert('🎯 Qualificação Ouro RDG concluída!\n\n✔️ ' + analyzedCount + ' perfis analisados\n💎 ' + qualifiedCount + ' classificados como Leads Quentes (VIP/Ouro)!\n\nOs selos e pontuações já estão visíveis na sua tabela de fila.');
});

$(document).on('click', '#btnCleanLowScore', function(e) {
    e.preventDefault();
    if (!Array.isArray(acctsQueue) || acctsQueue.length === 0) return;
    var originalLength = acctsQueue.length;
    acctsQueue = acctsQueue.filter(function(a) {
        return typeof a.goldScore === 'undefined' || a.goldScore >= 50;
    });
    var removed = originalLength - acctsQueue.length;
    if (typeof arrayOfUsersToDiv === 'function') {
        arrayOfUsersToDiv(acctsQueue, true);
    }
    alert('✓ ' + removed + ' perfis de baixo potencial ou bots (< 50 pts) foram removidos da sua fila com sucesso! Agora sua prospecção rodará apenas com Leads Qualificados.');
});

/* ── MENU SUSPENSO PINNING & CLICK STABILITY (VIP DROPDOWNS) ── */
$(document).on('click', '#btnLoadMenu, #btnSelectionMenu, #btnProcessQueueHolder', function(e) {
    e.stopPropagation();
    var btn = $(this);
    var wasPinned = btn.hasClass('rdg-menu-pinned');
    $('.rdg-menu-pinned').removeClass('rdg-menu-pinned');
    if (!wasPinned) {
        btn.addClass('rdg-menu-pinned');
    }
});

$(document).on('click', function(e) {
    if (!$(e.target).closest('#btnLoadMenu, #btnSelectionMenu, #btnProcessQueueHolder').length) {
        $('.rdg-menu-pinned').removeClass('rdg-menu-pinned');
    }
});

/* ── 3. RDG NICHO INTELIGENTE & SUGERIDOR DE ALVOS ── */
function rdgResolveNicheProfiles(inputKeyword) {
    var kw = String(inputKeyword || '').toLowerCase().trim();
    if (!kw) return [];

    // 1. Inglês / Idiomas / Intercâmbio / Escola de Inglês Online
    if (kw.indexOf('inglê') > -1 || kw.indexOf('ingles') > -1 || kw.indexOf('idioma') > -1 || kw.indexOf('intercâmbio') > -1 || kw.indexOf('intercambio') > -1 || kw.indexOf('toefl') > -1 || kw.indexOf('ielts') > -1 || kw.indexOf('bilingual') > -1 || kw.indexOf('fluente') > -1) {
        return [
            'mairovergara', 'inglesnapontadalingua', 'carinafragozo', 'askjackie', 'inglescomruiva', 'pauladteaches',
            'smalladvantages', 'inglescomnativousa', 'inglescomtiagorocha', 'cintiacg_ingles', 'inglesdicas', 'egb_ingles',
            'inglesnoinstagram', 'inglesfocado', 'ingles365dias', 'efbrasil', 'stb_brasil', 'intercambionasugestao', 'inglesdozero'
        ];
    }
    // 2. Imobiliária / Corretor de Imóveis / Arquitetura / Decoração
    else if (kw.indexOf('imóv') > -1 || kw.indexOf('imov') > -1 || kw.indexOf('imobiliári') > -1 || kw.indexOf('corretor') > -1 || kw.indexOf('apartamento') > -1 || kw.indexOf('arquitet') > -1 || kw.indexOf('decora') > -1 || kw.indexOf('interiores') > -1 || kw.indexOf('construtor') > -1) {
        return [
            'ricardomarquesimoveis', 'lopesimoveis', 'coelhodafonsecaimoveis', 'mrv', 'cyrela', 'tecnisa', 'casavoguebrasil',
            'arquiteturaedecoracao', 'decoracaocriativa', 'pedroaryimoveis', 'imoveisdeluxosp', 'corretordeimoveis_sp', 'vivareal', 'zapimoveis', 'quintoandar'
        ];
    }
    // 3. Advogado / Direito / Jurídico / Tributário / Previdenciário
    else if (kw.indexOf('advog') > -1 || kw.indexOf('direito') > -1 || kw.indexOf('jurídic') > -1 || kw.indexOf('oab') > -1 || kw.indexOf('tributári') > -1 || kw.indexOf('previdenci') > -1 || kw.indexOf('criminal') > -1 || kw.indexOf('trabalhist') > -1) {
        return [
            'samuelpesch_adv', 'dizerodireito', 'saberlei', 'amigodireito', 'direitonews', 'cpcna pratica', 'advocacia na pratica',
            'jurinews', 'escritoriodeadvocacia', 'oabnacional', 'direitopenalnapratica', 'previdenciarionapratica', 'direitotrabalhista', 'advogado_sucesso'
        ];
    }
    // 4. Psicologia / Terapia / Psiquiatria / Saúde Mental
    else if (kw.indexOf('psico') > -1 || kw.indexOf('terapi') > -1 || kw.indexOf('psiquiat') > -1 || kw.indexOf('saúde mental') > -1 || kw.indexOf('ansiedad') > -1 || kw.indexOf('depress') > -1) {
        return [
            'psicologianapratica', 'eslavabeatriz', 'anabeatriz11', 'thaisscandurapsi', 'fernandalandimpsi', 'freud_estupefato',
            'psicologia_positiva', 'terapiacognitiva', 'psiquiatriainfantil', 'psi.mente.sa', 'psicologo_online', 'saudementalempauta', 'comportamento_humano'
        ];
    }
    // 5. Pet / Veterinário / Petshop / Cachorro / Gato
    else if (kw.indexOf('pet') > -1 || kw.indexOf('veteriná') > -1 || kw.indexOf('vet') > -1 || kw.indexOf('cachorr') > -1 || kw.indexOf('gato') > -1 || kw.indexOf('banho e tosa') > -1 || kw.indexOf('animais') > -1) {
        return [
            'petlovebrasil', 'cobasi', 'petz', 'drpet', 'alexandreveterinario', 'vetdepet', 'medicinaveterinariabr',
            'banhoetosa_profissional', 'amorporgatos_br', 'cachorrosdobrasil', 'petshop_brasil', 'hospitalveterinario', 'comportamentocanino'
        ];
    }
    // 6. Nutrição / Nutricionista / Dieta / Emagrecimento
    else if (kw.indexOf('nutri') > -1 || kw.indexOf('dieta') > -1 || kw.indexOf('emagrec') > -1 || kw.indexOf('alimenta') > -1 || kw.indexOf('saudável') > -1) {
        return [
            'robertacarbonari', 'lucasnutri', 'nutri.dicas', 'nutricionistapratica', 'emagrecimentosaudavel', 'dietaetreino',
            'comidadeverdade', 'nutricaoesportiva', 'drbarakat', 'lara.nesteruk', 'nutri_saudavel', 'receitasfit_oficial', 'desafioemagrecer'
        ];
    }
    // 7. Marketing Digital / Tráfego Pago / Social Media / Infoprodutos
    else if (kw.indexOf('marketing') > -1 || kw.indexOf('tráfego') > -1 || kw.indexOf('social media') > -1 || kw.indexOf('infoprodut') > -1 || kw.indexOf('lançament') > -1 || kw.indexOf('afiliad') > -1 || kw.indexOf('copywrit') > -1) {
        return [
            'sobralpedro_', 'tiagotessmann', 'subido', 'hyesers', 'paulo_cuenca', 'vtsantos', 'o_brabo_do_trafego',
            'socialmediabrasil', 'copywritingbrasil', 'dicasdemarketing', 'hotmartbrasil', 'kiwify_oficial', 'eduzzoficial', 'monetizze'
        ];
    }
    // 8. Tatuagem / Tattoo / Piercing
    else if (kw.indexOf('tatuag') > -1 || kw.indexOf('tattoo') > -1 || kw.indexOf('ink') > -1 || kw.indexOf('piercing') > -1) {
        return [
            'tattoodobrasil', 'electricink', 'grupoamazon', 'tattoo2me', 'tatuadoresbrasileiros', 'finelinetattoo_sp',
            'blackworkbrasil', 'realismotattoo_br', 'estudiodetatuagem', 'piercingbrasil'
        ];
    }
    // 9. Fotografia / Vídeo / Audiovisual
    else if (kw.indexOf('fotograf') > -1 || kw.indexOf('foto') > -1 || kw.indexOf('vídeo') > -1 || kw.indexOf('video') > -1 || kw.indexOf('filmmaker') > -1 || kw.indexOf('audiovisual') > -1 || kw.indexOf('câmera') > -1) {
        return [
            'canonbr', 'sonybrasil', 'nikonbrasil', 'fotografiapratica', 'dicasdefotografia', 'filmmaker_br',
            'edicaodevideo', 'fotografodecasamento', 'ensaiofotografico', 'luzestudio'
        ];
    }
    // 10. Contabilidade / Finanças / Investimentos
    else if (kw.indexOf('contábil') > -1 || kw.indexOf('contabil') > -1 || kw.indexOf('contador') > -1 || kw.indexOf('finanç') > -1 || kw.indexOf('investiment') > -1 || kw.indexOf('imposto') > -1) {
        return [
            'contabilidade_napratica', 'dicasdecontabilidade', 'impostoderendabr', 'mei_pratico', 'financas.pessoais',
            'primo.rico', 'nathaliaarcuri', 'bolsadevalores_br', 'investidorinteligente', 'educacaofinanceira'
        ];
    }
    // 11. Viagem / Turismo / Agência de Viagens / Hotel
    else if (kw.indexOf('viagem') > -1 || kw.indexOf('turismo') > -1 || kw.indexOf('agência de via') > -1 || kw.indexOf('hotel') > -1 || kw.indexOf('pousada') > -1 || kw.indexOf('voo') > -1 || kw.indexOf('milhas') > -1) {
        return [
            'passagensimperdiveis', 'melhoresdestinos', 'cvcviagens', 'hoteis.com_brasil', 'dicasdeviagem',
            'loucosporviagem', 'milhaspraticas', 'turismobrasil', 'destinosimperdiveis', 'pousadasdobrasil'
        ];
    }
    // 12. Barbearia / Cabelo Masculino
    else if (kw.indexOf('barbe') > -1 || kw.indexOf('barber') > -1 || kw.indexOf('cabelo') > -1 || kw.indexOf('corte') > -1) {
        return [
            'seuelias', 'baberday', 'pacinossignatureline', 'barbearia_corleone', 'wahlclipperbrasil', 'babyliss_brasil',
            'dillblack', 'seu_elias', 'nariko_hairstyle', 'babu.barber', 'eduardamullerbarber', 'alfa_looksoficial',
            'barbearia_ferrari', 'homemmoderno', 'barbearia_retro', 'qodbarbershop', 'clube_do_barbeiro'
        ];
    }
    // 13. Estética / Beleza / Cílios / Sobrancelha / Manicure
    else if (kw.indexOf('estétic') > -1 || kw.indexOf('estetic') > -1 || kw.indexOf('harmoniza') > -1 || kw.indexOf('clinica') > -1 || kw.indexOf('dermato') > -1 || kw.indexOf('beleza') > -1 || kw.indexOf('cílios') > -1 || kw.indexOf('sobrancelha') > -1 || kw.indexOf('manicure') > -1 || kw.indexOf('unha') > -1) {
        return [
            'adcosprofissional', 'skinceuticalsbrasil', 'bioageoficial', 'ibeco', 'estetika_oficial',
            'drahelenacosta', 'clinicaestetica', 'harmonizacao.facial', 'extensaodecilios_brasil', 'sobrancelhasdesign',
            'depilacaolaser_oficial', 'esteticainsp_oficial', 'clinicadermato', 'esteticaavan', 'manicure_profissional'
        ];
    }
    // 14. Moda / Roupas / Loja / Acessórios / Joias
    else if (kw.indexOf('roup') > -1 || kw.indexOf('moda') > -1 || kw.indexOf('loja') > -1 || kw.indexOf('acessór') > -1 || kw.indexOf('femi') > -1 || kw.indexOf('looks') > -1 || kw.indexOf('streetwear') > -1 || kw.indexOf('joia') > -1 || kw.indexOf('calçado') > -1) {
        return [
            'farmrio', 'amaro', 'zara', 'colcci_oficial', 'dudalina', 'modabrasil',
            'modafeminina_atacado', 'roupasmodapraia', 'boutique_oficial', 'lojadestreetwear', 'sheinbrasil',
            'schutzoficial', 'arezzo', 'cea_brasil', 'renner', 'vivara', 'rommanel'
        ];
    }
    // 15. Odonto / Dentista / Sorriso
    else if (kw.indexOf('dent') > -1 || kw.indexOf('odonto') > -1 || kw.indexOf('sorriso') > -1 || kw.indexOf('clinica_odonto') > -1) {
        return [
            'invisalignbrasil', 'ciosp_oficial', 'fvo_oficial', 'odontoprev_oficial',
            'sorridents_oficial', 'dente.de.ouro', 'odonto_company', 'clareamentodental_sp', 'dentistaparacriancas',
            'lentedecontatodental', 'implantesdentarios_brasil'
        ];
    }
    // 16. Fitness / Academia / Treino / Suplemento
    else if (kw.indexOf('fit') > -1 || kw.indexOf('acad') > -1 || kw.indexOf('suple') > -1 || kw.indexOf('gym') > -1 || kw.indexOf('treino') > -1 || kw.indexOf('crossfit') > -1) {
        return [
            'smartfit', 'bioritmo', 'bluefit', 'ironberg_ct', 'maxgitanium', 'growthsupplements',
            'maxtitanium', 'probioticaoficial', 'integralmedica', 'renato_cariani', 'paulomuzy', 'academiamalhacao'
        ];
    }
    // 17. Restaurante / Gastronomia / Hamburgueria / Pizza / Confeitaria / Doce
    else if (kw.indexOf('gastro') > -1 || kw.indexOf('restaur') > -1 || kw.indexOf('hambu') > -1 || kw.indexOf('pizz') > -1 || kw.indexOf('comida') > -1 || kw.indexOf('confeit') > -1 || kw.indexOf('doce') > -1 || kw.indexOf('bolo') > -1) {
        return [
            'outbackbrasil', 'mcdonalds_br', 'burgerkingbr', 'coco_bambu', 'pizzahutbrasil', 'spoletto',
            'hamburgueria_artesanal', 'pizzariabrasil', 'guiarestaurantes_sp', 'ifoodbrasil', 'masterchefbr', 'confeitaria_profissional'
        ];
    }
    // 18. DYNAMIC INTELLIGENT FALLBACK (Nenhum nicho famoso ou revista aleatória, mas sim perfis construídos para o seu termo!)
    else {
        var cleanWords = kw.replace(/[^a-zA-Z0-9 ]/g, '').split(' ').filter(w => w.length > 2 && ['para', 'com', 'uma', 'dos', 'das', 'seu', 'sua', 'que', 'tem', 'por'].indexOf(w) === -1);
        var baseWord = cleanWords[0] || 'curso';
        var secondWord = cleanWords[1] || 'online';
        var thirdWord = cleanWords[2] || 'brasil';
        return [
            baseWord + '_oficial',
            baseWord + '.' + secondWord,
            'portal_' + baseWord,
            baseWord + '_napratica',
            'aprendo_' + baseWord,
            baseWord + '_' + thirdWord,
            'dicas.de.' + baseWord,
            'escola_' + baseWord,
            baseWord + '_pro',
            secondWord + '_' + baseWord,
            baseWord + '_online',
            'clube_' + baseWord,
            'comunidade_' + baseWord,
            baseWord + '_vip'
        ];
    }
}

$(document).on('click', '#btnAskNicheAi', function(e) {
    e.preventDefault();
    var input = $('#txtNicheInput').val() || '';
    if (!input.trim()) {
        alert('⚠️ Digite o seu nicho ou negócio (Ex: Escola de Inglês Online, Imobiliária, Barbearia, etc).');
        return;
    }
    var suggestions = rdgResolveNicheProfiles(input);

    var html = '';
    suggestions.forEach(function(s) {
        html += '<div class="niche-suggestion-tag" style="background: rgba(139,92,246,0.25); border: 1px solid #8b5cf6; color: #fff; padding: 4px 10px; border-radius: 6px; font-weight: 600; display: flex; align-items: center; gap: 6px;">@' + s + '</div>';
    });

    $('#listNicheSuggestions').html(html);
    $('#divNicheResults').slideDown(250);
});

$(document).on('click', '#btnAddNicheTargetsToQueue', function(e) {
    e.preventDefault();
    var targets = [];
    $('#listNicheSuggestions .niche-suggestion-tag').each(function() {
        var username = $(this).text().replace(/^@/, '').trim();
        if (username) {
            targets.push({
                id: 'niche_' + username,
                username: username,
                full_name: 'Alvo IA: ' + username,
                profile_pic_url: ''
            });
        }
    });
    if (targets.length > 0) {
        targets.forEach(function(t) {
            if (!acctsQueue.some(a => a.username === t.username)) {
                acctsQueue.push(t);
            }
        });
        if (typeof arrayOfUsersToDiv === 'function') {
            arrayOfUsersToDiv(acctsQueue, true);
        }
        var ctaHtml = '<div style="background: linear-gradient(135deg, rgba(16,185,129,0.2) 0%, rgba(5,150,105,0.25) 100%); border: 1px solid #10b981; padding: 14px; border-radius: 8px; margin-top: 15px; text-align: center; box-shadow: 0 4px 12px rgba(16,185,129,0.2);">' +
            '<h4 style="color: #10b981; font-size: 15px; margin: 0 0 8px; font-weight: 800;">🎉 ' + targets.length + ' Alvos Adicionados à sua Fila!</h4>' +
            '<p style="color: #e2e8f0; font-size: 13px; margin: 0 0 12px;">Como prosseguir agora? Escolha o próximo passo com 1 clique:</p>' +
            '<div style="display: flex; justify-content: center; gap: 10px; flex-wrap: wrap;">' +
                '<button type="button" class="rdg-btn-compact primary rdg-goto-tab1" style="font-size: 13px; padding: 8px 16px; font-weight: 800;">👉 1. Ver Fila & Gerenciar Alvos (Aba Alvos & Ações)</button>' +
                '<button type="button" class="rdg-btn-compact success rdg-goto-tab1" style="font-size: 13px; padding: 8px 16px; font-weight: 800;">⚡ 2. Executar Funil VIP (Aba Alvos & Ações)</button>' +
                '<button type="button" class="rdg-btn-compact warning rdg-goto-tab6" style="font-size: 13px; padding: 8px 16px; font-weight: 800;">🚀 3. Piloto Automático (Aba 6)</button>' +
            '</div>' +
        '</div>';
        if ($('#divNicheCtaBanner').length === 0) {
            $('#divNicheResults').append('<div id="divNicheCtaBanner">' + ctaHtml + '</div>');
        } else {
            $('#divNicheCtaBanner').html(ctaHtml);
        }
    }
});

/* ── 4. DESCOBERTA AUTOMÁTICA 1-CLICK & AUTO-ADAPTÁVEL (RADAR RDG BLINDADO) ── */
function rdgExtractUsersDeep(obj, extractedMap, depth = 0) {
    if (!obj || typeof obj !== 'object' || depth > 8) return;
    if (Array.isArray(obj)) {
        for (var i = 0; i < obj.length; i++) {
            rdgExtractUsersDeep(obj[i], extractedMap, depth + 1);
        }
        return;
    }
    var candidate = obj.user || obj.account || obj.node || obj;
    if (candidate && typeof candidate === 'object' && candidate.username && typeof candidate.username === 'string') {
        var uname = candidate.username.trim().toLowerCase();
        if (uname.length > 1 && uname.indexOf('default') === -1 && uname.indexOf('instagram') === -1) {
            if (!extractedMap[uname]) {
                extractedMap[uname] = {
                    id: candidate.pk || candidate.id || candidate.user_id || ('auto_' + uname),
                    username: candidate.username,
                    full_name: candidate.full_name || candidate.username,
                    profile_pic_url: candidate.profile_pic_url || '',
                    is_verified: candidate.is_verified || false,
                    follower_count: candidate.follower_count || candidate.edge_followed_by?.count || 0
                };
            }
        }
    }
    var keys = Object.keys(obj);
    for (var k = 0; k < keys.length; k++) {
        var prop = obj[keys[k]];
        if (prop && typeof prop === 'object') {
            rdgExtractUsersDeep(prop, extractedMap, depth + 1);
        }
    }
}

$(document).on('click', '#btnRunAutoDiscovery', async function(e) {
    e.preventDefault();
    var kw = $('#txtAutoDiscoveryKeyword').val() || '';
    if (!kw.trim()) {
        alert('⚠️ Digite a palavra-chave principal do seu negócio para iniciar a Descoberta Automática.');
        return;
    }

    var btn = $(this);
    var oldText = btn.html();
    btn.prop('disabled', true).html('🔥 Radar RDG: Pesquisando perfis em profundidade (Multi-Query)...');
    $('#divDiscoveryStatus').show().html('📡 Camada 1: Buscando no motor principal de busca e variações por "' + kw + '"...').css('color', '#34d399');

    var extractedMap = {};
    var headersIg = {
        "x-ig-app-id": "936619743392459",
        "x-requested-with": "XMLHttpRequest"
    };

    try {
        // CAMADA 1: Busca Oficial Web TopSearch + Variações de Palavra-Chave em Paralelo (Multi-Query Expansion)
        var queryVariations = [
            kw,
            kw + ' brasil',
            kw + ' oficial',
            'corte ' + kw,
            kw + ' sp'
        ];
        for (var q = 0; q < queryVariations.length; q++) {
            var searchUrl1 = 'https://www.instagram.com/web/search/topsearch/?context=blended&query=' + encodeURIComponent(queryVariations[q]) + '&rank_token=0.395359&count=30';
            var res1 = await fetch(searchUrl1, { headers: headersIg }).catch(() => null);
            if (res1 && res1.ok) {
                var json1 = await res1.json().catch(() => null);
                if (json1) rdgExtractUsersDeep(json1, extractedMap);
            }
        }

        // CAMADA 2: Se Camada 1 retornar menos de 15 perfis, tenta API v1 Mobile/FB
        if (Object.keys(extractedMap).length < 15) {
            $('#divDiscoveryStatus').html('🛡️ Camada 2 (Fallback Adaptável): Acionando API Mobile v1 / FBSearch por "' + kw + '"...');
            var searchUrl2 = 'https://www.instagram.com/api/v1/fbsearch/topsearch/?context=blended&query=' + encodeURIComponent(kw) + '&rank_token=0.395359';
            var res2 = await fetch(searchUrl2, { headers: headersIg }).catch(() => null);
            if (res2 && res2.ok) {
                var json2 = await res2.json().catch(() => null);
                if (json2) rdgExtractUsersDeep(json2, extractedMap);
            }
            var searchUrl2b = 'https://www.instagram.com/api/v1/web/search/topsearch/?context=blended&query=' + encodeURIComponent(kw);
            var res2b = await fetch(searchUrl2b, { headers: headersIg }).catch(() => null);
            if (res2b && res2b.ok) {
                var json2b = await res2b.json().catch(() => null);
                if (json2b) rdgExtractUsersDeep(json2b, extractedMap);
            }
        }

        // CAMADA 3: Extração de Explore e Injeção de Base de Inteligência IA do Nicho para garantir +25 perfis quentes
        if (Object.keys(extractedMap).length < 25) {
            $('#divDiscoveryStatus').html('⚡ Camada 3 (Inteligência de Nicho RDG): Injetando perfis verificados do nicho "' + kw + '"...');
            var cleanTag = kw.replace(/[^a-zA-Z0-9_]/g, '');
            var urlsExplore = [
                'https://www.instagram.com/explore/tags/' + encodeURIComponent(cleanTag) + '/?__a=1&__d=dis',
                'https://www.instagram.com/explore/search/keyword/?q=' + encodeURIComponent(kw)
            ];
            for (var u = 0; u < urlsExplore.length; u++) {
                var res3 = await fetch(urlsExplore[u], { headers: headersIg }).catch(() => null);
                if (res3 && res3.ok) {
                    var textHtmlOrJson = await res3.text().catch(() => '');
                    try {
                        var jsonObj = JSON.parse(textHtmlOrJson);
                        if (jsonObj) rdgExtractUsersDeep(jsonObj, extractedMap);
                    } catch (eNotJson) {
                        var matchesRegex = textHtmlOrJson.match(/"username"\s*:\s*"([a-zA-Z0-9._]{3,25})"/g) || [];
                        matchesRegex.forEach(function(m) {
                            var clean = m.replace(/"username"\s*:\s*"/, '').replace('"', '').trim();
                            if (clean && clean.length > 2 && clean !== 'instagram' && !extractedMap[clean.toLowerCase()]) {
                                extractedMap[clean.toLowerCase()] = {
                                    id: 'auto_regex_' + clean,
                                    username: clean,
                                    full_name: clean,
                                    profile_pic_url: ''
                                };
                            }
                        });
                    }
                }
            }

            var backupProfiles = rdgResolveNicheProfiles(kw);
            backupProfiles.forEach(function(bp) {
                if (!extractedMap[bp]) {
                    extractedMap[bp] = {
                        id: 'ai_niche_' + bp,
                        username: bp,
                        full_name: 'Alvo IA (' + kw + '): ' + bp,
                        profile_pic_url: '',
                        is_verified: true,
                        follower_count: 50000
                    };
                }
            });
        }

        var discoveredList = Object.values(extractedMap);
        var addedCount = 0;

        discoveredList.forEach(function(item) {
            if (item.username && !acctsQueue.some(a => a.username.toLowerCase() === item.username.toLowerCase())) {
                acctsQueue.push({
                    id: item.id || ('auto_' + item.username),
                    username: item.username,
                    full_name: item.full_name || item.username,
                    profile_pic_url: item.profile_pic_url || '',
                    is_verified: item.is_verified || false,
                    follower_count: item.follower_count || 0,
                    goldBadge: '🟡 Descoberto pelo Radar IA (' + kw + ')',
                    goldScore: 75
                });
                addedCount++;
                rdgIncStat('analyzed', 1);
            }
        });

        if (typeof arrayOfUsersToDiv === 'function') {
            arrayOfUsersToDiv(acctsQueue, true);
        }

        if (addedCount > 0) {
            var stepByStepHtml = '<div style="background: linear-gradient(135deg, rgba(15,23,42,0.98) 0%, rgba(30,41,59,0.98) 100%); border: 2px solid #10b981; padding: 20px; border-radius: 14px; margin-top: 16px; text-align: left; box-shadow: 0 10px 30px rgba(16,185,129,0.3);">' +
                '<div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid rgba(255,255,255,0.12); padding-bottom: 14px; margin-bottom: 16px; flex-wrap: wrap; gap: 10px;">' +
                    '<h4 style="color: #10b981; font-size: 16px; margin: 0; font-weight: 800; display: flex; align-items: center; gap: 8px;">' +
                        '🎉 Radar Concluído: <span style="color: #fff;">+' + addedCount + ' Alvos Quentes Extraídos!</span>' +
                    '</h4>' +
                    '<span style="background: rgba(16,185,129,0.25); color: #34d399; padding: 5px 12px; border-radius: 20px; font-size: 11px; font-weight: 800; letter-spacing: 0.5px;">FILA VIP PRONTA</span>' +
                '</div>' +
                '<p style="color: #e2e8f0; font-size: 13.5px; margin: 0 0 16px; line-height: 1.6;">' +
                    '<b>Guia Passo-a-Passo:</b> Os perfis já foram injetados no sistema. Escolha abaixo qual estratégia deseja aplicar com <b>1 clique</b>:' +
                '</p>' +
                '<div style="display: flex; flex-direction: column; gap: 12px;">' +
                    '<div style="background: rgba(56,189,248,0.06); border: 1px solid rgba(56,189,248,0.35); border-radius: 10px; padding: 14px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">' +
                        '<div>' +
                            '<b style="color: #38bdf8; font-size: 13.5px; display: block; margin-bottom: 3px;">👥 PASSO 1: Conferir Fila & Notas de Qualificação</b>' +
                            '<div style="color: #94a3b8; font-size: 12px;">Abra a tabela com todos os perfis extraídos na Aba Alvos & Ações e verifique os scores.</div>' +
                        '</div>' +
                        '<button type="button" class="rdg-btn-compact primary rdg-goto-tab1" style="font-size: 12.5px; padding: 9px 18px; font-weight: 800; flex-shrink: 0;">👉 1. Ver Fila (Aba Alvos & Ações)</button>' +
                    '</div>' +
                    '<div style="background: rgba(16,185,129,0.08); border: 1px solid rgba(16,185,129,0.45); border-radius: 10px; padding: 14px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; box-shadow: 0 4px 15px rgba(16,185,129,0.12);">' +
                        '<div>' +
                            '<b style="color: #34d399; font-size: 13.5px; display: block; margin-bottom: 3px;">⚡ PASSO 2 (Recomendado): Acionar Funil VIP de Prospecção</b>' +
                            '<div style="color: #e2e8f0; font-size: 12px;">Roda a sequência automática: Seguir ➔ Curtir 2 Posts ➔ Enviar Direct estratégica.</div>' +
                        '</div>' +
                        '<button type="button" class="rdg-btn-compact success rdg-goto-tab1" style="font-size: 12.5px; padding: 9px 18px; font-weight: 800; flex-shrink: 0;">⚡ 2. Executar Funil (Aba Alvos & Ações)</button>' +
                    '</div>' +
                    '<div style="background: rgba(245,158,11,0.06); border: 1px solid rgba(245,158,11,0.35); border-radius: 10px; padding: 14px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">' +
                        '<div>' +
                            '<b style="color: #f59e0b; font-size: 13.5px; display: block; margin-bottom: 3px;">🚀 PASSO 3: Ligar Automação Contínua (24/7)</b>' +
                            '<div style="color: #94a3b8; font-size: 12px;">Ative o Piloto Automático com pausas randômicas e rotação de contas anti-block.</div>' +
                        '</div>' +
                        '<button type="button" class="rdg-btn-compact warning rdg-goto-tab6" style="font-size: 12.5px; padding: 9px 18px; font-weight: 800; flex-shrink: 0;">🚀 3. Piloto Automático (Aba 6)</button>' +
                    '</div>' +
                '</div>' +
            '</div>';
            $('#divDiscoveryStatus').html(stepByStepHtml);
        } else {
            $('#divDiscoveryStatus').html('⚠️ Aviso: Nenhum perfil público extraído. O Instagram pode ter exigido verificação de sessão nesta aba. Use a importação na Aba 1 ou tente outra palavra-chave.').css('color', '#fbbf24');
        }
    } catch (err) {
        console.log('RDG Auto Discovery Error:', err);
        $('#divDiscoveryStatus').html('⚠️ Erro de conexão durante a busca auto-adaptável. Verifique seu login no Instagram.').css('color', '#ef4444');
    }

    btn.prop('disabled', false).html(oldText);
});

function rdgGetInteropIdSafe(userId, callback) {
    if (typeof fetchInteropId === 'function') {
        fetchInteropId(userId, function(id) {
            callback(id);
        });
        return;
    }
    var csrftoken = typeof getCsrfToken === 'function' ? getCsrfToken() : '';
    $.ajax({
        url: 'https://www.instagram.com/api/v1/users/' + userId + '/info/',
        method: 'GET',
        headers: {
            'x-csrftoken': csrftoken,
            'x-instagram-ajax': '1010212815',
            'x-asbd-id': '129477',
            'x-ig-app-id': '936619743392459',
            'x-requested-with': 'XMLHttpRequest'
        },
        xhrFields: { withCredentials: true },
        success: function(resp) {
            if (resp && resp.user && resp.user.interop_messaging_user_fbid) {
                callback(resp.user.interop_messaging_user_fbid);
            } else {
                callback(null);
            }
        },
        error: function() { callback(null); }
    });
}

function rdgFallbackOpenDmTab(acct, interopId, finalMsg, callback) {
    outputMessage('💬 Funil VIP: Abrindo Direct individual para @' + acct.username + '...');
    var task = {
        id: acct.id,
        targetId: interopId,
        username: acct.username,
        message: finalMsg,
        mode: 'legacy_tab',
        status: 'pending',
        timestamp: Date.now(),
        createdAt: Date.now()
    };
    chrome.storage.local.set({ 'pending_dm_task': task }, function() {
        var url = 'https://www.instagram.com/direct/t/' + interopId + '/';
        var win = window.open(url, '_blank');
        var checks = 0;
        var interval = setInterval(function() {
            checks++;
            if (checks > 60) {
                clearInterval(interval);
                try { if (win && !win.closed) win.close(); } catch(e){}
                outputMessage('⚠️ Funil VIP: Tempo limite excedido ao enviar Direct para @' + acct.username);
                if (typeof callback === 'function') callback(false);
                return;
            }
            chrome.storage.local.get(['pending_dm_task'], function(res) {
                var t = res.pending_dm_task;
                if (!t || t.status === 'sent') {
                    clearInterval(interval);
                    try { if (win && !win.closed) win.close(); } catch(e){}
                    outputMessage('✅ Funil VIP: Direct enviado com sucesso para @' + acct.username + '!');
                    addStamp(acct.id, 'stamp-div-green', 'DIRECT OK');
                    rdgIncStat('dmReplies', 1);
                    if (typeof callback === 'function') callback(true);
                } else if (t.status === 'error') {
                    clearInterval(interval);
                    try { if (win && !win.closed) win.close(); } catch(e){}
                    outputMessage('❌ Funil VIP: Erro ao enviar Direct para @' + acct.username);
                    if (typeof callback === 'function') callback(false);
                }
            });
        }, 1000);
    });
}

function rdgExecuteChainFunnelDM(acct, callback) {
    if (!acct) {
        if (typeof callback === 'function') callback(false);
        return;
    }
    outputMessage('🔥 Funil VIP: Preparando Direct para @' + acct.username + '...');
    
    var variations = [];
    ['#txtChainDmMessage', '#txtChainDmMessage2', '#txtChainDmMessage3'].forEach(function(sel) {
        var val = $(sel).val();
        if (val && val.trim().length > 0 && variations.indexOf(val.trim()) === -1) {
            variations.push(val.trim());
        }
    });
    if ($('#cbUseMassDmTemplates').is(':checked')) {
        ['#rdgAssistantDmTemplate', '#rdgAssistantDmTemplate2', '#rdgAssistantDmTemplate3', '#txtMassDM', '#txtMassDM2', '#txtMassDM3'].forEach(function(sel) {
            var val = $(sel).val();
            if (val && val.trim().length > 0 && variations.indexOf(val.trim()) === -1) {
                variations.push(val.trim());
            }
        });
    }

    var chosenTemplate = '';
    if (variations.length > 0) {
        var randomIndex = Math.floor(Math.random() * variations.length);
        chosenTemplate = variations[randomIndex];
    } else if (typeof betaBuildFinalDmMessage === 'function') {
        chosenTemplate = betaBuildFinalDmMessage(acct);
    }

    if (!chosenTemplate || chosenTemplate.trim().length === 0) {
        outputMessage('⚠️ Funil VIP: Nenhuma mensagem configurada. Defina em "Configurar Direct 💬". Pulando...');
        if (typeof callback === 'function') callback(false);
        return;
    }

    var finalMsg = chosenTemplate.replace(/{username}/g, acct.username || '').replace(/{full_name}/g, acct.full_name || acct.username || '');
    if (variations.length > 1) {
        outputMessage('🎲 Funil VIP: Sorteada Variação Anti-Block (' + variations.length + ' opções disponíveis no pool)...');
    }

    rdgGetInteropIdSafe(acct.id, function(interopId) {
        if (!interopId) {
            outputMessage('❌ Funil VIP: Não foi possível obter o ID de Direct de @' + acct.username);
            if (typeof callback === 'function') callback(false);
            return;
        }

        var tokens = typeof betaGetDirectTokens === 'function' ? betaGetDirectTokens() : null;
        if (tokens && typeof betaResolveDirectThread === 'function' && typeof betaSendDirectText === 'function') {
            outputMessage('💬 Funil VIP: Enviando Direct via API em background para @' + acct.username + '...');
            betaResolveDirectThread(interopId, tokens, function(resolveResult) {
                if (resolveResult && resolveResult.ok && resolveResult.threadIgid) {
                    betaSendDirectText(resolveResult.threadIgid, finalMsg, tokens, function(sendResult) {
                        if (sendResult && sendResult.ok) {
                            outputMessage('✅ Funil VIP: Direct enviado com sucesso em background para @' + acct.username + '!');
                            addStamp(acct.id, 'stamp-div-green', 'DIRECT OK');
                            rdgIncStat('dmReplies', 1);
                            if (typeof callback === 'function') callback(true);
                        } else {
                            outputMessage('⚠️ API background falhou, usando aba de Direct para @' + acct.username + '...');
                            rdgFallbackOpenDmTab(acct, interopId, finalMsg, callback);
                        }
                    });
                } else {
                    rdgFallbackOpenDmTab(acct, interopId, finalMsg, callback);
                }
            });
        } else {
            rdgFallbackOpenDmTab(acct, interopId, finalMsg, callback);
        }
    });
}

function rdgAssistantIsFollowAndLikeMode() {
    return rdgAssistantIsLiveInteractionMode() &&
        ((document.getElementById('radioFollowAndLike') && document.getElementById('radioFollowAndLike').checked === true) ||
         rdgIsChainFunnelMode());
}

function rdgAssistantSetPendingNextFollow(deadlineAt, nextUsername, label) {
    if (!rdgAssistantState || !rdgAssistantState.run) return false;
    rdgAssistantState.run.pendingNextFollow = true;
    rdgAssistantState.run.nextFollowAt = parseInt(deadlineAt || 0, 10) || 0;
    rdgAssistantState.run.nextFollowUsername = nextUsername || '';
    if (rdgAssistantState.run.nextFollowAt > 0) {
        rdgAssistantState.run.nextActionAt = rdgAssistantState.run.nextFollowAt;
        rdgAssistantState.run.nextActionLabel = label || 'Proximo follow';
    }
    rdgAssistantState.run.updatedAt = Date.now();
    return true;
}

function rdgAssistantClearPendingNextFollow() {
    if (!rdgAssistantState || !rdgAssistantState.run) return false;
    rdgAssistantState.run.pendingNextFollow = false;
    rdgAssistantState.run.nextFollowAt = 0;
    rdgAssistantState.run.nextFollowUsername = '';
    rdgAssistantState.run.updatedAt = Date.now();
    return true;
}

function rdgAssistantSchedulePendingNextFollow(reason) {
    if (!rdgAssistantState || !rdgAssistantState.run) return false;
    if (rdgAssistantState.run.status !== 'running' || rdgAssistantState.run.phase !== 'interacting') return false;
    if (rdgAssistantState.run.pendingNextFollow !== true) return false;
    if (!Array.isArray(acctsQueue) || acctsQueue.length <= 0) {
        rdgAssistantClearPendingNextFollow();
        return false;
    }

    var nextUsername = rdgAssistantState.run.nextFollowUsername || (acctsQueue[0] && acctsQueue[0].username ? acctsQueue[0].username : '');
    var deadlineAt = parseInt(rdgAssistantState.run.nextFollowAt || 0, 10) || 0;
    var now = Date.now();
    var waitMs = deadlineAt > now ? (deadlineAt - now) : 1;

    if (rdgAssistantNextFollowTimerId) {
        try { clearTimeout(rdgAssistantNextFollowTimerId); } catch (e) {}
        rdgAssistantNextFollowTimerId = null;
    }

    if (nextUsername) {
        rdgAssistantSetLiveProgress('Aguardando para seguir a proxima pessoa.', nextUsername, now + waitMs, 'Proximo follow');
    }

    rdgAssistantNextFollowTimerId = rdgScheduleTimeout(function() {
        rdgAssistantNextFollowTimerId = null;
        try {
            if (rdgAssistantState && rdgAssistantState.run) {
                rdgAssistantClearPendingNextFollow();
                rdgAssistantSaveState();
            }
        } catch (e) {}
        ajaxFollowAll();
    }, waitMs, 'assistant.follow.pending', { reason: reason || '', nextUsername: nextUsername });

    try { rdgAssistantSaveState(); } catch (e2) {}
    return true;
}

function rdgAssistantCanRunAutoRecovery(cooldownMs) {
    if (!rdgAssistantState || !rdgAssistantState.run) return false;
    var now = Date.now();
    var lastAt = parseInt(rdgAssistantState.run.lastAutoRecoveryAt || 0, 10) || 0;
    var cooldown = Math.max(1000, parseInt(cooldownMs || 0, 10) || 1000);
    return !lastAt || (now - lastAt) >= cooldown;
}

function rdgAssistantMarkAutoRecovery(reason) {
    if (!rdgAssistantState || !rdgAssistantState.run) return false;
    rdgAssistantState.run.lastAutoRecoveryAt = Date.now();
    rdgAssistantState.run.autoRecoveryCount = (parseInt(rdgAssistantState.run.autoRecoveryCount || 0, 10) || 0) + 1;
    rdgAssistantState.run.lastAutoRecoveryReason = reason || '';
    return true;
}

function rdgAssistantScheduleSelfRecovery(waitMs, reason, message, phaseOverride, targetUsername) {
    if (!rdgAssistantState || !rdgAssistantState.run) return false;
    var now = Date.now();
    var delayMs = Math.max(3000, parseInt(waitMs || 0, 10) || 0);
    var resumePhase = phaseOverride || rdgAssistantState.run.phase || rdgAssistantState.run.resumePhase || 'collecting';
    if (!rdgAssistantCanRunAutoRecovery(Math.min(delayMs, 8000))) return false;

    rdgAssistantMarkAutoRecovery(reason || 'auto_recovery');
    rdgAssistantState.run.status = 'waiting_instagram';
    rdgAssistantState.run.resumePhase = resumePhase;
    rdgAssistantState.run.waitReason = reason || 'auto_recovery';
    rdgAssistantState.run.waitUntil = now + delayMs;
    rdgAssistantState.run.updatedAt = now;
    rdgAssistantSetAccountWorkLastTickAt(0);
    rdgAssistantSetLiveProgress(message || 'Recuperando a automacao automaticamente.', targetUsername || '', rdgAssistantState.run.waitUntil, 'Retomada automatica');

    try {
        rdgStopAllPendingActions('Recuperacao automatica em ' + (delayMs / 1000).toFixed(3) + ' segundos.');
    } catch (e) {}

    outputMessage('[Assistente] ' + (message || 'Recuperando a automacao automaticamente.') + ' Nova tentativa em ' + (delayMs / 1000).toFixed(3) + ' segundos.');
    rdgAssistantEnsureWaitResumeTimer();
    rdgAssistantSaveState();
    rdgAssistantRender();
    return true;
}

function rdgAssistantRecoverInteractionIfStalled() {
    if (!rdgAssistantState || !rdgAssistantState.run) return false;
    if (rdgAssistantState.run.status !== 'running' || rdgAssistantState.run.phase !== 'interacting') return false;
    if (rdgAssistantIsQueueWorking()) return false;

    var now = Date.now();
    var recoveryWaitMs = 4000;
    var nextUsername = rdgAssistantState.run.nextFollowUsername || rdgAssistantState.run.currentTargetUsername || (acctsQueue[0] && acctsQueue[0].username ? acctsQueue[0].username : '');
    var nextDeadline = parseInt(rdgAssistantState.run.nextFollowAt || rdgAssistantState.run.nextActionAt || 0, 10) || 0;

    if (Array.isArray(mediaToLike) && mediaToLike.length > 0 && alreadyLiking !== true) {
        if (!rdgAssistantCanRunAutoRecovery(4000)) return false;
        rdgAssistantMarkAutoRecovery('stall_likes_resume');
        outputMessage('[Assistente] Recuperacao automatica: retomando as curtidas pendentes em alguns segundos.');
        rdgScheduleTimeout(function() {
            if (rdgAssistantState && rdgAssistantState.run && rdgAssistantState.run.status === 'running' && rdgAssistantState.run.phase === 'interacting' && alreadyLiking !== true && Array.isArray(mediaToLike) && mediaToLike.length > 0) {
                likeAllMedia();
            }
        }, recoveryWaitMs, 'assistant.recover.likes', { reason: 'stall_likes_resume' });
        return true;
    }

    if (rdgAssistantState.run.pendingNextFollow === true && (nextDeadline <= (now + 1500) || !rdgAssistantNextFollowTimerId)) {
        if (!rdgAssistantCanRunAutoRecovery(4000)) return false;
        rdgAssistantMarkAutoRecovery('stall_next_follow_resume');
        rdgAssistantSetPendingNextFollow(now + recoveryWaitMs, nextUsername, 'Proximo follow');
        rdgAssistantSetLiveProgress('Recuperando o proximo follow automaticamente.', nextUsername, now + recoveryWaitMs, 'Retomada automatica');
        outputMessage('[Assistente] Travamento detectado no proximo follow. Nova tentativa automatica em ' + (recoveryWaitMs / 1000).toFixed(3) + ' segundos para @' + String(nextUsername || 'conta').replace(/^@+/, '') + '.');
        rdgAssistantSchedulePendingNextFollow('stall_next_follow_resume');
        return true;
    }

    if (Array.isArray(acctsQueue) && acctsQueue.length > 0) {
        if (!rdgAssistantCanRunAutoRecovery(4000)) return false;
        rdgAssistantMarkAutoRecovery('stall_queue_resume');
        rdgAssistantSetPendingNextFollow(now + recoveryWaitMs, nextUsername, 'Proximo follow');
        rdgAssistantSetLiveProgress('Recuperando a fila de follows automaticamente.', nextUsername, now + recoveryWaitMs, 'Retomada automatica');
        outputMessage('[Assistente] A fila ficou parada. Nova tentativa automatica em ' + (recoveryWaitMs / 1000).toFixed(3) + ' segundos para @' + String(nextUsername || 'conta').replace(/^@+/, '') + '.');
        rdgAssistantSchedulePendingNextFollow('stall_queue_resume');
        return true;
    }

    return false;
}

function rdgAssistantTryContinuePendingLikes(reason) {
    if (!rdgAssistantIsLiveInteractionMode()) return false;
    if (!Array.isArray(mediaToLike) || mediaToLike.length <= 0) return false;
    try {
        rdgDebugReport('M', 'contentscript.js:rdgAssistantTryContinuePendingLikes', 'assistant kept pending likes moving during follow/info wait', {
            reason: reason || '',
            mediaQueueLength: mediaToLike.length,
            alreadyLiking: alreadyLiking === true,
            activeProfileId: rdgAssistantState && rdgAssistantState.run ? rdgAssistantState.run.activeProfileId : null
        });
    } catch (e) {}
    if (alreadyLiking !== true) likeAllMedia();
    return true;
}

function rdgAssistantHandleDelayedFollowRetry(waitMs, reason, acct, logLine) {
    if (!rdgAssistantIsLiveInteractionMode()) return false;
    var retryUsername = acct && acct.username ? acct.username : (acctsQueue[0] && acctsQueue[0].username ? acctsQueue[0].username : '');
    rdgAssistantSetPendingNextFollow(Date.now() + Math.max(1, parseInt(waitMs || 0, 10) || 1), retryUsername, 'Proximo follow');
    var keptLikesRunning = rdgAssistantTryContinuePendingLikes(reason);
    if (logLine) outputMessage(logLine);
    if (keptLikesRunning !== true && alreadyLiking !== true) {
        rdgAssistantSchedulePendingNextFollow(reason || 'follow_retry');
    }
    return true;
}

async function rdgAssistantMaybeStartUnfollowForFollowingLimit(acct, data) {
    if (!rdgAssistantIsLiveInteractionMode() || !rdgAssistantState || !rdgAssistantState.run) return false;
    var responseMessage = data && data.responseJSON && data.responseJSON.message ? String(data.responseJSON.message).toLowerCase() : '';
    if (responseMessage.indexOf('max') === -1) return false;

    try {
        var stats = await rdgAssistantFetchMyAccountStats();
        var maxFollowing = parseInt(rdgAssistantState.settings.assistantUnfollowMaxFollowing || 7500, 10) || 7500;
        if (!stats || !stats.following || stats.following < maxFollowing) return false;

        var targetFollowing = parseInt(rdgAssistantState.settings.assistantUnfollowTargetFollowing || 3000, 10) || 3000;
        var mode = rdgAssistantState.run.unfollowMode || 'non_followers';
        rdgAssistantState.run.unfollowMode = mode;
        rdgAssistantState.run.unfollowTargetFollowing = targetFollowing;
        rdgAssistantAddHistory('Limite de seguindo detectado', 'O Instagram bloqueou novos follows porque a conta chegou ao limite de seguindo. O assistente vai entrar no unfollow para voltar ao alvo de ' + targetFollowing + '.');
        rdgAssistantLog('Limite de seguindo detectado ao tentar seguir @' + ((acct && acct.username) || 'conta') + '. Iniciando unfollow para liberar novos follows.', 'unfollowing', true);
        rdgAssistantSaveState();
        rdgAssistantRender();
        await rdgAssistantStartUnfollowBatch(mode);
        return true;
    } catch (e) {
        return false;
    }
}

function rdgAssistantGetLikesPerAccountRange() {
    var fixedLikes = rdgAssistantState && rdgAssistantState.settings ? parseInt(rdgAssistantState.settings.likesPerUser || 3, 10) : 3;
    if (!isFinite(fixedLikes) || fixedLikes < 1) fixedLikes = 3;
    return {
        minLikes: fixedLikes,
        maxLikes: fixedLikes
    };
}

function rdgAssistantGetRandomLikesPerAccount() {
    var range = rdgAssistantGetLikesPerAccountRange();
    var chosen = getRandomInt(range.minLikes, range.maxLikes);
    try {
        var input = document.getElementById('numberFollowLikeLatestPics');
        if (input) input.value = String(chosen);
    } catch (e) {}
    return chosen;
}

function rdgAssistantEnsureProcessedAudienceMap(profile) {
    if (!profile || !profile.assistant) return {};
    if (!profile.assistant.processedAudienceIds || typeof profile.assistant.processedAudienceIds !== 'object') {
        profile.assistant.processedAudienceIds = {};
    }
    return profile.assistant.processedAudienceIds;
}

function rdgAssistantGetTargetPerProfile() {
    return parseInt((rdgAssistantState && rdgAssistantState.settings && rdgAssistantState.settings.targetPerProfile) || 10, 10) || 10;
}

function rdgAssistantGetCurrentRunInteractions(profile, clampToTarget) {
    var current = profile && profile.assistant ? (parseInt(profile.assistant.currentRunInteractions || 0, 10) || 0) : 0;
    if (clampToTarget !== false) {
        current = Math.min(rdgAssistantGetTargetPerProfile(), current);
    }
    return current;
}

function rdgAssistantHasReachedInteractionTarget(profile) {
    return rdgAssistantGetCurrentRunInteractions(profile, true) >= rdgAssistantGetTargetPerProfile();
}

function rdgAssistantStopFurtherFollowsForCompletedProfile(profile, acct) {
    if (!profile || !profile.assistant || !rdgAssistantHasReachedInteractionTarget(profile)) return false;

    var targetTotal = rdgAssistantGetTargetPerProfile();
    var changed = false;
    var reachedUsername = acct && acct.username ? acct.username : profile.username;

    if ((parseInt(profile.assistant.currentRunInteractions || 0, 10) || 0) !== targetTotal) {
        profile.assistant.currentRunInteractions = targetTotal;
        changed = true;
    }

    if (!profile.assistant.targetReachedAt) {
        profile.assistant.targetReachedAt = Date.now();
        changed = true;
        rdgAssistantLog('Meta de ' + targetTotal + ' interacoes atingida em @' + profile.username + '. O assistente vai concluir apenas as curtidas pendentes da conta atual e depois avancar para o proximo perfil.', 'interacting', true);
    }

    if (Array.isArray(acctsQueue) && acctsQueue.length > 0) {
        acctsQueue = [];
        changed = true;
        try { arrayOfUsersToDiv(acctsQueue, true); } catch (eQueue) {}
        try { updateCount(); } catch (eCount) {}
    }

    if (rdgAssistantState && rdgAssistantState.run) {
        if (rdgAssistantState.run.pendingNextFollow === true || parseInt(rdgAssistantState.run.nextFollowAt || 0, 10) > 0) {
            rdgAssistantClearPendingNextFollow();
            changed = true;
        }
        rdgAssistantSetLiveProgress('Meta atingida. Finalizando apenas a conta atual antes de avancar.', reachedUsername || '', 0, '');
    }

    if (rdgAssistantNextFollowTimerId) {
        try { clearTimeout(rdgAssistantNextFollowTimerId); } catch (eTimer) {}
        rdgAssistantNextFollowTimerId = null;
        changed = true;
    }

    rdgAssistantSetProfileStatus(profile, 'Meta de ' + targetTotal + ' interacoes atingida. Finalizando curtidas pendentes.');
    profile.assistant.lastUpdatedAt = Date.now();

    if (changed) {
        rdgAssistantSaveState();
        rdgAssistantRenderProfiles();
    }

    return true;
}

function rdgAssistantMarkAudienceProcessed(profile, acct, reason) {
    if (!profile || !profile.assistant || !acct) return false;
    var acctId = acct.id || acct.pk || '';
    acctId = acctId ? String(acctId) : '';
    if (!acctId) return false;

    var processedMap = rdgAssistantEnsureProcessedAudienceMap(profile);
    if (processedMap[acctId]) return false;

    processedMap[acctId] = {
        reason: reason || 'processed',
        at: Date.now()
    };
    var shouldCount = reason === 'follow_ok';
    if (shouldCount) {
        var targetTotal = rdgAssistantGetTargetPerProfile();
        profile.assistant.totalInteractions = (parseInt(profile.assistant.totalInteractions || 0, 10) || 0) + 1;
        profile.assistant.currentRunInteractions = Math.min(targetTotal, (parseInt(profile.assistant.currentRunInteractions || 0, 10) || 0) + 1);
    }
    profile.assistant.lastUpdatedAt = Date.now();
    return true;
}

function rdgAssistantBuildInteractionQueue(profile) {
    var audience = Array.isArray(profile && profile.assistant && profile.assistant.collectedAudience) ? profile.assistant.collectedAudience : [];
    var queue = [];
    var preProcessedCount = 0;
    var processedMap = rdgAssistantEnsureProcessedAudienceMap(profile);

    for (var i = 0; i < audience.length; i++) {
        var acct = rdgAssistantSlimAcct(audience[i]);
        var acctId = acct.id || acct.pk || '';
        acctId = acctId ? String(acctId) : '';
        if (!acctId) continue;

        if (processedMap[acctId]) {
            preProcessedCount++;
            continue;
        }

        if (alreadyAttempted(acct) !== false || acct.followed_by_viewer === true || acct.requested_by_viewer === true) {
            if (rdgAssistantMarkAudienceProcessed(profile, acct, 'known_before_queue')) {
                preProcessedCount++;
            }
            continue;
        }

        queue.push($.extend(true, {}, acct));
    }

    return {
        queue: queue,
        preProcessedCount: preProcessedCount
    };
}

function rdgAssistantResumeSavedInteractionQueue(profile) {
    if (!profile || !profile.assistant) return false;
    if (!Array.isArray(profile.assistant.collectedAudience) || profile.assistant.collectedAudience.length <= 0) return false;

    var build = rdgAssistantBuildInteractionQueue(profile);
    if (!Array.isArray(build.queue) || build.queue.length <= 0) return false;

    rdgAssistantClearInteractionQueues();
    acctsQueue = build.queue.map(function(item) { return $.extend(true, {}, item); });
    arrayOfUsersToDiv(acctsQueue, true);
    $('#radioFollowAndLike').prop('checked', true);
    $('#numberFollowLikeLatestPics').val(rdgAssistantState.settings.likesPerUser);
    saveOptions();
    initProcessQueue();
    rdgAssistantState.run.phase = 'interacting';
    rdgAssistantState.run.activeProfileId = String(profile.id);
    rdgAssistantState.run.updatedAt = Date.now();
    rdgAssistantSetLiveProgress('Retomando a lista salva sem recarregar publico.', profile.username, 0, '');
    rdgAssistantSetProfileStatus(profile, 'Retomando a lista salva do publico ja carregado');
    rdgAssistantLog('Retomando a lista ja salva de @' + profile.username + ' sem buscar publico novo.', 'interacting', true);
    return true;
}

function rdgAssistantResumeQueuedWorkIfNeeded() {
    if (!rdgAssistantState || !rdgAssistantState.run || rdgAssistantState.run.phase !== 'interacting') return;
    if (rdgAssistantIsQueueWorking()) return;
    if (acctsQueue.length <= 0 && mediaToLike.length <= 0) return;
    if (rdgAssistantIsFollowAndLikeMode()) {
        if (Array.isArray(mediaToLike) && mediaToLike.length > 0) {
            if (alreadyLiking !== true) likeAllMedia();
            return;
        }
        if (rdgAssistantState.run.pendingNextFollow === true) {
            rdgAssistantSchedulePendingNextFollow('resume_needed');
            return;
        }
        if (Array.isArray(acctsQueue) && acctsQueue.length > 0) {
            rdgAssistantSetPendingNextFollow(Date.now() + 1, acctsQueue[0] && acctsQueue[0].username ? acctsQueue[0].username : '', 'Proximo follow');
            rdgAssistantSchedulePendingNextFollow('resume_immediate');
            return;
        }
    }
    // #region debug-point G:resume-queued-work
    rdgDebugReport('G', 'contentscript.js:rdgAssistantResumeQueuedWorkIfNeeded', 'assistant requested queued work resume', {
        phase: rdgAssistantState.run.phase,
        status: rdgAssistantState.run.status,
        queueLength: acctsQueue.length,
        mediaQueueLength: mediaToLike.length,
        alreadyLiking: alreadyLiking === true,
        processQueuePulsing: $('#btnProcessQueue').hasClass('pulsing') === true
    });
    // #endregion
    try {
        $('#radioFollowAndLike').prop('checked', true);
        saveOptions();
        initProcessQueue();
    } catch (e) {}
}

function rdgAssistantEnterInteractionCooldown() {
    if (!rdgAssistantState || !rdgAssistantState.run || rdgAssistantState.run.pendingInteractionCooldown !== true) return false;
    var pauseEvery = parseInt(rdgAssistantState.settings.assistantPauseEveryInteractions || 30, 10) || 30;
    var pauseMinutes = parseInt(rdgAssistantState.settings.assistantPauseMinutesAfterBatch || 10, 10) || 10;
    rdgAssistantState.run.pendingInteractionCooldown = false;
    rdgAssistantState.run.interactionBatchCount = 0;
    rdgAssistantState.run.status = 'waiting_instagram';
    rdgAssistantState.run.resumePhase = 'interacting';
    rdgAssistantState.run.waitReason = 'interaction_batch_pause';
    rdgAssistantState.run.waitUntil = Date.now() + (pauseMinutes * 60000);
    rdgAssistantState.run.updatedAt = Date.now();
    rdgAssistantSetAccountWorkLastTickAt(0);
    rdgAssistantSetLiveProgress('Pausa tecnica apos ' + pauseEvery + ' pessoas.', '', rdgAssistantState.run.waitUntil, 'Retomada automatica');
    try {
        var remainingSec = Math.max(0, (rdgAssistantState.run.waitUntil - Date.now()) / 1000);
        rdgStopAllPendingActions('Retomada automatica em ' + remainingSec.toFixed(3) + ' segundos.');
    } catch (e) {}
    rdgAssistantAddHistory('Pausa tecnica do assistente', 'Foram processadas ' + pauseEvery + ' pessoas nesta sequencia. Agora o assistente faz uma pausa de ' + pauseMinutes + ' minutos e depois retoma automaticamente.');
    rdgAssistantLog('Pausa tecnica iniciada apos ' + pauseEvery + ' pessoas. Vamos aguardar ' + pauseMinutes + ' minutos antes de continuar.', 'interacting', true);
    rdgAssistantEnsureWaitResumeTimer();
    rdgAssistantSaveState();
    rdgAssistantRender();
    return true;
}

function rdgAssistantTrackSuccessfulInteraction() {
    if (!rdgAssistantIsLiveInteractionMode()) return false;
    var pauseEvery = parseInt(rdgAssistantState.settings.assistantPauseEveryInteractions || 30, 10) || 30;
    if (pauseEvery < 1) return false;
    rdgAssistantState.run.interactionBatchCount = (parseInt(rdgAssistantState.run.interactionBatchCount || 0, 10) || 0) + 1;
    rdgAssistantState.run.updatedAt = Date.now();
    if (rdgAssistantState.run.interactionBatchCount >= pauseEvery) {
        rdgAssistantState.run.pendingInteractionCooldown = true;
        return true;
    }
    return false;
}

function rdgGetPicsToLikePerAccount() {
    if (rdgIsChainFunnelMode()) {
        var el = document.getElementById('numberChainPics');
        var cnt = el ? parseInt(el.value, 10) : 2;
        return (isFinite(cnt) && cnt >= 0) ? cnt : 2;
    }

    if (document.getElementById('radioLikeOnly') && document.getElementById('radioLikeOnly').checked === true) {
        var likeOnlyCountInput = document.querySelector('input[name="likeOnlyLatestPicsCount"]:checked');
        var likeOnlyCount = likeOnlyCountInput ? parseInt(likeOnlyCountInput.value, 10) : parseInt(gblOptions.numberLikeOnlyLatestPics || 1, 10);
        if (!isFinite(likeOnlyCount) || likeOnlyCount < 1) likeOnlyCount = 1;
        if (likeOnlyCount > 4) likeOnlyCount = 4;
        return likeOnlyCount;
    }

    if (rdgAssistantIsLiveInteractionMode() && document.getElementById('radioFollowAndLike') && document.getElementById('radioFollowAndLike').checked === true) {
        return rdgAssistantGetRandomLikesPerAccount();
    }

    var followLikeCount = parseInt(document.getElementById('numberFollowLikeLatestPics').value, 10);
    if (!isFinite(followLikeCount) || followLikeCount < 0) followLikeCount = 0;
    return followLikeCount;
}

function rdgResetLikeOnlyState() {
    rdgLikeOnlyMode = false;
    rdgLikeOnlyCurrentAccount = null;
    rdgLikeOnlyCurrentBatchTotal = 0;
    rdgLikeOnlyCurrentBatchDone = 0;
}

function rdgFinishLikeOnlyBatch() {
    var finishedAccount = rdgLikeOnlyCurrentAccount;
    var totalDone = rdgLikeOnlyCurrentBatchDone;
    var totalExpected = rdgLikeOnlyCurrentBatchTotal;

    rdgLikeOnlyCurrentAccount = null;
    rdgLikeOnlyCurrentBatchTotal = 0;
    rdgLikeOnlyCurrentBatchDone = 0;

    if (finishedAccount) {
        outputMessage('Conta concluida: ' + finishedAccount.username + ' | ' + totalDone + '/' + totalExpected + ' foto(s) curtidas');
    }

    if (acctsQueue.length === 0) {
        outputMessage('Concluido. Nenhuma conta restante para curtir.');
        $('#btnProcessQueue').removeClass('pulsing');
        alreadyLiking = false;
        rdgResetLikeOnlyState();
        return;
    }

    var nextUsername = acctsQueue[0] && acctsQueue[0].username ? acctsQueue[0].username : '';
    var waitTime = Math.max(3000, getRandomizedTime(gblOptions.timeDelay));
    outputMessage('Aguardando ' + (waitTime / 1000).toFixed(3) + ' segundos para processar ' + nextUsername);
    timeoutsQueue.push(setTimeout(ajaxLikeAll, waitTime));
}

function usersMediaLoaded(r) {

    var requestedPicsToLike = rdgGetPicsToLikePerAccount();
    var numPicsToLike = requestedPicsToLike;

    if (r.acct && r.edges) {

        if (numPicsToLike > r.edges.length) {
            numPicsToLike = r.edges.length;
        }

    } else {
        numPicsToLike = 0;
    }

    for (var i = 0; i < numPicsToLike; i++) {
        var pieceOfMedia = r.edges[i].node;
        pieceOfMedia.owner = r.acct;
        pieceOfMedia.rdgAssistantLikeIndex = i + 1;
        pieceOfMedia.rdgAssistantLikeTotal = numPicsToLike;
        mediaToLike.push(pieceOfMedia);
    }

    if (rdgIsChainFunnelMode() && r && r.acct) {
        window.rdgCurrentFunnelAccount = r.acct;
        if (numPicsToLike <= 0) {
            outputMessage('⚠️ Funil VIP: Sem fotos para curtir em @' + r.acct.username + '. Pulando para Direct...');
            var funnelAcctNoPhoto = window.rdgCurrentFunnelAccount;
            window.rdgCurrentFunnelAccount = null;
            rdgExecuteChainFunnelDM(funnelAcctNoPhoto, function() {
                if (rdgAssistantState && rdgAssistantState.run && rdgAssistantState.run.pendingNextFollow === true) {
                    rdgAssistantSchedulePendingNextFollow('funnel_no_photo');
                } else {
                    var waitTime = getRandomizedTime(gblOptions.timeDelay);
                    outputMessage('⏳ Funil VIP: Aguardando ' + (waitTime / 1000).toFixed(1) + 's para o próximo perfil...');
                    timeoutsQueue.push(setTimeout(ajaxFollowAll, waitTime));
                }
            });
            return;
        }
    }

    if (rdgLikeOnlyMode === true && r && r.acct) {
        rdgLikeOnlyCurrentAccount = r.acct;
        rdgLikeOnlyCurrentBatchTotal = numPicsToLike;
        rdgLikeOnlyCurrentBatchDone = 0;

        if (numPicsToLike <= 0) {
            outputMessage('Conta sem fotos para curtir: ' + r.acct.username);
            rdgFinishLikeOnlyBatch();
            return;
        }

        outputMessage('Iniciando curtidas de ' + r.acct.username + ': ' + numPicsToLike + ' foto(s)');
    } else if (rdgAssistantIsLiveInteractionMode() && r && r.acct) {
        var activeProfile = rdgAssistantGetProfileById(rdgAssistantState.run.activeProfileId);
        var preservedNextActionAt = rdgAssistantState && rdgAssistantState.run ? parseInt(rdgAssistantState.run.nextActionAt || 0, 10) || 0 : 0;
        var preservedNextActionLabel = rdgAssistantState && rdgAssistantState.run ? (rdgAssistantState.run.nextActionLabel || 'Proximo follow') : 'Proximo follow';
        if (activeProfile && activeProfile.assistant) {
            rdgAssistantSetProfileStatus(activeProfile, numPicsToLike > 0 ? ('Curtindo ' + numPicsToLike + ' foto(s) de @' + r.acct.username) : ('Sem fotos em @' + r.acct.username + '. Aguardando proxima conta.'));
            rdgAssistantSaveState();
            rdgAssistantRenderProfiles();
        }
        if (numPicsToLike > 0) {
            rdgAssistantSetLiveProgress('Curtidas preparadas para a conta atual.', r.acct.username, 0, '');
            outputMessage('Curtidas preparadas para @' + r.acct.username + ': ' + numPicsToLike + ' foto(s) na fila.');
        } else {
            rdgAssistantSetLiveProgress('Nenhuma foto disponivel. Aguardando a proxima pessoa.', r.acct.username, preservedNextActionAt, preservedNextActionLabel);
            var noPhotoMsg = 'Nenhuma foto disponivel para curtir em @' + r.acct.username + '.';
            if (preservedNextActionAt > Date.now()) {
                noPhotoMsg += ' ' + preservedNextActionLabel + ' em ' + ((preservedNextActionAt - Date.now()) / 1000).toFixed(3) + ' segundos.';
            } else {
                noPhotoMsg += ' Seguindo para o proximo.';
            }
            outputMessage(noPhotoMsg);
            // #region debug-point L:no-photo-branch
            rdgDebugReport('L', 'contentscript.js:usersMediaLoaded', 'assistant no-photo branch executed', {
                accountUsername: r && r.acct ? r.acct.username : null,
                preservedNextActionAt: preservedNextActionAt,
                preservedNextActionLabel: preservedNextActionLabel,
                now: Date.now(),
                remainingMs: preservedNextActionAt ? (preservedNextActionAt - Date.now()) : null,
                queueLength: acctsQueue.length,
                timeoutsQueueLength: Array.isArray(timeoutsQueue) ? timeoutsQueue.length : null,
                lastScheduledTimeout: (window.rdgLastScheduledTimeout || null)
            });
            // #endregion
        }
        // #region debug-point H:assistant-media-loaded
        rdgDebugReport('H', 'contentscript.js:usersMediaLoaded', 'assistant media loaded after follow', {
            accountUsername: r && r.acct ? r.acct.username : null,
            numPicsToLike: numPicsToLike,
            mediaQueueLength: mediaToLike.length,
            queueLength: acctsQueue.length,
            activeProfileId: rdgAssistantState && rdgAssistantState.run ? rdgAssistantState.run.activeProfileId : null,
            phase: rdgAssistantState && rdgAssistantState.run ? rdgAssistantState.run.phase : null,
            status: rdgAssistantState && rdgAssistantState.run ? rdgAssistantState.run.status : null
        });
        // #endregion
    }

    // #region debug-point B:queue-like-media
    rdgDebugReport('B', 'contentscript.js:usersMediaLoaded', 'media queued for like after follow', {
        accountUsername: r && r.acct ? r.acct.username : null,
        accountId: r && r.acct ? r.acct.id : null,
        requestedPicsToLike: requestedPicsToLike,
        queuedNow: numPicsToLike,
        mediaQueueLength: mediaToLike.length,
        firstMediaId: mediaToLike.length > 0 ? mediaToLike[0].id : null
    });
    // #endregion

    arrayOfMediaToDiv(mediaToLike, true);

    if (alreadyLiking == false) {
        likeAllMedia();
    }

}

function ajaxFollowUser(acct) {

    if (gblOptions.autoSaveQueue == true) {
        saveQueueToStorage();
    }


    var promises = [];
    let followable = true;

    if (!acct) {
        outputMessage('no account');
        return false;
    }

    if (acct && String(acct.id).indexOf('custom_') === 0) {
        outputMessage('🔍 Buscando ID numérico de @' + acct.username + ' antes da ação/Funil...');
        if (typeof window.betaResolveNumericIdByUsername === 'function') {
            window.betaResolveNumericIdByUsername(acct.username, function(numericId) {
                if (numericId) {
                    var oldId = acct.id;
                    acct.id = numericId;
                    outputMessage('✓ ID numérico resolvido para @' + acct.username + ': ' + numericId);
                    var elem = document.getElementById(oldId + '_container');
                    if (elem) elem.id = numericId + '_container';
                    ajaxFollowUser(acct);
                } else {
                    outputMessage('❌ Perfil @' + acct.username + ' não encontrado ou privado/inválido. Pulando...');
                    addStamp(acct.id, 'stamp-div-red', 'INVÁLIDO');
                    setTimeout(ajaxFollowAll, 1500);
                }
            });
        } else {
            outputMessage('❌ Resolutor de ID de usuário indisponível.');
            setTimeout(ajaxFollowAll, 1500);
        }
        return false;
    }

    var acctFromStorage = alreadyAttempted(acct);
    var waitTime = getRandomizedTime(gblOptions.timeDelayAfterSkip);
    var acctsQueueNextUsername = '';
    if (acctsQueue.length > 0) {
        acctsQueueNextUsername = acctsQueue[0].username;
    }

    if (gblOptions.followPeopleAlreadyAttempted === false && acctFromStorage !== false) {
        acctsProcessed.push(acct);
        if (rdgAssistantIsLiveInteractionMode()) {
            var activeProfileAttempted = rdgAssistantGetProfileById(rdgAssistantState.run.activeProfileId);
            if (activeProfileAttempted && activeProfileAttempted.assistant) {
                rdgAssistantMarkAudienceProcessed(activeProfileAttempted, acct, 'already_attempted_skip');
                rdgAssistantSetProfileStatus(activeProfileAttempted, 'Pulando @' + acct.username + ' porque ja havia historico anterior.');
                rdgAssistantSaveState();
                rdgAssistantRenderProfiles();
            }
        }
        outputMessage(acct.username + ' already attempted ' + timeToDate(acctFromStorage.followAttemptDate) + ': skipped; waiting  ' + (waitTime / 1000) + ' seconds to follow ' + acctsQueueNextUsername);
        addStamp(acct.id, 'stamp-div-grey', 'TENTADO');
        if (rdgAssistantIsFollowAndLikeMode()) rdgAssistantSetPendingNextFollow(Date.now() + waitTime, acctsQueueNextUsername, 'Proximo follow');
        rdgScheduleTimeout(ajaxFollowAll, waitTime, 'follow.skip.already_attempted', { nextUsername: acctsQueueNextUsername });
        return false;
    } else if (acct.followed_by_viewer == true) {
        acctsProcessed.push(acct);
        if (rdgAssistantIsLiveInteractionMode()) {
            var activeProfileFollowed = rdgAssistantGetProfileById(rdgAssistantState.run.activeProfileId);
            if (activeProfileFollowed && activeProfileFollowed.assistant) {
                rdgAssistantMarkAudienceProcessed(activeProfileFollowed, acct, 'already_followed_skip');
            }
        }
        outputMessage(acct.username + ' already being followed: skipped; waiting  ' + (waitTime / 1000) + ' seconds to follow ' + acctsQueueNextUsername);
        addStamp(acct.id, 'stamp-div-grey', 'SEGUIDO');
        if (rdgAssistantIsFollowAndLikeMode()) rdgAssistantSetPendingNextFollow(Date.now() + waitTime, acctsQueueNextUsername, 'Proximo follow');
        rdgScheduleTimeout(ajaxFollowAll, waitTime, 'follow.skip.already_followed', { nextUsername: acctsQueueNextUsername });
        return false;
    } else if (acct.requested_by_viewer == true) {
        acctsProcessed.push(acct);
        if (rdgAssistantIsLiveInteractionMode()) {
            var activeProfileRequested = rdgAssistantGetProfileById(rdgAssistantState.run.activeProfileId);
            if (activeProfileRequested && activeProfileRequested.assistant) {
                rdgAssistantMarkAudienceProcessed(activeProfileRequested, acct, 'already_requested_skip');
            }
        }
        outputMessage(acct.username + ' already requested: skipped; waiting  ' + (waitTime / 1000) + ' seconds to follow ' + acctsQueueNextUsername);
        addStamp(acct.id, 'stamp-div-grey', 'SOLICITADO');
        if (rdgAssistantIsFollowAndLikeMode()) rdgAssistantSetPendingNextFollow(Date.now() + waitTime, acctsQueueNextUsername, 'Proximo follow');
        rdgScheduleTimeout(ajaxFollowAll, waitTime, 'follow.skip.already_requested', { nextUsername: acctsQueueNextUsername });
        return false;
    } else if (acct.is_private == true && gblOptions.followPrivateAccounts != true) {
        acctsProcessed.push(acct);
        if (rdgAssistantIsLiveInteractionMode()) {
            var activeProfilePrivate = rdgAssistantGetProfileById(rdgAssistantState.run.activeProfileId);
            if (activeProfilePrivate && activeProfilePrivate.assistant) {
                rdgAssistantMarkAudienceProcessed(activeProfilePrivate, acct, 'private_skip');
            }
        }
        outputMessage(acct.username + ' is private: skipped; waiting  ' + (waitTime / 1000) + ' seconds to follow ' + acctsQueueNextUsername);
        addStamp(acct.id, 'stamp-div-grey', 'PRIVADO');
        if (rdgAssistantIsFollowAndLikeMode()) rdgAssistantSetPendingNextFollow(Date.now() + waitTime, acctsQueueNextUsername, 'Proximo follow');
        rdgScheduleTimeout(ajaxFollowAll, waitTime, 'follow.skip.private', { nextUsername: acctsQueueNextUsername });
        return false;
    } else if (gblOptions.filterOptions.applyFiltersAutomatically == true) {
        promises.push(filterCriteriaMet(acct).then((met) => {
            if (met == false) {
                followable = false;
            }
        }));
    }

    Promise.all(promises).then(function() {

        if (followable === false) {
            acctsProcessed.push(acct);
            if (rdgAssistantIsLiveInteractionMode()) {
                var activeProfileFiltered = rdgAssistantGetProfileById(rdgAssistantState.run.activeProfileId);
                if (activeProfileFiltered && activeProfileFiltered.assistant) {
                    rdgAssistantMarkAudienceProcessed(activeProfileFiltered, acct, 'filtered_skip');
                }
            }
            outputMessage(acct.username + ' did not match your filters: skipped; waiting  ' + (waitTime / 1000) + ' seconds to follow ' + acctsQueueNextUsername);

            if (acct.assumedDeleted) {
                addStamp(acct.id, 'stamp-div-red', '404');
            } else {
                addStamp(acct.id, 'stamp-div-grey', 'FILTRADO');
            }

            if (noAcctsLeft()) return false;
            printMessage(' ');
            if (rdgAssistantIsFollowAndLikeMode()) rdgAssistantSetPendingNextFollow(Date.now() + waitTime, acctsQueueNextUsername, 'Proximo follow');
            rdgScheduleTimeout(ajaxFollowAll, waitTime, 'follow.skip.filtered', { nextUsername: acctsQueueNextUsername });
            return false;
        }

        waitTime = getRandomizedTime(gblOptions.timeDelay);

        $.ajax({
                //url: 'https://www.instagram.com/web/friendships/' + acct.id + '/follow/',
                url: 'https://www.instagram.com/api/v1/friendships/create/' + acct.id + '/',
                method: 'POST',
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                    xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                    xhr.setRequestHeader('x-asbd-id', '129477');
                    xhr.setRequestHeader('x-ig-app-id', '936619743392459');
                },
                xhrFields: {
                    withCredentials: true
                }
            })
            .done(function() {

               acctsProcessed.push(acct);
actionsTaken++;
addStamp(acct.id, 'stamp-div-green', '<span style="font-weight: bold; color: black;">Seguido</span>');
rdgIncStat('interactions', 1);
rdgIncStat('newFollowers', 1);
addToAttempted(acct);
                if (rdgAssistantIsLiveInteractionMode()) {
                    var activeProfile = rdgAssistantGetProfileById(rdgAssistantState.run.activeProfileId);
                    var targetReached = false;
                    if (activeProfile && activeProfile.assistant) {
                        rdgAssistantMarkAudienceProcessed(activeProfile, acct, 'follow_ok');
                        rdgAssistantStopFurtherFollowsForCompletedProfile(activeProfile, acct);
                        targetReached = rdgAssistantHasReachedInteractionTarget(activeProfile);
                        if (!targetReached) {
                            rdgAssistantSetProfileStatus(activeProfile, 'Follow ok em @' + acct.username + '. Preparando curtidas desta conta.');
                        }
                        rdgAssistantSaveState();
                        rdgAssistantRenderProfiles();
                    }
                    if (targetReached) {
                        rdgAssistantSetLiveProgress('Meta atingida. Finalizando as curtidas pendentes da conta atual.', acct.username, 0, '');
                    } else {
                        rdgAssistantSetLiveProgress('Seguindo e preparando curtidas.', acct.username, Date.now() + waitTime, 'Proximo follow');
                    }
                }

                // #region debug-point C:follow-success
                rdgDebugReport('C', 'contentscript.js:ajaxFollowUser.done', 'follow succeeded', {
                    accountUsername: acct.username,
                    accountId: acct.id,
                    processedCount: acctsProcessed.length,
                    nextUsername: acctsQueueNextUsername,
                    waitTimeMs: waitTime,
                    followAndLike: document.getElementById('radioFollowAndLike').checked === true
                });
                // #endregion


                var shouldPauseBatch = rdgAssistantTrackSuccessfulInteraction();
                if (document.getElementById('radioFollowAndLike').checked == true) {
                    ajaxLoadUsersMedia('', false, usersMediaLoaded, acct);
                }

                if (rdgAssistantIsFollowAndLikeMode() && !(activeProfile && rdgAssistantHasReachedInteractionTarget(activeProfile))) {
                    rdgAssistantSetPendingNextFollow(Date.now() + waitTime, acctsQueueNextUsername, 'Proximo follow');
                }

                if (activeProfile && rdgAssistantHasReachedInteractionTarget(activeProfile)) {
                    outputMessage('FOLLOW ok: seguido ' + acct.username + ' (' + acct.id + ') | ' + acctsProcessed.length + ' processed; meta ' + rdgAssistantGetTargetPerProfile() + '/' + rdgAssistantGetTargetPerProfile() + ' atingida, finalizando curtidas da conta atual.');
                } else if (shouldPauseBatch) {
                    outputMessage('FOLLOW ok: seguido ' + acct.username + ' (' + acct.id + ') | ' + acctsProcessed.length + ' processed; pausa tecnica do assistente ao concluir este lote.');
                } else {
                    outputMessage('FOLLOW ok: seguido ' + acct.username + ' (' + acct.id + ') | ' + acctsProcessed.length + ' processed; proximo follow em ' + (waitTime / 1000) + ' segundos para ' + acctsQueueNextUsername);
                    if (!rdgAssistantIsFollowAndLikeMode() && !(activeProfile && rdgAssistantHasReachedInteractionTarget(activeProfile))) {
                        rdgScheduleTimeout(ajaxFollowAll, waitTime, 'follow.next', { nextUsername: acctsQueueNextUsername, processedCount: acctsProcessed.length });
                    }
                }

            })
            .fail(function(data) {
                // #region debug-point D:follow-fail
                rdgDebugReport('D', 'contentscript.js:ajaxFollowUser.fail', 'follow failed', {
                    accountUsername: acct.username,
                    accountId: acct.id,
                    status: data ? data.status : null,
                    statusText: data ? data.statusText : null,
                    responseMessage: data && data.responseJSON ? data.responseJSON.message : null,
                    feedbackTitle: data && data.responseJSON ? data.responseJSON.feedback_title : null,
                    feedbackMessage: data && data.responseJSON ? data.responseJSON.feedback_message : null
                });
                // #endregion
                if (data.status !== 404) {
                    acctsQueue.unshift(acct);
                }

                if (data.status == 404) {
                    printMessage(acct.username + ' ' + chrome.i18n.getMessage('AccountNotFound404'));
                    addStamp(acct.id, 'stamp-div-red', '404');
                    timeoutsQueue.push(setTimeout(ajaxFollowAll, 1000));
                } else if (data.status == 403) {
                    if (rdgAssistantHandleDelayedFollowRetry(gblOptions.timeDelayAfterSoftRateLimit, 'follow_rate_limit_soft', acct, chrome.i18n.getMessage('RateLimitSoft', [(gblOptions.timeDelayAfterSoftRateLimit / 60000)]))) return false;
                    printMessage(chrome.i18n.getMessage('RateLimitSoft', [(gblOptions.timeDelayAfterSoftRateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(ajaxFollowAll, gblOptions.timeDelayAfterSoftRateLimit));
                } else if (data.status == 400) {
                    if (data.responseJSON && data.responseJSON.message) {
                        if (data.responseJSON.feedback_title) {
                            outputMessage(data.responseJSON.feedback_title);
                        }

                        if (data.responseJSON.feedback_url) {
                            outputMessage(data.responseJSON.feedback_url);
                        }

                        if (data.responseJSON.feedback_message) {
                            if (data.responseJSON.feedback_message.indexOf('blocked') > -1) {
                                outputMessage('Mensagem do Instagram (*NÃO* do RDG instaPRO): ' + data.responseJSON.feedback_message);
                            }
                        }
                        // check if they are at the max
                        if (data.responseJSON.message.indexOf('max') > -1) {
                            if (rdgAssistantIsLiveInteractionMode()) {
                                (async function() {
                                    if (await rdgAssistantMaybeStartUnfollowForFollowingLimit(acct, data)) return;
                                    rdgAssistantHandleDelayedFollowRetry(gblOptions.timeDelayAfterHardRateLimit, 'follow_rate_limit_hard', acct, chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]));
                                })();
                                return false;
                            }
                            $('#btnProcessQueue').removeClass('pulsing');
                            alert(data.responseJSON.message);
                            alert('If you have reached the maximum number of following, please note that pending follow requests on private accounts are counted by instagram as following.  You can see your pending requests by clicking the Load Pending Follow Requests button.');
                            return false;
                        }
                    }

                    if (rdgAssistantHandleDelayedFollowRetry(gblOptions.timeDelayAfterHardRateLimit, 'follow_rate_limit_hard', acct, chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]))) return false;
                    printMessage(chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]));
                    showRateLimitPopup();
                    timeoutsQueue.push(setTimeout(ajaxFollowAll, gblOptions.timeDelayAfterHardRateLimit));
                } else if (data.status == 429) {
                    if (rdgAssistantHandleDelayedFollowRetry(gblOptions.timeDelayAfter429RateLimit, 'follow_rate_limit_429', acct, chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]))) return false;
                    printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(ajaxFollowAll, gblOptions.timeDelayAfter429RateLimit));
                } else {
                    if (rdgAssistantHandleDelayedFollowRetry(5000, 'follow_retry_generic', acct, 'FOLLOW error ' + data.status + ', trying again in 5 seconds')) return false;
                    outputMessage('FOLLOW error ' + data.status + ', trying again in 5 seconds');
                    timeoutsQueue.push(setTimeout(ajaxFollowAll, 5000));
                }
            });
    });
}


function ajaxLoadPostsFromHashtag(after) {

    if (typeof after != 'string') after = '';

    var hashtag = getHashtagFromUrl();

    if (hashtag == '') {
        outputMessage('Error - not on hashtag page');
        return false;
    }

    var count = 50;

    if (!isNaN(document.getElementById('txtLimitMediaQueueSize').value)) {
        count = document.getElementById('txtLimitMediaQueueSize').value;
    }


    document.getElementById('btnLikeHashtag').classList.add('pulsing');


    $.ajax({
            url: 'https://i.instagram.com/api/v1/tags/' + hashtag + '/sections/',
            data: after,
            method: 'POST',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        })
        .done(function(data) {

            if (data.more_available == true && (mediaToLike.length < parseInt(gblOptions.maxMediaQueueLength) || gblOptions.limitMediaQueue !== true)) {



                var medias = allNodes(data, 'media');
                for (var i = 0; i < medias.length; i++) {
                    mediaToLike.push(medias[i]);
                }

                mediaToLike = uniq(mediaToLike);

                printMessage('Loaded ' + mediaToLike.length + ' media out of ' + gblOptions.maxMediaQueueLength);

                outputMessage(mediaToLike.length + ' media out of ' + count + ' loaded to media queue')
                arrayOfMediaToDiv(mediaToLike, false);



                after = {
                    "max_id": data.next_max_id,
                    "page": data.next_page,
                    "next_media_ids": data.next_media_ids,
                    "tab": "recent",
                    "surface": "grid",
                    "include_persistent": 0
                }

                timeoutsQueue.push(setTimeout(function() {
                    ajaxLoadPostsFromHashtag(after);
                }, 500));

            } else {

                $('#btnLikeHashtag').removeClass('pulsing');

                arrayOfMediaToDiv(mediaToLike, true);
                printMessage(chrome.i18n.getMessage('Done'));

            }


        }).fail(function(f) {
            if (f.status == 429) {
                printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                timeoutsQueue.push(setTimeout(function() {
                    ajaxLoadPostsFromHashtag(after);
                }, gblOptions.timeDelayAfter429RateLimit));
            }
        });



}



function allNodes(obj, key, array) {
    array = array || [];
    if ('object' === typeof obj) {
        for (let k in obj) {
            if (k === key) {
                array.push(obj[k]);
            } else {
                allNodes(obj[k], key, array);
            }
        }
    }
    return array;
}

function uniq(arr) {


    const ids = arr.map(o => o.id)
    const filtered = arr.filter(({
        id
    }, index) => !ids.includes(id, index + 1))

    return filtered;

}


function getLocationFromUrl() {

    if (window.location.href.indexOf('/explore/locations/') == -1) {
        return '';
    }

    var tagFromUrl = window.location.href;
    tagFromUrl = tagFromUrl.replace('https://www.instagram.com/explore/locations/', '');
    tagFromUrl = tagFromUrl.slice(0, tagFromUrl.indexOf('/'));

    tagFromUrl = decodeURIComponent(tagFromUrl);

    return tagFromUrl;

}


function ajaxLoadPostsFromLocation(after) {

    var location = getLocationFromUrl();

    if (location == '') {
        outputMessage('Error - not on location page');
        return false;
    }

    $('#btnLoadLocationPosts').addClass('pulsing');


    if (!after.page) {
        printMessage('Loading media from location: ' + location);

        // the first request has a different URL and is a get request
        var url = 'https://www.instagram.com/api/v1/locations/web_info/?location_id=' + location + '&show_nearby=false';
        var method = 'GET';
        after = {};
    } else {
        var url = 'https://www.instagram.com/api/v1/locations/' + location + '/sections/';
        var method = 'POST';
    }

    $.ajax({
            url: url,
            data: after,
            method: method,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        })
        .done(function(data) {

            var medias = allNodes(data, 'media');
            for (var i = 0; i < medias.length; i++) {
                mediaToLike.push(medias[i]);
            }

            mediaToLike = uniq(mediaToLike);

            printMessage('Loaded ' + mediaToLike.length + ' media out of ' + gblOptions.maxMediaQueueLength);

            arrayOfMediaToDiv(mediaToLike, false);

            // for first api call
            if (data.native_location_data && data.native_location_data.recent) {
                data = data.native_location_data.recent;
            }

            if (data.more_available == true && (mediaToLike.length < parseInt(gblOptions.maxMediaQueueLength) || gblOptions.limitMediaQueue !== true)) {

                after = {
                    "max_id": JSON.stringify(data.next_max_id),
                    "page": data.next_page,
                    "next_media_ids": JSON.stringify(data.next_media_ids),
                    "tab": "recent",
                    "surface": "grid",
                }

                timeoutsQueue.push(setTimeout(function() {
                    ajaxLoadPostsFromLocation(after);
                }, 200));
            } else {
                $('#btnLoadLocationPosts').removeClass('pulsing');

                printMessage(chrome.i18n.getMessage('Done'));
                printMessage(' ');
            }


        }).fail(function(f) {
            if (f.status == 429) {
                printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                timeoutsQueue.push(setTimeout(function() {
                    ajaxLoadPostsFromLocation(after);
                }, gblOptions.timeDelayAfter429RateLimit));
            }
        });

}



function LoadAccountsFromMedia() {

    if (mediaToLike.length == 0) {
        outputMessage('Error - no media loaded, please load media on the media queue tab');
        return false;
    }

    $('#btnLoadMediaPosters').addClass('pulsing');

    if (gblOptions.MediaIncludeLikersCommentersTagged == true) {
        var owners = allNodes(mediaToLike, 'owner');
        for (var i = 0; i < owners.length; i++) {
            var u = owners[i];

            if (u && u.pk) u.id = u.pk;
            if (u != null) acctsQueue.push(u);
        }

        var users = allNodes(mediaToLike, 'user');
        for (var i = 0; i < users.length; i++) {
            var u = users[i];
            if (u && u.pk) u.id = u.pk;
            if (u != null) acctsQueue.push(u);
        }
    } else {
        for (var i = 0; i < mediaToLike.length; i++) {
            if (mediaToLike[i].owner) {
                var u = mediaToLike[i].owner;
                if (u && u.pk) u.id = u.pk;
                if (u != null) acctsQueue.push(u);
            }
        }
    }


    acctsQueue = uniq(acctsQueue);


    // truncateQueue(gblOptions.truncateStart);


    arrayOfUsersToDiv(acctsQueue, true);

    $('#btnLoadMediaPosters').removeClass('pulsing');

    printMessage(chrome.i18n.getMessage('Done'));
    printMessage(' ');
}

async function ajaxLikeAllPostsFromFeed(after) {

    if (typeof after != 'string') {
        after = '';
    } else {
        after = '%22after%22%3A%22' + after + '%22%2C';
    }

    var count = '??';
    if (gblOptions.limitMediaQueue == true && !isNaN(document.getElementById('txtLimitMediaQueueSize').value)) {
        count = document.getElementById('txtLimitMediaQueueSize').value;
    }

    document.getElementById('btnLikeFeed').classList.add('pulsing');

    const fetchMedia = await fetch("https://www.instagram.com/graphql/query", {
        "headers": {
            "accept": "*/*",
            "content-type": "application/x-www-form-urlencoded",
            "priority": "u=1, i",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "x-asbd-id": "129477",
            "x-csrftoken": getCsrfFromCookie(),
            "x-fb-friendly-name": "PolarisProfilePostsQuery",
            "x-ig-app-id": "936619743392459"
        },
        "referrer": "https://www.instagram.com/",
        "referrerPolicy": "strict-origin-when-cross-origin",
        "body": "av=17841400482242408&__d=www&__user=0&__a=1&__req=t&__hs=20154.HYP%3Ainstagram_web_pkg.2.1...1&dpr=1&__ccg=EXCELLENT&__rev=1020686322&__s=0fq4up%3Aqwk9fx%3Aztxdzb&__hsi=7479118361645267327&__dyn=7xeUjG1mxu1syUbFp41twpUnwgU7SbzEdF8aUco2qwJxS0DU2wx609vCwjE1EE2Cw8G11wBz81s8hwGxu786a3a1YwBgao6C0Mo2iyo7u3ifK0EUjwGzEaE2iwNwmE2eUlwhEe87q0oa2-azqwt8d-2u2J0bS1LwTwKG1pg2fwxyo6O1FwlEcUed6goK2O4Xxui2qi7E5y4UrwHwGwa6bBK4o&__csr=goMB1hb2tRfdQwxbpLTSRvmhQB8jpqhWHA-BmnJkhQhrGRzGcUD9yV9p9oShAQ9GmUytfhAvAijVifBpaJ5AyummmqFGWABBypaJ4pohy49yVfCG8leoFA8Ahp8Kt4BleEK8x2UhAgyim8haBXDAWUF1J28jz8jVH-2lxCE01cu9FA9w2vVlhEkdV4vIwqwhQ0mO1axlwxGE2c81DxS1Aw39U1iU1-U1EE1ie26eg16C0wXwyxqfQAu5O2K4soTp83gyU421BU4JCg4a48ybxa5abwcR0d6mU5m0icgay9UCpwB2msg3K05Gcw06si0D80kDw&__hsdp=&__hblp=&__comet_req=7&fb_dtsg=NAcODTLMt5kxM-9MlWOVJnE0CiZb6vhOikbp1xwiOVjWF9npxxboJ3g%3A17843683126168011%3A1741209447&jazoest=26370&lsd=kulaA_fnsLsmyiVZWRxfLZ&__spin_r=1020686322&__spin_b=trunk&__spin_t=1741367942&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=PolarisFeedRootPaginationCachedQuery_subscribe&variables=%7B" + after + "%22before%22%3Anull%2C%22data%22%3A%7B%22device_id%22%3A%22E1F25225-A6AE-44CF-9EC8-932EC7E261CB%22%2C%22is_async_ads_double_request%22%3A%220%22%2C%22is_async_ads_in_headload_enabled%22%3A%220%22%2C%22is_async_ads_rti%22%3A%220%22%2C%22rti_delivery_backend%22%3A%220%22%7D%2C%22first%22%3A12%2C%22last%22%3Anull%2C%22variant%22%3A%22home%22%2C%22__relay_internal__pv__PolarisIsLoggedInrelayprovider%22%3Atrue%2C%22__relay_internal__pv__PolarisShareSheetV3relayprovider%22%3Afalse%7D&server_timestamps=true&doc_id=28982951317985068",
        "method": "POST",
        "mode": "cors",
        "credentials": "include"
    });

    var jsonData = await fetchMedia.json();
    var r = jsonData.data.xdt_api__v1__feed__timeline__connection;

    if (r.edges) {
        for (var i = 0; i < r.edges.length; i++) {
            var mediaNode = r.edges[i].node.media;
            if (gblOptions.includeSuggestedPostsFromFeed == true || (mediaNode && mediaNode != null && mediaNode.owner && mediaNode.owner != null && mediaNode.owner.friendship_status && mediaNode.owner.friendship_status.following == true)) {
                if (mediaNode && mediaNode.id) mediaToLike.push(mediaNode);
            }
        }
        var hasNextPage = r.page_info.has_next_page;
        if (hasNextPage == true) {
            after = r.page_info.end_cursor;
        }
        arrayOfMediaToDiv(mediaToLike, false);
    } else {
        printMessage(' ');
        printMessage(' ');
        outputMessage('Erro ao curtir feed - por favor verifique sua conexão ou contate suporte@rdgsolucoes.com.br');
        printMessage(' ');
        printMessage(' ');
    }

    if ((hasNextPage == true && after != '') && (gblOptions.limitMediaQueue == false || mediaToLike.length < gblOptions.maxMediaQueueLength)) {
        outputMessage(mediaToLike.length + ' media out of ' + count + ' loaded to media queue.')
        timeoutsQueue.push(setTimeout(function() {
            ajaxLikeAllPostsFromFeed(after);
        }, 500));
    } else {
        document.getElementById('btnLikeFeed').classList.remove('pulsing');
        printMessage('Done.');
    }


}

async function watchReels() {

    var reels = mediaToLike.filter(e => e.media_type == 2 || e.is_video == true);

    for (var i = 0; i < reels.length; i++) {

        reels[i].SaveWhenWatchingReel = gblOptions.SaveWhenWatchingReel;
        reels[i].LikeWhenWatchingReel = gblOptions.LikeWhenWatchingReel;

        var done = await watchReel(reels[i]);

        addStamp(reels[i].id, 'stamp-div-green', 'ASSISTIDO');

        if (timeoutsQueue.length == 0) break;

    }

}

function watchReel(reel) {

    return new Promise(function(resolve, reject) {

        chrome.runtime.sendMessage({
            "openReelTab": reel
        });

        timeoutsQueue.push(
            setTimeout(function() {
                resolve(true);
            }, ((reel.video_duration || 20) * 1000) + 5)
        );

    });

}

function likeAllMedia() {
    if (!$('#btnLikeMediaQueue').hasClass('pulsing') && !$('#btnProcessQueue').hasClass('pulsing')) return false;
    var btnMedia = $('#btnLikeMediaQueue');
    if (!btnMedia.attr('data-original-text')) {
        btnMedia.attr('data-original-text', btnMedia.text());
    }
    btnMedia.addClass('pulsing').text('Curtindo Postagens...');

    alreadyLiking = true;
    if (gblOptions.showLikesInQueue === true) {
        handleImagePreload();
        handleMediaCheckBoxes(mediaToLike);
    }

    if (mediaToLike.length == 0) {
        // #region debug-point I:like-all-empty
        rdgDebugReport('I', 'contentscript.js:likeAllMedia', 'likeAllMedia reached with empty media queue', {
            queueLength: acctsQueue.length,
            mediaQueueLength: mediaToLike.length,
            alreadyLiking: alreadyLiking === true,
            assistantLiveMode: rdgAssistantIsLiveInteractionMode(),
            assistantPhase: rdgAssistantState && rdgAssistantState.run ? rdgAssistantState.run.phase : null,
            assistantStatus: rdgAssistantState && rdgAssistantState.run ? rdgAssistantState.run.status : null,
            pendingInteractionCooldown: rdgAssistantState && rdgAssistantState.run ? rdgAssistantState.run.pendingInteractionCooldown === true : false
        });
        // #endregion
        $('#btnLikeFeed,#btnLikeHashtag,#btnLikeMediaQueue').removeClass('pulsing');
        var btnMedia = $('#btnLikeMediaQueue');
        if (btnMedia.attr('data-original-text')) {
            btnMedia.text(btnMedia.attr('data-original-text'));
        }
        alreadyLiking = false;
        if (rdgIsChainFunnelMode() && window.rdgCurrentFunnelAccount) {
            var funnelAcctEmpty = window.rdgCurrentFunnelAccount;
            window.rdgCurrentFunnelAccount = null;
            rdgExecuteChainFunnelDM(funnelAcctEmpty, function() {
                if (rdgAssistantState && rdgAssistantState.run && rdgAssistantState.run.pendingNextFollow === true) {
                    rdgAssistantSchedulePendingNextFollow('funnel_dm_done_empty');
                } else if (!rdgAssistantIsLiveInteractionMode()) {
                    var waitTime = getRandomizedTime(gblOptions.timeDelay);
                    outputMessage('⏳ Funil VIP: Aguardando ' + (waitTime / 1000).toFixed(1) + 's para o próximo perfil...');
                    timeoutsQueue.push(setTimeout(ajaxFollowAll, waitTime));
                }
            });
            return false;
        }
        if (rdgAssistantIsLiveInteractionMode() && rdgAssistantState && rdgAssistantState.run) {
            var liveProfile = rdgAssistantGetProfileById(rdgAssistantState.run.activeProfileId);
            var queueExhausted = !Array.isArray(acctsQueue) || acctsQueue.length === 0;
            var profileReachedTarget = liveProfile ? rdgAssistantHasReachedInteractionTarget(liveProfile) : false;
            if (rdgAssistantState.run.pendingNextFollow !== true && (queueExhausted || profileReachedTarget)) {
                $('#btnProcessQueue').removeClass('pulsing');
                if (profileReachedTarget) {
                    if (rdgAssistantScheduleProfileTransitionDelay(liveProfile) === true) {
                        rdgAssistantSaveState();
                        rdgAssistantRender();
                        return false;
                    }
                    rdgAssistantSetLiveProgress('Conta atual finalizada. Avancando automaticamente para o proximo perfil.', '', 0, '');
                } else if (queueExhausted) {
                    rdgAssistantSetLiveProgress('Lista atual terminou. Preparando a continuidade automatica do assistente.', '', 0, '');
                }
            }
        }
        if (rdgLikeOnlyMode === true && rdgLikeOnlyCurrentAccount) {
            rdgFinishLikeOnlyBatch();
        } else if (rdgAssistantEnterInteractionCooldown() === true) {
            return false;
        } else if (rdgAssistantIsFollowAndLikeMode() && rdgAssistantState && rdgAssistantState.run && rdgAssistantState.run.pendingNextFollow === true) {
            rdgAssistantSchedulePendingNextFollow('likes_empty_queue');
        }
        return false;
    }

    var media = mediaToLike.shift();
    var id = media.id;

    for (var i = 0; i < previousLikes.length; i++) {
        if (id == previousLikes[i]) {
            outputMessage('Already liked, moving on...');
            addStamp(media.id, 'stamp-div-grey', 'PULADO');

            timeoutsQueue.push(setTimeout(likeAllMedia, 1));
            return false;
        }
    }

    likeMedia(media);
}

function likeMedia(media) {

    var idToLike = media.id;

    if (media.pk) idToLike = media.pk;

    function rdgGetCookieValue(name) {
        try {
            var escapedName = String(name).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            var match = document.cookie.match(new RegExp('(?:^|;\\s*)' + escapedName + '=([^;]+)'));
            return match ? decodeURIComponent(match[1]) : '';
        } catch (e) {
            return '';
        }
    }

    function rdgGetLoggedInUserId() {
        var fromCookie = rdgGetCookieValue('ds_user_id');
        if (fromCookie) return fromCookie;
        if (typeof currentProfilePage !== 'undefined' && currentProfilePage) {
            if (currentProfilePage.id) return String(currentProfilePage.id);
            if (currentProfilePage.pk) return String(currentProfilePage.pk);
        }
        return '';
    }

    function rdgExtractTokenFromDom(tokenName) {
        try {
            var el = document.querySelector('input[name="' + tokenName + '"]');
            if (el && el.value) return String(el.value);
        } catch (e) {}
        try {
            var html = document.documentElement ? document.documentElement.innerHTML : '';
            if (!html) return '';

            if (tokenName === 'lsd') {
                var m1 = html.match(/"LSD"\s*,\s*\[\]\s*,\s*\{\s*"token"\s*:\s*"([^"]+)"/);
                if (m1 && m1[1]) return m1[1];
                var m2 = html.match(/"lsd"\s*:\s*"([^"]+)"/);
                if (m2 && m2[1]) return m2[1];
            }

            if (tokenName === 'fb_dtsg') {
                var d1 = html.match(/"DTSGInitialData"\s*,\s*\[\]\s*,\s*\{\s*"token"\s*:\s*"([^"]+)"/);
                if (d1 && d1[1]) return d1[1];
                var d2 = html.match(/"fb_dtsg"\s*:\s*\{\s*"token"\s*:\s*"([^"]+)"/);
                if (d2 && d2[1]) return d2[1];
                var d3 = html.match(/"fb_dtsg"\s*:\s*"([^"]+)"/);
                if (d3 && d3[1]) return d3[1];
            }
        } catch (e) {}
        return '';
    }

    function rdgComputeJazoest(fbDtsg) {
        if (!fbDtsg) return '';
        var sum = 0;
        for (var i = 0; i < fbDtsg.length; i++) sum += fbDtsg.charCodeAt(i);
        return '2' + String(sum);
    }

    function likeDone() {
            previousLikes.push(media.id);

            savePreviousLikesToStorage();

            var likeUsername = (media.owner && media.owner.username) || (media.user && media.user.username) || 'conta';
            var likeStep = parseInt(media.rdgAssistantLikeIndex || 0, 10) || 0;
            var likeTotal = parseInt(media.rdgAssistantLikeTotal || 0, 10) || 0;

            if (rdgLikeOnlyMode === true) {
                rdgLikeOnlyCurrentBatchDone++;
                var batchUsername = (rdgLikeOnlyCurrentAccount && rdgLikeOnlyCurrentAccount.username) || (media.owner && media.owner.username) || (media.user && media.user.username) || 'conta';
                outputMessage('Curtida ' + rdgLikeOnlyCurrentBatchDone + '/' + rdgLikeOnlyCurrentBatchTotal + ' para ' + batchUsername);
            } else if (rdgAssistantIsLiveInteractionMode() && likeStep > 0 && likeTotal > 0) {
                var activeProfile = rdgAssistantGetProfileById(rdgAssistantState.run.activeProfileId);
                if (activeProfile && activeProfile.assistant) {
                    activeProfile.assistant.currentRunLikes = (parseInt(activeProfile.assistant.currentRunLikes || 0, 10) || 0) + 1;
                    rdgAssistantSetProfileStatus(activeProfile, 'Curtindo foto ' + likeStep + '/' + likeTotal + ' de @' + likeUsername);
                    rdgAssistantSaveState();
                    rdgAssistantRenderProfiles();
                }
                rdgAssistantSetLiveProgress('Curtindo foto ' + likeStep + '/' + likeTotal + '.', likeUsername, 0, '');
                outputMessage('Curtindo foto ' + likeStep + '/' + likeTotal + ' de @' + likeUsername + ': ok');
            } else if (media.user && media.user.username) {
                outputMessage('Liked post for ' + media.user.username);
            } else {
                outputMessage('Liked post')
            }

            addStamp(media.id, 'stamp-div-green', 'CURTIDO');
            rdgIncStat('interactions', 1);


            var waitTime = getRandomizedTime(gblOptions.timeDelay);
            if (rdgLikeOnlyMode === true) {
                waitTime = Math.max(3000, waitTime);
            }

            if (mediaToLike.length > 0) {
                if (rdgLikeOnlyMode === true) {
                    outputMessage('Aguardando ' + (waitTime / 1000).toFixed(3) + ' segundos para a proxima foto de ' + ((rdgLikeOnlyCurrentAccount && rdgLikeOnlyCurrentAccount.username) || 'conta'));
                } else if (rdgAssistantIsLiveInteractionMode()) {
                    rdgAssistantSetLiveProgress('Aguardando a proxima curtida.', likeUsername, Date.now() + waitTime, 'Proxima curtida');
                    outputMessage('Proxima curtida em ' + (waitTime / 1000).toFixed(3) + ' segundos para @' + likeUsername);
                } else {
                    outputMessage('waiting  ' + (waitTime / 1000) + ' seconds to Like next');
                }
                timeoutsQueue.push(setTimeout(likeAllMedia, waitTime));
                alreadyLiking = true;
            } else {
                alreadyLiking = false;
                if (rdgIsChainFunnelMode() && window.rdgCurrentFunnelAccount) {
                    var funnelAcctLast = window.rdgCurrentFunnelAccount;
                    window.rdgCurrentFunnelAccount = null;
                    rdgExecuteChainFunnelDM(funnelAcctLast, function() {
                        if (rdgAssistantState && rdgAssistantState.run && rdgAssistantState.run.pendingNextFollow === true) {
                            rdgAssistantSchedulePendingNextFollow('funnel_dm_done_last');
                        } else if (!rdgAssistantIsLiveInteractionMode()) {
                            var waitTime = getRandomizedTime(gblOptions.timeDelay);
                            outputMessage('⏳ Funil VIP: Aguardando ' + (waitTime / 1000).toFixed(1) + 's para o próximo perfil...');
                            timeoutsQueue.push(setTimeout(ajaxFollowAll, waitTime));
                        }
                    });
                    return false;
                }
                if (rdgLikeOnlyMode === true && rdgLikeOnlyCurrentAccount) {
                    rdgFinishLikeOnlyBatch();
                } else if (rdgAssistantIsLiveInteractionMode()) {
                    var currentProfile = rdgAssistantGetProfileById(rdgAssistantState.run.activeProfileId);
                    var currentProfileReachedTarget = currentProfile ? rdgAssistantHasReachedInteractionTarget(currentProfile) : false;
                    var finishedCurrentProfile = !!(currentProfile && currentProfileReachedTarget === true && (!Array.isArray(acctsQueue) || acctsQueue.length === 0) && (!Array.isArray(mediaToLike) || mediaToLike.length === 0) && !(rdgAssistantState && rdgAssistantState.run && rdgAssistantState.run.pendingNextFollow === true));
                    if (currentProfile && currentProfile.assistant) {
                        rdgAssistantSetProfileStatus(currentProfile, finishedCurrentProfile ? ('Curtidas concluidas para @' + likeUsername + '. Fechando perfil atual.') : ('Curtidas concluidas para @' + likeUsername + '. Aguardando proxima conta.'));
                        rdgAssistantSaveState();
                        rdgAssistantRenderProfiles();
                    }
                    var nextAcctUsername = acctsQueue.length > 0 && acctsQueue[0] && acctsQueue[0].username ? acctsQueue[0].username : '';
                    if (finishedCurrentProfile) {
                        rdgAssistantSetLiveProgress('Curtidas concluidas no perfil atual. Finalizando a etapa automaticamente.', currentProfile && currentProfile.username ? currentProfile.username : likeUsername, 0, '');
                    } else {
                        rdgAssistantSetLiveProgress('Curtidas concluidas para a conta atual.', likeUsername, 0, '');
                    }
                    if (nextAcctUsername && !finishedCurrentProfile) {
                        rdgAssistantSetLiveProgress('Curtidas concluidas. Preparando proxima pessoa.', nextAcctUsername, 0, '');
                    }
                    outputMessage('Curtidas concluidas para @' + likeUsername + '. ' + (finishedCurrentProfile ? 'Finalizando o perfil atual e seguindo automaticamente.' : 'Seguindo para a proxima pessoa.'));
                    if (finishedCurrentProfile && currentProfile) {
                        rdgAssistantFinishInteraction(currentProfile);
                        rdgAssistantClearInteractionQueues();
                        if (rdgAssistantScheduleProfileTransitionDelay(currentProfile) === true) {
                            rdgAssistantSaveState();
                            rdgAssistantRender();
                            return false;
                        }
                        rdgAssistantState.run.phase = 'collecting';
                        rdgAssistantState.run.activeProfileId = '';
                        rdgAssistantState.run.pendingInteractionCooldown = false;
                        rdgAssistantState.run.updatedAt = Date.now();
                        rdgAssistantLog('Perfil @' + currentProfile.username + ' finalizou nesta ultima interacao. O assistente vai verificar automaticamente a proxima etapa sem travar.', 'collecting', true);
                        rdgScheduleTimeout(function() {
                            if (rdgAssistantState && rdgAssistantState.run && rdgAssistantState.run.status === 'running') {
                                rdgAssistantTick();
                            }
                        }, 80, 'assistant.final_profile.after_last_like', { profileId: currentProfile.id || '', username: currentProfile.username || '' });
                        rdgAssistantSaveState();
                        rdgAssistantRender();
                        return false;
                    }
                    if (rdgAssistantEnterInteractionCooldown() !== true) {
                        if (rdgAssistantState && rdgAssistantState.run && rdgAssistantState.run.pendingNextFollow === true) {
                            rdgAssistantSchedulePendingNextFollow('likes_finished');
                        } else {
                            if (rdgAssistantState && rdgAssistantState.run && currentProfileReachedTarget === true && (!Array.isArray(acctsQueue) || acctsQueue.length === 0)) {
                                if (rdgAssistantScheduleProfileTransitionDelay(currentProfile) === true) {
                                    rdgAssistantSaveState();
                                    rdgAssistantRender();
                                    return false;
                                }
                            }
                            rdgAssistantResumeQueuedWorkIfNeeded();
                        }
                    }
                } else if (rdgAssistantEnterInteractionCooldown() !== true) {
                    rdgAssistantResumeQueuedWorkIfNeeded();
                }
            }

    }

    function likeFail(data) {
            mediaToLike.unshift(media);
            if (data.status == 403) {
                printMessage(chrome.i18n.getMessage('RateLimitSoft', [(gblOptions.timeDelayAfterSoftRateLimit / 60000)]));
                timeoutsQueue.push(setTimeout(likeAllMedia, gblOptions.timeDelayAfterSoftRateLimit));
            } else if (data.status == 400) {
                printMessage(chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]));
                showRateLimitPopup();
                timeoutsQueue.push(setTimeout(likeAllMedia, gblOptions.timeDelayAfterHardRateLimit));
            } else if (data.status == 429) {
                printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                timeoutsQueue.push(setTimeout(likeAllMedia, gblOptions.timeDelayAfter429RateLimit));
            } else {
                outputMessage(data.status + ' error, trying again in 5 seconds');
                timeoutsQueue.push(setTimeout(likeAllMedia, 5000));
            }
    }

    function rdgTryGraphqlLike() {
        var actorId = rdgGetLoggedInUserId();
        var fbDtsg = rdgExtractTokenFromDom('fb_dtsg');
        var lsd = rdgExtractTokenFromDom('lsd');

        if (!actorId || !fbDtsg || !lsd) {
            outputMessage('LIKE fallback: tokens GraphQL indisponiveis, usando endpoint antigo');
            return false;
        }

        window.rdgLikeMutationId = (window.rdgLikeMutationId || 0) + 1;
        var clientMutationId = String(window.rdgLikeMutationId);

        var variablesObj = {
            input: {
                media_id: String(idToLike),
                actor_id: String(actorId),
                client_mutation_id: clientMutationId
            }
        };

        $.ajax({
                url: 'https://www.instagram.com/api/graphql',
                method: 'POST',
                data: {
                    av: String(actorId),
                    __d: 'www',
                    __user: '0',
                    __a: '1',
                    __req: clientMutationId,
                    dpr: '1',
                    __ccg: 'EXCELLENT',
                    __comet_req: '7',
                    fb_dtsg: fbDtsg,
                    jazoest: rdgComputeJazoest(fbDtsg),
                    lsd: lsd,
                    fb_api_caller_class: 'RelayModern',
                    fb_api_req_friendly_name: 'PolarisAPILikePostMutation',
                    server_timestamps: 'true',
                    variables: JSON.stringify(variablesObj),
                    doc_id: '27232073366423857'
                },
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                    xhr.setRequestHeader('x-asbd-id', '359341');
                    xhr.setRequestHeader('x-ig-app-id', '936619743392459');
                    xhr.setRequestHeader('x-fb-friendly-name', 'PolarisAPILikePostMutation');
                    xhr.setRequestHeader('x-fb-lsd', lsd);
                },
                xhrFields: {
                    withCredentials: true
                }
            })
            .done(function(resp) {
                try {
                    if (typeof resp === 'string') {
                        var lower = resp.toLowerCase();
                        if (lower.indexOf('login') > -1 || lower.indexOf('accounts/login') > -1) {
                            likeFail({ status: 401, statusText: 'login_required' });
                            return;
                        }
                    }
                    if (resp && typeof resp === 'object') {
                        if (resp.errors && resp.errors.length) {
                            likeFail({ status: 500, statusText: 'graphql_errors' });
                            return;
                        }
                        if (resp.data == null) {
                            likeFail({ status: 500, statusText: 'graphql_no_data' });
                            return;
                        }
                    }
                } catch (e) {}

                likeDone();
            })
            .fail(function(err) {
                outputMessage('LIKE GraphQL falhou (' + (err && err.status ? err.status : 'sem status') + '), tentando fallback antigo');
                $.ajax({
                        url: 'https://www.instagram.com/web/likes/' + idToLike + '/like/',
                        method: 'POST',
                        beforeSend: function(xhr) {
                            xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                            xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                            xhr.setRequestHeader('x-asbd-id', '129477');
                            xhr.setRequestHeader('x-ig-app-id', '936619743392459');
                        },
                        xhrFields: {
                            withCredentials: true
                        }
                    })
                    .done(likeDone)
                    .fail(likeFail);
            });

        return true;
    }

    if (rdgTryGraphqlLike() === true) {
        return;
    }

    $.ajax({
            url: 'https://www.instagram.com/web/likes/' + idToLike + '/like/',
            method: 'POST',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        })
        .done(likeDone)
        .fail(likeFail);
}

async function populateAllQueueUsersInfo(q) {
    function rdgPad2(n) {
        return String(n).padStart(2, '0');
    }

    function rdgFormatDurationMs(ms) {
        if (!isFinite(ms) || ms < 0) ms = 0;
        var totalSeconds = Math.round(ms / 1000);
        var minutes = Math.floor(totalSeconds / 60);
        var seconds = totalSeconds % 60;
        if (minutes <= 0) return seconds + ' segundos';
        return minutes + ' minutos e ' + rdgPad2(seconds) + ' segundos';
    }

    function rdgNormalizeEmail(email) {
        if (!email) return '';
        return String(email).trim().toLowerCase();
    }

    function rdgNormalizePhone(phone) {
        if (!phone) return '';
        var str = String(phone).trim();
        var hasPlus = str.startsWith('+');
        var digits = str.replace(/[^\d]/g, '');
        if (!digits) return '';
        return (hasPlus ? '+' : '') + digits;
    }

    function rdgCsvEscape(value) {
        var s = value == null ? '' : String(value);
        if (/[",\n\r]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
        return s;
    }

    function rdgDownloadTextFile(filename, text, mimeType) {
        try {
            var blob = new Blob([text], { type: mimeType || 'text/plain;charset=utf-8' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(function() {
                try { URL.revokeObjectURL(url); } catch (e) {}
            }, 1000);
        } catch (e) {}
    }

    function rdgExtractContacts(queue) {
        var emailsSet = new Set();
        var phonesSet = new Set();
        var rows = [];

        for (var i = 0; i < queue.length; i++) {
            var a = queue[i] || {};
            var email = rdgNormalizeEmail(a.public_email || a.email);
            var phone = rdgNormalizePhone(a.contact_phone_number || a.public_phone_number || a.whatsapp_number || a.phone);

            if (email) emailsSet.add(email);
            if (phone) phonesSet.add(phone);

            if (email || phone) {
                rows.push({ email: email, phone: phone });
            }
        }

        return {
            emails: Array.from(emailsSet),
            phones: Array.from(phonesSet),
            rows: rows
        };
    }

    function rdgBuildCsvSingleColumn(header, values) {
        var out = [header];
        for (var i = 0; i < values.length; i++) {
            out.push(rdgCsvEscape(values[i]));
        }
        return out.join('\n');
    }

    function rdgBuildCsvEmailPhone(rows) {
        var out = ['email,phone'];
        for (var i = 0; i < rows.length; i++) {
            out.push(rdgCsvEscape(rows[i].email || '') + ',' + rdgCsvEscape(rows[i].phone || ''));
        }
        return out.join('\n');
    }

    function rdgEnsureProgressPopup() {
        var existing = document.getElementById('rdg-extendeddata-progress-popup');
        if (existing) existing.remove();

        var overlay = document.createElement('div');
        overlay.id = 'rdg-extendeddata-progress-popup';
        overlay.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.7); z-index:999999; display:flex; justify-content:center; align-items:center; padding:20px;';

        var content = document.createElement('div');
        content.style.cssText = 'background:#121212; border:1px solid rgba(255,255,255,0.12); border-radius:14px; padding:18px 18px 14px 18px; width:100%; max-width:520px; box-shadow:0 25px 50px rgba(0,0,0,0.6);';

        var title = document.createElement('div');
        title.style.cssText = 'color:#fff; font-size:18px; font-weight:700; margin-bottom:10px;';
        title.innerText = 'Carregando dados estendidos';

        var msg = document.createElement('div');
        msg.style.cssText = 'color:#cbd5e1; font-size:14px; line-height:1.5; margin-bottom:10px;';

        var barWrap = document.createElement('div');
        barWrap.style.cssText = 'width:100%; height:10px; border-radius:999px; background:rgba(255,255,255,0.12); overflow:hidden; margin-bottom:10px;';
        var bar = document.createElement('div');
        bar.style.cssText = 'height:100%; width:0%; background:linear-gradient(90deg,#22c55e,#3b82f6); border-radius:999px;';
        barWrap.appendChild(bar);

        var log = document.createElement('div');
        log.style.cssText = 'color:#ffcc00; font-size:13px; margin-top:6px; font-family:monospace; background:rgba(0,0,0,0.3); padding:6px 10px; border-radius:8px; border:1px solid rgba(255,255,255,0.08); width:100%; box-sizing:border-box; text-align:left; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;';
        log.innerText = 'Iniciando...';

        var actions = document.createElement('div');
        actions.style.cssText = 'margin-top:12px; display:flex; gap:10px; justify-content:flex-end; flex-wrap:wrap;';

        content.appendChild(title);
        content.appendChild(msg);
        content.appendChild(barWrap);
        content.appendChild(log);
        content.appendChild(actions);
        overlay.appendChild(content);
        document.body.appendChild(overlay);

        return { overlay: overlay, title: title, msg: msg, bar: bar, log: log, actions: actions };
    }

    var popup = rdgEnsureProgressPopup();
    var total = q.length;
    var processed = 0;
    var startTime = Date.now();
    var activeUsername = '';

    function updatePopup() {
        var pct = total > 0 ? Math.round((processed / total) * 100) : 0;
        popup.bar.style.width = pct + '%';

        var elapsed = Date.now() - startTime;
        var avg = processed > 0 ? (elapsed / processed) : (gblOptions && gblOptions.timeDelayAfterAdditionalInfo ? gblOptions.timeDelayAfterAdditionalInfo : 7000);
        var remaining = Math.max(0, (total - processed) * avg);

        popup.msg.innerHTML = 'Progresso: <b style="color:#fff;">' + processed + '</b> de <b style="color:#fff;">' + total + '</b><br>Tempo estimado: <b style="color:#fff;">' + rdgFormatDurationMs(remaining) + '</b>';
        popup.log.innerText = activeUsername ? ('Processando: ' + activeUsername) : 'Processando...';
    }

    updatePopup();
    var progressTimer = setInterval(updatePopup, 1000);

    for (var i = 0; i < q.length; i++) {
        activeUsername = (q[i] && q[i].username) ? q[i].username : 'Usuário';
        updatePopup();

        q[i] = await getAdditionalDataForAcct(q[i]);
        processed = i + 1;
        updatePopup();

        var $$tr = $('#cb_' + q[i].id).parents('tr[role="row"]');

        for (const [key, value] of Object.entries(q[i])) {
            var cols = gbDefaultColumns;
            cols = cols.filter(c => c.data == key);

            var $$td = $$tr.children('td[column-data="' + key + '"]');
            if ($$td.html() == '' || $$td.text() == '-' || $$td.attr('column-data') == 'external_url') {
                $$td.text(value);
                if (cols[0] && cols[0].formatter && typeof value != 'undefined' && value != null) {
                    $$td.html(cols[0].formatter.replace(/\${ig_id}/g, q[i].id).replace(/\${cell}/g, value));
                }
            }
        }

        printMessage(chrome.i18n.getMessage('DataLoaded', [(i + 1), q.length]));
    }

    clearInterval(progressTimer);

    acctsQueue = q;
    arrayOfUsersToDiv(acctsQueue, true);

    function renderSummary() {
        var deletedCount = acctsQueue.filter(function(e) { return e && e.assumedDeleted; }).length;
        var contacts = rdgExtractContacts(acctsQueue.filter(function(e) { return e && !e.assumedDeleted; }));
        var hasAny = contacts.emails.length > 0 || contacts.phones.length > 0;

        popup.title.innerText = 'Dados estendidos carregados';
        popup.bar.style.width = '100%';

        popup.msg.innerHTML =
            'Resumo:<br>' +
            '- Contas processadas: <b style="color:#fff;">' + acctsQueue.length + '</b><br>' +
            '- Contas não encontradas (404): <b style="color:#fff;">' + deletedCount + '</b><br>' +
            '- Telefones encontrados: <b style="color:#fff;">' + contacts.phones.length + '</b><br>' +
            '- Emails encontrados: <b style="color:#fff;">' + contacts.emails.length + '</b>';

        popup.log.innerText = 'Pronto para salvar ou exportar.';
        popup.actions.innerHTML = '';

        if (deletedCount > 0) {
            var btnRemove404 = document.createElement('button');
            btnRemove404.type = 'button';
            btnRemove404.innerText = 'Remover contas 404';
            btnRemove404.style.cssText = 'padding:10px 12px; border-radius:10px; border:1px solid rgba(255,255,255,0.18); background:rgba(255,255,255,0.06); color:#fff; cursor:pointer;';
            btnRemove404.onclick = function() {
                acctsQueue = acctsQueue.filter(function(e) { return e && !e.assumedDeleted; });
                arrayOfUsersToDiv(acctsQueue, true);
                renderSummary();
            };
            popup.actions.appendChild(btnRemove404);
        }

        var btnPhones = document.createElement('button');
        btnPhones.type = 'button';
        btnPhones.innerText = 'Baixar telefones (CSV)';
        btnPhones.style.cssText = 'padding:10px 12px; border-radius:10px; border:1px solid rgba(34,197,94,0.45); background:rgba(34,197,94,0.12); color:#d1fae5; cursor:pointer;';
        btnPhones.disabled = contacts.phones.length === 0;
        btnPhones.onclick = function() {
            var csv = rdgBuildCsvSingleColumn('phone', contacts.phones);
            rdgDownloadTextFile('rdg-telefones.csv', csv, 'text/csv;charset=utf-8');
        };
        popup.actions.appendChild(btnPhones);

        var btnEmails = document.createElement('button');
        btnEmails.type = 'button';
        btnEmails.innerText = 'Baixar emails (CSV)';
        btnEmails.style.cssText = 'padding:10px 12px; border-radius:10px; border:1px solid rgba(59,130,246,0.45); background:rgba(59,130,246,0.12); color:#dbeafe; cursor:pointer;';
        btnEmails.disabled = contacts.emails.length === 0;
        btnEmails.onclick = function() {
            var csv = rdgBuildCsvSingleColumn('email', contacts.emails);
            rdgDownloadTextFile('rdg-emails.csv', csv, 'text/csv;charset=utf-8');
        };
        popup.actions.appendChild(btnEmails);

        var btnAll = document.createElement('button');
        btnAll.type = 'button';
        btnAll.innerText = 'Baixar tudo (CSV)';
        btnAll.style.cssText = 'padding:10px 12px; border-radius:10px; border:1px solid rgba(255,255,255,0.18); background:rgba(255,255,255,0.08); color:#fff; cursor:pointer;';
        btnAll.disabled = !hasAny;
        btnAll.onclick = function() {
            var csv = rdgBuildCsvEmailPhone(contacts.rows);
            rdgDownloadTextFile('rdg-emails-telefones.csv', csv, 'text/csv;charset=utf-8');
        };
        popup.actions.appendChild(btnAll);

        var btnSave = document.createElement('button');
        btnSave.type = 'button';
        btnSave.innerText = 'Salvar fila agora';
        btnSave.style.cssText = 'padding:10px 12px; border-radius:10px; border:1px solid rgba(255,204,0,0.5); background:rgba(255,204,0,0.12); color:#fff; cursor:pointer;';
        btnSave.onclick = function() {
            saveQueueToStorageAndDisk();
            try { popup.overlay.remove(); } catch (e) {}
        };
        popup.actions.appendChild(btnSave);

        var btnClose = document.createElement('button');
        btnClose.type = 'button';
        btnClose.innerText = 'Fechar';
        btnClose.style.cssText = 'padding:10px 12px; border-radius:10px; border:1px solid rgba(255,255,255,0.18); background:transparent; color:#fff; cursor:pointer;';
        btnClose.onclick = function() {
            try { popup.overlay.remove(); } catch (e) {}
        };
        popup.actions.appendChild(btnClose);
    }

    renderSummary();

    $('#btnProcessQueue').removeClass('pulsing');
}

function maxActionsExceeded() {
    if (gblOptions.maxPerEnabled == true && (actionsTaken >= gblOptions.maxPerActions)) {
        var todaysdate = new Date();
        maxActionsDelayStartTime = todaysdate.getTime();

        return true;
    }
    return false;
}

function maxActionsDelayRemaining() {
    var todaysdate = new Date();
    var today = todaysdate.getTime();
    var timeSinceActionsMaxed;
    timeSinceActionsMaxed = today - maxActionsDelayStartTime;

    return (gblOptions.maxPerPeriod - timeSinceActionsMaxed);
}

function checkMaxActionsAndDelayIfNecessary(callback) {
    if (maxActionsExceeded() && maxActionsDelayRemaining() > 0) {
        timeoutsQueue.push(setTimeout(callback, maxActionsDelayRemaining()));
        outputMessage('Max actions exceeded, waiting ' + millisecondsToHumanReadable(maxActionsDelayRemaining(), true))

        actionsTaken = 0;

        return true;
    }

    return false;
}


function ajaxRemoveOrBlockAll() {
    if (!$('#btnProcessQueue').hasClass('pulsing')) return false;
    if (checkMaxActionsAndDelayIfNecessary(ajaxRemoveOrBlockAll) == false) {
        ajaxRemoveOrBlockAcct(acctsQueue.pop());
    }
}


function viewStories() {
    if (checkMaxActionsAndDelayIfNecessary(viewStories) == false) {
        viewStory(acctsQueue.pop());
    }
}

async function viewStory(acct) {

    acct = await getAdditionalDataForAcct(acct);

    if (acct.is_private === true && acct.followed_by_viewer === false) {
        addStamp(acct.id, 'stamp-div-grey', 'PRIVADO');
        outputMessage('Skipping ' + acct.username + ' because it is a private account');
        timeoutsQueue.push(setTimeout(viewStories, gblOptions.timeDelayAfterSkip));
        return false;
    }

    if (acct.assumedDeleted == true) {
        addStamp(acct.id, 'stamp-div-red', '404');
        outputMessage('Skipping ' + acct.username + ' because it is missing');
        timeoutsQueue.push(setTimeout(viewStories, gblOptions.timeDelayAfterSkip));
        return false;
    }

    chrome.runtime.sendMessage({
        "openStoryTab": {
            "username": acct.username,
            "LikeWhenWatchingStory": document.getElementById('cbViewStoryLike').checked,
            "acct": acct
        }
    });

    // closedStoryTab(acct);

}

function closedStoryTab(request) {

    var acct = request.acct;

    if (request.viewed == true) {
        addStamp(acct.id, 'stamp-div-green', 'STORY VISTO');
    } else {
        addStamp(acct.id, 'stamp-div-grey', 'SEM STORY');
    }

    if (noAcctsLeft()) {
        return false;
    }

    if (gblOptions.autoSaveQueue == true) {
        saveQueueToStorage();
    }

    var waitTime = getRandomizedTime(gblOptions.timeDelay);

    outputMessage('waiting  ' + (waitTime / 1000) + ' seconds to view ' + acctsQueue[acctsQueue.length - 1].username + ' story');
    timeoutsQueue.push(setTimeout(viewStories, waitTime));
    return false;
}

function ajaxUnfollowAll() {
    if (!$('#btnProcessQueue').hasClass('pulsing')) return false;
    if (checkMaxActionsAndDelayIfNecessary(ajaxUnfollowAll) == false) {
        ajaxUnfollowAcct(acctsQueue.pop());
    }
}

function quickUnfollowAcct(acct) {
    $.ajax({
            url: 'https://www.instagram.com/web/friendships/' + acct.id + '/unfollow/',
            method: 'POST',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        })
        .done(function() {
            outputMessage('Unfollowed ' + acct.username + ' (' + acct.id + ') using button');
            $('.igBotInjectedLinkWhitelist[data-username="' + acct.username + '"]').parents('article').fadeOut();
        })
        .fail(function(data) {
            if (data.status == 403) {
                alert('soft rate limit encountered, failed to unfollow ' + acct.username);
            } else if (data.status == 400) {
                alert('hard rate limit encountered, failed to unfollow ' + acct.username);
            } else {
                alert('Error ' + data.status + ', failed to unfollow ' + acct.username);
            }
        })
}

function ajaxUnfollowAcct(acct) {
    if (gblOptions.autoSaveQueue == true) {
        saveQueueToStorage();
    }

    var promises = [];
    let unfollowable = true;

    var waitTime = getRandomizedTime(gblOptions.timeDelayAfterSkip);

    if (typeof acct == 'undefined') {
        noAcctsLeft();
        return false;
    }

    if (acct && String(acct.id).indexOf('custom_') === 0) {
        outputMessage('🔍 Buscando ID numérico de @' + acct.username + ' antes do Unfollow...');
        if (typeof window.betaResolveNumericIdByUsername === 'function') {
            window.betaResolveNumericIdByUsername(acct.username, function(numericId) {
                if (numericId) {
                    var oldId = acct.id;
                    acct.id = numericId;
                    outputMessage('✓ ID numérico resolvido para @' + acct.username + ': ' + numericId);
                    var elem = document.getElementById(oldId + '_container');
                    if (elem) elem.id = numericId + '_container';
                    ajaxUnfollowAcct(acct);
                } else {
                    outputMessage('❌ Perfil @' + acct.username + ' não encontrado ou inválido. Pulando...');
                    addStamp(acct.id, 'stamp-div-red', 'INVÁLIDO');
                    setTimeout(ajaxUnfollowAll, 1500);
                }
            });
        } else {
            outputMessage('❌ Resolutor de ID indisponível.');
            setTimeout(ajaxUnfollowAll, 1500);
        }
        return false;
    }

    if (containsObject(acct, acctsWhiteList) == true) {
        outputMessage(acct.username + ' is whitelisted, skipping');
        addStamp(acct.id, 'stamp-div-grey', 'LISTA BRANCA');
        acctsProcessed.push(acct);
        setTimeout(ajaxUnfollowAll, 1);
        return false;
    }


    if (gblOptions.dontUnFollowNonRdg === true) {
        var acctFromStorage = alreadyAttempted(acct);
        if (acctFromStorage === false) {
            outputMessage(acct.username + ' was followed outside of RDG, skipping');
            addStamp(acct.id, 'stamp-div-grey', 'EXTERNO');
            acctsProcessed.push(acct);
            setTimeout(ajaxUnfollowAll, 1);
            return false;
        }
    }

    if (gblOptions.dontUnFollowFilters == true || gblOptions.dontUnFollowFollowers == true || gblOptions.unFollowIfOld == true) {
        promises.push(filterCriteriaMetForUnfollowing(acct).then((met) => {
            if (met == false) {
                unfollowable = false;
            }
        }));
    }

    Promise.all(promises).then(function() {
        if (unfollowable === false) {
            acctsProcessed.push(acct);
            outputMessage(acct.username + ' skipped (matches your filters)');

            if (acct.assumedDeleted) {
                addStamp(acct.id, 'stamp-div-red', '404');

            } else {
                addStamp(acct.id, 'stamp-div-grey', 'FILTRADO');
            }


            if (noAcctsLeft()) {
                return false;
            } else {
                outputMessage('Aguardando  ' + (waitTime / 1000) + ' Segundos para deixar de seguir ' + acctsQueue[acctsQueue.length - 1].username);
                timeoutsQueue.push(setTimeout(ajaxUnfollowAll, waitTime));
                return false;
            }
        }

        waitTime = getRandomizedTime(gblOptions.timeDelay);

        $.ajax({
                //url: 'https://www.instagram.com/web/friendships/' + acct.id + '/unfollow/',
                url: 'https://www.instagram.com/api/v1/friendships/destroy/' + acct.id + '/',
                method: 'POST',
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                    xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                    xhr.setRequestHeader('x-asbd-id', '129477');
                    xhr.setRequestHeader('x-ig-app-id', '936619743392459');
                },
                xhrFields: {
                    withCredentials: true
                }
            })
            .done(function() {

                acctsProcessed.push(acct);
actionsTaken++;
addStamp(acct.id, 'stamp-div-green stamp-unfollowed', 'DEIXOU DE<br>SEGUIR');


                outputMessage('Unfollowed ' + acct.username + ' (' + acct.id + ') | ' + acctsProcessed.length + ' processed, ' + acctsQueue.length + ' left to go');


                if (noAcctsLeft()) {
                    return false;
                } else {
                    outputMessage('Aguardando  ' + (waitTime / 1000) + ' Segundos para deixar de seguir ' + acctsQueue[acctsQueue.length - 1].username);
                    timeoutsQueue.push(setTimeout(ajaxUnfollowAll, waitTime));
                }

            })
            .fail(function(data) {
                if (data.status !== 404) {
                    acctsQueue.push(acct);
                }

                if (data.status == 404) {
                    printMessage(acct.username + ' ' + chrome.i18n.getMessage('AccountNotFound404'));
                    addStamp(acct.id, 'stamp-div-red', '404');
                    timeoutsQueue.push(setTimeout(ajaxUnfollowAll, 1000));
                } else if (data.status == 403) {
                    printMessage(chrome.i18n.getMessage('RateLimitSoft', [(gblOptions.timeDelayAfterSoftRateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(ajaxUnfollowAll, gblOptions.timeDelayAfterSoftRateLimit));
                } else if (data.status == 400) {
                    printMessage(chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]));
                    showRateLimitPopup();
                    timeoutsQueue.push(setTimeout(ajaxUnfollowAll, gblOptions.timeDelayAfterHardRateLimit));
                } else if (data.status == 429) {
                    printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(ajaxUnfollowAll, gblOptions.timeDelayAfter429RateLimit));
                } else {
                    outputMessage(data.status + ' error, trying again in 5 seconds');
                    timeoutsQueue.push(setTimeout(ajaxUnfollowAll, 5000));
                }
            })
    });

}

function ajaxRemoveOrBlockAcct(acct) {
    if (gblOptions.autoSaveQueue == true) {
        saveQueueToStorage();
    }

    var promises = [];
    let removable = true;

    var waitTime = getRandomizedTime(gblOptions.timeDelayAfterSkip);

    if (typeof acct == 'undefined') {
        noAcctsLeft();
        return false;
    }

    if (acct && String(acct.id).indexOf('custom_') === 0) {
        outputMessage('🔍 Buscando ID numérico de @' + acct.username + ' antes de Remover/Bloquear...');
        if (typeof window.betaResolveNumericIdByUsername === 'function') {
            window.betaResolveNumericIdByUsername(acct.username, function(numericId) {
                if (numericId) {
                    var oldId = acct.id;
                    acct.id = numericId;
                    outputMessage('✓ ID numérico resolvido para @' + acct.username + ': ' + numericId);
                    var elem = document.getElementById(oldId + '_container');
                    if (elem) elem.id = numericId + '_container';
                    ajaxRemoveOrBlockAcct(acct);
                } else {
                    outputMessage('❌ Perfil @' + acct.username + ' não encontrado ou inválido. Pulando...');
                    addStamp(acct.id, 'stamp-div-red', 'INVÁLIDO');
                    setTimeout(ajaxRemoveOrBlockAll, 1500);
                }
            });
        } else {
            outputMessage('❌ Resolutor de ID indisponível.');
            setTimeout(ajaxRemoveOrBlockAll, 1500);
        }
        return false;
    }

    if (containsObject(acct, acctsWhiteList) == true) {
        outputMessage(acct.username + ' is whitelisted, skipping');
        addStamp(acct.id, 'stamp-div-grey', 'LISTA BRANCA');
        acctsProcessed.push(acct);
        setTimeout(ajaxRemoveOrBlockAll, 1);
        return false;
    }

    if (gblOptions.dontRemoveOrBlockFilters == true) {
        promises.push(filterCriteriaMetForRemoveOrBlock(acct).then((met) => {
            if (met == false) {
                removable = false;
            }
        }));
    }

    Promise.all(promises).then(function() {

        var removeOrBlockEndpoint = '/remove_follower/';
        var removeOrBlockString = 'Remover';
        var removedOrBlockedString = 'REMOVIDO';


        if (document.getElementById('radioBlock').checked === true) {
            removeOrBlockEndpoint = '/block/';
            removeOrBlockString = 'Bloquear'
            removedOrBlockedString = 'BLOQUEADO';
        }

        if (removable === false) {
            acctsProcessed.push(acct);

            outputMessage(acct.username + ' skipped (matches your filters)');
            addStamp(acct.id, 'stamp-div-grey', 'FILTRADO');


            if (noAcctsLeft()) {
                return false;
            } else {
                outputMessage('waiting  ' + (waitTime / 1000) + ' seconds to ' + removeOrBlockString + ' ' + acctsQueue[acctsQueue.length - 1].username);
                timeoutsQueue.push(setTimeout(ajaxRemoveOrBlockAll, waitTime));
                return false;
            }
        }

        waitTime = getRandomizedTime(gblOptions.timeDelay);

        $.ajax({
                url: 'https://www.instagram.com/web/friendships/' + acct.id + removeOrBlockEndpoint,
                method: 'POST',
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                    xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                    xhr.setRequestHeader('x-asbd-id', '129477');
                    xhr.setRequestHeader('x-ig-app-id', '936619743392459');
                },
                xhrFields: {
                    withCredentials: true
                }
            })
            .done(function() {
                acctsProcessed.push(acct);
                actionsTaken++;
                addStamp(acct.id, 'stamp-div-green', removedOrBlockedString);

                outputMessage(removedOrBlockedString + ' ' + acct.username + ' (' + acct.id + ') | ' + acctsProcessed.length + ' processed, ' + acctsQueue.length + ' left to go');

                if (noAcctsLeft()) {
                    return false;
                } else {
                    outputMessage('waiting  ' + (waitTime / 1000) + ' seconds to ' + removeOrBlockString + ' ' + acctsQueue[acctsQueue.length - 1].username);
                    timeoutsQueue.push(setTimeout(ajaxRemoveOrBlockAll, waitTime));
                }

            })
            .fail(function(data) {
                acctsQueue.push(acct);
                if (data.status == 403) {
                    printMessage(chrome.i18n.getMessage('RateLimitSoft', [(gblOptions.timeDelayAfterSoftRateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(ajaxRemoveOrBlockAll, gblOptions.timeDelayAfterSoftRateLimit));
                } else if (data.status == 400) {
                    printMessage(chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]));
                    showRateLimitPopup();
                    timeoutsQueue.push(setTimeout(ajaxRemoveOrBlockAll, gblOptions.timeDelayAfterHardRateLimit));
                } else if (data.status == 429) {
                    printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(ajaxRemoveOrBlockAll, gblOptions.timeDelayAfter429RateLimit));
                } else {
                    outputMessage(data.status + ' error, trying again in 5 seconds');
                    timeoutsQueue.push(setTimeout(ajaxRemoveOrBlockAll, 5000));
                }
            })
    });

}

function noAcctsLeft() {
    if (acctsQueue.length === 0) {
        outputMessage('No accounts left!');
        var btnProcess = $('#btnProcessQueue');
        btnProcess.removeClass('pulsing');
        if (btnProcess.attr('data-original-text')) {
            btnProcess.text(btnProcess.attr('data-original-text'));
        }
        return true;
    }
    return false;
}

function injectIcon() {
    var imgURL = chrome.runtime.getURL("logo_RDG.jpg");

    $('#instabotIcon').remove();

    var isLogged = typeof rdgIsUiUnlockedOnThisPage === 'function' ? rdgIsUiUnlockedOnThisPage() : false;
    var statusClass = isLogged ? '' : 'status-off';
    var titleText = isLogged ? 'RDG instaPRO (ON - Logado)' : 'RDG instaPRO (OFF - Faça Login)';

    $('body').prepend('<div id="instabotIcon" class="' + statusClass + '" title="' + titleText + '"></div>');

    $('#instabotIcon').css({
        'top': '0px',
        'right': '0px',
        'background-image': 'url("' + imgURL + '")'
    }).click(toggleControlsDiv);
}

function injectVersionNumber(data) {
    const versionElement = document.getElementById('versionNumber');

    // Adicione esta verificação para garantir que o elemento existe
    if (versionElement) {
        versionElement.textContent = data.version;
    } else {
    }
}

function hideControlsDiv(save) {

    $('#igBotInjectedContainer').hide();
    shakeInstabotIcon();

    if (save && save == false) return true;

    saveHiddenStatus(true);
}

function shakeInstabotIcon() {
    $('#instabotIcon').shake(50, 2, 8);
}

function openControlsDiv(save) {
    rdgAssistantKeepUiSessionAlive();
    const isAuthenticated = rdgIsUiUnlockedOnThisPage();
    const container = $('#igBotInjectedContainer');

    if (!container.length) return;

    if (!isAuthenticated) {
        $('#mainSection').hide();
        $('#divCampos').show();
        if (document.getElementById('divEntrarId')) document.getElementById('divEntrarId').style.display = 'none';
        $('#divLoginWrapper').removeClass('rdg-hidden').css('display', 'flex');
    } else {
        $('#mainSection').show();
        $('#divCampos').hide();
        $('#divLoginWrapper').addClass('rdg-hidden').attr('style', 'display: none !important;');
    }

    container.show();

    if (!window._rdgZoomApplied) {
        // removed zoom as it breaks position fixed in chrome 128+
        window._rdgZoomApplied = true;
    }

    if (typeof initBeta === 'function') {
        initBeta();
    }

    if (!(save === false)) {
        saveHiddenStatus(false);
    }
}

function toggleControlsDiv() {
    if ($('#igBotInjectedContainer').length === 0) {
        injectControlsDiv();
        setTimeout(function() {
            if ($('#igBotInjectedContainer').length > 0) {
                $('#igBotInjectedContainer').fadeIn(300);
            }
        }, 500);
        return;
    }
    rdgAssistantKeepUiSessionAlive();
    const isAuthenticated = rdgIsUiUnlockedOnThisPage();
    const container = $('#igBotInjectedContainer');

    if (container.is(':visible')) {
        // Vai fechar
        $('#divCampos').hide();
        if(document.getElementById('divEntrarId')) document.getElementById('divEntrarId').style.display = 'none';
        $('#divLoginWrapper').addClass('rdg-hidden').attr('style', 'display: none !important;');

        container.fadeToggle(300);
    } else {
        // Vai abrir
        if (!isAuthenticated) {
            // Se não logado, garante que o form de login apareça e a ferramenta suma
            $('#mainSection').hide();
            $('#divCampos').show();
            // Se houver outro container de login (ex: entrar por ID), reseta ou esconde
            if(document.getElementById('divEntrarId')) document.getElementById('divEntrarId').style.display = 'none';
            $('#divLoginWrapper').removeClass('rdg-hidden').css('display', 'flex');
        } else {
            // Se logado, mostra a ferramenta e esconde login
            $('#mainSection').show();
            $('#divCampos').hide();
            $('#divLoginWrapper').addClass('rdg-hidden').attr('style', 'display: none !important;');
        }

        container.fadeToggle(300);
        
        // Aplicar zoom de 75% ao abrir pela primeira vez
        if (!window._rdgZoomApplied) {
            container.css('zoom', '0.75');
            window._rdgZoomApplied = true;
        }
        
        // Ensure Beta UI is initialized and visible
        if (typeof initBeta === 'function') {
            initBeta();
        }
    }
}



function injectControlsDiv() {

    if (shouldLoadRdgOnThisPage() == false) return false;

    if (window._rdgControlsInjecting) return;
    window._rdgControlsInjecting = true;

    $('#igBotInjectedContainer').remove();

    $.get(chrome.runtime.getURL('rdg.html') + '?v=' + Date.now(), function(data) {
        var processedData = data.replace(/logo_RDG\.jpg/g, chrome.runtime.getURL('logo_RDG.jpg'))
                                .replace(/Logo\.png/g, chrome.runtime.getURL('Logo.png'))
                                .replace(/logo_RDG\.png/g, chrome.runtime.getURL('logo_RDG.png'));
        $('html').append($.parseHTML(processedData));
        $('#btnMinimizeRdg').click(function() {
            toggleControlsDiv();
        });
        // Modal logic for Assistente tab
        $('#btnAssistenteThumb').click(function() {
            $('#assistenteModal').fadeIn();
        });
        $('#closeAssistenteModal').click(function() {
            $('#assistenteModal').fadeOut();
        });
        $('#assistenteModal').click(function(e) {
            if (e.target.id === 'assistenteModal') {
                $(this).fadeOut();
            }
        });

        // Modal logic for Help & FAQ Floating Button
        $('#rdgFloatingHelpBtn').click(function() {
            var $modal = $('#rdgHelpModal');
            var $parent = $('#igBotInjectedContainer');
            $modal.css({
                top: $parent.css('top'),
                right: $parent.css('right'),
                left: $parent.css('left'),
                bottom: $parent.css('bottom'),
                width: $parent.outerWidth() + 'px',
                height: $parent.outerHeight() + 'px',
                borderRadius: $parent.css('border-radius'),
                display: 'flex',
                opacity: 0
            }).animate({ opacity: 1 }, 250);
            $parent.css('overflow', 'hidden');
            $('#rdgHelpSearchInput').focus();
        });
        $('#closeHelpModalBtn').click(function() {
            $('#rdgHelpModal').animate({ opacity: 0 }, 200, function() {
                $(this).css('display', 'none');
                $('#igBotInjectedContainer').css('overflow', 'auto');
            });
        });
        $('#rdgHelpModal').click(function(e) {
            if (e.target.id === 'rdgHelpModal') {
                $(this).animate({ opacity: 0 }, 200, function() {
                    $(this).css('display', 'none');
                    $('#igBotInjectedContainer').css('overflow', 'auto');
                });
            }
        });

        // FAQ Accordion click
        $('#rdgFaqList').on('click', '.faq-question', function() {
            $(this).toggleClass('open');
            $(this).next('.faq-answer').slideToggle(200);
        });

        // FAQ Category filtering
        $('.faq-cat-btn').click(function() {
            $('.faq-cat-btn').removeClass('active');
            $(this).addClass('active');
            let cat = $(this).attr('data-cat');
            let query = ($('#rdgHelpSearchInput').val() || '').trim().toLowerCase();
            rdgFilterFaqItems(cat, query);
        });

        // FAQ Search filtering
        $('#rdgHelpSearchInput').on('input keyup', function() {
            let query = ($(this).val() || '').trim().toLowerCase();
            let cat = $('.faq-cat-btn.active').attr('data-cat') || 'all';
            rdgFilterFaqItems(cat, query);
        });

        function rdgFilterFaqItems(cat, query) {
            $('#rdgFaqList .faq-item').each(function() {
                let itemCat = cat === 'all' || $(this).hasClass(cat);
                if (!itemCat) {
                    $(this).hide();
                    return;
                }
                if (!query) {
                    $(this).show();
                    return;
                }
                let questionText = ($(this).find('.faq-question').text() || '').toLowerCase();
                let answerText = ($(this).find('.faq-answer').text() || '').toLowerCase();
                let keywords = ($(this).attr('data-keywords') || '').toLowerCase();
                if (questionText.includes(query) || answerText.includes(query) || keywords.includes(query)) {
                    $(this).show();
                    if (query.length >= 3) {
                        $(this).find('.faq-question').addClass('open');
                        $(this).find('.faq-answer').slideDown(150);
                    }
                } else {
                    $(this).hide();
                }
            });
        }


        // Validation for login inputs
        const entrarIdAppInput = document.getElementById('entrarIdApp');
        const entrarNameAppInput = document.getElementById('youNameLog');
        
        function impedirEspacosCaracteresEspeciais(input) {
            if (input) {
                input.addEventListener('input', () => {
                    input.value = input.value.replace(/[^a-zA-Z0-9-]/g, '');
                });
            }
        }
    
        impedirEspacosCaracteresEspeciais(entrarIdAppInput);
        impedirEspacosCaracteresEspeciais(entrarNameAppInput);

        // Auto-restore saved license key and skip login if already authenticated
        try {
            const savedKey = localStorage.getItem('rdgSavedLicenseKey');
            if (savedKey && entrarNameAppInput) {
                entrarNameAppInput.value = savedKey;
            }
            if (savedKey && localStorage.getItem('rdgAuthenticated') === 'true') {
                // Already authenticated - skip login screen silently
                liberarInterface(true);
            }
        } catch(e) {}

        if (!rdgIsUiUnlockedOnThisPage()) {
            $('#mainSection').hide();
        }

        localizeExtension();
        ensureRdgHelpWidget();

        rdgLoadScopedLogIntoConsole();
        rdgLoadTodayStats();        loadOptions();
        rdgVerifyAndRefreshLicenseFromSupabase();
        setTimeout(function() {
            loadWhiteList();
            loadPreviousAttempts(function() {
                rdgAssistantInit();
            });
            injectVersionNumber();
            loadActionsQueue();
            initStoriesPlusUi();

            ready(igExternalVars.qsForConvenienceButtons, function(element) {
                addNewConvenienceLinks(element);
            });
            getHiddenStatus(hiddenStatusCallback);

            setTimeout(function() {
                if (acctsQueue.length === 0 || (gblOptions && gblOptions.loadQueueOnStartup !== false)) {
                    loadQueueFromLocal();
                }
            }, 1000);
        }, 0);

        window._rdgControlsInjecting = false;
    }).fail(function() {
        window._rdgControlsInjecting = false;
    });
}

function ensureRdgHelpWidget() {
    try {
        if (document.getElementById('rdg-help-widget')) return;
        var mainSection = document.getElementById('mainSection');
        if (!mainSection) return;

        if (!mainSection.style.position) {
            mainSection.style.position = 'relative';
        }

        if (!document.getElementById('rdg-help-widget-style')) {
            var style = document.createElement('style');
            style.id = 'rdg-help-widget-style';
            style.textContent =
                '#rdg-help-widget{position:absolute;top:12px;right:12px;z-index:50;display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:999px;border:1px solid rgba(0,0,0,0.12);background:#fff;cursor:pointer;user-select:none;box-shadow:0 6px 18px rgba(0,0,0,0.12);max-width:240px}' +
                '#rdg-help-widget:hover{transform:translateY(-1px);box-shadow:0 10px 24px rgba(0,0,0,0.16)}' +
                '#rdg-help-widget img{width:20px;height:20px;display:block;flex:0 0 auto}' +
                '#rdg-help-widget .rdg-help-text{font-size:12px;font-weight:700;color:#0f172a;white-space:nowrap}' +
                '#rdg-help-menu{position:absolute;top:46px;right:0;min-width:260px;background:#fff;border:1px solid rgba(0,0,0,0.12);border-radius:12px;box-shadow:0 18px 40px rgba(0,0,0,0.18);padding:10px;display:none}' +
                '#rdg-help-menu .rdg-help-title{font-size:13px;font-weight:800;color:#0f172a;margin:0 0 8px 0}' +
                '#rdg-help-menu .rdg-help-sub{font-size:12px;color:#334155;margin:0 0 10px 0;line-height:1.4}' +
                '#rdg-help-menu .rdg-help-actions{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}' +
                '#rdg-help-menu button{border:0;border-radius:10px;padding:9px 12px;font-weight:900;font-size:12px;cursor:pointer;color:#fff;box-shadow:0 6px 14px rgba(0,0,0,0.18);transition:transform .12s ease,box-shadow .12s ease,filter .12s ease}' +
                '#rdg-help-menu button:hover{transform:translateY(-1px);box-shadow:0 10px 18px rgba(0,0,0,0.22);filter:brightness(1.02)}' +
                '#rdg-help-menu button:active{transform:translateY(0px);box-shadow:0 6px 14px rgba(0,0,0,0.18);filter:brightness(0.98)}' +
                '#rdg-help-menu button:disabled{opacity:.55;filter:grayscale(0.2);cursor:not-allowed;box-shadow:none}' +
                '#rdg-help-menu button.rdg-help-videos{background:linear-gradient(135deg,#3b82f6,#1d4ed8);border:1px solid rgba(29,78,216,0.35)}' +
                '#rdg-help-menu button.rdg-help-whats{background:linear-gradient(135deg,#22c55e,#16a34a);border:1px solid rgba(22,163,74,0.35)}' +
                '@media (max-width: 520px){#rdg-help-widget{top:8px;right:8px;padding:7px 9px;max-width:200px}#rdg-help-widget .rdg-help-text{font-size:11px}}';
            document.head.appendChild(style);
        }

        var widget = document.createElement('div');
        widget.id = 'rdg-help-widget';

        var img = document.createElement('img');
        try {
            img.src = chrome.runtime.getURL('whats.png');
        } catch (e) {}
        img.alt = 'WhatsApp';

        var text = document.createElement('div');
        text.className = 'rdg-help-text';
        text.innerText = 'Precisa de ajuda?';

        var menu = document.createElement('div');
        menu.id = 'rdg-help-menu';

        var title = document.createElement('div');
        title.className = 'rdg-help-title';
        title.innerText = 'Precisa de ajuda?';

        var sub = document.createElement('div');
        sub.className = 'rdg-help-sub';
        sub.innerText = 'Clique no botão abaixo para falar diretamente com nosso suporte no WhatsApp!';

        var actions = document.createElement('div');
        actions.className = 'rdg-help-actions';

        var btnVideos = document.createElement('button');
        btnVideos.type = 'button';
        btnVideos.className = 'rdg-help-videos';
        btnVideos.innerText = 'Ver os vídeos';
        btnVideos.style.display = 'none'; // Oculto até haver vídeos gravados

        var btnWhats = document.createElement('button');
        btnWhats.type = 'button';
        btnWhats.className = 'rdg-help-whats';
        btnWhats.innerText = 'Falar no WhatsApp';

        actions.appendChild(btnVideos);
        actions.appendChild(btnWhats);

        menu.appendChild(title);
        menu.appendChild(sub);
        menu.appendChild(actions);

        widget.appendChild(img);
        widget.appendChild(text);
        widget.appendChild(menu);

        mainSection.appendChild(widget);

        function closeMenu() {
            menu.style.display = 'none';
        }

        function toggleMenu() {
            menu.style.display = (menu.style.display === 'block') ? 'none' : 'block';
        }

        widget.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleMenu();
        });

        document.addEventListener('click', function(e) {
            if (!widget.contains(e.target)) closeMenu();
        }, true);

        btnVideos.addEventListener('click', function(e) {
            e.stopPropagation();
            closeMenu();
            window.open('https://api.whatsapp.com/send?phone=5521920078469', '_blank');
        });

        btnWhats.addEventListener('click', function(e) {
            e.stopPropagation();
            closeMenu();
            window.open('https://api.whatsapp.com/send?phone=5521920078469', '_blank');
        });
    } catch (e) {}
}

function localizeExtension() {
    $('#igBotInjectedContainer [localeMessage]').each(function() {
        var localeMessage = chrome.i18n.getMessage($(this).attr('localeMessage'));
        if (localeMessage.length > 0) {
            $(this).text(localeMessage);
        }
    });

    $('#igBotInjectedContainer [localeReplaceString]').each(function() {
        $(this).text($(this).text().replace($(this).attr('localeReplaceString'), chrome.i18n.getMessage($(this).attr('localeReplaceString').replace(/ /g, '_'))));
    });
}

function buildMessagesJson() {
    var jsonbuilder = '';

    $('#igBotInjectedContainer [localeMessage]').each(function() {
        var titlestr = '';
        if ($(this).attr('title')) {
            titlestr = ', "title": "' + $(this).attr('title') + '"';
        }
        var str2add = '"' + $(this).attr('localeMessage') + '": { "message": "' + $(this).html() + '"' + titlestr + '},'
        if (jsonbuilder.indexOf(str2add) == -1) jsonbuilder = jsonbuilder + str2add;

        if ($(this).html() == '') {
            alert($(this).attr('localeMessage'));
        }
    });
}

(function(win) {
    'use strict';

    var listeners = [],
        doc = win.document,
        MutationObserver = win.MutationObserver || win.WebKitMutationObserver,
        observer;

    function ready(selector, fn) {
        // Store the selector and callback to be monitored
        listeners.push({
            selector: selector,
            fn: fn
        });
        if (!observer) {
            // Watch for changes in the document
            observer = new MutationObserver(check);
            observer.observe(doc.documentElement, {
                childList: true,
                subtree: true
            });
        }
        // Check if the element is currently in the DOM
        check();
    }

    function check() {
        // Check the DOM for elements matching a stored selector
        for (var i = 0, len = listeners.length, listener, elements; i < len; i++) {
            listener = listeners[i];
            // Query for elements matching the specified selector
            elements = doc.querySelectorAll(listener.selector);
            for (var j = 0, jLen = elements.length, element; j < jLen; j++) {
                element = elements[j];
                // Make sure the callback isn't invoked with the
                // same element more than once
                if (!element.ready) {
                    element.ready = true;
                    // Invoke the callback with the element
                    listener.fn.call(element, element);
                }
            }
        }
    }

    // Expose `ready`
    win.ready = ready;

})(this);



function ajaxLikeAll() {
    if (!$('#btnProcessQueue').hasClass('pulsing')) return false;
    if (rdgLikeOnlyMode === true) {
        if (alreadyLiking === true || mediaToLike.length > 0) {
            return;
        }

        if (acctsQueue.length === 0) {
            outputMessage('Concluido. Nenhuma conta restante para curtir.');
            $('#btnProcessQueue').removeClass('pulsing');
            rdgResetLikeOnlyState();
            return;
        }

        getUsersMedia(acctsQueue.shift());
        return;
    }

    if (noAcctsLeft() == false) {
        getUsersMedia(acctsQueue.shift());
    } else {
        outputMessage('Done loading media, beginning likes...');
        likeAllMedia();
    }
}

function getUsersMedia(acct) {

    if (rdgLikeOnlyMode === true) {
        removeAcctFromQueueDisplay(acct.id, true);
        rdgLikeOnlyCurrentAccount = acct;
        outputMessage('Carregando fotos de ' + acct.username + ' (' + acct.id + ')');
        ajaxLoadUsersMedia('', false, usersMediaLoaded, acct);
        return;
    }

    var acctsQueueNextUsername = '';
    removeAcctFromQueueDisplay(acct.id, true);
    if (noAcctsLeft() === false) {
        acctsQueueNextUsername = acctsQueue[0].username;
    }

    ajaxLoadUsersMedia('', false, usersMediaLoaded, acct);

    var waitTime = getRandomizedTime(gblOptions.timeDelay);

    outputMessage('Adding media for ' + acct.username + ' (' + acct.id + ') to like queue;  waiting  ' + (waitTime / 1000) + ' seconds to process ' + acctsQueueNextUsername);

    timeoutsQueue.push(setTimeout(ajaxLikeAll, waitTime));
}

function initProcessQueue() {
    if ($('#btnProcessQueue').hasClass('pulsing') || alreadyLiking === true || (Array.isArray(timeoutsQueue) && timeoutsQueue.length > 0)) {
        outputMessage('A fila já está em processamento! Clique em "Parar!" antes de iniciar uma nova ação.');
        return false;
    }

    var todaysdate = new Date();
    maxActionsDelayStartTime = todaysdate.getTime();

    alreadyLiking = false;
    rdgLikeVerificationDone = false;
    rdgResetLikeOnlyState();

    var btn = $('#btnProcessQueue');
    var originalText = btn.attr('data-original-text') || 'Processar Fila ↑';
    var actionText = originalText;

    if (document.getElementById('radioFollowLikeAndDM') && document.getElementById('radioFollowLikeAndDM').checked === true) {
        actionText = 'Executando Funil...';
    } else if (document.getElementById('radioFollowAndLike').checked === true) {
        actionText = 'Seguindo + Curtindo...';
    } else if (document.getElementById('radioFollow').checked === true) {
        actionText = 'Seguindo a Fila...';
    } else if (document.getElementById('radioUnFollow').checked === true) {
        actionText = 'Deixando de Seguir...';
    } else if (document.getElementById('radioLikeOnly').checked === true) {
        actionText = 'Curtindo a Fila...';
    } else if (document.getElementById('radioBlock').checked === true) {
        actionText = 'Bloqueando a Fila...';
    } else if (document.getElementById('radioRemoveFromFollowers').checked === true) {
        actionText = 'Removendo Seguidores...';
    } else if (document.getElementById('radioViewStory').checked === true) {
        actionText = 'Visualizando Stories...';
    } else if (document.getElementById('radioGetMoreData').checked === true) {
        actionText = 'Extraindo Dados...';
    }

    if (!btn.attr('data-original-text')) {
        btn.attr('data-original-text', btn.text());
    }
    btn.addClass('pulsing').text(actionText);

    if (document.getElementById('radioFollow').checked === true || document.getElementById('radioFollowAndLike').checked === true || (document.getElementById('radioFollowLikeAndDM') && document.getElementById('radioFollowLikeAndDM').checked === true)) {
        ajaxFollowAll();
    } else if (document.getElementById('radioUnFollow').checked === true) {
        initUnfollowMyFollowers();
    } else if (document.getElementById('radioLikeOnly').checked === true) {
        rdgLikeOnlyMode = true;
        ajaxLikeAll();
    } else if (document.getElementById('radioBlock').checked === true || document.getElementById('radioRemoveFromFollowers').checked === true) {
        ajaxRemoveOrBlockAll();
    } else if (document.getElementById('radioGetMoreData').checked === true) {

        var safeDelaySeconds = 1;

        if (acctsQueue.length > 100) safeDelaySeconds = 2;
        if (acctsQueue.length > 500) safeDelaySeconds = 3;
        if (acctsQueue.length > 1000) safeDelaySeconds = 4;
        if (acctsQueue.length > 2000) safeDelaySeconds = 5;
        if (acctsQueue.length > 3000) safeDelaySeconds = 6;
        if (acctsQueue.length > 4000) safeDelaySeconds = 10;



        if (acctsQueue.length > 40 && (gblOptions.useTimeDelayAfterAdditionalInfo == false || document.getElementById('texttimeDelayAfterAdditionalInfo').value < safeDelaySeconds)) {

            dialog({
                no: "No",
                yes: "Yes",
                question: "WARNING: <br><br>Low or no delay set after loading data for each account. <br><br> Set " + safeDelaySeconds + " second delay?"
            }, function() {
                document.getElementById('cbuseTimeDelayAfterAdditionalInfo').checked = true;
                document.getElementById('texttimeDelayAfterAdditionalInfo').value = safeDelaySeconds;
                saveOptions();

                populateAllQueueUsersInfo(acctsQueue);

            }, function() {
                populateAllQueueUsersInfo(acctsQueue);
            })
        } else {
            populateAllQueueUsersInfo(acctsQueue);
        }



    } else if (document.getElementById('radioViewStory').checked === true) {
        viewStories();
    }
}

function rdgStopAllPendingActions(msg) {
    // #region debug-point J:stop-all-pending
    try {
        rdgDebugReport('J', 'contentscript.js:rdgStopAllPendingActions', 'stop all pending actions called', {
            msg: msg || '',
            timeoutsQueueLength: Array.isArray(timeoutsQueue) ? timeoutsQueue.length : null,
            alreadyLiking: alreadyLiking === true,
            mediaQueueLength: typeof mediaToLike !== 'undefined' && mediaToLike ? mediaToLike.length : null,
            queueLength: typeof acctsQueue !== 'undefined' && acctsQueue ? acctsQueue.length : null,
            assistantRun: rdgAssistantState && rdgAssistantState.run ? {
                status: rdgAssistantState.run.status,
                phase: rdgAssistantState.run.phase,
                activeProfileId: rdgAssistantState.run.activeProfileId,
                pendingInteractionCooldown: rdgAssistantState.run.pendingInteractionCooldown === true,
                waitUntil: rdgAssistantState.run.waitUntil || 0,
                currentAction: rdgAssistantState.run.currentAction || '',
                currentTargetUsername: rdgAssistantState.run.currentTargetUsername || '',
                nextActionAt: rdgAssistantState.run.nextActionAt || 0,
                nextActionLabel: rdgAssistantState.run.nextActionLabel || ''
            } : null,
            stack: (new Error('rdgStopAllPendingActions')).stack || ''
        });
    } catch (e) {}
    // #endregion
    for (var i = 0; i < timeoutsQueue.length; i++) {
        clearTimeout(timeoutsQueue[i]);
    }

    timeoutsQueue = [];
    try {
        if (typeof gblOptions !== 'undefined' && gblOptions) {
            gblOptions.bIsPaused = true;
        }
    } catch (eGblPause) {}
    if (rdgAssistantNextFollowTimerId) {
        try { clearTimeout(rdgAssistantNextFollowTimerId); } catch (e3) {}
        rdgAssistantNextFollowTimerId = null;
    }
    alreadyLiking = false;
    rdgLikeVerificationDone = false;
    rdgResetLikeOnlyState();

    $('#igBotInjectedContainer *').removeClass('pulsing');
    
    var btnProcess = $('#btnProcessQueue');
    if (btnProcess.attr('data-original-text')) {
        btnProcess.text(btnProcess.attr('data-original-text'));
    }
    var btnMedia = $('#btnLikeMediaQueue');
    if (btnMedia.attr('data-original-text')) {
        btnMedia.text(btnMedia.attr('data-original-text'));
    }
    
    outputMessage(msg || 'Stopped all pending actions');
}

// #region debug-point K:schedule-helper
function rdgScheduleTimeout(fn, ms, label, meta) {
    try {
        rdgDebugReport('K', 'contentscript.js:rdgScheduleTimeout', 'scheduled timeout', {
            label: label || '',
            ms: ms,
            meta: meta || {},
            assistantRun: rdgAssistantState && rdgAssistantState.run ? {
                status: rdgAssistantState.run.status,
                phase: rdgAssistantState.run.phase,
                activeProfileId: rdgAssistantState.run.activeProfileId
            } : null
        });
    } catch (e) {}
    var id = null;
    var wrappedFn = function() {
        try {
            var idx = timeoutsQueue.indexOf(id);
            if (idx > -1) timeoutsQueue.splice(idx, 1);
        } catch (e3) {}
        return fn();
    };
    id = setTimeout(wrappedFn, ms);
    timeoutsQueue.push(id);
    try {
        window.rdgLastScheduledTimeout = {
            label: label || '',
            ms: ms,
            at: Date.now()
        };
    } catch (e2) {}
    return id;
}
// #endregion

function rdgAssistantDefaultProfileAssistantState() {
    return {
        currentRunId: '',
        currentStatus: 'Aguardando configuracao',
        collectedAudience: [],
        audienceSources: {
            likes: 0,
            comments: 0,
            followers: 0
        },
        collectedAt: 0,
        interactionCompletedAt: 0,
        warmingUntil: 0,
        dmCompletedAt: 0,
        totalCollected: 0,
        totalInteractions: 0,
        currentRunInteractions: 0,
        currentRunLikes: 0,
        processedAudienceIds: {},
        targetReachedAt: 0,
        totalConverted: 0,
        currentRunConverted: 0,
        totalDmSent: 0,
        emptyAudienceRetryCount: 0,
        emptyAudienceSkippedAt: 0,
        lastUpdatedAt: 0
    };
}

function rdgAssistantDefaultState() {
    return {
        cycles: [],
        activeCycleId: '',
        cycleCounter: 1,
        profiles: [],
        dmTemplate: '',
        dmTemplates: [],
        run: null,
        history: [],
        settings: {
            minProfiles: 1,
            targetPerProfile: 150,
            assistantAudiencePoolSize: 150,
            warmupDays: 0,
            likesPerUser: 3,
            likesPerUserMin: 3,
            likesPerUserMax: 3,
            workHoursPerDay: 10,
            restHoursPerDay: 10,
            assistantDelayMinSec: 120,
            assistantDelayMaxSec: 168,
            assistantSkipDelaySec: 8,
            assistantDmDelayMinSec: 10,
            assistantDmDelayMaxSec: 30,
            assistantPauseEveryInteractions: 30,
            assistantPauseMinutesAfterBatch: 10,
            assistantUnfollowMaxFollowing: 7500,
            assistantUnfollowTargetFollowing: 3000,
            assistantUnfollowBatchSize: 500
        },
        accountRuntime: {
            workWindowStartedAt: 0,
            workMsInWindow: 0,
            workLastTickAt: 0,
            restUntil: 0,
            restStartedAt: 0,
            lastUpdatedAt: 0
        },
        savedAt: 0
    };
}

function rdgAssistantNormalizeDmTemplates(stateLike) {
    stateLike = stateLike || {};
    var normalized = [];
    var source = Array.isArray(stateLike.dmTemplates) ? stateLike.dmTemplates.slice(0, 3) : [];
    if (!source.length && stateLike.dmTemplate) source = [stateLike.dmTemplate];
    for (var i = 0; i < source.length; i++) {
        var text = String(source[i] || '').trim();
        if (!text) continue;
        if (normalized.indexOf(text) === -1) normalized.push(text);
        if (normalized.length >= 3) break;
    }
    stateLike.dmTemplates = normalized;
    stateLike.dmTemplate = normalized[0] || String(stateLike.dmTemplate || '').trim();
    return stateLike.dmTemplates;
}

function rdgAssistantGetNormalizedDmTemplatesFromInputs(ids) {
    var stateLike = {
        dmTemplate: '',
        dmTemplates: []
    };
    (ids || []).forEach(function(id) {
        var el = document.getElementById(id);
        var text = String(el && typeof el.value !== 'undefined' ? el.value : '').trim();
        if (!text) return;
        stateLike.dmTemplates.push(text);
        if (!stateLike.dmTemplate) stateLike.dmTemplate = text;
    });
    rdgAssistantNormalizeDmTemplates(stateLike);
    return stateLike.dmTemplates.slice(0, 3);
}

function rdgAssistantGetDmTemplatesSummary() {
    var templates = Array.isArray(rdgAssistantState && rdgAssistantState.dmTemplates) ? rdgAssistantState.dmTemplates.slice(0, 3) : [];
    if (!templates.length) return '';
    var first = String(templates[0] || '').trim();
    if (!first) return '';
    if (templates.length === 1) return first;
    return first + ' | +' + (templates.length - 1) + ' variacao(oes)';
}

function rdgAssistantSyncDirectDmInputs() {
    if (!rdgAssistantState) return;
    rdgAssistantNormalizeDmTemplates(rdgAssistantState);
    var templates = Array.isArray(rdgAssistantState.dmTemplates) ? rdgAssistantState.dmTemplates : [];
    var ids = ['txtMassDM', 'txtMassDM2', 'txtMassDM3'];
    for (var i = 0; i < ids.length; i++) {
        var el = document.getElementById(ids[i]);
        if (!el) continue;
        el.value = templates[i] || '';
        try {
            if (window.jQuery) window.jQuery(el).trigger('input');
        } catch (e) {}
    }
}

function rdgAssistantSlimAcct(acct) {
    acct = acct || {};
    var id = acct.id || acct.pk || acct.user_id || '';
    id = id ? String(id) : '';
    return {
        id: id,
        pk: id,
        username: acct.username || '',
        full_name: acct.full_name || acct.name || '',
        profile_pic_url: acct.profile_pic_url || '',
        is_private: acct.is_private === true,
        followed_by_viewer: acct.followed_by_viewer === true,
        requested_by_viewer: acct.requested_by_viewer === true
    };
}

function rdgAssistantNormalizeProfile(profile) {
    profile = profile || {};
    profile.id = profile.id ? String(profile.id) : '';
    profile.username = profile.username || '';
    profile.full_name = profile.full_name || '';
    profile.profile_pic_url = profile.profile_pic_url || '';
    profile.follower_count = parseInt(profile.follower_count || 0, 10) || 0;
    profile.addedAt = parseInt(profile.addedAt || 0, 10) || Date.now();
    profile.assistant = $.extend(true, {}, rdgAssistantDefaultProfileAssistantState(), profile.assistant || {});
    profile.assistant.collectedAudience = Array.isArray(profile.assistant.collectedAudience) ? profile.assistant.collectedAudience.map(rdgAssistantSlimAcct) : [];
    profile.assistant.processedAudienceIds = profile.assistant.processedAudienceIds && typeof profile.assistant.processedAudienceIds === 'object' ? profile.assistant.processedAudienceIds : {};
    return profile;
}

function rdgAssistantNormalizeState(raw) {
    var state = $.extend(true, {}, rdgAssistantDefaultState(), raw || {});
    state.settings.minProfiles = parseInt(state.settings.minProfiles || 1, 10) || 1;
    state.settings.targetPerProfile = 150;
    state.settings.assistantAudiencePoolSize = 150;
    state.settings.warmupDays = 0;
    state.settings.likesPerUser = parseInt(state.settings.likesPerUser || 3, 10) || 3;
    state.settings.likesPerUserMin = state.settings.likesPerUser;
    state.settings.likesPerUserMax = state.settings.likesPerUser;
    state.settings.workHoursPerDay = parseInt(state.settings.workHoursPerDay || 10, 10) || 10;
    state.settings.restHoursPerDay = parseInt(state.settings.restHoursPerDay || 10, 10) || 10;
    state.settings.assistantDelayMinSec = parseInt(state.settings.assistantDelayMinSec || 120, 10) || 120;
    state.settings.assistantDelayMaxSec = parseInt(state.settings.assistantDelayMaxSec || 168, 10) || 168;
    state.settings.assistantSkipDelaySec = parseInt(state.settings.assistantSkipDelaySec || 8, 10) || 8;
    state.settings.assistantDmDelayMinSec = parseInt(state.settings.assistantDmDelayMinSec || 10, 10) || 10;
    state.settings.assistantDmDelayMaxSec = parseInt(state.settings.assistantDmDelayMaxSec || 30, 10) || 30;
    state.settings.assistantPauseEveryInteractions = parseInt(state.settings.assistantPauseEveryInteractions || 30, 10) || 30;
    state.settings.assistantPauseMinutesAfterBatch = parseInt(state.settings.assistantPauseMinutesAfterBatch || 10, 10) || 10;
    state.settings.assistantUnfollowMaxFollowing = parseInt(state.settings.assistantUnfollowMaxFollowing || 7500, 10) || 7500;
    state.settings.assistantUnfollowTargetFollowing = parseInt(state.settings.assistantUnfollowTargetFollowing || 3000, 10) || 3000;
    state.settings.assistantUnfollowBatchSize = parseInt(state.settings.assistantUnfollowBatchSize || 500, 10) || 500;
    if (state.settings.likesPerUserMin < 1) state.settings.likesPerUserMin = 3;
    if (state.settings.likesPerUserMax < state.settings.likesPerUserMin) state.settings.likesPerUserMax = state.settings.likesPerUserMin;
    if (state.settings.assistantDelayMaxSec < state.settings.assistantDelayMinSec) state.settings.assistantDelayMaxSec = state.settings.assistantDelayMinSec;
    if (state.settings.assistantDmDelayMaxSec < state.settings.assistantDmDelayMinSec) state.settings.assistantDmDelayMaxSec = state.settings.assistantDmDelayMinSec;
    if (state.settings.assistantDelayMinSec === 90 && state.settings.assistantDelayMaxSec === 180) {
        state.settings.assistantDelayMinSec = 120;
        state.settings.assistantDelayMaxSec = 168;
    }
    if (state.settings.assistantDmDelayMinSec === 90 && state.settings.assistantDmDelayMaxSec === 180) {
        state.settings.assistantDmDelayMinSec = 10;
        state.settings.assistantDmDelayMaxSec = 30;
    }
    if (state.settings.assistantDmDelayMinSec === 120 && state.settings.assistantDmDelayMaxSec === 168) {
        state.settings.assistantDmDelayMinSec = 10;
        state.settings.assistantDmDelayMaxSec = 30;
    }
    var normalizeRun = function(run) {
        if (!run) return null;
        run.id = run.id || ('assist-' + Date.now());
        run.status = run.status || 'idle';
        run.phase = run.phase || 'idle';
        run.logs = Array.isArray(run.logs) ? run.logs.slice(0, 80) : [];
        run.waitUntil = parseInt(run.waitUntil || 0, 10) || 0;
        run.activeProfileId = run.activeProfileId ? String(run.activeProfileId) : '';
        run.rateLimitHits = parseInt(run.rateLimitHits || 0, 10) || 0;
        run.dmStarted = run.dmStarted === true;
        run.dmHistoryBaselineCount = parseInt(run.dmHistoryBaselineCount || 0, 10) || 0;
        run.dmQueueSize = parseInt(run.dmQueueSize || 0, 10) || 0;
        run.resumePhase = run.resumePhase || '';
        run.waitReason = run.waitReason || '';
        run.interactionBatchCount = parseInt(run.interactionBatchCount || 0, 10) || 0;
        run.pendingInteractionCooldown = run.pendingInteractionCooldown === true;
        run.workWindowStartedAt = parseInt(run.workWindowStartedAt || 0, 10) || 0;
        run.workMsInWindow = parseInt(run.workMsInWindow || 0, 10) || 0;
        run.workLastTickAt = parseInt(run.workLastTickAt || 0, 10) || 0;
        run.currentAction = run.currentAction || '';
        run.currentTargetUsername = run.currentTargetUsername || '';
        run.nextActionAt = parseInt(run.nextActionAt || 0, 10) || 0;
        run.nextActionLabel = run.nextActionLabel || '';
        run.emptyAudienceRetryAt = parseInt(run.emptyAudienceRetryAt || 0, 10) || 0;
        run.emptyAudienceRetryProfileId = run.emptyAudienceRetryProfileId ? String(run.emptyAudienceRetryProfileId) : '';
        run.profileTransitionAt = parseInt(run.profileTransitionAt || 0, 10) || 0;
        run.profileTransitionNextProfileId = run.profileTransitionNextProfileId ? String(run.profileTransitionNextProfileId) : '';
        run.profileTransitionNextUsername = run.profileTransitionNextUsername || '';
        run.profileTransitionFromUsername = run.profileTransitionFromUsername || '';
        run.pendingNextFollow = run.pendingNextFollow === true;
        run.nextFollowAt = parseInt(run.nextFollowAt || 0, 10) || 0;
        run.nextFollowUsername = run.nextFollowUsername || '';
        run.lastAutoRecoveryAt = parseInt(run.lastAutoRecoveryAt || 0, 10) || 0;
        run.autoRecoveryCount = parseInt(run.autoRecoveryCount || 0, 10) || 0;
        run.lastAutoRecoveryReason = run.lastAutoRecoveryReason || '';
        run.dmQualifiedCount = parseInt(run.dmQualifiedCount || 0, 10) || 0;
        run.dmQualifiedAt = parseInt(run.dmQualifiedAt || 0, 10) || 0;
        run.dmSentCount = parseInt(run.dmSentCount || 0, 10) || 0;
        run.dmProcessedCount = parseInt(run.dmProcessedCount || 0, 10) || 0;
        run.dmStatusText = run.dmStatusText || '';
        return run;
    };

    var normalizeCycle = function(cycle) {
        cycle = cycle || {};
        cycle.id = cycle.id ? String(cycle.id) : '';
        cycle.name = cycle.name || 'Ciclo';
        cycle.createdAt = parseInt(cycle.createdAt || 0, 10) || Date.now();
        cycle.updatedAt = parseInt(cycle.updatedAt || 0, 10) || Date.now();
        cycle.profiles = Array.isArray(cycle.profiles) ? cycle.profiles.map(rdgAssistantNormalizeProfile).filter(function(profile) {
            return profile && profile.id && profile.username;
        }) : [];
        rdgAssistantNormalizeDmTemplates(cycle);
        cycle.history = Array.isArray(cycle.history) ? cycle.history.slice(0, 80) : [];
        cycle.run = normalizeRun(cycle.run);
        return cycle;
    };

    if (!Array.isArray(state.cycles) || !state.cycles.length) {
        var legacyProfiles = Array.isArray(state.profiles) ? state.profiles : [];
        var legacyHistory = Array.isArray(state.history) ? state.history : [];
        var legacyRun = normalizeRun(state.run);
        var cycleId = 'cycle-' + Date.now();
        state.cycles = [normalizeCycle({
            id: cycleId,
            name: 'Ciclo 1',
            createdAt: Date.now(),
            updatedAt: Date.now(),
            profiles: legacyProfiles,
            dmTemplate: state.dmTemplate || '',
            dmTemplates: state.dmTemplates || [],
            history: legacyHistory,
            run: legacyRun
        })];
        state.activeCycleId = cycleId;
        state.cycleCounter = 2;
    } else {
        state.cycles = state.cycles.map(normalizeCycle).filter(function(c) { return c && c.id; });
        state.cycleCounter = parseInt(state.cycleCounter || (state.cycles.length + 1), 10) || (state.cycles.length + 1);
        if (!state.activeCycleId || !state.cycles.some(function(c) { return c.id === state.activeCycleId; })) {
            state.activeCycleId = state.cycles[0] ? state.cycles[0].id : '';
        }
    }

    var activeCycle = null;
    for (var i = 0; i < state.cycles.length; i++) {
        if (state.cycles[i].id === state.activeCycleId) { activeCycle = state.cycles[i]; break; }
    }
    if (!activeCycle && state.cycles.length) activeCycle = state.cycles[0];

    state.profiles = activeCycle ? activeCycle.profiles.map(rdgAssistantNormalizeProfile) : [];
    if (state.settings.warmupDays === 0 && Array.isArray(state.profiles)) {
        var targetForUi = parseInt(state.settings.targetPerProfile || 10, 10) || 10;
        state.profiles.forEach(function(profile) {
            if (!profile || !profile.assistant) return;
            profile.assistant.warmingUntil = 0;
            if (profile.assistant.interactionCompletedAt && !profile.assistant.dmCompletedAt && String(profile.assistant.currentStatus || '').indexOf('aquecimento') > -1) {
                profile.assistant.currentStatus = 'Interacoes concluidas. Aguardando os outros perfis fecharem ' + targetForUi + '/' + targetForUi + ' para liberar o direct';
            }
        });
    }
    state.dmTemplate = activeCycle ? (activeCycle.dmTemplate || '') : '';
    state.dmTemplates = activeCycle ? (Array.isArray(activeCycle.dmTemplates) ? activeCycle.dmTemplates.slice(0, 3) : []) : [];
    state.history = activeCycle ? (activeCycle.history || []).slice(0, 80) : [];
    state.run = activeCycle ? normalizeRun(activeCycle.run) : null;
    rdgAssistantNormalizeDmTemplates(state);
    state.accountRuntime = state.accountRuntime || {};
    state.accountRuntime.workWindowStartedAt = parseInt(state.accountRuntime.workWindowStartedAt || 0, 10) || 0;
    state.accountRuntime.workMsInWindow = parseInt(state.accountRuntime.workMsInWindow || 0, 10) || 0;
    state.accountRuntime.workLastTickAt = parseInt(state.accountRuntime.workLastTickAt || 0, 10) || 0;
    state.accountRuntime.restUntil = parseInt(state.accountRuntime.restUntil || 0, 10) || 0;
    state.accountRuntime.restStartedAt = parseInt(state.accountRuntime.restStartedAt || 0, 10) || 0;
    state.accountRuntime.lastUpdatedAt = parseInt(state.accountRuntime.lastUpdatedAt || 0, 10) || 0;
    if (!state.accountRuntime.workMsInWindow && state.run && (parseInt(state.run.workMsInWindow || 0, 10) || 0) > 0) {
        state.accountRuntime.workWindowStartedAt = parseInt(state.run.workWindowStartedAt || 0, 10) || state.accountRuntime.workWindowStartedAt;
        state.accountRuntime.workMsInWindow = parseInt(state.run.workMsInWindow || 0, 10) || 0;
        state.accountRuntime.workLastTickAt = parseInt(state.run.workLastTickAt || 0, 10) || 0;
    }
    if (!state.accountRuntime.restUntil) {
        for (var rtIdx = 0; rtIdx < state.cycles.length; rtIdx++) {
            var cycleRun = state.cycles[rtIdx] && state.cycles[rtIdx].run ? state.cycles[rtIdx].run : null;
            var cycleRestCandidate = cycleRun ? (parseInt(cycleRun.waitUntil || 0, 10) || 0) : 0;
            if (cycleRun && cycleRestCandidate > Date.now() && (cycleRun.status === 'resting' || cycleRun.phase === 'resting') && cycleRestCandidate > state.accountRuntime.restUntil) {
                state.accountRuntime.restUntil = cycleRestCandidate;
            }
        }
    }
    return state;
}

function rdgAssistantGetAccountRuntime() {
    if (!rdgAssistantState) return null;
    if (!rdgAssistantState.accountRuntime || typeof rdgAssistantState.accountRuntime !== 'object') {
        rdgAssistantState.accountRuntime = {
            workWindowStartedAt: 0,
            workMsInWindow: 0,
            workLastTickAt: 0,
            restUntil: 0,
            restStartedAt: 0,
            lastUpdatedAt: 0
        };
    }
    return rdgAssistantState.accountRuntime;
}

function rdgAssistantNormalizeAccountRuntime(rawRuntime) {
    var runtime = $.extend(true, {}, {
        workWindowStartedAt: 0,
        workMsInWindow: 0,
        workLastTickAt: 0,
        restUntil: 0,
        restStartedAt: 0,
        lastUpdatedAt: 0
    }, rawRuntime || {});
    runtime.workWindowStartedAt = parseInt(runtime.workWindowStartedAt || 0, 10) || 0;
    runtime.workMsInWindow = parseInt(runtime.workMsInWindow || 0, 10) || 0;
    runtime.workLastTickAt = parseInt(runtime.workLastTickAt || 0, 10) || 0;
    runtime.restUntil = parseInt(runtime.restUntil || 0, 10) || 0;
    runtime.restStartedAt = parseInt(runtime.restStartedAt || 0, 10) || 0;
    runtime.lastUpdatedAt = parseInt(runtime.lastUpdatedAt || 0, 10) || 0;
    var now = Date.now();
    var limitMs = (parseInt((rdgAssistantState && rdgAssistantState.settings && rdgAssistantState.settings.workHoursPerDay) || 10, 10) || 10) * 3600000;
    if (runtime.workWindowStartedAt > now) runtime.workWindowStartedAt = 0;
    if (runtime.workLastTickAt > now) runtime.workLastTickAt = 0;
    if (runtime.lastUpdatedAt > now) runtime.lastUpdatedAt = now;
    if (runtime.restUntil <= now) runtime.restUntil = 0;
    if (!runtime.restUntil) runtime.restStartedAt = 0;
    if (runtime.workMsInWindow < 0) runtime.workMsInWindow = 0;
    if (runtime.restUntil > now && runtime.workMsInWindow > 0 && runtime.workMsInWindow < Math.max(0, limitMs - 1800000)) {
        runtime.restUntil = 0;
        runtime.restStartedAt = 0;
    }
    return runtime;
}

function rdgAssistantGetAccountRuntimeTimestamp(rawRuntime) {
    var runtime = rdgAssistantNormalizeAccountRuntime(rawRuntime);
    return Math.max(
        parseInt(runtime.lastUpdatedAt || 0, 10) || 0,
        parseInt(runtime.restStartedAt || 0, 10) || 0,
        parseInt(runtime.workLastTickAt || 0, 10) || 0,
        parseInt(runtime.workWindowStartedAt || 0, 10) || 0
    );
}

function rdgAssistantHasMeaningfulAccountRuntime(runtime) {
    runtime = rdgAssistantNormalizeAccountRuntime(runtime);
    return !!(runtime.workWindowStartedAt || runtime.workMsInWindow || runtime.workLastTickAt || runtime.restUntil || runtime.restStartedAt);
}

function rdgAssistantMergeAccountRuntime(baseRuntime, incomingRuntime) {
    var base = rdgAssistantNormalizeAccountRuntime(baseRuntime);
    var incoming = rdgAssistantNormalizeAccountRuntime(incomingRuntime);
    if (!rdgAssistantHasMeaningfulAccountRuntime(base)) return incoming;
    if (!rdgAssistantHasMeaningfulAccountRuntime(incoming)) return base;

    var baseTs = rdgAssistantGetAccountRuntimeTimestamp(base);
    var incomingTs = rdgAssistantGetAccountRuntimeTimestamp(incoming);
    var newer = incomingTs > baseTs ? incoming : base;
    var older = incomingTs > baseTs ? base : incoming;
    var merged = rdgAssistantNormalizeAccountRuntime(newer);

    if (!merged.workWindowStartedAt && older.workWindowStartedAt) merged.workWindowStartedAt = older.workWindowStartedAt;
    if (!merged.workLastTickAt && older.workLastTickAt) merged.workLastTickAt = older.workLastTickAt;
    if (!merged.lastUpdatedAt && older.lastUpdatedAt) merged.lastUpdatedAt = older.lastUpdatedAt;

    if (!baseTs || !incomingTs || Math.abs(incomingTs - baseTs) < 1000) {
        if (older.restUntil > merged.restUntil) {
            merged.restUntil = older.restUntil;
            merged.restStartedAt = older.restStartedAt || merged.restStartedAt;
        }
        if (older.workMsInWindow > merged.workMsInWindow) {
            merged.workMsInWindow = older.workMsInWindow;
            merged.workWindowStartedAt = older.workWindowStartedAt || merged.workWindowStartedAt;
            merged.workLastTickAt = older.workLastTickAt || merged.workLastTickAt;
        }
    }

    return rdgAssistantNormalizeAccountRuntime(merged);
}

function rdgAssistantParseLogLineTimestamp(line) {
    var match = String(line || '').match(/^(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2}:\d{2})\s*-/);
    if (!match) return 0;
    var isoLike = match[1] + 'T' + match[2];
    var parsed = new Date(isoLike).getTime();
    if (!isFinite(parsed)) return 0;
    return parsed;
}

function rdgAssistantRecoverAccountRuntimeFromLogText(logText, baseRuntime) {
    var runtime = rdgAssistantNormalizeAccountRuntime(baseRuntime);
    var lines = String(logText || '').split('\n');
    if (lines.length > 6000) lines = lines.slice(lines.length - 6000);
    var workHours = parseInt((rdgAssistantState && rdgAssistantState.settings && rdgAssistantState.settings.workHoursPerDay) || 10, 10) || 10;
    var restHours = parseInt((rdgAssistantState && rdgAssistantState.settings && rdgAssistantState.settings.restHoursPerDay) || 10, 10) || 10;
    var workMs = workHours * 3600000;
    var restMs = restHours * 3600000;

    for (var i = 0; i < lines.length; i++) {
        var line = String(lines[i] || '').trim();
        if (!line) continue;
        if (line.indexOf('Descanso automatico iniciado apos') === -1) continue;
        var ts = rdgAssistantParseLogLineTimestamp(line);
        if (!ts) continue;
        var candidate = {
            workWindowStartedAt: Math.max(0, ts - workMs),
            workMsInWindow: workMs,
            workLastTickAt: 0,
            restStartedAt: ts,
            restUntil: ts + restMs,
            lastUpdatedAt: ts
        };
        runtime = rdgAssistantMergeAccountRuntime(runtime, candidate);
    }

    return runtime;
}

function rdgAssistantBuildAccountRuntimePersistPayload(runtime) {
    var normalized = rdgAssistantNormalizeAccountRuntime(runtime);
    var storageKey = rdgResolveAccountRuntimeStorageKey();
    var payload = {};
    payload[storageKey] = normalized;
    try {
        var scopeId = rdgAssistantGetStorageScopeId();
        var backupKey = scopeId ? (RDG_ACCOUNT_RUNTIME_STORAGE_KEY + ':backup:' + scopeId) : (RDG_ACCOUNT_RUNTIME_STORAGE_KEY + ':backup');
        payload[backupKey] = normalized;
    } catch (e) {}
    return payload;
}

function rdgAssistantPersistAccountRuntime(runtime, callback) {
    chrome.storage.local.set(rdgAssistantBuildAccountRuntimePersistPayload(runtime), function() {
        if (typeof callback === 'function') callback(rdgAssistantNormalizeAccountRuntime(runtime));
    });
}

function rdgAssistantLoadAccountRuntime(fallbackRuntime, callback) {
    var scopedKey = rdgResolveAccountRuntimeStorageKey();
    var storageKeys = rdgResolveAccountRuntimeStorageKeyCandidates();
    chrome.storage.local.get(storageKeys, function(data) {
        var chosenKey = scopedKey;
        var rawRuntime = null;
        var shouldPersistRecovered = false;

        if (typeof data[scopedKey] !== 'undefined') {
            rawRuntime = data[scopedKey];
        } else {
            var newestCandidateTs = 0;
            for (var i = 0; i < storageKeys.length; i++) {
                var candidateKey = storageKeys[i];
                if (!candidateKey || candidateKey === scopedKey || candidateKey === RDG_ACCOUNT_RUNTIME_STORAGE_KEY) continue;
                if (typeof data[candidateKey] === 'undefined') continue;
                var candidateRuntime = data[candidateKey];
                if (!rdgAssistantHasMeaningfulAccountRuntime(candidateRuntime)) continue;
                var candidateTs = rdgAssistantGetAccountRuntimeTimestamp(candidateRuntime);
                if (!rawRuntime || candidateTs > newestCandidateTs) {
                    rawRuntime = candidateRuntime;
                    chosenKey = candidateKey;
                    newestCandidateTs = candidateTs;
                    shouldPersistRecovered = true;
                }
            }
        }

        if (!rawRuntime && typeof data[RDG_ACCOUNT_RUNTIME_STORAGE_KEY] !== 'undefined') {
            rawRuntime = data[RDG_ACCOUNT_RUNTIME_STORAGE_KEY];
            chosenKey = RDG_ACCOUNT_RUNTIME_STORAGE_KEY;
            shouldPersistRecovered = true;
        }

        var mergedRuntime = rdgAssistantMergeAccountRuntime(fallbackRuntime, rawRuntime);
        if (rdgAssistantHasMeaningfulAccountRuntime(mergedRuntime)) {
            if (shouldPersistRecovered === true || chosenKey !== scopedKey) {
                rdgAssistantPersistAccountRuntime(mergedRuntime, function(savedRuntime) {
                    if (typeof callback === 'function') callback(savedRuntime);
                });
                return;
            }
            if (typeof callback === 'function') callback(mergedRuntime);
            return;
        }

        rdgReadScopedLogText(function(logText) {
            var recoveredRuntime = rdgAssistantRecoverAccountRuntimeFromLogText(logText, mergedRuntime);
            if (rdgAssistantHasMeaningfulAccountRuntime(recoveredRuntime)) {
                rdgAssistantPersistAccountRuntime(recoveredRuntime, function(savedRuntime) {
                    if (typeof callback === 'function') callback(savedRuntime);
                });
                return;
            }
            if (typeof callback === 'function') callback(recoveredRuntime);
        });
    });
}

function rdgAssistantGetAccountRestUntil() {
    var runtime = rdgAssistantGetAccountRuntime();
    if (!runtime) return 0;
    return parseInt(runtime.restUntil || 0, 10) || 0;
}

function rdgAssistantHasAccountRestLock() {
    return rdgAssistantGetAccountRestUntil() > Date.now();
}

function rdgAssistantHydrateAccountRestLockFromRun(run) {
    if (!run) return 0;
    var candidate = parseInt(run.waitUntil || 0, 10) || 0;
    if (candidate <= Date.now()) return rdgAssistantGetAccountRestUntil();
    if (!(run.status === 'resting' || run.phase === 'resting')) return rdgAssistantGetAccountRestUntil();
    var runtime = rdgAssistantGetAccountRuntime();
    if (!runtime) return candidate;
    var current = parseInt(runtime.restUntil || 0, 10) || 0;
    if (current > Date.now() && current >= candidate) return current;
    runtime.restUntil = candidate;
    runtime.restStartedAt = parseInt(runtime.restStartedAt || Date.now(), 10) || Date.now();
    runtime.lastUpdatedAt = Date.now();
    return runtime.restUntil;
}

function rdgAssistantSyncRunWorkCounters(run) {
    if (!run || !rdgAssistantState) return;
    var runtime = rdgAssistantGetAccountRuntime();
    if (!runtime) return;
    run.workWindowStartedAt = parseInt(runtime.workWindowStartedAt || 0, 10) || 0;
    run.workMsInWindow = parseInt(runtime.workMsInWindow || 0, 10) || 0;
    run.workLastTickAt = parseInt(runtime.workLastTickAt || 0, 10) || 0;
    if ((parseInt(runtime.restUntil || 0, 10) || 0) > (parseInt(run.waitUntil || 0, 10) || 0) && run.status === 'resting') {
        run.waitUntil = parseInt(runtime.restUntil || 0, 10) || 0;
    }
}

function rdgAssistantSetAccountWorkLastTickAt(value) {
    var runtime = rdgAssistantGetAccountRuntime();
    if (!runtime) return;
    runtime.workLastTickAt = parseInt(value || 0, 10) || 0;
    runtime.lastUpdatedAt = Date.now();
    if (rdgAssistantState && rdgAssistantState.run) {
        rdgAssistantState.run.workLastTickAt = runtime.workLastTickAt;
    }
}

function rdgAssistantSetAccountRestLock(restUntil, restStartedAt) {
    var runtime = rdgAssistantGetAccountRuntime();
    if (!runtime) return;
    var existingRestUntil = parseInt(runtime.restUntil || 0, 10) || 0;
    var nextRestUntil = parseInt(restUntil || 0, 10) || 0;
    if (existingRestUntil > Date.now()) {
        nextRestUntil = existingRestUntil;
    }
    runtime.restUntil = nextRestUntil;
    runtime.restStartedAt = parseInt(runtime.restStartedAt || restStartedAt || 0, 10) || 0;
    runtime.workLastTickAt = 0;
    runtime.lastUpdatedAt = Date.now();
    if (rdgAssistantState && rdgAssistantState.run) {
        rdgAssistantState.run.workLastTickAt = 0;
        if (runtime.restUntil > 0) rdgAssistantState.run.waitUntil = runtime.restUntil;
    }
}

function rdgAssistantResetAccountWorkWindow(nowValue) {
    var runtime = rdgAssistantGetAccountRuntime();
    if (!runtime) return;
    var now = parseInt(nowValue || Date.now(), 10) || Date.now();
    runtime.workWindowStartedAt = now;
    runtime.workMsInWindow = 0;
    runtime.workLastTickAt = now;
    runtime.restUntil = 0;
    runtime.lastUpdatedAt = now;
    if (rdgAssistantState && rdgAssistantState.run) {
        rdgAssistantState.run.workWindowStartedAt = now;
        rdgAssistantState.run.workMsInWindow = 0;
        rdgAssistantState.run.workLastTickAt = now;
    }
}

function rdgAssistantClearAccountRestLock() {
    var runtime = rdgAssistantGetAccountRuntime();
    if (!runtime) return;
    runtime.restUntil = 0;
    runtime.restStartedAt = 0;
    runtime.lastUpdatedAt = Date.now();
}

function rdgAssistantCancelManualBlockingWaits(preserveAccountRest) {
    if (!rdgAssistantState || !rdgAssistantState.run) return;
    var run = rdgAssistantState.run;
    var resumePhase = run.resumePhase || '';
    var shouldPreserveRest = preserveAccountRest === true && rdgAssistantHasAccountRestLock();
    if (!shouldPreserveRest) {
        rdgAssistantClearAccountRestLock();
        run.waitUntil = 0;
        run.waitReason = '';
    } else {
        run.waitUntil = rdgAssistantGetAccountRestUntil();
        run.waitReason = 'account_rest';
    }
    if (run.phase === 'resting' || shouldPreserveRest) {
        run.phase = resumePhase || 'paused';
    }
}

function rdgAssistantApplyAccountRestLockToCurrentRun() {
    if (!rdgAssistantState || !rdgAssistantState.run || !rdgAssistantHasAccountRestLock()) return false;
    rdgAssistantState.run.status = 'resting';
    rdgAssistantState.run.phase = 'resting';
    rdgAssistantState.run.waitUntil = rdgAssistantGetAccountRestUntil();
    rdgAssistantState.run.updatedAt = Date.now();
    rdgAssistantSetAccountWorkLastTickAt(0);
    rdgAssistantEnsureWaitResumeTimer();
    return true;
}

function rdgAssistantResumeAutomaticallyFromWait(resumePhase, reason) {
    if (!rdgAssistantState || !rdgAssistantState.run) return false;
    rdgAssistantClearWaitResumeTimer();
    var nextPhase = resumePhase || rdgAssistantState.run.resumePhase || 'collecting';
    rdgAssistantState.run.status = 'running';
    rdgAssistantState.run.phase = nextPhase;
    rdgAssistantState.run.resumePhase = nextPhase;
    rdgAssistantState.run.waitReason = '';
    rdgAssistantState.run.waitUntil = 0;
    rdgAssistantState.run.updatedAt = Date.now();
    rdgAssistantSetAccountWorkLastTickAt(Date.now());
    rdgAssistantApplyAssistantDelays();
    rdgAssistantMarkSessionActive();
    rdgAssistantLog(reason || 'Campanha retomada automaticamente.', nextPhase, true);
    return true;
}

function rdgAssistantClearWaitResumeTimer() {
    if (rdgAssistantWaitResumeTimer) {
        clearTimeout(rdgAssistantWaitResumeTimer);
        rdgAssistantWaitResumeTimer = null;
    }
    rdgAssistantWaitResumeTargetAt = 0;
}

function rdgAssistantEnsureWaitResumeTimer() {
    if (!rdgAssistantState || !rdgAssistantState.run) {
        rdgAssistantClearWaitResumeTimer();
        return false;
    }
    var run = rdgAssistantState.run;
    if (['waiting_instagram', 'resting'].indexOf(run.status) === -1) {
        rdgAssistantClearWaitResumeTimer();
        return false;
    }
    var waitUntil = parseInt(run.waitUntil || 0, 10) || 0;
    if (waitUntil <= 0) {
        rdgAssistantClearWaitResumeTimer();
        return false;
    }
    if (rdgAssistantWaitResumeTimer && rdgAssistantWaitResumeTargetAt === waitUntil) return true;

    rdgAssistantClearWaitResumeTimer();
    rdgAssistantWaitResumeTargetAt = waitUntil;
    rdgAssistantWaitResumeTimer = setTimeout(function() {
        rdgAssistantWaitResumeTimer = null;
        rdgAssistantWaitResumeTargetAt = 0;
        if (!rdgAssistantState || !rdgAssistantState.run) return;
        var activeRun = rdgAssistantState.run;
        var now = Date.now();
        if (activeRun.status === 'waiting_instagram') {
            if ((parseInt(activeRun.waitUntil || 0, 10) || 0) > now) {
                rdgAssistantEnsureWaitResumeTimer();
                return;
            }
            var resumePhase = activeRun.resumePhase || '';
            rdgAssistantRestoreManualDelays();
            rdgAssistantResumeAutomaticallyFromWait(resumePhase, 'A pausa tecnica terminou. O assistente retomou automaticamente do ponto salvo.');
            rdgAssistantSaveState(function() {
                rdgAssistantRender();
                rdgAssistantTick();
            });
            return;
        }
        if (activeRun.status === 'resting') {
            if (rdgAssistantHasAccountRestLock() && rdgAssistantGetAccountRestUntil() > now) {
                activeRun.waitUntil = Math.max(parseInt(activeRun.waitUntil || 0, 10) || 0, rdgAssistantGetAccountRestUntil());
                rdgAssistantEnsureWaitResumeTimer();
                return;
            }
            var restingResumePhase = activeRun.resumePhase || '';
            rdgAssistantCloseNoticePopup();
            rdgAssistantResetAccountWorkWindow(now);
            rdgAssistantClearAccountRestLock();
            rdgAssistantRestoreManualDelays();
            rdgAssistantResumeAutomaticallyFromWait(restingResumePhase, 'O descanso terminou. O assistente retomou automaticamente a campanha.');
            rdgAssistantSaveState(function() {
                rdgAssistantRender();
                rdgAssistantTick();
            });
        }
    }, Math.max(0, waitUntil - Date.now()) + 250);
    return true;
}

function rdgAssistantSyncActiveCycleIntoState() {
    if (!rdgAssistantState || !Array.isArray(rdgAssistantState.cycles) || !rdgAssistantState.activeCycleId) return;
    rdgAssistantNormalizeDmTemplates(rdgAssistantState);
    for (var i = 0; i < rdgAssistantState.cycles.length; i++) {
        var cycle = rdgAssistantState.cycles[i];
        if (!cycle || cycle.id !== rdgAssistantState.activeCycleId) continue;
        cycle.profiles = Array.isArray(rdgAssistantState.profiles) ? rdgAssistantState.profiles : [];
        cycle.dmTemplate = rdgAssistantState.dmTemplate || '';
        cycle.dmTemplates = Array.isArray(rdgAssistantState.dmTemplates) ? rdgAssistantState.dmTemplates.slice(0, 3) : [];
        cycle.history = Array.isArray(rdgAssistantState.history) ? rdgAssistantState.history : [];
        cycle.run = rdgAssistantState.run || null;
        cycle.updatedAt = Date.now();
        break;
    }
}

function rdgAssistantApplyCycleToState(cycleId) {
    if (!rdgAssistantState || !Array.isArray(rdgAssistantState.cycles) || !cycleId) return;
    var chosen = null;
    for (var i = 0; i < rdgAssistantState.cycles.length; i++) {
        if (rdgAssistantState.cycles[i].id === String(cycleId)) { chosen = rdgAssistantState.cycles[i]; break; }
    }
    if (!chosen) return;
    rdgAssistantState.activeCycleId = chosen.id;
    rdgAssistantState.profiles = Array.isArray(chosen.profiles) ? chosen.profiles.map(rdgAssistantNormalizeProfile) : [];
    rdgAssistantState.dmTemplate = chosen.dmTemplate || '';
    rdgAssistantState.dmTemplates = Array.isArray(chosen.dmTemplates) ? chosen.dmTemplates.slice(0, 3) : [];
    rdgAssistantState.history = Array.isArray(chosen.history) ? chosen.history.slice(0, 80) : [];
    rdgAssistantState.run = chosen.run || null;
    rdgAssistantNormalizeDmTemplates(rdgAssistantState);
    if (rdgAssistantState.run) rdgAssistantSyncRunWorkCounters(rdgAssistantState.run);
}

function rdgAssistantSaveState(callback) {
    if (!rdgAssistantState) {
        if (typeof callback === 'function') callback();
        return;
    }
    if (rdgAssistantState.run) rdgAssistantSyncRunWorkCounters(rdgAssistantState.run);
    rdgAssistantSyncActiveCycleIntoState();
    rdgAssistantState.accountScopeId = rdgAssistantGetStorageScopeId();
    rdgAssistantState.accountUsername = rdgAssistantGetViewerUsername();
    rdgAssistantState.accountViewerId = rdgAssistantGetViewerId();
    rdgAssistantState.savedAt = Date.now();
    var storageKey = rdgAssistantResolveStorageKey();
    chrome.storage.local.set((function() {
        var payload = {};
        payload[storageKey] = rdgAssistantState;
        var runtimePayload = rdgAssistantBuildAccountRuntimePersistPayload(rdgAssistantState.accountRuntime || {});
        Object.keys(runtimePayload).forEach(function(key) {
            payload[key] = runtimePayload[key];
        });
        try {
            if (rdgAssistantState && Array.isArray(rdgAssistantState.cycles) && rdgAssistantState.cycles.length) {
                var scopeId = rdgAssistantGetStorageScopeId();
                var backupKey = scopeId ? (RDG_ASSISTANT_STORAGE_KEY + ':backup:' + scopeId) : (RDG_ASSISTANT_STORAGE_KEY + ':backup');
                payload[backupKey] = rdgAssistantState;
            }
        } catch (e) {}
        return payload;
    })(), function() {
        rdgAssistantLoadedStorageKey = storageKey;
        if (typeof callback === 'function') callback();
    });
}

function rdgAssistantLoadState(callback) {
    var scopedKey = rdgAssistantResolveStorageKey();
    var legacyKey = RDG_ASSISTANT_STORAGE_KEY;
    var storageKeys = rdgAssistantResolveStorageKeyCandidates();
    chrome.storage.local.get(storageKeys, function(data) {
        var rawState = null;
        var chosenKey = scopedKey || legacyKey;
        var shouldMigrateLegacy = false;
        var shouldResetChosenKey = false;
        var keyMarkedForReset = '';
        var currentScopeId = rdgAssistantGetStorageScopeId();
        var currentUsername = rdgAssistantGetViewerUsername() ? String(rdgAssistantGetViewerUsername()) : '';
        var currentViewerId = rdgAssistantGetViewerId() ? String(rdgAssistantGetViewerId()) : '';
        var scopedValue = typeof data[scopedKey] === 'undefined' ? null : data[scopedKey];
        var legacyValue = typeof data[legacyKey] === 'undefined' ? null : data[legacyKey];
        if (scopedValue) {
            rawState = scopedValue;
            chosenKey = scopedKey;
        } else {
            for (var idxScoped = 0; idxScoped < storageKeys.length; idxScoped++) {
                var candidateKey = storageKeys[idxScoped];
                if (!candidateKey || candidateKey === scopedKey || candidateKey === legacyKey) continue;
                if (typeof data[candidateKey] === 'undefined') continue;
                rawState = data[candidateKey];
                chosenKey = candidateKey;
                shouldMigrateLegacy = true;
                break;
            }
        }
        if (!rawState && legacyValue) {
            var legacyScopeId = legacyValue && legacyValue.accountScopeId ? String(legacyValue.accountScopeId) : '';
            var legacyUsername = legacyValue && legacyValue.accountUsername ? String(legacyValue.accountUsername) : '';
            var legacyViewerId = legacyValue && legacyValue.accountViewerId ? String(legacyValue.accountViewerId) : '';
            if (legacyViewerId && currentViewerId && legacyViewerId === currentViewerId) {
                rawState = legacyValue;
                chosenKey = legacyKey;
                shouldMigrateLegacy = true;
            } else if (legacyScopeId && currentScopeId && legacyScopeId === String(currentScopeId)) {
                rawState = legacyValue;
                chosenKey = legacyKey;
                shouldMigrateLegacy = true;
            } else if (!legacyScopeId && legacyUsername && currentUsername && legacyUsername === currentUsername) {
                rawState = legacyValue;
                chosenKey = legacyKey;
                shouldMigrateLegacy = true;
            } else {
                rawState = null;
                chosenKey = scopedKey;
            }
        }
        if (rawState) {
            try {
                var rawScopeId = rawState.accountScopeId ? String(rawState.accountScopeId) : '';
                var rawUsername = rawState.accountUsername ? String(rawState.accountUsername) : '';
                var rawViewerId = rawState.accountViewerId ? String(rawState.accountViewerId) : '';
                if (rawViewerId && currentViewerId && rawViewerId !== currentViewerId) {
                    rawState = null;
                    shouldMigrateLegacy = false;
                    chosenKey = scopedKey;
                } else if (rawUsername && currentUsername && rawUsername !== currentUsername) {
                    rawState = null;
                    shouldMigrateLegacy = false;
                    chosenKey = scopedKey;
                }
            } catch (eValidate) {}
            try {
                if (rawState && rdgAssistantStateContainsForeignInstagramOwner(rawState, currentUsername)) {
                    keyMarkedForReset = chosenKey;
                    rawState = null;
                    shouldMigrateLegacy = false;
                    shouldResetChosenKey = true;
                    chosenKey = scopedKey;
                }
            } catch (eOwnerValidate) {}
        }
        rdgAssistantLoadedStorageKey = chosenKey;
        rdgAssistantState = rdgAssistantNormalizeState(rawState);
        var fallbackRuntime = rdgAssistantState.accountRuntime || {};
        rdgAssistantLoadAccountRuntime(fallbackRuntime, function(loadedRuntime) {
            rdgAssistantState.accountRuntime = rdgAssistantNormalizeAccountRuntime(loadedRuntime);
            if (rdgAssistantState.run) rdgAssistantSyncRunWorkCounters(rdgAssistantState.run);
            if (shouldMigrateLegacy === true && chosenKey !== scopedKey && scopedKey && scopedKey !== legacyKey) {
                var keyToRemove = chosenKey;
                rdgAssistantSaveState(function() {
                    chrome.storage.local.remove(keyToRemove, function() {
                        rdgAssistantLoadedStorageKey = scopedKey;
                        rdgAssistantRender();
                        if (typeof callback === 'function') callback(rdgAssistantState);
                    });
                });
                return;
            }
            if (shouldResetChosenKey && keyMarkedForReset) {}
            if (rdgAssistantState && rdgAssistantState.settings) {
                if (document.getElementById('txtrdgCoffeeActions')) {
                    document.getElementById('txtrdgCoffeeActions').value = rdgAssistantState.settings.assistantPauseEveryInteractions || 30;
                }
                if (document.getElementById('txtrdgCoffeeMinutes')) {
                    document.getElementById('txtrdgCoffeeMinutes').value = rdgAssistantState.settings.assistantPauseMinutesAfterBatch || 10;
                }
            }
            rdgAssistantRender();
            if (typeof callback === 'function') callback(rdgAssistantState);
        });
    });
}

function rdgAssistantStateContainsForeignInstagramOwner(rawState, currentUsername) {
    currentUsername = String(currentUsername || '').trim().toLowerCase();
    if (!rawState || !currentUsername) return false;
    var rawDump = '';
    try {
        rawDump = JSON.stringify(rawState).toLowerCase();
    } catch (eDump) {
        rawDump = '';
    }
    if (!rawDump || rawDump.indexOf('perfil do instagram:') === -1) return false;
    var match;
    var regex = /perfil do instagram:\s*([a-z0-9._]+)/g;
    while ((match = regex.exec(rawDump))) {
        var owner = String(match[1] || '').trim().toLowerCase();
        if (owner && owner !== currentUsername) return true;
    }
    return false;
}

function rdgAssistantFormatNumber(value) {
    return (parseInt(value || 0, 10) || 0).toLocaleString('pt-BR');
}

function rdgAssistantFormatDate(value) {
    if (!value) return '-';
    try {
        return new Date(parseInt(value, 10)).toLocaleString('pt-BR');
    } catch (e) {
        return '-';
    }
}

function rdgAssistantFormatRelativeWait(value) {
    if (!value || value <= Date.now()) return 'Agora';
    var remaining = value - Date.now();
    var hours = Math.floor(remaining / 3600000);
    var mins = Math.floor((remaining % 3600000) / 60000);
    if (hours > 0) return hours + 'h ' + mins + 'min';
    return mins + 'min';
}

function rdgAssistantFormatActiveDurationMs(ms) {
    var total = Math.max(0, parseInt(ms || 0, 10) || 0);
    var seconds = Math.floor(total / 1000);
    var hours = Math.floor(seconds / 3600);
    var minutes = Math.floor((seconds % 3600) / 60);
    var secs = seconds % 60;
    var hh = String(hours);
    var mm = String(minutes).padStart(2, '0');
    var ss = String(secs).padStart(2, '0');
    return hh + 'h ' + mm + 'min ' + ss + 's';
}

function rdgAssistantComputeActiveWorkMs(run) {
    var runtime = rdgAssistantGetAccountRuntime();
    if (!runtime) return 0;
    var effectiveStatus = run && run.status ? run.status : (rdgAssistantHasAccountRestLock() ? 'resting' : 'idle');
    var base = parseInt(runtime.workMsInWindow || 0, 10) || 0;
    if (effectiveStatus !== 'running') return base;
    var last = parseInt(runtime.workLastTickAt || 0, 10) || 0;
    if (!last) return base;
    var delta = Date.now() - last;
    if (delta < 0 || delta > 600000) delta = 0;
    return base + delta;
}

function rdgAssistantShouldClearInvalidLongPause(run) {
    if (!rdgAssistantState || !run) return false;
    var runtime = rdgAssistantGetAccountRuntime();
    if (!runtime) return false;
    var now = Date.now();
    var workLimitMs = (parseInt((rdgAssistantState.settings && rdgAssistantState.settings.workHoursPerDay) || 10, 10) || 10) * 3600000;
    var activeMs = rdgAssistantComputeActiveWorkMs(run);
    if (activeMs <= 0 || activeMs >= workLimitMs) return false;

    var restUntil = parseInt(runtime.restUntil || 0, 10) || 0;
    if (restUntil > now) return true;

    var waitUntil = parseInt(run.waitUntil || 0, 10) || 0;
    if (waitUntil <= now) return false;

    var remainingMs = waitUntil - now;
    var longPauseThresholdMs = Math.max(6 * 3600000, workLimitMs - activeMs);
    var phase = String(run.phase || '').toLowerCase();
    var waitReason = String(run.waitReason || '').toLowerCase();
    if (run.status === 'resting') return true;
    if (remainingMs < longPauseThresholdMs) return false;
    if (phase === 'waiting_rate_limit') return true;
    if (waitReason === 'account_rest') return true;
    if (phase === 'resting') return true;
    return false;
}

function rdgAssistantAutoRecoverInvalidLongPause(reasonText) {
    if (!rdgAssistantState || !rdgAssistantState.run) return false;
    var run = rdgAssistantState.run;
    if (!rdgAssistantShouldClearInvalidLongPause(run)) return false;
    var recoveredActiveMs = Math.max(0, rdgAssistantComputeActiveWorkMs(run));

    var resumePhase = run.resumePhase || '';
    if (!resumePhase || resumePhase === 'resting' || resumePhase === 'waiting_rate_limit') {
        resumePhase = rdgAssistantInferResumePhase(run);
    }
    if (!resumePhase || resumePhase === 'resting' || resumePhase === 'waiting_rate_limit') {
        resumePhase = 'collecting';
    }

    rdgAssistantClearWaitResumeTimer();
    rdgAssistantClearAccountRestLock();
    run.status = 'running';
    run.phase = resumePhase;
    run.resumePhase = resumePhase;
    run.waitUntil = 0;
    run.waitReason = '';
    run.updatedAt = Date.now();
    rdgAssistantResetAccountWorkWindow(Date.now() - recoveredActiveMs);
    rdgAssistantGetAccountRuntime().workMsInWindow = recoveredActiveMs;
    rdgAssistantSyncRunWorkCounters(run);
    rdgAssistantSetAccountWorkLastTickAt(Date.now());
    rdgAssistantRestoreManualDelays();
    rdgAssistantMarkSessionActive();
    rdgAssistantLog(reasonText || 'Pausa longa invalida removida automaticamente apos recalculo do tempo ativo da conta.', resumePhase, true);
    outputMessage('[Assistente] Pausa longa invalida removida automaticamente. O tempo ativo recalculado da conta ainda esta abaixo de ' + ((rdgAssistantState.settings && rdgAssistantState.settings.workHoursPerDay) || 10) + 'h.');
    return true;
}

function rdgAssistantUpdateActiveHoursBanner() {
    var banner = document.getElementById('rdgAssistantActiveHoursBanner');
    if (!banner) return;
    if (!rdgAssistantState) {
        banner.style.display = 'none';
        return;
    }
    var runtime = rdgAssistantGetAccountRuntime();
    var run = rdgAssistantState.run || { status: 'idle', phase: '' };
    if (!run.status && runtime && (parseInt(runtime.workMsInWindow || 0, 10) || 0) > 0) run.status = 'paused';
    if (rdgAssistantHasAccountRestLock() && run.status !== 'paused' && run.status !== 'stopped') {
        run.status = 'resting';
        run.waitUntil = rdgAssistantGetAccountRestUntil();
    }
    var activeMs = rdgAssistantComputeActiveWorkMs(run);
    var statusLabel = run.status === 'running' ? 'rodando' : (run.status === 'waiting_instagram' ? 'aguardando' : (run.status === 'resting' ? 'descanso' : (run.status === 'paused' ? 'pausado' : String(run.status || ''))));
    var phaseLabel = run.phase ? String(run.phase) : '';
    var extra = '';
    if (run.status === 'resting' && run.waitUntil > Date.now()) {
        extra = ' | volta em ' + rdgAssistantFormatRelativeWait(run.waitUntil);
    } else if (run.status === 'waiting_instagram' && run.waitUntil > Date.now()) {
        extra = ' | retoma em ' + rdgAssistantFormatRelativeWait(run.waitUntil);
    }

    try {
        if (run.status === 'running') {
            banner.style.background = '#052e16';
            banner.style.borderColor = 'rgba(34,197,94,0.30)';
            banner.style.color = '#dcfce7';
        } else if (run.status === 'waiting_instagram') {
            banner.style.background = '#3a2a00';
            banner.style.borderColor = 'rgba(234,179,8,0.35)';
            banner.style.color = '#fff7d6';
        } else if (run.status === 'resting') {
            banner.style.background = '#0b2049';
            banner.style.borderColor = 'rgba(96,165,250,0.35)';
            banner.style.color = '#dbeafe';
        } else if (run.status === 'paused') {
            banner.style.background = '#1f2937';
            banner.style.borderColor = 'rgba(148,163,184,0.35)';
            banner.style.color = '#e5e7eb';
        } else {
            banner.style.background = '#0f172a';
            banner.style.borderColor = 'rgba(148,163,184,0.25)';
            banner.style.color = '#e2e8f0';
        }
    } catch (e) {}

    banner.textContent = 'Tempo ativo do assistente: ' + rdgAssistantFormatActiveDurationMs(activeMs) + ' | status: ' + statusLabel + (phaseLabel ? (' | etapa: ' + phaseLabel) : '') + extra;
    banner.style.display = 'block';
}

function rdgAssistantUpdateRestBanner() {
    var banner = document.getElementById('rdgAssistantRestBanner');
    if (!banner) return;
    var restUntil = rdgAssistantGetAccountRestUntil();
    if (!restUntil) {
        banner.style.display = 'none';
        return;
    }
    if (restUntil > Date.now()) {
        banner.textContent = 'Conta logada em descanso ate ' + rdgAssistantFormatDate(restUntil) + ' | volta em ' + rdgAssistantFormatRelativeWait(restUntil);
        banner.style.display = 'block';
        return;
    }
    banner.textContent = 'Conta logada finalizou o descanso em ' + rdgAssistantFormatDate(restUntil) + ' e esta pronta para uma nova janela.';
    banner.style.display = 'block';
}

function rdgAssistantGetProfilesForRun(runId) {
    var currentRunId = String(runId || '');
    if (!currentRunId || !rdgAssistantState || !Array.isArray(rdgAssistantState.profiles)) return [];
    return rdgAssistantState.profiles.filter(function(profile) {
        return profile && profile.assistant && profile.assistant.currentRunId === currentRunId;
    });
}

function rdgAssistantAreAllRunProfilesInteractionCompleted(run) {
    if (!run || !run.id) return false;
    var runProfiles = rdgAssistantGetProfilesForRun(run.id);
    if (!runProfiles.length) return false;
    return runProfiles.every(function(profile) {
        return profile && profile.assistant && profile.assistant.interactionCompletedAt;
    });
}

function rdgAssistantGetRunProfilesWaitingWarmup(run) {
    if (!run || !run.id) return [];
    return rdgAssistantGetProfilesForRun(run.id).filter(function(profile) {
        return profile && profile.assistant &&
            profile.assistant.interactionCompletedAt &&
            !profile.assistant.dmCompletedAt &&
            (parseInt(profile.assistant.warmingUntil || 0, 10) || 0) > Date.now();
    });
}

function rdgAssistantGetRunProfilesPendingDm(run) {
    if (!run || !run.id) return [];
    return rdgAssistantGetProfilesForRun(run.id).filter(function(profile) {
        return profile && profile.assistant &&
            profile.assistant.interactionCompletedAt &&
            !profile.assistant.dmCompletedAt;
    });
}

function rdgAssistantGetRunProgressSnapshot(run) {
    var targetPerProfile = parseInt((rdgAssistantState && rdgAssistantState.settings && rdgAssistantState.settings.targetPerProfile) || 10, 10) || 10;
    var runProfiles = run && run.id ? rdgAssistantGetProfilesForRun(run.id) : [];
    var totalProfiles = runProfiles.length || (rdgAssistantState && Array.isArray(rdgAssistantState.profiles) ? rdgAssistantState.profiles.length : 0) || 0;
    var completedProfiles = 0;
    var totalInteractions = 0;
    for (var i = 0; i < runProfiles.length; i++) {
        var assistant = runProfiles[i] && runProfiles[i].assistant ? runProfiles[i].assistant : {};
        var interactions = Math.min(targetPerProfile, parseInt(assistant.currentRunInteractions || 0, 10) || 0);
        totalInteractions += interactions;
        if (assistant.interactionCompletedAt) completedProfiles++;
    }
    var waitingProfiles = run ? rdgAssistantGetRunProfilesWaitingWarmup(run) : [];
    waitingProfiles.sort(function(a, b) {
        return (parseInt(a.assistant.warmingUntil || 0, 10) || 0) - (parseInt(b.assistant.warmingUntil || 0, 10) || 0);
    });
    return {
        totalProfiles: totalProfiles,
        completedProfiles: completedProfiles,
        targetPerProfile: targetPerProfile,
        totalInteractions: totalInteractions,
        totalGoal: totalProfiles * targetPerProfile,
        pendingWarmupProfiles: waitingProfiles.length,
        nextWarmupAt: waitingProfiles.length ? (parseInt(waitingProfiles[0].assistant.warmingUntil || 0, 10) || 0) : 0,
        pendingDmProfiles: run ? rdgAssistantGetRunProfilesPendingDm(run).length : 0,
        qualifiedCount: run ? (parseInt(run.dmQualifiedCount || 0, 10) || 0) : 0
    };
}

function rdgAssistantBuildRestPopupCopy(waitUntil) {
    var workHours = parseInt((rdgAssistantState && rdgAssistantState.settings && rdgAssistantState.settings.workHoursPerDay) || 10, 10) || 10;
    var restHours = parseInt((rdgAssistantState && rdgAssistantState.settings && rdgAssistantState.settings.restHoursPerDay) || 10, 10) || 10;
    var viewerUsername = rdgAssistantGetViewerUsername();
    var viewerLabel = viewerUsername ? ('@' + viewerUsername) : 'esta conta';
    return {
        title: 'Descanso automatico de ' + restHours + 'h iniciado',
        message: 'A conta ' + viewerLabel + ' chegou ao limite diario de trabalho configurado. Precisamos manter o descanso dessa mesma conta para proteger o algoritmo do Instagram.',
        subMessage: 'Descanso previsto: ' + restHours + 'h. Retomada estimada em ' + rdgAssistantFormatDate(waitUntil) + '. Tempo restante: ' + rdgAssistantFormatRelativeWait(waitUntil) + '. Se quiser continuar agora, use outra conta/perfil.'
    };
}

function rdgAssistantSetLiveProgress(action, targetUsername, nextActionAt, nextActionLabel) {
    if (!rdgAssistantState || !rdgAssistantState.run) return;
    rdgAssistantState.run.currentAction = action || '';
    rdgAssistantState.run.currentTargetUsername = targetUsername || '';
    rdgAssistantState.run.nextActionAt = parseInt(nextActionAt || 0, 10) || 0;
    rdgAssistantState.run.nextActionLabel = nextActionLabel || '';
}

function rdgAssistantGetLiveProgressSummary() {
    if (!rdgAssistantState || !rdgAssistantState.run) return '';
    var run = rdgAssistantState.run;
    var parts = [];
    if (run.currentAction) parts.push(run.currentAction);
    if (run.currentTargetUsername) parts.push('Pessoa atual: @' + String(run.currentTargetUsername).replace(/^@+/, ''));
    if (run.nextActionAt && run.nextActionAt > Date.now()) {
        var label = run.nextActionLabel || 'Proxima acao';
        parts.push(label + ' em ' + rdgAssistantFormatRelativeWait(run.nextActionAt));
    } else if (run.status === 'waiting_instagram' && run.waitUntil > Date.now()) {
        parts.push('Retomada em ' + rdgAssistantFormatRelativeWait(run.waitUntil));
    } else if (run.status === 'resting' && run.waitUntil > Date.now()) {
        parts.push('Descanso termina em ' + rdgAssistantFormatRelativeWait(run.waitUntil));
    }
    return parts.join(' | ');
}

function rdgAssistantGetCurrentStatusLine() {
    try {
        var statusDiv = document.getElementById('igBotStatusDiv');
        if (!statusDiv) return '';
        return String(statusDiv.textContent || '').trim();
    } catch (e) {
        return '';
    }
}

function rdgAssistantGetManualLogLines(limit) {
    try {
        var fakeConsole = document.getElementById('txtConsole');
        if (!fakeConsole) return [];
        var lines = String(fakeConsole.textContent || '').split('\n').map(function(line) {
            return String(line || '').trim();
        }).filter(function(line) {
            return !!line;
        });
        if (!lines.length) return [];
        return lines.slice(Math.max(0, lines.length - (limit || 4))).reverse();
    } catch (e) {
        return [];
    }
}

function rdgAssistantGetActiveProfileProgressText() {
    try {
        if (!rdgAssistantState || !rdgAssistantState.run || !rdgAssistantState.run.activeProfileId) return '';
        var activeProfile = rdgAssistantGetProfileById(rdgAssistantState.run.activeProfileId);
        if (!activeProfile || !activeProfile.assistant) return '';
        var targetTotal = rdgAssistantGetTargetPerProfile();
        return ' | Lista: ' + rdgAssistantFormatNumber(rdgAssistantGetCurrentRunInteractions(activeProfile, true)) + '/' + rdgAssistantFormatNumber(targetTotal) + ' interacoes | Convertidos: ' + rdgAssistantFormatNumber(activeProfile.assistant.currentRunConverted || 0) + '/' + rdgAssistantFormatNumber(targetTotal);
    } catch (e) {
        return '';
    }
}

function rdgAssistantGetProfileById(profileId) {
    if (!rdgAssistantState || !Array.isArray(rdgAssistantState.profiles)) return null;
    for (var i = 0; i < rdgAssistantState.profiles.length; i++) {
        if (String(rdgAssistantState.profiles[i].id) === String(profileId)) return rdgAssistantState.profiles[i];
    }
    return null;
}

function rdgAssistantCanStart() {
    if (!rdgAssistantState) return false;
    rdgAssistantNormalizeDmTemplates(rdgAssistantState);
    var activeCycle = null;
    if (Array.isArray(rdgAssistantState.cycles) && rdgAssistantState.activeCycleId) {
        for (var i = 0; i < rdgAssistantState.cycles.length; i++) {
            if (rdgAssistantState.cycles[i] && rdgAssistantState.cycles[i].id === rdgAssistantState.activeCycleId) {
                activeCycle = rdgAssistantState.cycles[i];
                break;
            }
        }
    }
    if (rdgAssistantIsCycleLocked(activeCycle)) return false;
    return rdgAssistantState.profiles.length >= rdgAssistantState.settings.minProfiles &&
        Array.isArray(rdgAssistantState.dmTemplates) &&
        rdgAssistantState.dmTemplates.length > 0;
}

function rdgAssistantGetTotals() {
    var totals = {
        collected: 0,
        interactions: 0,
        dms: 0
    };
    if (!rdgAssistantState || !Array.isArray(rdgAssistantState.profiles)) return totals;
    var targetTotal = parseInt((rdgAssistantState.settings && rdgAssistantState.settings.targetPerProfile) || 10, 10) || 10;
    rdgAssistantState.profiles.forEach(function(profile) {
        var assistant = profile.assistant || {};
        totals.collected += Math.min((Array.isArray(assistant.collectedAudience) ? assistant.collectedAudience.length : 0), targetTotal);
        totals.interactions += parseInt(assistant.totalInteractions || 0, 10) || 0;
        totals.dms += parseInt(assistant.totalDmSent || 0, 10) || 0;
    });
    return totals;
}

function rdgAssistantGetRunPopupKey() {
    if (!rdgCanShowUnlockedAutomationUi()) return '';
    if (!rdgAssistantState || !rdgAssistantState.run) return '';
    var run = rdgAssistantState.run;
    if (['running', 'waiting_instagram', 'resting', 'paused'].indexOf(run.status) === -1) return '';
    if (run.phase !== 'interacting') return '';
    return [
        run.id || '',
        run.status || '',
        run.phase || '',
        run.activeProfileId || ''
    ].join(':');
}

function rdgAssistantCloseRunPopup(markDismissed) {
    var popup = document.getElementById('rdgAssistantRunPopup');
    if (rdgAssistantRunPopupTimer) {
        clearTimeout(rdgAssistantRunPopupTimer);
        rdgAssistantRunPopupTimer = null;
    }
    if (markDismissed === true && rdgAssistantRunPopupKey) {
        rdgAssistantRunPopupDismissedKey = rdgAssistantRunPopupKey;
    }
    if (!popup) return;
    popup.classList.remove('active');
    popup.style.display = 'none';
}

function rdgAssistantOpenRunPopup(key, message, subMessage) {
    var popup = document.getElementById('rdgAssistantRunPopup');
    var popupMessage = document.getElementById('rdgAssistantRunPopupMessage');
    var popupSubMessage = document.getElementById('rdgAssistantRunPopupSubMessage');
    if (!popup || !key) return;
    if (popupMessage) popupMessage.textContent = message || 'Vamos mantendo voce informado. No momento nossa prospeccao esta ativa e estamos interagindo aos poucos para chamar atencao do publico semelhante/concorrente.';
    if (popupSubMessage) popupSubMessage.textContent = subMessage || 'Sistema ativo a todo vapor. Pode minimizar, mas nao feche e nem atualize esta pagina.';
    if (rdgAssistantRunPopupTimer) {
        clearTimeout(rdgAssistantRunPopupTimer);
        rdgAssistantRunPopupTimer = null;
    }
    popup.classList.remove('active');
    popup.style.display = 'flex';
    void popup.offsetWidth;
    popup.classList.add('active');
    rdgAssistantRunPopupKey = key;
    rdgAssistantRunPopupTimer = setTimeout(function() {
        rdgAssistantCloseRunPopup(true);
    }, 50000);
}

function rdgAssistantCloseNoticePopup() {
    var existing = document.getElementById('rdgAssistantNoticePopup');
    if (existing && existing.parentNode) {
        existing.parentNode.removeChild(existing);
    }
}

function rdgAssistantShowNoticePopup(title, message, subMessage, options) {
    rdgAssistantCloseNoticePopup();
    options = options || {};
    var dismissible = options.dismissible !== false;

    var overlay = document.createElement('div');
    overlay.id = 'rdgAssistantNoticePopup';
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(6,10,18,0.72);z-index:2147483646;display:flex;align-items:center;justify-content:center;padding:20px;';

    var card = document.createElement('div');
    card.style.cssText = 'width:min(520px,100%);background:#111827;color:#f9fafb;border:1px solid rgba(255,255,255,0.12);border-radius:18px;box-shadow:0 24px 60px rgba(0,0,0,0.45);padding:22px 22px 18px;';

    var badge = document.createElement('div');
    badge.textContent = options.badgeText || 'Assistente em descanso';
    badge.style.cssText = 'display:inline-block;padding:6px 10px;border-radius:999px;background:' + (options.badgeBg || 'rgba(59,130,246,0.18)') + ';color:' + (options.badgeColor || '#bfdbfe') + ';font-size:12px;font-weight:700;letter-spacing:0.02em;text-transform:uppercase;';
    card.appendChild(badge);

    var heading = document.createElement('div');
    heading.textContent = title || 'Descanso automatico iniciado';
    heading.style.cssText = 'margin-top:14px;font-size:22px;font-weight:700;line-height:1.3;';
    card.appendChild(heading);

    var body = document.createElement('div');
    body.textContent = message || 'O assistente entrou no descanso programado para proteger a conta.';
    body.style.cssText = 'margin-top:10px;font-size:15px;line-height:1.6;color:#e5e7eb;';
    card.appendChild(body);

    if (subMessage) {
        var sub = document.createElement('div');
        sub.textContent = subMessage;
        sub.style.cssText = 'margin-top:10px;font-size:13px;line-height:1.6;color:#cbd5e1;';
        card.appendChild(sub);
    }

    var actions = document.createElement('div');
    actions.style.cssText = 'margin-top:18px;display:flex;justify-content:flex-end;gap:10px;';

    var addButton = function(label, styleCss, onClick) {
        var btn = document.createElement('button');
        btn.textContent = label;
        btn.style.cssText = styleCss;
        btn.onclick = function() {
            try { if (typeof onClick === 'function') onClick(); } catch (e) {}
        };
        actions.appendChild(btn);
        return btn;
    };

    var hasCustomActions = !!(options.primaryText || options.secondaryText);
    if (hasCustomActions) {
        if (options.secondaryText) {
            addButton(
                options.secondaryText,
                'border:1px solid rgba(255,255,255,0.16);border-radius:10px;padding:10px 16px;background:rgba(148,163,184,0.12);color:#e5e7eb;font-weight:800;cursor:pointer;',
                function() {
                    rdgAssistantCloseNoticePopup();
                    if (typeof options.onSecondary === 'function') options.onSecondary();
                }
            );
        }
        if (options.primaryText) {
            addButton(
                options.primaryText,
                'border:0;border-radius:10px;padding:10px 16px;background:' + (options.primaryBg || '#16a34a') + ';color:#fff;font-weight:900;cursor:pointer;',
                function() {
                    rdgAssistantCloseNoticePopup();
                    if (typeof options.onPrimary === 'function') options.onPrimary();
                }
            );
        }
    } else {
        addButton(
            'Entendi',
            'border:0;border-radius:10px;padding:10px 16px;background:#2563eb;color:#fff;font-weight:700;cursor:pointer;',
            function() {
                rdgAssistantCloseNoticePopup();
            }
        );
    }

    card.appendChild(actions);
    overlay.appendChild(card);
    overlay.onclick = function(e) {
        if (dismissible && e.target === overlay) rdgAssistantCloseNoticePopup();
    };
    document.body.appendChild(overlay);
    var autoCloseMs = parseInt(options.autoCloseMs || 0, 10) || 0;
    if (dismissible && autoCloseMs > 0) {
        setTimeout(function() {
            rdgAssistantCloseNoticePopup();
        }, autoCloseMs);
    }
}

function rdgAssistantShowCycleSummaryPopup(interactionsCount, interestedCount, dmSentCount) {
    var interacted = Math.max(0, parseInt(interactionsCount || 0, 10) || 0);
    var interested = Math.max(0, parseInt(interestedCount || 0, 10) || 0);
    var dms = Math.max(0, parseInt(dmSentCount || 0, 10) || 0);
    rdgAssistantShowNoticePopup(
        'Ciclo finalizado',
        'Terminamos nosso ciclo. Chamamos atencao de ' + rdgAssistantFormatNumber(interacted) + ' pessoa(s), tivemos ' + rdgAssistantFormatNumber(interested) + ' interessado(s) e enviamos directs para ' + rdgAssistantFormatNumber(dms) + ' pessoa(s), realizando uma abordagem.',
        'Ciclo finalizado. Clique OK para fechar.',
        {
            badgeText: 'Resumo do Ciclo',
            badgeBg: 'rgba(34,197,94,0.18)',
            badgeColor: '#bbf7d0',
            dismissible: false,
            primaryText: 'OK',
            primaryBg: '#16a34a',
            onPrimary: function() {
                rdgAssistantCreateNextCycleFromCurrent();
            }
        }
    );
}

function rdgAssistantCloseDmProgressPopup() {
    var existing = document.getElementById('rdgAssistantDmProgressPopup');
    if (existing && existing.parentNode) existing.parentNode.removeChild(existing);
}

function rdgAssistantIsCycleLocked(cycle) {
    if (!cycle) return false;
    return cycle.locked === true || !!(cycle.run && cycle.run.status === 'completed');
}

function rdgAssistantBuildCycleSummaryText(cycle) {
    if (!cycle) return '';
    var summary = cycle.summary || {};
    var interactions = Math.max(0, parseInt(summary.interactions || 0, 10) || 0);
    var interested = Math.max(0, parseInt(summary.interested || 0, 10) || 0);
    var dms = Math.max(0, parseInt(summary.dms || 0, 10) || 0);
    if (!interactions && cycle.run && cycle.run.status === 'completed') {
        var targetTotal = parseInt((rdgAssistantState && rdgAssistantState.settings && rdgAssistantState.settings.targetPerProfile) || 10, 10) || 10;
        interactions = 0;
        interested = Math.max(0, parseInt(cycle.run.dmQualifiedCount || cycle.run.dmQueueSize || 0, 10) || 0);
        dms = Math.max(0, parseInt(cycle.run.dmSentCount || 0, 10) || 0);
        if (Array.isArray(cycle.profiles)) {
            cycle.profiles.forEach(function(profile) {
                var assistant = profile && profile.assistant ? profile.assistant : {};
                interactions += Math.min(targetTotal, parseInt(assistant.currentRunInteractions || assistant.totalInteractions || 0, 10) || 0);
            });
        }
    }
    return 'Resumo: ' + rdgAssistantFormatNumber(interactions) + ' interacoes | ' + rdgAssistantFormatNumber(interested) + ' interessados | ' + rdgAssistantFormatNumber(dms) + ' directs.';
}

function rdgAssistantStampActiveCycleCompletion(interactionsCount, interestedCount, dmSentCount) {
    if (!rdgAssistantState || !Array.isArray(rdgAssistantState.cycles) || !rdgAssistantState.activeCycleId) return false;
    for (var i = 0; i < rdgAssistantState.cycles.length; i++) {
        var cycle = rdgAssistantState.cycles[i];
        if (!cycle || cycle.id !== rdgAssistantState.activeCycleId) continue;
        cycle.locked = true;
        cycle.finalizedAt = Date.now();
        cycle.summary = {
            interactions: Math.max(0, parseInt(interactionsCount || 0, 10) || 0),
            interested: Math.max(0, parseInt(interestedCount || 0, 10) || 0),
            dms: Math.max(0, parseInt(dmSentCount || 0, 10) || 0)
        };
        cycle.updatedAt = Date.now();
        return true;
    }
    return false;
}

function rdgAssistantGetActiveCycle() {
    if (!rdgAssistantState || !Array.isArray(rdgAssistantState.cycles) || !rdgAssistantState.activeCycleId) return null;
    for (var i = 0; i < rdgAssistantState.cycles.length; i++) {
        if (rdgAssistantState.cycles[i] && rdgAssistantState.cycles[i].id === rdgAssistantState.activeCycleId) {
            return rdgAssistantState.cycles[i];
        }
    }
    return null;
}

function rdgAssistantShouldShowDmProgressPopup() {
    return !!(rdgCanShowUnlockedAutomationUi() &&
        rdgAssistantState &&
        rdgAssistantState.run &&
        rdgAssistantState.run.dmStarted === true &&
        rdgAssistantState.run.phase === 'sending_dm' &&
        ['running', 'waiting_instagram'].indexOf(rdgAssistantState.run.status) > -1);
}

function rdgAssistantShouldSuppressMassDmAlert() {
    return !!(rdgAssistantState && rdgAssistantState.run && rdgAssistantState.run.dmStarted === true);
}

function rdgAssistantHandleMassDmProgress(payload) {
    if (!rdgAssistantState || !rdgAssistantState.run || rdgAssistantState.run.dmStarted !== true) return false;
    payload = payload || {};
    if (typeof payload.total === 'number') rdgAssistantState.run.dmQueueSize = Math.max(0, parseInt(payload.total, 10) || 0);
    if (typeof payload.processed === 'number') rdgAssistantState.run.dmProcessedCount = Math.max(0, parseInt(payload.processed, 10) || 0);
    if (typeof payload.sent === 'number') rdgAssistantState.run.dmSentCount = Math.max(0, parseInt(payload.sent, 10) || 0);
    if (payload.statusText) rdgAssistantState.run.dmStatusText = String(payload.statusText);
    if (payload.currentUsername) rdgAssistantState.run.currentTargetUsername = String(payload.currentUsername).replace(/^@+/, '');
    if (payload.completed === true) rdgAssistantState.run.dmStatusText = payload.statusText || 'Envio em massa concluido.';
    rdgAssistantRenderDmProgressPopup();
    return true;
}

function rdgAssistantResumeMassDmFromStoragePromise() {
    return new Promise(function(resolve) {
        if (typeof betaResumeMassDMFromRuntime === 'function') {
            betaResumeMassDMFromRuntime(function(resumed) {
                resolve(resumed === true);
            });
            return;
        }
        resolve(false);
    });
}

function rdgAssistantLoadMassDmRuntimePromise() {
    return new Promise(function(resolve) {
        if (typeof betaLoadMassDmRuntime === 'function') {
            betaLoadMassDmRuntime(function(state) {
                resolve(state || null);
            });
            return;
        }
        resolve(null);
    });
}

function rdgAssistantRenderDmProgressPopup() {
    if (!rdgAssistantShouldShowDmProgressPopup()) {
        rdgAssistantCloseDmProgressPopup();
        return;
    }
    var run = rdgAssistantState.run;
    var total = Math.max(0, parseInt(run.dmQueueSize || 0, 10) || 0);
    var processed = Math.max(0, parseInt(run.dmProcessedCount || 0, 10) || 0);
    var sent = Math.max(0, parseInt(run.dmSentCount || 0, 10) || 0);
    var remaining = Math.max(0, total - processed);
    var statusText = run.dmStatusText || 'Preparando o envio em massa de mensagens.';
    var targetLabel = run.currentTargetUsername ? ('@' + String(run.currentTargetUsername).replace(/^@+/, '')) : 'fila do direct';
    var loadingInterested = total <= 0;
    var progressPercent = loadingInterested ? 18 : Math.max(4, Math.min(100, total > 0 ? Math.round((processed / total) * 100) : 0));

    var popup = document.getElementById('rdgAssistantDmProgressPopup');
    if (!popup) {
        popup = document.createElement('div');
        popup.id = 'rdgAssistantDmProgressPopup';
        popup.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:2147483645;width:min(460px,calc(100vw - 32px));background:linear-gradient(135deg,#081226 0%,#0b1734 100%);color:#f8fafc;border:1px solid rgba(255,255,255,0.12);border-radius:18px;box-shadow:0 24px 60px rgba(0,0,0,0.35);padding:18px 18px 16px;';
        document.body.appendChild(popup);
    }

    popup.innerHTML =
        '<div style="display:flex;align-items:flex-start;gap:14px;">' +
            '<div style="width:40px;height:40px;border-radius:999px;border:3px solid rgba(255,255,255,0.22);border-top-color:#22c55e;animation:rdgAssistantSpin 1s linear infinite;flex:0 0 auto;"></div>' +
            '<div style="flex:1 1 auto;min-width:0;">' +
                '<div style="display:inline-block;padding:5px 10px;border-radius:999px;background:rgba(34,197,94,0.18);color:#bbf7d0;font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.04em;">Envio em Massa</div>' +
                '<div style="margin-top:10px;font-size:22px;font-weight:800;line-height:1.25;">Disparo automatico em andamento</div>' +
                '<div style="margin-top:8px;font-size:14px;line-height:1.55;color:#dbeafe;">' + rdgEscapeHtml(statusText) + '</div>' +
                '<div style="margin-top:6px;font-size:13px;line-height:1.45;color:#93c5fd;">Tela atual: assistente | alvo atual: ' + rdgEscapeHtml(targetLabel) + '</div>' +
                '<div style="margin-top:12px;height:10px;border-radius:999px;background:rgba(255,255,255,0.08);overflow:hidden;">' +
                    '<div style="height:100%;width:' + progressPercent + '%;border-radius:999px;background:' + (loadingInterested ? 'linear-gradient(90deg,#38bdf8 0%,#60a5fa 100%)' : 'linear-gradient(90deg,#22c55e 0%,#14b8a6 100%)') + ';animation:' + (loadingInterested ? 'rdgAssistantLoadingBar 1.4s ease-in-out infinite alternate' : 'none') + ';"></div>' +
                '</div>' +
                '<div style="margin-top:8px;font-size:12px;color:#cbd5e1;">' + (loadingInterested ? 'Carregando interessados qualificados para montar a fila do direct...' : ('Fila pronta: ' + rdgAssistantFormatNumber(total) + ' interessado(s).')) + '</div>' +
                '<div style="margin-top:14px;display:grid;grid-template-columns:repeat(3,1fr);gap:10px;">' +
                    '<div style="background:rgba(255,255,255,0.05);border-radius:12px;padding:10px 12px;"><div style="font-size:22px;font-weight:800;">' + rdgAssistantFormatNumber(total) + '</div><div style="font-size:11px;color:#cbd5e1;text-transform:uppercase;">Interessados</div></div>' +
                    '<div style="background:rgba(255,255,255,0.05);border-radius:12px;padding:10px 12px;"><div style="font-size:22px;font-weight:800;">' + rdgAssistantFormatNumber(processed) + '</div><div style="font-size:11px;color:#cbd5e1;text-transform:uppercase;">Ja processados</div></div>' +
                    '<div style="background:rgba(255,255,255,0.05);border-radius:12px;padding:10px 12px;"><div style="font-size:22px;font-weight:800;">' + rdgAssistantFormatNumber(remaining) + '</div><div style="font-size:11px;color:#cbd5e1;text-transform:uppercase;">Restantes</div></div>' +
                '</div>' +
                '<div style="margin-top:10px;font-size:12px;color:#cbd5e1;">Directs enviados ate agora: ' + rdgAssistantFormatNumber(sent) + '</div>' +
            '</div>' +
        '</div>';

    if (!document.getElementById('rdgAssistantDmProgressPopupStyle')) {
        var style = document.createElement('style');
        style.id = 'rdgAssistantDmProgressPopupStyle';
        style.textContent = '@keyframes rdgAssistantSpin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}@keyframes rdgAssistantLoadingBar{from{opacity:.55;transform:translateX(-8%)}to{opacity:1;transform:translateX(8%)}}';
        document.head.appendChild(style);
    }
}

function rdgAssistantOpenTab(tabId) {
    var tab = document.getElementById(tabId);
    if (tab) tab.checked = true;
}

function rdgAssistantRenderProfiles() {
    var container = document.getElementById('rdgAssistantProfiles');
    var empty = document.getElementById('rdgAssistantProfilesEmpty');
    if (!container || !empty || !rdgAssistantState) return;
    container.innerHTML = '';
    if (!rdgAssistantState.profiles.length) {
        empty.style.display = 'block';
        return;
    }
    empty.style.display = 'none';
    var isRunActive = !!(rdgAssistantState.run && rdgAssistantState.run.status === 'running');
    var activeProfileId = isRunActive && rdgAssistantState.run && rdgAssistantState.run.activeProfileId ? String(rdgAssistantState.run.activeProfileId) : '';
    var lockUi = rdgAssistantIsLockingUi();
    rdgAssistantState.profiles.forEach(function(profile) {
        var assistant = profile.assistant || rdgAssistantDefaultProfileAssistantState();
        var targetTotal = rdgAssistantGetTargetPerProfile();
        var savedCount = Math.min((assistant.collectedAudience || []).length || 0, targetTotal);
        var isActive = !!activeProfileId && String(profile.id) === activeProfileId;
        var liveCopy = isActive ? rdgAssistantGetLiveStatusCopy(profile) : null;
        var card = document.createElement('div');
        card.className = 'rdgAssistantProfileCard' + (lockUi && !isActive ? ' is-dimmed' : '') + (isActive ? ' is-active' : '');
        var activeTop = '';
        if (isActive) {
            activeTop =
                '<div class="rdgAssistantActiveTop">' +
                    '<div class="rdgAssistantRobotWrap">' +
                        '<div class="rdgAssistantRobotBadge">🤖</div>' +
                        '<div class="rdgAssistantRobotSpeech">' +
                            '<strong>Conta em trabalho agora</strong>' +
                            '<span>' + liveCopy.message + '</span>' +
                            '<em>' + liveCopy.subMessage + '</em>' +
                        '</div>' +
                    '</div>' +
                    '<div class="rdgAssistantActiveDotWrap">' +
                        '<span class="rdgAssistantActiveDot"></span>' +
                        '<span class="rdgAssistantActiveLabel">Ativo</span>' +
                        '<div class="rdgAssistantActiveTooltip">Sistema ativo a todo vapor. Nao precisa fazer mais nada, apenas deixar ligado, sem fechar e sem atualizar essa pagina. Pode minimizar se quiser.</div>' +
                    '</div>' +
                '</div>';
        }
        card.innerHTML =
            activeTop +
            '<div class="rdgAssistantProfileHead">' +
                '<div class="rdgAssistantProfileAvatarWrap">' +
                    '<img class="rdgAssistantProfileAvatar" alt="perfil">' +
                    '<span class="rdgAssistantProfileAvatarStroke"></span>' +
                '</div>' +
                '<div class="rdgAssistantProfileMeta">' +
                    '<strong>@' + profile.username + '</strong>' +
                    '<span>' + (profile.full_name || 'Perfil concorrente') + '</span>' +
                '</div>' +
            '</div>' +
            '<div class="rdgAssistantProfileStats">' +
                '<div class="rdgAssistantMiniStat"><b>' + rdgAssistantFormatNumber(savedCount) + '</b><small>Publico salvo</small></div>' +
                '<div class="rdgAssistantMiniStat"><b>' + rdgAssistantFormatNumber(rdgAssistantGetCurrentRunInteractions(profile, true)) + '/' + rdgAssistantFormatNumber(targetTotal) + '</b><small>Interacoes</small></div>' +
                '<div class="rdgAssistantMiniStat"><b>' + rdgAssistantFormatNumber(assistant.currentRunConverted || 0) + '/' + rdgAssistantFormatNumber(targetTotal) + '</b><small>Convertidos</small></div>' +
                '<div class="rdgAssistantMiniStat"><b>' + rdgAssistantFormatNumber(assistant.totalDmSent || 0) + '</b><small>DM enviadas</small></div>' +
                '<div class="rdgAssistantMiniStat"><b>' + rdgAssistantFormatNumber(profile.follower_count || 0) + '</b><small>Seguidores</small></div>' +
            '</div>' +
            '<div class="rdgAssistantProfileActions">' +
                '<span class="rdgAssistantMuted">' + (assistant.currentStatus || 'Aguardando') + '</span>' +
                '<button type="button" class="rdgAssistantMiniBtn" data-remove-assistant-profile="' + profile.id + '">Remover</button>' +
            '</div>';
        var avatar = card.querySelector('.rdgAssistantProfileAvatar');
        if (avatar) {
            var avatarUrl = rdgAssistantResolveProfilePictureUrl(profile, profile.username);
            rdgAssistantAvatarDebug('Render avatar', {
                username: profile.username,
                savedUrl: profile.profile_pic_url || '',
                resolvedUrl: avatarUrl
            });
            avatar.decoding = 'async';
            if (rdgAssistantIsUsableImageUrl(avatarUrl)) {
                avatar.src = avatarUrl;
            } else {
                rdgAssistantRefreshProfileAvatar(profile);
            }
            avatar.onload = function(profileRef) {
                return function() {
                    rdgAssistantAvatarDebug('Avatar loaded', {
                        username: profileRef.username,
                        src: this.currentSrc || this.src || ''
                    });
                };
            }(profile);
            avatar.onerror = function(profileRef) {
                return function() {
                    rdgAssistantAvatarDebug('Avatar failed', {
                        username: profileRef.username,
                        attemptedSrc: this.currentSrc || this.src || '',
                        savedUrl: profileRef.profile_pic_url || ''
                    });
                    this.onerror = null;
                    rdgAssistantRefreshProfileAvatar(profileRef);
                };
            }(profile);
        }
        container.appendChild(card);
    });
}

function rdgAssistantGetLiveStatusCopy(profile) {
    var run = rdgAssistantState && rdgAssistantState.run ? rdgAssistantState.run : null;
    var username = profile && profile.username ? ('@' + profile.username) : 'a pagina atual';
    var phase = run && run.phase ? String(run.phase) : 'idle';
    if (phase === 'collecting') {
        return {
            message: 'Buscando publico alvo e chamando atencao, qualificando cada pessoa para uma melhor conversao em ' + username + '.',
            subMessage: 'Vamos mantendo voce informado do nosso passo a passo. Deixe a pagina ligada ate quando eu avisar.'
        };
    }
    if (phase === 'interacting') {
        return {
            message: 'Vamos mantendo voce informado. No momento nossa prospeccao esta ativa e estamos interagindo aos poucos para chamar atencao do publico semelhante/concorrente em ' + username + '.',
            subMessage: 'Sistema ativo a todo vapor. Pode minimizar, mas nao feche e nem atualize esta pagina.'
        };
    }
    if (phase === 'sending_dm') {
        return {
            message: 'Interessados rastreados e qualificados estao entrando agora no disparo automatico de mensagens em massa para ' + username + '.',
            subMessage: 'O envio segue automatico e o progresso aparece aqui mesmo na tela do assistente, sem precisar sair desta pagina.'
        };
    }
    if (phase === 'warming') {
        return {
            message: 'Aquecimento em andamento para manter o ciclo seguro antes do Direct automatico de ' + username + '.',
            subMessage: 'Nao precisa fazer nada agora. O sistema continua no tempo certo e avisa os proximos passos.'
        };
    }
    if (phase === 'unfollowing') {
        return {
            message: 'Abrindo espaco no perfil logado com ciclo de deixar de seguir em seguranca, sem sobrecarregar o Instagram.',
            subMessage: 'Seguimos trabalhando dentro da janela de tempo do assistente para depois continuar a prospeccao.'
        };
    }
    if (run && run.status === 'waiting_instagram') {
        return {
            message: 'Instagram pediu uma pausa temporaria. Estamos aguardando o tempo certo para retomar com seguranca.',
            subMessage: 'Pode deixar ligado. O assistente volta sozinho quando chegar a hora.'
        };
    }
    if (run && run.status === 'resting') {
        return {
            message: 'Modo descanso ativo para proteger a conta e o algoritmo do Instagram.',
            subMessage: 'Quando a janela de descanso terminar, voce pode retomar do ponto salvo.'
        };
    }
    if (run && run.status === 'paused') {
        return {
            message: 'O ciclo ficou pausado no ponto salvo e pronto para retomar sem perder o historico.',
            subMessage: 'Clique em Retomar quando quiser continuar.'
        };
    }
    return {
        message: 'Sistema preparado para rodar sua prospeccao ativa com publico de paginas semelhantes/concorrentes.',
        subMessage: 'Vamos mantendo voce informado do nosso passo a passo.'
    };
}

function rdgAssistantRenderHistory() {
    var container = document.getElementById('rdgAssistantHistory');
    var empty = document.getElementById('rdgAssistantHistoryEmpty');
    if (!container || !empty || !rdgAssistantState) return;
    container.innerHTML = '';
    if (!rdgAssistantState.history.length) {
        empty.style.display = 'block';
        return;
    }
    empty.style.display = 'none';
    rdgAssistantState.history.slice(0, 8).forEach(function(item) {
        var div = document.createElement('div');
        div.className = 'rdgAssistantHistoryItem';
        div.innerHTML =
            '<strong>' + (item.title || 'Historico do assistente') + '</strong>' +
            '<div class="rdgAssistantHistoryMeta">' + (item.description || '') + '</div>' +
            '<div class="rdgAssistantHistoryMeta">Data: ' + rdgAssistantFormatDate(item.timestamp) + '</div>';
        container.appendChild(div);
    });
}

function rdgAssistantRenderActivity() {
    var container = document.getElementById('rdgAssistantActivity');
    var empty = document.getElementById('rdgAssistantActivityEmpty');
    if (!container || !empty || !rdgAssistantState) return;
    container.innerHTML = '';
    var liveSummary = rdgAssistantGetLiveProgressSummary();
    var statusLine = rdgAssistantGetCurrentStatusLine();
    var manualLines = rdgAssistantGetManualLogLines(8);
    var progressText = rdgAssistantGetActiveProfileProgressText();
    if (!rdgAssistantState.run || (!liveSummary && !statusLine && !manualLines.length && (!Array.isArray(rdgAssistantState.run.logs) || !rdgAssistantState.run.logs.length))) {
        empty.style.display = 'block';
        return;
    }
    empty.style.display = 'none';
    if (statusLine) {
        var statusDiv = document.createElement('div');
        statusDiv.className = 'rdgAssistantActivityItem';
        statusDiv.innerHTML =
            '<strong>Agora: ' + statusLine + progressText + '</strong>' +
            '<div class="rdgAssistantActivityMeta">Status vivo do registro manual</div>';
        container.appendChild(statusDiv);
    } else if (liveSummary) {
        var liveDiv = document.createElement('div');
        liveDiv.className = 'rdgAssistantActivityItem';
        liveDiv.innerHTML =
            '<strong>Agora: ' + liveSummary + progressText + '</strong>' +
            '<div class="rdgAssistantActivityMeta">Fase: ' + ((rdgAssistantState.run && rdgAssistantState.run.phase) || '-') + ' | Atualizado em: ' + rdgAssistantFormatDate(Date.now()) + '</div>';
        container.appendChild(liveDiv);
    }
    manualLines.forEach(function(line) {
        var manualDiv = document.createElement('div');
        manualDiv.className = 'rdgAssistantActivityItem';
        manualDiv.innerHTML =
            '<strong>' + line + '</strong>' +
            '<div class="rdgAssistantActivityMeta">Registro espelhado da Fila de Contas</div>';
        container.appendChild(manualDiv);
    });
    var logs = rdgAssistantState.run && Array.isArray(rdgAssistantState.run.logs) ? rdgAssistantState.run.logs.slice(0, 12) : [];
    logs.forEach(function(item) {
        var div = document.createElement('div');
        div.className = 'rdgAssistantActivityItem';
        div.innerHTML =
            '<strong>' + (item.message || '') + '</strong>' +
            '<div class="rdgAssistantActivityMeta">Fase: ' + (item.phase || '-') + ' | Data: ' + rdgAssistantFormatDate(item.timestamp) + '</div>';
        container.appendChild(div);
    });
}

function rdgAssistantRenderLiveLogCard() {
    var card = document.getElementById('rdgAssistantLiveLogCard');
    var nowText = document.getElementById('rdgAssistantLiveLogNowText');
    if (!card || !nowText || !rdgAssistantState) return;

    var liveSummary = rdgAssistantGetLiveProgressSummary();
    var statusLine = rdgAssistantGetCurrentStatusLine();
    var fallbackText = 'Assim que voce iniciar, o assistente vai mostrar aqui a pessoa atual, a acao em andamento e quanto falta para a proxima etapa.';
    var progressText = rdgAssistantGetActiveProfileProgressText();
    nowText.textContent = (statusLine || liveSummary || fallbackText) + progressText;
}

function rdgAssistantOpenMiniPanelSection(key) {
    var panel = document.getElementById('rdgAssistantMiniPanel');
    var title = document.getElementById('rdgAssistantMiniPanelTitle');
    if (!panel || !title) return;

    var dotButtons = document.querySelectorAll('.rdgAssistantDotBtn[data-assistant-mini]');
    for (var i = 0; i < dotButtons.length; i++) dotButtons[i].classList.remove('active');

    var summary = document.getElementById('rdgAssistantMiniSectionSummary');
    var activity = document.getElementById('rdgAssistantMiniSectionActivity');
    var history = document.getElementById('rdgAssistantMiniSectionHistory');
    if (summary) summary.classList.remove('active');
    if (activity) activity.classList.remove('active');
    if (history) history.classList.remove('active');

    var clicked = document.querySelector('.rdgAssistantDotBtn[data-assistant-mini="' + key + '"]');
    if (clicked) clicked.classList.add('active');

    if (key === 'summary') {
        title.textContent = 'Resumo';
        if (summary) summary.classList.add('active');
    } else if (key === 'activity') {
        title.textContent = 'Atividades';
        if (activity) activity.classList.add('active');
    } else if (key === 'history') {
        title.textContent = 'Historico';
        if (history) history.classList.add('active');
    }

    panel.style.display = 'block';
}

function rdgAssistantUpdateProfileButtonLabel() {
    var button = document.getElementById('rdgAssistantAddProfileInline');
    if (!button) return;
    if (rdgAssistantAddProfileBusy) {
        button.innerHTML = '<svg style="animation:spin 1s linear infinite;width:15px;height:15px;flex-shrink:0;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> <span>Adicionando ao Piloto RDG...</span>';
        button.disabled = true;
        button.style.background = 'linear-gradient(135deg, #1e293b 0%, #334155 100%)';
        button.style.borderColor = 'rgba(148,163,184,0.3)';
        button.style.color = '#94a3b8';
        button.style.boxShadow = 'none';
        return;
    }
    var username = rdgAssistantResolveCurrentProfileUsername();
    if (!username) {
        button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg> <span>⚡ RDG: Adicionar Alvo VIP</span>';
        button.disabled = false;
        button.style.background = 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0369a1 100%)';
        button.style.borderColor = 'rgba(56,189,248,0.6)';
        button.style.color = '#38bdf8';
        return;
    }
    var normalizedUsername = String(username || '').toLowerCase();
    var already = false;
    if (rdgAssistantState && Array.isArray(rdgAssistantState.profiles)) {
        already = rdgAssistantState.profiles.some(function(profile) {
            return String(profile && profile.username ? profile.username : '').toLowerCase() === normalizedUsername;
        });
    }
    if (already) {
        button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><polyline points="20 6 9 17 4 12"></polyline></svg> <span style="color:#dcfce7;font-weight:800;">✓ Alvo Ativo no Piloto RDG</span>';
        button.disabled = true;
        button.style.background = 'linear-gradient(135deg, #064e3b 0%, #065f46 100%)';
        button.style.borderColor = 'rgba(16,185,129,0.6)';
        button.style.color = '#10b981';
        button.style.boxShadow = '0 4px 14px rgba(16,185,129,0.25)';
    } else {
        button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg> <span>⚡ RDG: Adicionar Alvo VIP</span>';
        button.disabled = false;
        button.style.background = 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0369a1 100%)';
        button.style.borderColor = 'rgba(56,189,248,0.6)';
        button.style.color = '#38bdf8';
        button.style.boxShadow = '0 6px 20px rgba(14,165,233,0.35), inset 0 1px 0 rgba(255,255,255,0.15)';
    }
}

function rdgAssistantResolveCurrentProfileUsername() {
    if (typeof currentProfilePage !== 'undefined' && currentProfilePage && currentProfilePage !== false && currentProfilePage.username) {
        return String(currentProfilePage.username).trim();
    }
    return rdgGetInstagramUsernameFromPage();
}

function rdgAssistantNormalizeImageUrl(url) {
    if (url && typeof url === 'object' && url.url) {
        url = url.url;
    }
    var value = String(url || '').trim();
    if (!value) return '';
    if ((value[0] === '"' && value[value.length - 1] === '"') || (value[0] === "'" && value[value.length - 1] === "'")) {
        value = value.slice(1, -1);
    }
    return value
        .replace(/\\u0026/g, '&')
        .replace(/\u0026/g, '&')
        .replace(/&amp;/g, '&')
        .replace(/\\\//g, '/');
}

function rdgAssistantIsUsableImageUrl(url) {
    var value = rdgAssistantNormalizeImageUrl(url);
    if (!value) return false;
    return /^(https?:)?\/\//i.test(value) || /^data:image\//i.test(value) || /^blob:/i.test(value);
}

function rdgAssistantAvatarDebug(label, payload) {
    try {
        console.log('[Assistente][Avatar] ' + label, payload || {});
    } catch (e) {}
}

function rdgAssistantGetCurrentProfileImageFromDom() {
    var images = Array.from(document.querySelectorAll('main header img, header img'));
    var bestUrl = '';
    var bestScore = 0;

    for (var i = 0; i < images.length; i++) {
        var img = images[i];
        if (!img) continue;

        var candidate = rdgAssistantNormalizeImageUrl(img.currentSrc || img.getAttribute('src') || img.src || '');
        if (!rdgAssistantIsUsableImageUrl(candidate)) {
            var srcset = String(img.getAttribute('srcset') || '').trim();
            if (srcset) {
                if (/^data:image\//i.test(srcset)) {
                    candidate = rdgAssistantNormalizeImageUrl(srcset);
                } else {
                    var srcsetMatch = srcset.match(/^\s*([^\s,]+)\s*(?:\d+[wx])?/);
                    candidate = rdgAssistantNormalizeImageUrl(srcsetMatch && srcsetMatch[1] ? srcsetMatch[1] : '');
                }
            }
        }

        if (!rdgAssistantIsUsableImageUrl(candidate)) continue;

        var naturalWidth = parseInt(img.naturalWidth || 0, 10) || 0;
        var naturalHeight = parseInt(img.naturalHeight || 0, 10) || 0;
        var visibleWidth = parseInt(img.clientWidth || img.width || 0, 10) || 0;
        var visibleHeight = parseInt(img.clientHeight || img.height || 0, 10) || 0;
        var score = Math.max(naturalWidth * naturalHeight, visibleWidth * visibleHeight);
        if (score < 1600) continue;

        if (score > bestScore) {
            bestScore = score;
            bestUrl = candidate;
        }
    }

    rdgAssistantAvatarDebug('DOM image selected', {
        bestUrl: bestUrl,
        bestScore: bestScore,
        imageCount: images.length,
        pageUsername: currentProfilePage && currentProfilePage.username ? currentProfilePage.username : ''
    });
    return bestUrl;
}

function rdgAssistantResolveProfilePictureUrl(profileData, username) {
    profileData = profileData || {};
    if (currentProfilePage && String(currentProfilePage.username || '').toLowerCase() === String(username || '').toLowerCase()) {
        var domImage = rdgAssistantGetCurrentProfileImageFromDom();
        if (rdgAssistantIsUsableImageUrl(domImage)) {
            rdgAssistantAvatarDebug('Using DOM image', {
                username: username,
                url: domImage
            });
            return domImage;
        }
    }
    var candidates = [
        profileData.profile_pic_url,
        profileData.profile_pic_url_hd,
        profileData.profile_pic_url_hd_https,
        profileData.profile_pic_url_info && profileData.profile_pic_url_info.url,
        profileData.hd_profile_pic_url_info && profileData.hd_profile_pic_url_info.url,
        profileData.hd_profile_pic_versions && profileData.hd_profile_pic_versions[0] && profileData.hd_profile_pic_versions[0].url
    ];
    for (var i = 0; i < candidates.length; i++) {
        var candidate = rdgAssistantNormalizeImageUrl(candidates[i]);
        if (rdgAssistantIsUsableImageUrl(candidate)) {
            rdgAssistantAvatarDebug('Using profileData image', {
                username: username,
                candidateIndex: i,
                url: candidate
            });
            return candidate;
        }
    }
    rdgAssistantAvatarDebug('No valid image resolved', {
        username: username,
        profileData: {
            profile_pic_url: profileData.profile_pic_url || '',
            profile_pic_url_hd: profileData.profile_pic_url_hd || '',
            profile_pic_url_hd_https: profileData.profile_pic_url_hd_https || '',
            profile_pic_url_info: profileData.profile_pic_url_info || null,
            hd_profile_pic_url_info: profileData.hd_profile_pic_url_info || null
        }
    });
    return '';
}

function rdgAssistantRefreshProfileAvatar(profile) {
    if (!profile || !profile.username) return;
    var username = String(profile.username || '').trim().toLowerCase();
    if (!username || rdgAssistantAvatarRefreshMap[username]) return;
    rdgAssistantAvatarRefreshMap[username] = true;
    rdgAssistantAvatarDebug('Refreshing avatar', {
        username: profile.username,
        savedUrl: profile.profile_pic_url || ''
    });
    rdgAssistantFetchProfileByUsername(profile.username).then(function(rawProfile) {
        var profileData = rawProfile && rawProfile.user ? rawProfile.user : rawProfile;
        var freshUrl = rdgAssistantResolveProfilePictureUrl(profileData, profile.username);
        rdgAssistantAvatarDebug('Refresh result', {
            username: profile.username,
            freshUrl: freshUrl,
            rawProfile: profileData || null
        });
        if (!freshUrl || !rdgAssistantState || !Array.isArray(rdgAssistantState.profiles)) return;
        var updated = false;
        for (var i = 0; i < rdgAssistantState.profiles.length; i++) {
            var item = rdgAssistantState.profiles[i];
            if (!item || String(item.username || '').toLowerCase() !== username) continue;
            item.profile_pic_url = freshUrl;
            updated = true;
            break;
        }
        if (updated) {
            rdgAssistantSaveState();
            rdgAssistantRender();
        }
    }).catch(function() {
    }).finally(function() {
        delete rdgAssistantAvatarRefreshMap[username];
    });
}

function rdgAssistantRenderCycles() {
    var dots = document.getElementById('rdgAssistantCyclesDots');
    var empty = document.getElementById('rdgAssistantCyclesEmpty');
    var modal = document.getElementById('rdgAssistantCycleModal');
    var expandTitle = document.getElementById('rdgAssistantCycleExpandTitle');
    var expandMeta = document.getElementById('rdgAssistantCycleExpandMeta');
    var expandInput = document.getElementById('rdgAssistantCycleNameInput');
    var btnActivate = document.getElementById('rdgAssistantCycleActivateBtn');
    var btnSave = document.getElementById('rdgAssistantCycleSaveBtn');
    var btnRemove = document.getElementById('rdgAssistantCycleRemoveBtn');
    if (!dots || !empty || !rdgAssistantState || !Array.isArray(rdgAssistantState.cycles)) return;
    dots.innerHTML = '';
    if (!rdgAssistantState.cycles.length) {
        empty.style.display = 'block';
        if (modal) modal.style.display = 'none';
        rdgAssistantSetExpandedCycleId(null);
        return;
    }
    empty.style.display = 'none';
    var expandedId = rdgAssistantGetExpandedCycleId();
    var expandedCycle = null;
    rdgAssistantState.cycles.forEach(function(cycle, idx) {
        if (!cycle || !cycle.id) return;
        var isActive = cycle.id === rdgAssistantState.activeCycleId;
        var isLocked = rdgAssistantIsCycleLocked(cycle);
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'rdgAssistantCycleDot' + (isActive ? ' active' : '') + (expandedId && expandedId === cycle.id ? ' open' : '') + (isLocked ? ' locked' : '');
        btn.setAttribute('data-cycle-id', cycle.id);
        btn.setAttribute('data-cycle-locked', isLocked ? '1' : '0');
        btn.textContent = String((idx + 1));
        dots.appendChild(btn);
        if (expandedId && expandedId === cycle.id) expandedCycle = cycle;
    });

    if (!modal || !expandTitle || !expandMeta || !expandInput || !btnActivate || !btnSave || !btnRemove) return;
    if (!expandedCycle) {
        modal.style.display = 'none';
        return;
    }

    var run = expandedCycle.run || null;
    var status = run ? (run.status || 'idle') : 'idle';
    var phase = run ? (run.phase || '-') : '-';
    var isLockedCycle = rdgAssistantIsCycleLocked(expandedCycle);
    var label = status === 'running' ? ('Rodando (' + phase + ')') : (status === 'waiting_instagram' ? 'Pausado (Instagram)' : (status === 'resting' ? 'Descansando' : (status === 'paused' ? 'Pausado' : (status === 'completed' ? 'Concluido' : 'Parado'))));
    expandTitle.textContent = expandedCycle.name || 'Ciclo';
    expandMeta.textContent = label + ' | Atualizado: ' + rdgAssistantFormatDate(expandedCycle.updatedAt) + (isLockedCycle ? ' | Ciclo finalizado e bloqueado. ' + rdgAssistantBuildCycleSummaryText(expandedCycle) : '');
    expandInput.value = expandedCycle.name || '';
    expandInput.disabled = isLockedCycle;
    expandInput.readOnly = isLockedCycle;
    btnActivate.textContent = isLockedCycle ? 'Finalizado' : (expandedCycle.id === rdgAssistantState.activeCycleId ? 'Ativo' : 'Ativar');
    btnActivate.disabled = !isLockedCycle && expandedCycle.id === rdgAssistantState.activeCycleId;
    btnActivate.setAttribute('data-cycle-id', expandedCycle.id);
    btnSave.disabled = isLockedCycle;
    btnSave.setAttribute('data-cycle-id', expandedCycle.id);
    btnRemove.disabled = false;
    btnRemove.setAttribute('data-cycle-id', expandedCycle.id);
    modal.style.display = 'flex';
}

function rdgAssistantIsLockingUi() {
    return false; // UI liberada, tabs continuam clicáveis
}

function rdgAssistantGetDelaySettings() {
    var minSec = rdgAssistantState && rdgAssistantState.settings ? parseInt(rdgAssistantState.settings.assistantDelayMinSec || 120, 10) : 120;
    var maxSec = rdgAssistantState && rdgAssistantState.settings ? parseInt(rdgAssistantState.settings.assistantDelayMaxSec || 168, 10) : 168;
    if (!isFinite(minSec) || minSec < 10) minSec = 120;
    if (!isFinite(maxSec) || maxSec < 10) maxSec = 168;
    if (maxSec < minSec) maxSec = minSec;
    return { minSec: minSec, maxSec: maxSec };
}

function rdgAssistantGetDmDelaySettings() {
    var minSec = rdgAssistantState && rdgAssistantState.settings ? parseInt(rdgAssistantState.settings.assistantDmDelayMinSec || 10, 10) : 10;
    var maxSec = rdgAssistantState && rdgAssistantState.settings ? parseInt(rdgAssistantState.settings.assistantDmDelayMaxSec || 30, 10) : 30;
    if (!isFinite(minSec) || minSec < 10) minSec = 10;
    if (!isFinite(maxSec) || maxSec < 10) maxSec = 30;
    if (minSec > 30) minSec = 10;
    if (maxSec > 30) maxSec = 30;
    if (maxSec < minSec) maxSec = minSec;
    return { minSec: minSec, maxSec: maxSec };
}

function rdgAssistantEstimatedHours(tasks) {
    var d = rdgAssistantGetDelaySettings();
    var avg = (d.minSec + d.maxSec) / 2;
    return (Math.max(0, parseInt(tasks || 0, 10) || 0) * avg) / 3600;
}

function rdgAssistantEnsureViewer() {
    try {
        if (user && user.viewer && user.viewer.username) return true;
    } catch (e) {}
    try {
        return extractUserInfoFromScriptTags() === true;
    } catch (e2) {
        return false;
    }
}

function rdgAssistantFetchMyAccountStats() {
    return new Promise(function(resolve) {
        if (!rdgAssistantEnsureViewer()) {
            resolve({ following: 0, followers: 0 });
            return;
        }
        $.ajax({
            url: '' + urlAcctInfo + user.viewer.username,
            method: 'GET',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: { withCredentials: true }
        }).done(function(r) {
            var u = extractJSONfromUserPageHTML(r);
            var following = u && u.edge_follow ? (parseInt(u.edge_follow.count || 0, 10) || 0) : 0;
            var followers = u && u.edge_followed_by ? (parseInt(u.edge_followed_by.count || 0, 10) || 0) : 0;
            resolve({ following: following, followers: followers });
        }).fail(function() {
            resolve({ following: 0, followers: 0 });
        });
    });
}

async function rdgAssistantLoadMyFollowingLimited(limit) {
    if (!rdgAssistantEnsureViewer()) return [];
    var take = Math.max(1, parseInt(limit || 0, 10) || 0);
    var out = [];
    var after = '';
    while (out.length < take) {
        var vars = { id: user.viewer.id, first: 48 };
        if (after) vars.after = after;
        var url = 'https://www.instagram.com/graphql/query/?query_hash=58712303d941c6855d4e888c5f0cd22f&variables=' + encodeURIComponent(JSON.stringify(vars));
        var resp = await $.ajax(url);
        var edges = resp && resp.data && resp.data.user && resp.data.user.edge_follow && resp.data.user.edge_follow.edges ? resp.data.user.edge_follow.edges : [];
        for (var i = 0; i < edges.length && out.length < take; i++) {
            if (edges[i] && edges[i].node) out.push(edges[i].node);
        }
        var pageInfo = resp && resp.data && resp.data.user && resp.data.user.edge_follow && resp.data.user.edge_follow.page_info ? resp.data.user.edge_follow.page_info : null;
        if (!pageInfo || pageInfo.has_next_page !== true || !pageInfo.end_cursor) break;
        after = pageInfo.end_cursor;
    }
    return out;
}

async function rdgAssistantStartUnfollowBatch(mode) {
    if (!rdgAssistantState || !rdgAssistantState.run) return false;
    if (typeof gblOptions === 'undefined' || !gblOptions) return false;
    var batch = Math.max(50, parseInt(rdgAssistantState.settings.assistantUnfollowBatchSize || 500, 10) || 500);
    rdgStopAllPendingActions('Preparando unfollow...');
    acctsQueue = [];
    mediaToLike = [];
    currentList = 'acctsQueue';

    gblOptions.limitQueue = true;
    gblOptions.maxAcctQueueLength = batch;
    try {
        var limitCb = document.getElementById('cbLimitQueueSize');
        var limitInput = document.getElementById('txtLimitQueueSize');
        if (limitCb) limitCb.checked = true;
        if (limitInput) limitInput.value = String(batch);
    } catch (e) {}

    var dontUnfollowFollowers = mode === 'non_followers';
    gblOptions.dontUnFollowFollowers = dontUnfollowFollowers;
    try {
        var cb = document.getElementById('cbDontUnfollowFollowers');
        if (cb) cb.checked = dontUnfollowFollowers;
    } catch (e2) {}

    saveOptions();

    var loaded = await rdgAssistantLoadMyFollowingLimited(batch);
    acctsQueue = loaded.map(function(a) { return $.extend(true, {}, a); });
    truncateQueue(0);
    arrayOfUsersToDiv(acctsQueue, true);
    $('#radioUnFollow').prop('checked', true);

    rdgAssistantState.run.phase = 'unfollowing';
    rdgAssistantState.run.unfollowMode = mode;
    rdgAssistantState.run.unfollowBatchStartedAt = Date.now();
    rdgAssistantLog('Iniciando unfollow de ' + acctsQueue.length + ' contas (' + (dontUnfollowFollowers ? 'somente quem nao te segue' : 'todos') + ').', 'unfollowing');

    initProcessQueue();
    return true;
}

function rdgAssistantCaptureManualDelaysIfNeeded() {
    if (!rdgAssistantState || !rdgAssistantState.run || typeof gblOptions === 'undefined' || !gblOptions) return;
    if (!rdgAssistantState.run.manualDelays) {
        rdgAssistantState.run.manualDelays = {
            timeDelay: parseInt(gblOptions.timeDelay || 0, 10) || 0,
            timeDelayAfterSkip: parseInt(gblOptions.timeDelayAfterSkip || 0, 10) || 0,
            useRandomTimeDelay: gblOptions.useRandomTimeDelay === true,
            percentRandomTimeDelay: parseFloat(gblOptions.percentRandomTimeDelay || 0) || 0
        };
    }
}

function rdgAssistantApplyAssistantDelays() {
    if (!rdgAssistantState || !rdgAssistantState.run || typeof gblOptions === 'undefined' || !gblOptions) return;
    rdgAssistantCaptureManualDelaysIfNeeded();
    var d = rdgAssistantGetDelaySettings();
    var baseMs = Math.round(((d.minSec + d.maxSec) / 2) * 1000);
    var skipMs = Math.max(1000, (parseInt((rdgAssistantState.settings && rdgAssistantState.settings.assistantSkipDelaySec) || 8, 10) || 8) * 1000);
    var halfRangeMs = Math.max(0, Math.round(((d.maxSec - d.minSec) / 2) * 1000));
    var percent = baseMs > 0 ? (halfRangeMs / baseMs) : 0;
    gblOptions.useRandomTimeDelay = true;
    gblOptions.percentRandomTimeDelay = percent;
    gblOptions.timeDelay = baseMs;
    gblOptions.timeDelayAfterSkip = skipMs;
}

function rdgAssistantRestoreManualDelays() {
    if (!rdgAssistantState || !rdgAssistantState.run || typeof gblOptions === 'undefined' || !gblOptions) return;
    var md = rdgAssistantState.run.manualDelays;
    if (!md) return;
    gblOptions.timeDelay = parseInt(md.timeDelay || 0, 10) || gblOptions.timeDelay;
    gblOptions.timeDelayAfterSkip = parseInt(md.timeDelayAfterSkip || 0, 10) || gblOptions.timeDelayAfterSkip;
    gblOptions.useRandomTimeDelay = md.useRandomTimeDelay === true;
    gblOptions.percentRandomTimeDelay = parseFloat(md.percentRandomTimeDelay || 0) || gblOptions.percentRandomTimeDelay;
}

function rdgAssistantRender() {
    if (!rdgAssistantState) return;
    rdgAssistantNormalizeDmTemplates(rdgAssistantState);
    rdgAssistantRenderDmProgressPopup();
    var totals = rdgAssistantGetTotals();
    rdgAssistantUpdateActiveHoursBanner();
    rdgAssistantUpdateRestBanner();
    var runProgress = rdgAssistantGetRunProgressSnapshot(rdgAssistantState.run);
    var accountRestUntil = rdgAssistantGetAccountRestUntil();
    var hasAccountRestLock = accountRestUntil > Date.now();
    var profilesCount = document.getElementById('rdgAssistantProfilesCount');
    var collectedCount = document.getElementById('rdgAssistantCollectedCount');
    var interactionsCount = document.getElementById('rdgAssistantInteractionsCount');
    var dmCount = document.getElementById('rdgAssistantDmCount');
    var requirements = document.getElementById('rdgAssistantRequirements');
    var statusBadge = document.getElementById('rdgAssistantStatusBadge');
    var startBtn = document.getElementById('rdgAssistantStart');
    var dmTemplate = document.getElementById('rdgAssistantDmTemplate');
    var dmTemplate2 = document.getElementById('rdgAssistantDmTemplate2');
    var dmTemplate3 = document.getElementById('rdgAssistantDmTemplate3');
    var saveDmBtn = document.getElementById('rdgAssistantSaveDm');
    var openDirectBtn = document.getElementById('rdgAssistantOpenDirect');
    var dmCard = document.getElementById('rdgAssistantDmCard');
    var dmToggle = document.getElementById('rdgAssistantDmToggle');
    var dmBody = document.getElementById('rdgAssistantDmBody');
    var dmCollapsedPreview = document.getElementById('rdgAssistantDmCollapsedPreview');
    var dmCollapsedText = document.getElementById('rdgAssistantDmCollapsedText');
    var dmStatusIcon = document.getElementById('rdgAssistantDmStatusIcon');
    var dmChevron = document.getElementById('rdgAssistantDmChevron');
    var dmHeaderText = document.getElementById('rdgAssistantDmHeaderText');
    var startCard = document.getElementById('rdgAssistantStartCard');
    var summary = document.getElementById('rdgAssistantCascadeSummary');
    var flow1 = document.getElementById('rdgAssistantFlowStep1');
    var flow2 = document.getElementById('rdgAssistantFlowStep2');
    var flow3 = document.getElementById('rdgAssistantFlowStep3');
    var flow1Status = document.getElementById('rdgAssistantFlowStep1Status');
    var flow2Status = document.getElementById('rdgAssistantFlowStep2Status');
    var flow3Status = document.getElementById('rdgAssistantFlowStep3Status');
    var glowBar = document.getElementById('rdgAssistantGlowBar');
    var glowText = document.getElementById('rdgAssistantGlowText');
    var pauseBtn = document.getElementById('rdgAssistantPause');
    var stopBtn = document.getElementById('rdgAssistantStop');
    var activeCycle = rdgAssistantGetActiveCycle();
    var activeCycleLocked = rdgAssistantIsCycleLocked(activeCycle);
    var profilesReady = rdgAssistantState.profiles.length >= rdgAssistantState.settings.minProfiles;
    var messageReady = Array.isArray(rdgAssistantState.dmTemplates) && rdgAssistantState.dmTemplates.length > 0;
    var startReady = !activeCycleLocked && profilesReady && messageReady;
    var hasActiveRun = rdgAssistantState.run && ['running', 'waiting_instagram', 'resting', 'paused'].indexOf(rdgAssistantState.run.status) > -1;
    var isRunActive = !!(rdgAssistantState.run && rdgAssistantState.run.status === 'running');
    if (!messageReady) rdgAssistantDmExpanded = true;
    if (profilesCount) profilesCount.textContent = rdgAssistantState.profiles.length + '/' + rdgAssistantState.settings.minProfiles;
    if (collectedCount) collectedCount.textContent = rdgAssistantFormatNumber(totals.collected);
    if (interactionsCount) interactionsCount.textContent = rdgAssistantFormatNumber(totals.interactions);
    if (dmCount) dmCount.textContent = rdgAssistantFormatNumber(totals.dms);
    if (dmTemplate && document.activeElement !== dmTemplate) dmTemplate.value = rdgAssistantState.dmTemplate || '';
    if (dmTemplate2 && document.activeElement !== dmTemplate2) dmTemplate2.value = (rdgAssistantState.dmTemplates && rdgAssistantState.dmTemplates[1]) || '';
    if (dmTemplate3 && document.activeElement !== dmTemplate3) dmTemplate3.value = (rdgAssistantState.dmTemplates && rdgAssistantState.dmTemplates[2]) || '';

    var requirementLines = [];
    if (activeCycleLocked) {
        requirementLines.push('Este ciclo foi finalizado e bloqueado. ' + rdgAssistantBuildCycleSummaryText(activeCycle));
    } else if (rdgAssistantState.profiles.length < rdgAssistantState.settings.minProfiles) {
        requirementLines.push('Faltam ' + (rdgAssistantState.settings.minProfiles - rdgAssistantState.profiles.length) + ' perfil(is) para liberar o Start.');
    } else {
        requirementLines.push('Perfis minimos OK.');
    }
    if (!messageReady) {
        requirementLines.push('Salve pelo menos 1 mensagem do direct no proprio assistente.');
    } else {
        requirementLines.push('Mensagem do direct salva' + (rdgAssistantState.dmTemplates.length > 1 ? ' (' + rdgAssistantState.dmTemplates.length + ' variacoes).' : '.'));
    }
    if (requirements) requirements.innerHTML = requirementLines.join('<br>');

    if (statusBadge) {
        if (activeCycleLocked) {
            statusBadge.textContent = 'Ciclo finalizado e bloqueado. Crie um novo ciclo para usar novamente.';
        } else if (rdgAssistantState.run && rdgAssistantState.run.status === 'paused') {
            statusBadge.textContent = 'Pausado manualmente.' + (hasAccountRestLock ? (' Descanso da conta logada segue ativo: retoma em ' + rdgAssistantFormatRelativeWait(accountRestUntil) + '.') : ' Clique em Retomar para continuar.');
        } else if (hasAccountRestLock) {
            statusBadge.textContent = 'Descanso da conta logada ativo: retoma em ' + rdgAssistantFormatRelativeWait(accountRestUntil);
        } else if (rdgAssistantState.run && rdgAssistantState.run.status === 'waiting_instagram') {
            statusBadge.textContent = 'Pausado: aguardando ' + rdgAssistantFormatRelativeWait(rdgAssistantState.run.waitUntil);
        } else if (rdgAssistantState.run && rdgAssistantState.run.status === 'resting') {
            statusBadge.textContent = 'Descansando: retoma em ' + rdgAssistantFormatRelativeWait(rdgAssistantState.run.waitUntil);
        } else if (rdgAssistantState.run && rdgAssistantState.run.status === 'running') {
            statusBadge.textContent = 'Rodando: ' + (rdgAssistantState.run.phase || 'processando');
        } else if (rdgAssistantCanStart()) {
            statusBadge.textContent = 'Configurado e pronto para iniciar';
        } else {
            statusBadge.textContent = 'Aguardando configuracao inicial';
        }
    }

    if (startBtn) {
        var run = rdgAssistantState.run;
        var isExecutingRun = !!(run && ['running', 'waiting_instagram', 'resting'].indexOf(run.status) > -1);
        if (activeCycleLocked) {
            startBtn.disabled = false;
            startBtn.textContent = 'FINALIZADO';
        } else if (run && run.status === 'paused') {
            startBtn.disabled = false;
            startBtn.textContent = 'RETOMAR';
        } else if (hasAccountRestLock) {
            startBtn.disabled = true;
            startBtn.textContent = 'DESCANSO';
        } else if (isExecutingRun) {
            startBtn.disabled = true;
            startBtn.textContent = run.status === 'running' ? 'RODANDO' : 'AGUARDANDO';
        } else {
            startBtn.disabled = !startReady && !hasActiveRun;
            startBtn.textContent = hasActiveRun ? 'RETOMAR' : 'START';
        }
    }

    if (pauseBtn) {
        var canPause = rdgAssistantState.run && rdgAssistantState.run.status === 'running';
        pauseBtn.style.display = canPause ? 'inline-flex' : 'none';
    }
    if (stopBtn) {
        var canStop = !!(rdgAssistantState.run && ['running', 'waiting_instagram', 'resting'].indexOf(rdgAssistantState.run.status) > -1);
        stopBtn.disabled = !canStop;
    }

    if (glowBar && glowText) {
        var showGlow = rdgAssistantState.run && rdgAssistantState.run.status === 'running' && rdgAssistantState.run.phase === 'collecting';
        glowBar.classList.toggle('active', showGlow);
        if (showGlow) {
            glowText.textContent = 'Carregando o publico quente (alta chance de conversao)...';
        } else {
            glowText.textContent = '';
        }
    }

    try {
        var root = document.getElementById('igBotInjectedContainer');
        if (root) root.classList.toggle('rdgAssistantLockTabs', rdgAssistantIsLockingUi());
    } catch (e) {}
    try {
        var wrap = document.querySelector('#tab6 .rdgAssistantWrap');
        if (wrap) wrap.classList.toggle('rdgAssistantRunMode', !!(rdgAssistantState.run && rdgAssistantState.run.status === 'running'));
        var activeProfile = null;
        if (rdgAssistantState.run && rdgAssistantState.run.activeProfileId) {
            activeProfile = rdgAssistantGetProfileById(rdgAssistantState.run.activeProfileId);
        }
        var liveCopy = rdgAssistantGetLiveStatusCopy(activeProfile);
        var popupKey = rdgAssistantGetRunPopupKey();
        var suppressRunPopup = !!(rdgAssistantState.run && rdgAssistantState.run.phase === 'sending_dm');
        if (suppressRunPopup) {
            rdgAssistantCloseRunPopup(false);
            rdgAssistantRunPopupKey = '';
        } else if (isRunActive && popupKey) {
            if (popupKey !== rdgAssistantRunPopupDismissedKey && popupKey !== rdgAssistantRunPopupKey) {
                rdgAssistantOpenRunPopup(popupKey, liveCopy.message, liveCopy.subMessage);
            }
        } else {
            rdgAssistantCloseRunPopup(false);
            rdgAssistantRunPopupKey = '';
            rdgAssistantRunPopupDismissedKey = '';
        }
    } catch (e) {}

    if (dmTemplate) dmTemplate.disabled = !profilesReady;
    if (dmTemplate2) dmTemplate2.disabled = !profilesReady;
    if (dmTemplate3) dmTemplate3.disabled = !profilesReady;
    if (saveDmBtn) {
        saveDmBtn.style.pointerEvents = profilesReady ? 'auto' : 'none';
        saveDmBtn.style.opacity = profilesReady ? '1' : '0.55';
    }
    if (openDirectBtn) {
        openDirectBtn.style.pointerEvents = profilesReady ? 'auto' : 'none';
        openDirectBtn.style.opacity = profilesReady ? '1' : '0.55';
    }
    if (dmToggle) {
        dmToggle.style.pointerEvents = profilesReady ? 'auto' : 'none';
        dmToggle.style.opacity = profilesReady ? '1' : '0.7';
    }
    if (dmBody) dmBody.style.display = rdgAssistantDmExpanded ? 'grid' : 'none';
    if (dmCollapsedPreview) dmCollapsedPreview.style.display = (!rdgAssistantDmExpanded && messageReady) ? 'block' : 'none';
    if (dmCollapsedText) dmCollapsedText.textContent = rdgAssistantGetDmTemplatesSummary();
    if (dmStatusIcon) {
        dmStatusIcon.textContent = messageReady ? '✓' : '2';
        dmStatusIcon.classList.toggle('ok', messageReady);
    }
    if (dmChevron) dmChevron.textContent = rdgAssistantDmExpanded ? '-' : '+';
    if (dmHeaderText) {
        if (!profilesReady) dmHeaderText.textContent = 'Primeiro adicione os perfis minimos para liberar esta etapa.';
        else if (messageReady && !rdgAssistantDmExpanded) dmHeaderText.textContent = 'Mensagem aprovada e salva' + (rdgAssistantState.dmTemplates.length > 1 ? ' com variacoes' : '') + '. Clique para editar quando quiser.';
        else if (messageReady) dmHeaderText.textContent = 'Mensagem configurada. Se quiser, adicione ate 3 variacoes e salve novamente.';
        else dmHeaderText.textContent = 'Depois de adicionar os perfis, salve aqui de 1 a 3 mensagens que o assistente vai usar no final da estrategia.';
    }

    if (dmCard) {
        dmCard.classList.toggle('rdgAssistantSectionLocked', !profilesReady);
    }
    if (startCard) {
        startCard.classList.toggle('rdgAssistantSectionLocked', !startReady && !hasActiveRun);
    }

    if (flow1) {
        flow1.classList.remove('active', 'completed', 'locked');
        flow1.classList.add(profilesReady ? 'completed' : 'active');
    }
    if (flow2) {
        flow2.classList.remove('active', 'completed', 'locked');
        if (!profilesReady) flow2.classList.add('locked');
        else if (messageReady) flow2.classList.add('completed');
        else flow2.classList.add('active');
    }
    if (flow3) {
        flow3.classList.remove('active', 'completed', 'locked');
        if (!profilesReady || !messageReady) flow3.classList.add('locked');
        else if (hasActiveRun || (rdgAssistantState.run && rdgAssistantState.run.status === 'completed')) flow3.classList.add('completed');
        else flow3.classList.add('active');
    }

    if (flow1Status) {
        flow1Status.textContent = profilesReady ? 'Concluido' : ('Faltam ' + (rdgAssistantState.settings.minProfiles - rdgAssistantState.profiles.length) + ' perfil(is)');
    }
    if (flow2Status) {
        if (!profilesReady) flow2Status.textContent = 'Aguardando etapa 1';
        else flow2Status.textContent = messageReady ? ('Mensagem salva' + (rdgAssistantState.dmTemplates.length > 1 ? ' (' + rdgAssistantState.dmTemplates.length + ' variacoes)' : '')) : 'Salvar mensagem';
    }
    if (flow3Status) {
        if (!profilesReady || !messageReady) flow3Status.textContent = 'Aguardando etapas anteriores';
        else if (rdgAssistantState.run && rdgAssistantState.run.phase === 'sending_dm') flow3Status.textContent = 'Interessados qualificados: ' + rdgAssistantFormatNumber(runProgress.qualifiedCount || 0) + ' | Disparando mensagens';
        else if (hasActiveRun && runProgress.totalProfiles > 0 && runProgress.completedProfiles < runProgress.totalProfiles) flow3Status.textContent = 'Interacoes concluidas: ' + runProgress.completedProfiles + '/' + runProgress.totalProfiles + ' perfis';
        else if (hasActiveRun && runProgress.nextWarmupAt > Date.now()) flow3Status.textContent = 'Direct liberado em: ' + rdgAssistantFormatDate(runProgress.nextWarmupAt);
        else if (hasActiveRun && runProgress.pendingDmProfiles > 0) flow3Status.textContent = 'Direct pronto para disparo automatico';
        else if (hasActiveRun) flow3Status.textContent = 'Assistente em andamento';
        else if (rdgAssistantState.run && rdgAssistantState.run.status === 'completed') flow3Status.textContent = 'Ultima rodada concluida';
        else flow3Status.textContent = 'Pronto para iniciar';
    }

    if (summary) {
        var summaryLines = [];
        summaryLines.push((profilesReady ? 'Etapa 1 concluida:' : 'Etapa 1 pendente:') + ' ' + rdgAssistantState.profiles.length + '/' + rdgAssistantState.settings.minProfiles + ' perfis adicionados.');
        summaryLines.push((messageReady ? 'Etapa 2 concluida:' : 'Etapa 2 pendente:') + ' ' + (messageReady ? ('mensagem salva no assistente' + (rdgAssistantState.dmTemplates.length > 1 ? ' com ' + rdgAssistantState.dmTemplates.length + ' variacoes.' : '.')) : 'salve pelo menos 1 mensagem do direct.'));
        summaryLines.push((startReady ? 'Etapa 3 liberada:' : 'Etapa 3 bloqueada:') + ' ' + (startReady ? 'o Start ja pode ser usado.' : 'o Start sera liberado depois das duas etapas acima.'));
        summaryLines.push('Meta do ciclo: ' + rdgAssistantState.settings.minProfiles + ' perfis x ' + rdgAssistantState.settings.targetPerProfile + ' pessoas = ' + rdgAssistantFormatNumber((rdgAssistantState.settings.minProfiles * rdgAssistantState.settings.targetPerProfile)) + ' interacoes.');
        var delaySettings = rdgAssistantGetDelaySettings();
        var avgSec = Math.round((delaySettings.minSec + delaySettings.maxSec) / 2);
        var estHours = rdgAssistantEstimatedHours(rdgAssistantState.settings.targetPerProfile || 10);
        summaryLines.push('Delay do assistente: ' + delaySettings.minSec + ' a ' + delaySettings.maxSec + ' segundos (randomizado).');
        summaryLines.push('Media por tarefa: ' + avgSec + 's | Estimativa: ~' + (Math.round(estHours * 10) / 10) + 'h para ' + (rdgAssistantState.settings.targetPerProfile || 10) + ' interacoes (por perfil).');
        if (runProgress.totalProfiles > 0) {
            summaryLines.push('Interacoes concluidas: ' + runProgress.completedProfiles + '/' + runProgress.totalProfiles + ' perfis | Total da rodada: ' + rdgAssistantFormatNumber(runProgress.totalInteractions) + '/' + rdgAssistantFormatNumber(runProgress.totalGoal) + ' interacoes.');
            if (rdgAssistantState.run && rdgAssistantState.run.phase === 'sending_dm') {
                summaryLines.push('Direct automatico em massa: interessados rastreados e qualificados = ' + rdgAssistantFormatNumber(runProgress.qualifiedCount || 0) + '. Disparo em andamento.');
            } else if (runProgress.nextWarmupAt > Date.now()) {
                summaryLines.push('Direct liberado em: ' + rdgAssistantFormatDate(runProgress.nextWarmupAt) + ' depois do aquecimento automatico de 7 dias dos 3 perfis.');
            } else if (runProgress.pendingDmProfiles > 0) {
                summaryLines.push('Direct liberado: os 3 perfis fecharam as ' + rdgAssistantGetTargetPerProfile() + ' interacoes de cada. O assistente vai rastrear os interessados e iniciar o disparo automatico.');
            }
        }
        summary.innerHTML = summaryLines.join('<br>');
    }

    rdgAssistantRenderCycles();
    rdgAssistantRenderProfiles();
    rdgAssistantRenderActivity();
    rdgAssistantRenderLiveLogCard();
    rdgAssistantRenderHistory();
    rdgAssistantUpdateProfileButtonLabel();
}

function rdgAssistantAddHistory(title, description) {
    if (!rdgAssistantState) return;
    rdgAssistantState.history.unshift({
        title: title,
        description: description,
        timestamp: Date.now()
    });
    rdgAssistantState.history = rdgAssistantState.history.slice(0, 50);
}

function rdgAssistantPushRuntimeLog(message, phase) {
    if (!rdgAssistantState || !rdgAssistantState.run) return;
    var cleanMessage = String(message || '').trim();
    if (!cleanMessage) return;
    rdgAssistantState.run.logs.unshift({
        message: cleanMessage,
        phase: phase || rdgAssistantState.run.phase || 'idle',
        timestamp: Date.now()
    });
    rdgAssistantState.run.logs = rdgAssistantState.run.logs.slice(0, 80);
}

function rdgAssistantLog(message, phase, skipConsole) {
    if (!rdgAssistantState || !rdgAssistantState.run) return;
    rdgAssistantPushRuntimeLog(message, phase);
    if (skipConsole === true) {
        rdgAssistantSaveState();
        rdgAssistantRender();
        return;
    }
    rdgAssistantConsoleMessage(message);
}

function rdgAssistantSetProfileStatus(profile, status) {
    if (!profile || !profile.assistant) return;
    profile.assistant.currentStatus = status;
    profile.assistant.lastUpdatedAt = Date.now();
}

function rdgAssistantPushUniqueAcct(list, seenMap, acct, exclusionMap) {
    var normalized = rdgAssistantSlimAcct(acct);
    if (!normalized.id || !normalized.username) return false;
    if (exclusionMap && exclusionMap[normalized.id]) return false;
    if (normalized.followed_by_viewer === true || normalized.requested_by_viewer === true) return false;
    if (seenMap[normalized.id]) return false;
    seenMap[normalized.id] = true;
    list.push(normalized);
    return true;
}

function rdgAssistantIsProfilePage() {
    var username = rdgGetInstagramUsernameFromPage();
    if (username && username !== '') return true;
    var parts = window.location.pathname.split('/').filter(Boolean);
    if (!parts.length) return false;
    return ['p', 'reel', 'reels', 'explore', 'direct', 'stories', 'accounts', 'tags'].indexOf(parts[0].toLowerCase()) === -1;
}

function rdgAssistantEnsureProfileButton() {
    var existing = document.getElementById('rdgAssistantAddProfileInline');
    var isProf = rdgAssistantIsProfilePage();
    if (!isProf) {
        if (existing) existing.remove();
        return;
    }
    var header = document.querySelector('main header') ||
                 document.querySelector('header section') ||
                 document.querySelector('section section') ||
                 document.querySelector('header') ||
                 document.querySelector('main section');
    if (!header) return;
    if (existing) {
        rdgAssistantUpdateProfileButtonLabel();
        return;
    }
    var container = document.createElement('div');
    container.style.marginTop = '14px';
    container.style.marginBottom = '14px';
    container.style.display = 'flex';
    container.style.justifyContent = 'center';
    container.style.width = '100%';

    var button = document.createElement('button');
    button.type = 'button';
    button.id = 'rdgAssistantAddProfileInline';
    button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg> <span>+ Adicionar ao Piloto Automático</span>';
    button.style.cssText = 'display:inline-flex;align-items:center;gap:8px;padding:10px 22px;border-radius:999px;border:1px solid rgba(56,189,248,0.6);background:linear-gradient(135deg,#0f172a 0%,#1e293b 50%,#0369a1 100%);color:#38bdf8;font-weight:800;font-size:13px;letter-spacing:0.3px;cursor:pointer;box-shadow:0 6px 20px rgba(14,165,233,0.35),inset 0 1px 0 rgba(255,255,255,0.15);position:relative;z-index:9999;pointer-events:auto;transition:all 0.25s ease;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;';
    button.onmouseover = function() {
        if (!this.disabled) {
            this.style.transform = 'translateY(-2px) scale(1.03)';
            this.style.boxShadow = '0 10px 25px rgba(14,165,233,0.55), inset 0 1px 0 rgba(255,255,255,0.25)';
            this.style.color = '#7dd3fc';
        }
    };
    button.onmouseout = function() {
        if (!this.disabled) {
            this.style.transform = 'none';
            this.style.boxShadow = '0 6px 20px rgba(14,165,233,0.35), inset 0 1px 0 rgba(255,255,255,0.15)';
            this.style.color = '#38bdf8';
        }
    };

    container.appendChild(button);
    header.appendChild(container);
    rdgAssistantUpdateProfileButtonLabel();
}

function rdgAssistantFetchProfileByUsername(username) {
    return new Promise(function(resolve, reject) {
        if (!username) {
            reject(new Error('Username invalido'));
            return;
        }
        $.ajax({
            url: 'https://www.instagram.com/' + encodeURIComponent(username) + '/',
            method: 'GET',
            headers: {
                'x-requested-with': 'XMLHttpRequest',
                'x-csrftoken': getCsrfFromCookie()
            },
            xhrFields: {
                withCredentials: true
            }
        }).done(function(resp) {
            var parsed = extractJSONfromUserPageHTML(resp);
            if (parsed && parsed.username) {
                resolve(parsed);
            } else {
                reject(new Error('Perfil nao retornado'));
            }
        }).fail(function(xhr) {
            reject(xhr || new Error('Falha ao buscar perfil'));
        });
    });
}

async function rdgAssistantAddCurrentProfile() {
    if (rdgAssistantAddProfileBusy) return;
    try {
        if (!rdgAssistantState) {
            rdgAssistantState = rdgAssistantDefaultState();
        }
        rdgAssistantState = rdgAssistantNormalizeState(rdgAssistantState);
        if (!Array.isArray(rdgAssistantState.profiles)) {
            rdgAssistantState.profiles = [];
        }
        rdgAssistantAddProfileBusy = true;
        rdgAssistantUpdateProfileButtonLabel();
        var username = rdgAssistantResolveCurrentProfileUsername();
        if (!username) {
            outputMessage('[Assistente] Abra um perfil concorrente antes de adicionar.');
            return;
        }
        var normalizedUsername = String(username || '').toLowerCase();
        var existing = rdgAssistantState.profiles.some(function(profile) {
            return String(profile && profile.username ? profile.username : '').toLowerCase() === normalizedUsername;
        });
        if (existing) {
            outputMessage('[Assistente] Esse perfil ja esta salvo no assistente.');
            return;
        }

        var rawProfile = null;
        if (currentProfilePage && String(currentProfilePage.username || '').toLowerCase() === normalizedUsername) {
            rawProfile = currentProfilePage;
        } else {
            try {
                rawProfile = await rdgAssistantFetchProfileByUsername(username);
            } catch (fetchError) {
                rawProfile = null;
            }
        }
        var profileData = rawProfile && rawProfile.user ? rawProfile.user : rawProfile;
        if (!profileData) {
            profileData = {
                id: normalizedUsername,
                username: username,
                full_name: '',
                profile_pic_url: '',
                follower_count: 0
            };
        }
        var profile = rdgAssistantNormalizeProfile({
            id: String(profileData.id || profileData.pk || normalizedUsername),
            username: profileData.username || username,
            full_name: profileData.full_name || '',
            profile_pic_url: rdgAssistantResolveProfilePictureUrl(profileData, username),
            follower_count: (profileData.edge_followed_by && profileData.edge_followed_by.count) || profileData.follower_count || 0,
            addedAt: Date.now(),
            assistant: rdgAssistantDefaultProfileAssistantState()
        });

        rdgAssistantState.profiles.push(profile);
        rdgAssistantAddHistory('Perfil salvo no assistente', '@' + profile.username + ' entrou na base privada do assistente.');
        rdgAssistantSaveState();
        rdgAssistantRender();
        outputMessage('[Assistente] Perfil @' + profile.username + ' adicionado com sucesso.');
    } catch (e) {
        outputMessage('[Assistente] Nao foi possivel adicionar esse perfil agora.');
    } finally {
        rdgAssistantAddProfileBusy = false;
        rdgAssistantUpdateProfileButtonLabel();
    }
}

function rdgAssistantRemoveProfile(profileId) {
    if (!rdgAssistantState) return;
    var profile = rdgAssistantGetProfileById(profileId);
    rdgAssistantState.profiles = rdgAssistantState.profiles.filter(function(item) {
        return String(item.id) !== String(profileId);
    });
    if (profile) {
        rdgAssistantAddHistory('Perfil removido', '@' + profile.username + ' foi removido da base do assistente.');
        outputMessage('[Assistente] Perfil @' + profile.username + ' removido.');
    }
    rdgAssistantSaveState();
    rdgAssistantRender();
}

function rdgAssistantPrepareNewRun() {
    if (!rdgAssistantState) return;
    var runtime = rdgAssistantGetAccountRuntime();
    var runtimeWorkWindowStartedAt = runtime ? (parseInt(runtime.workWindowStartedAt || 0, 10) || 0) : 0;
    var runtimeWorkMsInWindow = runtime ? (parseInt(runtime.workMsInWindow || 0, 10) || 0) : 0;
    var runtimeWorkLastTickAt = runtime ? (parseInt(runtime.workLastTickAt || 0, 10) || 0) : 0;
    if (!runtimeWorkWindowStartedAt) runtimeWorkWindowStartedAt = Date.now();
    if (!runtimeWorkLastTickAt) runtimeWorkLastTickAt = Date.now();
    var runId = 'assist-' + Date.now();
    rdgAssistantState.run = {
        id: runId,
        status: 'running',
        phase: 'collecting',
        startedAt: Date.now(),
        updatedAt: Date.now(),
        activeProfileId: '',
        waitUntil: 0,
        rateLimitHits: 0,
        dmStarted: false,
        dmHistoryBaselineCount: 0,
        dmQueueSize: 0,
        workWindowStartedAt: runtimeWorkWindowStartedAt,
        workMsInWindow: runtimeWorkMsInWindow,
        workLastTickAt: runtimeWorkLastTickAt,
        currentAction: '',
        currentTargetUsername: '',
        nextActionAt: 0,
        nextActionLabel: '',
        emptyAudienceRetryAt: 0,
        emptyAudienceRetryProfileId: '',
        profileTransitionAt: 0,
        profileTransitionNextProfileId: '',
        profileTransitionNextUsername: '',
        profileTransitionFromUsername: '',
        lastAutoRecoveryAt: 0,
        autoRecoveryCount: 0,
        lastAutoRecoveryReason: '',
        dmQualifiedCount: 0,
        dmQualifiedAt: 0,
        dmSentCount: 0,
        dmProcessedCount: 0,
        dmStatusText: '',
        logs: []
    };
    rdgAssistantSyncRunWorkCounters(rdgAssistantState.run);
    rdgAssistantCaptureManualDelaysIfNeeded();
    rdgAssistantApplyAssistantDelays();
    rdgAssistantRunPopupKey = '';
    rdgAssistantRunPopupDismissedKey = '';
    rdgAssistantState.profiles.forEach(function(profile) {
        profile.assistant = $.extend(true, {}, profile.assistant || rdgAssistantDefaultProfileAssistantState(), {
            currentRunId: runId,
            currentStatus: 'Aguardando coleta',
            collectedAudience: [],
            audienceSources: {
                likes: 0,
                comments: 0,
                followers: 0
            },
            collectedAt: 0,
            interactionCompletedAt: 0,
            warmingUntil: 0,
            dmCompletedAt: 0,
            currentRunInteractions: 0,
            currentRunLikes: 0,
            processedAudienceIds: {},
            targetReachedAt: 0,
            currentRunConverted: 0,
            emptyAudienceRetryCount: 0,
            emptyAudienceSkippedAt: 0,
            lastUpdatedAt: Date.now()
        });
    });
}

function rdgAssistantGetProfilesForRun(runId) {
    if (!rdgAssistantState || !Array.isArray(rdgAssistantState.profiles) || !runId) return [];
    return rdgAssistantState.profiles.filter(function(profile) {
        return profile && profile.assistant && profile.assistant.currentRunId === String(runId);
    });
}

function rdgAssistantHasResumableRunProgress(run) {
    if (!run || !run.id) return false;
    var runProfiles = rdgAssistantGetProfilesForRun(run.id);
    if (!runProfiles.length) return false;

    var hasPendingDm = false;
    var hasInProgressInteraction = false;

    for (var i = 0; i < runProfiles.length; i++) {
        var assistant = runProfiles[i].assistant || {};
        var processedMap = assistant.processedAudienceIds && typeof assistant.processedAudienceIds === 'object' ? assistant.processedAudienceIds : {};
        var processedCount = Object.keys(processedMap).length;
        var collectedCount = Array.isArray(assistant.collectedAudience) ? assistant.collectedAudience.length : 0;
        var interactionCount = parseInt(assistant.currentRunInteractions || 0, 10) || 0;

        if (assistant.interactionCompletedAt && !assistant.dmCompletedAt) {
            hasPendingDm = true;
        }

        if (!assistant.interactionCompletedAt && (collectedCount > 0 || processedCount > 0 || interactionCount > 0)) {
            hasInProgressInteraction = true;
        }
    }

    return hasPendingDm || hasInProgressInteraction;
}

function rdgAssistantInferResumePhase(run) {
    if (!run || !run.id) return 'collecting';
    var runProfiles = rdgAssistantGetProfilesForRun(run.id);
    if (!runProfiles.length) return 'collecting';

    if (run.dmStarted === true) {
        return 'sending_dm';
    }

    var activeProfile = null;
    for (var i = 0; i < runProfiles.length; i++) {
        var assistant = runProfiles[i].assistant || {};
        var processedCount = assistant.processedAudienceIds && typeof assistant.processedAudienceIds === 'object' ? Object.keys(assistant.processedAudienceIds).length : 0;
        var collectedCount = Array.isArray(assistant.collectedAudience) ? assistant.collectedAudience.length : 0;
        var interactionCount = parseInt(assistant.currentRunInteractions || 0, 10) || 0;
        if (!assistant.interactionCompletedAt && (collectedCount > 0 || processedCount > 0 || interactionCount > 0)) {
            activeProfile = runProfiles[i];
            break;
        }
    }

    if (activeProfile) {
        run.activeProfileId = String(activeProfile.id || '');
        return 'interacting';
    }

    for (var j = 0; j < runProfiles.length; j++) {
        if (!runProfiles[j].assistant || !runProfiles[j].assistant.interactionCompletedAt) {
            run.activeProfileId = String(runProfiles[j].id || '');
            return 'collecting';
        }
    }

    var waitingDmProfiles = rdgAssistantGetRunProfilesWaitingWarmup(run);
    if (waitingDmProfiles.length > 0) {
        run.activeProfileId = String(waitingDmProfiles[0].id || '');
        return 'warming';
    }

    var pendingDmProfiles = rdgAssistantGetRunProfilesPendingDm(run);
    if (pendingDmProfiles.length > 0) {
        run.activeProfileId = String(pendingDmProfiles[0].id || '');
        return 'sending_dm';
    }

    return 'collecting';
}

function rdgAssistantResumeSavedRun() {
    if (!rdgAssistantState || !rdgAssistantState.run) return false;
    if (!rdgAssistantHasResumableRunProgress(rdgAssistantState.run) && rdgAssistantState.run.dmStarted === true) {
        var rebound = false;
        if (Array.isArray(rdgAssistantState.profiles)) {
            for (var i = 0; i < rdgAssistantState.profiles.length; i++) {
                var profile = rdgAssistantState.profiles[i];
                if (!profile || !profile.assistant) continue;
                if (profile.assistant.interactionCompletedAt && !profile.assistant.dmCompletedAt) {
                    profile.assistant.currentRunId = String(rdgAssistantState.run.id || '');
                    profile.assistant.lastUpdatedAt = Date.now();
                    rebound = true;
                }
            }
        }
        if (!rebound && !rdgAssistantHasResumableRunProgress(rdgAssistantState.run)) return false;
    } else if (!rdgAssistantHasResumableRunProgress(rdgAssistantState.run)) {
        return false;
    }
    rdgAssistantState.run.status = 'running';
    rdgAssistantState.run.phase = rdgAssistantInferResumePhase(rdgAssistantState.run);
    rdgAssistantState.run.updatedAt = Date.now();
    rdgAssistantSetAccountWorkLastTickAt(Date.now());
    rdgAssistantSyncRunWorkCounters(rdgAssistantState.run);
    rdgAssistantApplyAssistantDelays();
    if (rdgAssistantState.run.phase === 'sending_dm') {
        rdgAssistantState.run.dmStarted = true;
        rdgAssistantState.run.dmStatusText = rdgAssistantState.run.dmStatusText || 'Retomando o direct automatico do ponto salvo.';
        rdgAssistantRenderDmProgressPopup();
    }
    rdgAssistantLog('Campanha retomada do ponto salvo.', rdgAssistantState.run.phase || 'running');
    return true;
}

function rdgAssistantCountFollowOkFromProcessedMap(processedMap, clampLimit) {
    if (!processedMap || typeof processedMap !== 'object') return 0;
    var ids = Object.keys(processedMap);
    var count = 0;
    for (var i = 0; i < ids.length; i++) {
        var entry = processedMap[ids[i]];
        var reason = entry && entry.reason ? String(entry.reason) : '';
        if (reason.indexOf('follow_ok') === 0) count++;
    }
    if (typeof clampLimit === 'number' && clampLimit > 0) count = Math.min(clampLimit, count);
    return count;
}

async function rdgAssistantRecalculateRunProgressFromLogIfNeeded() {
    if (!rdgAssistantState || !rdgAssistantState.run) return false;

    var runId = rdgAssistantState.run.id ? String(rdgAssistantState.run.id) : '';
    if (!runId) return false;

    var runProfiles = rdgAssistantGetProfilesForRun(runId);
    if (!runProfiles.length) runProfiles = Array.isArray(rdgAssistantState.profiles) ? rdgAssistantState.profiles : [];
    if (!runProfiles.length) return false;

    var changed = false;

    for (var i = 0; i < runProfiles.length; i++) {
        var p = runProfiles[i];
        if (!p || !p.assistant) continue;
        var processedMap = p.assistant.processedAudienceIds && typeof p.assistant.processedAudienceIds === 'object' ? p.assistant.processedAudienceIds : {};
        var computed = rdgAssistantCountFollowOkFromProcessedMap(processedMap, rdgAssistantGetTargetPerProfile());
        var current = parseInt(p.assistant.currentRunInteractions || 0, 10) || 0;
        if (computed !== current) {
            p.assistant.currentRunInteractions = computed;
            var total = parseInt(p.assistant.totalInteractions || 0, 10) || 0;
            if (computed > total) p.assistant.totalInteractions = computed;
            p.assistant.lastUpdatedAt = Date.now();
            changed = true;
        }
    }

    var anyHasProgress = runProfiles.some(function(p) {
        return p && p.assistant && (parseInt(p.assistant.currentRunInteractions || 0, 10) || 0) > 0;
    });
    if (anyHasProgress) {
        if (changed) {
            rdgAssistantSaveState();
            rdgAssistantRenderProfiles();
        }
        return changed;
    }

    var logText = await new Promise(function(resolve) {
        try {
            rdgReadScopedLogText(function(text) {
                resolve(String(text || ''));
            });
        } catch (e) {
            resolve('');
        }
    });
    if (!logText) return changed;

    if (logText.length > 120000) logText = logText.slice(-120000);
    var lines = logText.split('\n');
    if (lines.length > 6000) lines = lines.slice(lines.length - 6000);

    var profileByUsername = {};
    runProfiles.forEach(function(p) {
        if (p && p.username) profileByUsername[String(p.username)] = p;
    });

    var currentProfileUsername = '';
    var nowAt = Date.now();
    for (var li = 0; li < lines.length; li++) {
        var line = String(lines[li] || '');
        if (!line) continue;

        var mCtx = line.match(/Agora vamos interagir com o publico de\s+@([A-Za-z0-9_\\.]+)/i);
        if (mCtx && mCtx[1]) {
            currentProfileUsername = String(mCtx[1]);
            continue;
        }

        var mFollow = line.match(/FOLLOW ok:\s*seguido\s+([^\s]+)\s+\((\d+)\)/i);
        if (!mFollow || !mFollow[2]) continue;

        var p2 = currentProfileUsername ? profileByUsername[currentProfileUsername] : null;
        if (!p2 || !p2.assistant) continue;

        var acctId = String(mFollow[2]);
        if (!acctId) continue;

        if (!p2.assistant.processedAudienceIds || typeof p2.assistant.processedAudienceIds !== 'object') {
            p2.assistant.processedAudienceIds = {};
        }

        if (!p2.assistant.processedAudienceIds[acctId]) {
            p2.assistant.processedAudienceIds[acctId] = { reason: 'follow_ok_recovered', at: nowAt };
            changed = true;
        }
    }

    if (changed) {
        for (var j = 0; j < runProfiles.length; j++) {
            var p3 = runProfiles[j];
            if (!p3 || !p3.assistant) continue;
            var map2 = p3.assistant.processedAudienceIds && typeof p3.assistant.processedAudienceIds === 'object' ? p3.assistant.processedAudienceIds : {};
            var computed2 = rdgAssistantCountFollowOkFromProcessedMap(map2, rdgAssistantGetTargetPerProfile());
            var current2 = parseInt(p3.assistant.currentRunInteractions || 0, 10) || 0;
            if (computed2 !== current2) p3.assistant.currentRunInteractions = computed2;
            var total2 = parseInt(p3.assistant.totalInteractions || 0, 10) || 0;
            if (computed2 > total2) p3.assistant.totalInteractions = computed2;
            p3.assistant.lastUpdatedAt = Date.now();
        }
        rdgAssistantSaveState();
        rdgAssistantRenderProfiles();
    }

    return changed;
}

function rdgAssistantPauseRun(reason) {
    if (!rdgAssistantState || !rdgAssistantState.run) return;
    rdgAssistantCancelManualBlockingWaits(true);
    rdgAssistantClearWaitResumeTimer();
    rdgAssistantState.run.status = 'paused';
    if (!rdgAssistantState.run.phase || rdgAssistantState.run.phase === 'resting') {
        rdgAssistantState.run.phase = rdgAssistantState.run.resumePhase || 'paused';
    }
    rdgAssistantState.run.updatedAt = Date.now();
    rdgAssistantSetAccountWorkLastTickAt(0);
    rdgAssistantSetLiveProgress('Assistente pausado manualmente.', '', 0, '');
    rdgAssistantCloseNoticePopup();
    rdgAssistantRestoreManualDelays();
    if (reason) rdgAssistantLog(reason, 'paused', true);
    try {
        rdgStopAllPendingActions('Assistente pausado.');
    } catch (e) {}
    try {
        if (typeof stopMassDM === 'function') stopMassDM();
    } catch (e2) {}
    rdgAssistantRunPopupKey = '';
    rdgAssistantSaveState();
    rdgAssistantRender();
}

function rdgAssistantStopRun(reason) {
    if (!rdgAssistantState || !rdgAssistantState.run) return;
    rdgAssistantCancelManualBlockingWaits(true);
    rdgAssistantClearWaitResumeTimer();
    rdgAssistantState.run.status = 'stopped';
    rdgAssistantState.run.phase = 'stopped';
    rdgAssistantState.run.updatedAt = Date.now();
    rdgAssistantSetAccountWorkLastTickAt(0);
    rdgAssistantSetLiveProgress('', '', 0, '');
    rdgAssistantCloseNoticePopup();
    rdgAssistantRestoreManualDelays();
    if (reason) rdgAssistantAddHistory('Assistente parado', reason);
    try {
        rdgStopAllPendingActions('Assistente parado.');
    } catch (e) {}
    try {
        if (typeof stopMassDM === 'function') stopMassDM();
    } catch (e2) {}
    rdgAssistantCloseRunPopup(false);
    rdgAssistantRunPopupKey = '';
    rdgAssistantRunPopupDismissedKey = '';
    rdgAssistantSaveState();
    rdgAssistantRender();
}

function rdgAssistantCreateNewCycle() {
    if (!rdgAssistantState) return;
    if (rdgAssistantState.run && ['running', 'waiting_instagram', 'resting'].indexOf(rdgAssistantState.run.status) > -1) {
        alert('Pare ou pause o ciclo atual antes de criar um novo ciclo.');
        return;
    }
    rdgAssistantSyncActiveCycleIntoState();
    var idx = parseInt(rdgAssistantState.cycleCounter || 1, 10) || 1;
    var id = 'cycle-' + Date.now();
    var name = 'Ciclo ' + idx;
    var dmTemplate = rdgAssistantState.dmTemplate || '';
    var dmTemplates = Array.isArray(rdgAssistantState.dmTemplates) ? rdgAssistantState.dmTemplates.slice(0, 3) : [];
    if (!Array.isArray(rdgAssistantState.cycles)) rdgAssistantState.cycles = [];
    rdgAssistantState.cycles.unshift({
        id: id,
        name: name,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        profiles: [],
        dmTemplate: dmTemplate,
        dmTemplates: dmTemplates,
        run: null,
        history: []
    });
    rdgAssistantState.cycleCounter = idx + 1;
    rdgAssistantApplyCycleToState(id);
    rdgAssistantSetExpandedCycleId(id);
    rdgAssistantSaveState();
    rdgAssistantRender();
}

function rdgAssistantCreateNextCycleFromCurrentAndStart() {
    if (!rdgAssistantState) return false;
    if (rdgAssistantState.run && ['running', 'waiting_instagram', 'resting'].indexOf(rdgAssistantState.run.status) > -1) return false;
    rdgAssistantSyncActiveCycleIntoState();
    var idx = parseInt(rdgAssistantState.cycleCounter || 1, 10) || 1;
    var id = 'cycle-' + Date.now();
    var name = 'Ciclo ' + idx;
    var dmTemplate = rdgAssistantState.dmTemplate || '';
    var dmTemplates = Array.isArray(rdgAssistantState.dmTemplates) ? rdgAssistantState.dmTemplates.slice(0, 3) : [];
    var copiedProfiles = Array.isArray(rdgAssistantState.profiles) ? rdgAssistantState.profiles.map(function(p) {
        var base = $.extend(true, {}, p || {});
        base.assistant = rdgAssistantDefaultProfileAssistantState();
        return rdgAssistantNormalizeProfile(base);
    }).filter(function(p) { return p && p.id && p.username; }) : [];
    if (!Array.isArray(rdgAssistantState.cycles)) rdgAssistantState.cycles = [];
    rdgAssistantState.cycles.unshift({
        id: id,
        name: name,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        profiles: copiedProfiles,
        dmTemplate: dmTemplate,
        dmTemplates: dmTemplates,
        run: null,
        history: []
    });
    rdgAssistantState.cycleCounter = idx + 1;
    rdgAssistantApplyCycleToState(id);
    rdgAssistantSetExpandedCycleId(id);
    rdgAssistantPrepareNewRun();
    rdgAssistantSaveState(function() {
        rdgAssistantMarkSessionActive();
        rdgAssistantRender();
        rdgAssistantTick();
    });
    return true;
}

function rdgAssistantCreateNextCycleFromCurrent() {
    if (!rdgAssistantState) return false;
    if (rdgAssistantState.run && ['running', 'waiting_instagram', 'resting'].indexOf(rdgAssistantState.run.status) > -1) return false;
    rdgAssistantSyncActiveCycleIntoState();
    var idx = parseInt(rdgAssistantState.cycleCounter || 1, 10) || 1;
    var id = 'cycle-' + Date.now();
    var name = 'Ciclo ' + idx;
    var dmTemplate = rdgAssistantState.dmTemplate || '';
    var dmTemplates = Array.isArray(rdgAssistantState.dmTemplates) ? rdgAssistantState.dmTemplates.slice(0, 3) : [];
    var copiedProfiles = Array.isArray(rdgAssistantState.profiles) ? rdgAssistantState.profiles.map(function(p) {
        var base = $.extend(true, {}, p || {});
        base.assistant = rdgAssistantDefaultProfileAssistantState();
        return rdgAssistantNormalizeProfile(base);
    }).filter(function(p) { return p && p.id && p.username; }) : [];
    if (!Array.isArray(rdgAssistantState.cycles)) rdgAssistantState.cycles = [];
    rdgAssistantState.cycles.unshift({
        id: id,
        name: name,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        profiles: copiedProfiles,
        dmTemplate: dmTemplate,
        dmTemplates: dmTemplates,
        run: null,
        history: []
    });
    rdgAssistantState.cycleCounter = idx + 1;
    rdgAssistantApplyCycleToState(id);
    rdgAssistantSetExpandedCycleId(id);
    rdgAssistantState.run = null;
    rdgAssistantState.history = [];
    rdgAssistantCloseDmProgressPopup();
    rdgAssistantCloseRunPopup(false);
    rdgAssistantSaveState(function() {
        rdgAssistantRender();
    });
    return true;
}

function rdgAssistantActivateCycle(cycleId) {
    if (!rdgAssistantState || !cycleId) return;
    if (rdgAssistantState.run && ['running', 'waiting_instagram', 'resting'].indexOf(rdgAssistantState.run.status) > -1) {
        alert('Pare ou pause o ciclo atual antes de trocar de ciclo.');
        return;
    }
    var chosenCycle = null;
    if (Array.isArray(rdgAssistantState.cycles)) {
        for (var i = 0; i < rdgAssistantState.cycles.length; i++) {
            if (rdgAssistantState.cycles[i] && rdgAssistantState.cycles[i].id === String(cycleId)) {
                chosenCycle = rdgAssistantState.cycles[i];
                break;
            }
        }
    }
    if (rdgAssistantIsCycleLocked(chosenCycle)) {
        alert('Este ciclo ja foi finalizado e bloqueado. Para continuar, crie um novo ciclo.');
        return;
    }
    rdgAssistantSyncActiveCycleIntoState();
    rdgAssistantApplyCycleToState(String(cycleId));
    rdgAssistantSaveState();
    rdgAssistantRender();
}

function rdgAssistantViewLockedCycle(cycleId) {
    if (!rdgAssistantState || !cycleId) return;
    if (rdgAssistantState.run && ['running', 'waiting_instagram', 'resting'].indexOf(rdgAssistantState.run.status) > -1) {
        rdgAssistantSetExpandedCycleId(String(cycleId));
        rdgAssistantRender();
        return;
    }
    rdgAssistantSyncActiveCycleIntoState();
    rdgAssistantApplyCycleToState(String(cycleId));
    rdgAssistantSetExpandedCycleId(String(cycleId));
    rdgAssistantSaveState();
    rdgAssistantRender();
}

function rdgAssistantRenameCycle(cycleId) {
    if (!rdgAssistantState || !Array.isArray(rdgAssistantState.cycles) || !cycleId) return;
    var cycle = null;
    for (var i = 0; i < rdgAssistantState.cycles.length; i++) {
        if (rdgAssistantState.cycles[i].id === String(cycleId)) { cycle = rdgAssistantState.cycles[i]; break; }
    }
    if (!cycle) return;
    var newName = window.prompt('Nome do ciclo:', cycle.name || 'Ciclo');
    if (!newName) return;
    cycle.name = String(newName).trim().slice(0, 60) || cycle.name;
    cycle.updatedAt = Date.now();
    if (cycle.id === rdgAssistantState.activeCycleId) {
        rdgAssistantSaveState();
        rdgAssistantRender();
        return;
    }
    rdgAssistantSaveState();
    rdgAssistantRender();
}

function rdgAssistantRemoveCycle(cycleId) {
    if (!rdgAssistantState || !Array.isArray(rdgAssistantState.cycles) || !cycleId) return;
    var cycle = null;
    for (var i = 0; i < rdgAssistantState.cycles.length; i++) {
        if (rdgAssistantState.cycles[i].id === String(cycleId)) { cycle = rdgAssistantState.cycles[i]; break; }
    }
    if (cycle && cycle.run && ['running', 'waiting_instagram', 'resting'].indexOf(cycle.run.status) > -1) {
        alert('Nao e possivel remover um ciclo que esta rodando.');
        return;
    }
    rdgAssistantState.cycles = rdgAssistantState.cycles.filter(function(c) { return c && c.id !== String(cycleId); });
    if (rdgAssistantState.activeCycleId === String(cycleId)) {
        var next = rdgAssistantState.cycles[0] ? rdgAssistantState.cycles[0].id : '';
        if (next) {
            rdgAssistantApplyCycleToState(next);
        } else {
            rdgAssistantState.activeCycleId = '';
            rdgAssistantState.profiles = [];
            rdgAssistantState.dmTemplate = '';
            rdgAssistantState.dmTemplates = [];
            rdgAssistantState.run = null;
            rdgAssistantState.history = [];
        }
    }
    rdgAssistantSaveState();
    rdgAssistantRender();
}

function rdgAssistantAskUnfollowChoice(followingCount, maxFollowing, targetFollowing, callback) {
    var modeInputName = 'rdgAssistantUnfollowMode';
    var questionHtml =
        'Seu perfil ja segue <b>' + rdgAssistantFormatNumber(followingCount) + '</b> contas (limite ~' + rdgAssistantFormatNumber(maxFollowing) + ').<br><br>' +
        'Para continuar com seguranca, precisamos <b>deixar de seguir</b> ate chegar em ~<b>' + rdgAssistantFormatNumber(targetFollowing) + '</b> seguindo.<br><br>' +
        '<div style="display:grid; gap:10px; text-align:left; margin-top:10px;">' +
            '<label style="display:flex; gap:10px; align-items:flex-start; padding:10px; border:1px solid #ececf2; border-radius:12px; background:#fff;">' +
                '<input type="radio" name="' + modeInputName + '" value="non_followers" checked>' +
                '<div><b>Apenas quem nao te segue de volta</b><br><span style="font-size:12px; color:#666;">Mais seguro e recomendado.</span></div>' +
            '</label>' +
            '<label style="display:flex; gap:10px; align-items:flex-start; padding:10px; border:1px solid #ececf2; border-radius:12px; background:#fff;">' +
                '<input type="radio" name="' + modeInputName + '" value="all">' +
                '<div><b>Todos</b><br><span style="font-size:12px; color:#666;">Remove seguindo sem filtrar (mais agressivo).</span></div>' +
            '</label>' +
        '</div>';

    dialog({
        yes: "Avancar",
        no: "Cancelar",
        question: questionHtml
    }, function() {
        var chosen = $('input[name="' + modeInputName + '"]:checked').val() || 'non_followers';
        if (typeof callback === 'function') callback(chosen);
    }, function() {
        if (typeof callback === 'function') callback(null);
    });
}

async function rdgAssistantHandleStart() {
    if (!rdgAssistantState) return;
    var activeCycle = rdgAssistantGetActiveCycle();
    if (rdgAssistantIsCycleLocked(activeCycle)) {
        if (activeCycle && activeCycle.id) {
            rdgAssistantViewLockedCycle(activeCycle.id);
        }
        return;
    }
    if (!rdgAssistantCanStart() && !(rdgAssistantState.run && ['running', 'waiting_instagram', 'resting', 'paused'].indexOf(rdgAssistantState.run.status) > -1)) {
        alert('Para liberar o Start, salve a mensagem do direct e adicione pelo menos 1 perfil concorrente.');
        return;
    }

    try {
        await rdgAssistantRecalculateRunProgressFromLogIfNeeded();
    } catch (e0) {}
    try {
        if (rdgAssistantState.run) rdgAssistantHydrateAccountRestLockFromRun(rdgAssistantState.run);
    } catch (eHydrate) {}
    try {
        if (rdgAssistantState.run && rdgAssistantAutoRecoverInvalidLongPause('Pausa longa invalida corrigida automaticamente apos atualizar a versao. A conta ainda nao atingiu o limite real de horas ligadas.')) {
            rdgAssistantSaveState();
        }
    } catch (eRecoverInvalidPause) {}

    if (rdgAssistantHasAccountRestLock()) {
        if (rdgAssistantState.run && rdgAssistantState.run.status !== 'paused') rdgAssistantApplyAccountRestLockToCurrentRun();
        var accountRestUntil = rdgAssistantGetAccountRestUntil();
        var accountRestCopy = rdgAssistantBuildRestPopupCopy(accountRestUntil);
        rdgAssistantShowNoticePopup(accountRestCopy.title, accountRestCopy.message, accountRestCopy.subMessage);
        rdgAssistantSaveState();
        rdgAssistantRender();
        return;
    }
    var accountRuntime = rdgAssistantGetAccountRuntime();
    if (accountRuntime && (parseInt(accountRuntime.restUntil || 0, 10) || 0) > 0 && (parseInt(accountRuntime.restUntil || 0, 10) || 0) <= Date.now()) {
        rdgAssistantResetAccountWorkWindow(Date.now());
        accountRuntime.restStartedAt = 0;
    }

    if (!rdgAssistantState.run || ['completed', 'idle', 'stopped'].indexOf(rdgAssistantState.run.status) > -1) {
        if (rdgAssistantState.run && rdgAssistantResumeSavedRun()) {
            rdgAssistantSaveState(function() {
                rdgAssistantMarkSessionActive();
                rdgAssistantRender();
                rdgAssistantTick();
            });
            return;
        }
        rdgAssistantPrepareNewRun();
        try {
            var stats = await rdgAssistantFetchMyAccountStats();
            var maxFollowing = parseInt(rdgAssistantState.settings.assistantUnfollowMaxFollowing || 7500, 10) || 7500;
            if (stats && stats.following >= maxFollowing) {
                var targetFollowing = parseInt(rdgAssistantState.settings.assistantUnfollowTargetFollowing || 3000, 10) || 3000;
                var chosenMode = await new Promise(function(resolve) {
                    rdgAssistantAskUnfollowChoice(stats.following, maxFollowing, targetFollowing, resolve);
                });
                if (!chosenMode) {
                    rdgAssistantStopRun('Ciclo cancelado: o perfil esta no limite de seguindo. Para iniciar, escolha um modo de unfollow e clique em Avancar.');
                    return;
                }
                rdgAssistantState.run.phase = 'unfollowing';
                rdgAssistantState.run.unfollowMode = chosenMode;
                rdgAssistantState.run.unfollowTargetFollowing = targetFollowing;
                rdgAssistantAddHistory('Ciclo de unfollow iniciado', 'O perfil estava no limite de seguindo. Modo: ' + (chosenMode === 'non_followers' ? 'somente quem nao te segue' : 'todos') + '. Meta: reduzir seguindo ate ' + targetFollowing + '.');
                await rdgAssistantStartUnfollowBatch(rdgAssistantState.run.unfollowMode);
            } else {
                rdgAssistantLog('Campanha iniciada com ' + rdgAssistantState.profiles.length + ' perfil(is) concorrente(s).', 'collecting');
            }
        } catch (e) {
            rdgAssistantLog('Campanha iniciada com ' + rdgAssistantState.profiles.length + ' perfil(is) concorrente(s).', 'collecting');
        }
    } else if ((rdgAssistantState.run.status === 'waiting_instagram' || rdgAssistantState.run.status === 'resting') && rdgAssistantState.run.waitUntil > Date.now()) {
        rdgAssistantEnsureWaitResumeTimer();
        if (rdgAssistantState.run.status === 'resting') {
            var restCopy = rdgAssistantBuildRestPopupCopy(rdgAssistantState.run.waitUntil);
            rdgAssistantShowNoticePopup(restCopy.title, restCopy.message, restCopy.subMessage);
        } else {
            rdgAssistantShowNoticePopup(
                'Pausa tecnica em andamento',
                'O assistente esta em uma pausa tecnica temporaria para retomar com mais seguranca.',
                'Retomada prevista em ' + rdgAssistantFormatDate(rdgAssistantState.run.waitUntil) + '.'
            );
        }
        return;
    } else {
        rdgAssistantState.run.status = 'running';
        rdgAssistantState.run.updatedAt = Date.now();
        rdgAssistantSetAccountWorkLastTickAt(Date.now());
        rdgAssistantSyncRunWorkCounters(rdgAssistantState.run);
        rdgAssistantApplyAssistantDelays();
        rdgAssistantLog('Campanha retomada do ponto salvo.', rdgAssistantState.run.phase || 'running');
    }

    rdgAssistantSaveState(function() {
        rdgAssistantMarkSessionActive();
        rdgAssistantRender();
        rdgAssistantTick();
    });
}

function rdgAssistantSaveDmTemplate() {
    if (!rdgAssistantState) return;
    var templates = rdgAssistantGetNormalizedDmTemplatesFromInputs(['rdgAssistantDmTemplate', 'rdgAssistantDmTemplate2', 'rdgAssistantDmTemplate3']);
    rdgAssistantState.dmTemplates = templates.slice(0, 3);
    rdgAssistantState.dmTemplate = rdgAssistantState.dmTemplates[0] || '';
    rdgAssistantDmExpanded = rdgAssistantState.dmTemplates.length === 0;
    rdgAssistantAddHistory('Mensagem do direct salva', 'A mensagem do dia 6 foi atualizada dentro do assistente' + (rdgAssistantState.dmTemplates.length > 1 ? (' com ' + rdgAssistantState.dmTemplates.length + ' variacoes') : '') + '.');
    rdgAssistantSaveState();
    rdgAssistantRender();
    rdgAssistantSyncDirectDmInputs();
    outputMessage('[Assistente] Mensagem do direct salva no modulo do assistente' + (rdgAssistantState.dmTemplates.length > 1 ? (' com ' + rdgAssistantState.dmTemplates.length + ' variacoes') : '') + '.');
}

function rdgAssistantBindUi() {
    if (rdgAssistantUiBound) return;
    rdgAssistantUiBound = true;

    $(document).off('click.rdgAssistantAddProfileInline').on('click.rdgAssistantAddProfileInline', '#rdgAssistantAddProfileInline', function(e) {
        e.preventDefault();
        e.stopPropagation();
        rdgAssistantAddCurrentProfile();
    });
    $(document).off('click.rdgAssistantStart').on('click.rdgAssistantStart', '#rdgAssistantStart', rdgAssistantHandleStart);
    $(document).off('click.rdgAssistantStop').on('click.rdgAssistantStop', '#rdgAssistantStop', function() {
        rdgAssistantPauseRun('Assistente parado pelo usuario. Clique em Retomar quando quiser continuar do ponto salvo.');
    });
    $(document).off('click.rdgAssistantRunPopupClose').on('click.rdgAssistantRunPopupClose', '#rdgAssistantRunPopupClose', function() {
        rdgAssistantCloseRunPopup(true);
    });
    $(document).off('click.rdgAssistantRunPopupDismiss').on('click.rdgAssistantRunPopupDismiss', '#rdgAssistantRunPopupDismiss', function() {
        rdgAssistantCloseRunPopup(true);
    });
    $(document).off('click.rdgAssistantRunPopupBackdrop').on('click.rdgAssistantRunPopupBackdrop', '#rdgAssistantRunPopup', function(e) {
        if (e.target && e.target.id === 'rdgAssistantRunPopup') rdgAssistantCloseRunPopup(true);
    });
    $(document).off('click.rdgAssistantNewCycle').on('click.rdgAssistantNewCycle', '#rdgAssistantNewCycle', function() {
        rdgAssistantCreateNewCycle();
    });
    $(document).off('click.rdgAssistantCycleDot').on('click.rdgAssistantCycleDot', '.rdgAssistantCycleDot[data-cycle-id]', function() {
        var id = $(this).attr('data-cycle-id');
        if (!id) return;
        var current = rdgAssistantGetExpandedCycleId();
        rdgAssistantSetExpandedCycleId(current && current === String(id) ? null : String(id));
        rdgAssistantRender();
    });
    $(document).off('click.rdgAssistantCycleExpandClose').on('click.rdgAssistantCycleExpandClose', '#rdgAssistantCycleExpandClose', function() {
        rdgAssistantSetExpandedCycleId(null);
        rdgAssistantRender();
    });
    $(document).off('click.rdgAssistantCycleModalBg').on('click.rdgAssistantCycleModalBg', '#rdgAssistantCycleModal', function(e) {
        if (e.target && e.target.id === 'rdgAssistantCycleModal') {
            rdgAssistantSetExpandedCycleId(null);
            rdgAssistantRender();
        }
    });
    $(document).off('click.rdgAssistantCycleActivateBtn').on('click.rdgAssistantCycleActivateBtn', '#rdgAssistantCycleActivateBtn', function() {
        var id = $(this).attr('data-cycle-id');
        if (!id) return;
        var chosenCycle = null;
        if (rdgAssistantState && Array.isArray(rdgAssistantState.cycles)) {
            for (var i = 0; i < rdgAssistantState.cycles.length; i++) {
                if (rdgAssistantState.cycles[i] && rdgAssistantState.cycles[i].id === String(id)) {
                    chosenCycle = rdgAssistantState.cycles[i];
                    break;
                }
            }
        }
        if (rdgAssistantIsCycleLocked(chosenCycle)) {
            rdgAssistantViewLockedCycle(id);
            return;
        }
        rdgAssistantActivateCycle(id);
        rdgAssistantSetExpandedCycleId(id);
        rdgAssistantRender();
    });
    $(document).off('click.rdgAssistantCycleSaveBtn').on('click.rdgAssistantCycleSaveBtn', '#rdgAssistantCycleSaveBtn', function() {
        var id = $(this).attr('data-cycle-id');
        if (!rdgAssistantState || !Array.isArray(rdgAssistantState.cycles) || !id) return;
        var input = document.getElementById('rdgAssistantCycleNameInput');
        var newName = input ? String(input.value || '').trim().slice(0, 60) : '';
        for (var i = 0; i < rdgAssistantState.cycles.length; i++) {
            if (rdgAssistantState.cycles[i] && rdgAssistantState.cycles[i].id === String(id)) {
                if (newName) rdgAssistantState.cycles[i].name = newName;
                rdgAssistantState.cycles[i].updatedAt = Date.now();
                break;
            }
        }
        rdgAssistantSaveState();
        rdgAssistantRender();
    });
    $(document).off('click.rdgAssistantCycleRemoveBtn').on('click.rdgAssistantCycleRemoveBtn', '#rdgAssistantCycleRemoveBtn', function() {
        var id = $(this).attr('data-cycle-id');
        if (!id) return;
        rdgAssistantRemoveCycle(id);
        rdgAssistantSetExpandedCycleId(null);
        rdgAssistantRender();
    });
    $(document).off('click.rdgAssistantDmToggle').on('click.rdgAssistantDmToggle', '#rdgAssistantDmToggle', function() {
        if (!rdgAssistantState) return;
        var profilesReady = rdgAssistantState.profiles.length >= rdgAssistantState.settings.minProfiles;
        if (!profilesReady) return;
        rdgAssistantNormalizeDmTemplates(rdgAssistantState);
        if (!Array.isArray(rdgAssistantState.dmTemplates) || !rdgAssistantState.dmTemplates.length) {
            rdgAssistantDmExpanded = true;
        } else {
            rdgAssistantDmExpanded = !rdgAssistantDmExpanded;
        }
        rdgAssistantRender();
    });
    $(document).off('click.rdgAssistantSaveDm').on('click.rdgAssistantSaveDm', '#rdgAssistantSaveDm', rdgAssistantSaveDmTemplate);
    $(document).off('click.rdgAssistantQueue').on('click.rdgAssistantQueue', '#rdgAssistantOpenQueue', function() {
        rdgAssistantOpenTab('rdg_tab1');
    });
    $(document).off('click.rdgAssistantOpenLog').on('click.rdgAssistantOpenLog', '#rdgAssistantOpenLog', function() {
        rdgAssistantOpenTab('rdg_tab5');
    });
    $(document).off('click.rdgAssistantOpenActivityQuick').on('click.rdgAssistantOpenActivityQuick', '#rdgAssistantOpenActivityQuick', function() {
        rdgAssistantOpenMiniPanelSection('activity');
    });
    $(document).off('click.rdgAssistantDirect').on('click.rdgAssistantDirect', '#rdgAssistantOpenDirect', function() {
        rdgAssistantOpenTab('rdg_tab7');
        if (typeof initBeta === 'function') initBeta();
        rdgAssistantSyncDirectDmInputs();
    });
    $(document).off('click.rdgAssistantRemoveProfile').on('click.rdgAssistantRemoveProfile', '[data-remove-assistant-profile]', function() {
        rdgAssistantRemoveProfile($(this).attr('data-remove-assistant-profile'));
    });

    $(document).off('click.rdgAssistantMiniDock').on('click.rdgAssistantMiniDock', '[data-assistant-mini]', function() {
        var key = $(this).attr('data-assistant-mini');
        rdgAssistantOpenMiniPanelSection(key);
    });

    $(document).off('click.rdgAssistantMiniClose').on('click.rdgAssistantMiniClose', '#rdgAssistantMiniClose', function() {
        var panel = document.getElementById('rdgAssistantMiniPanel');
        if (panel) panel.style.display = 'none';
        var dotButtons = document.querySelectorAll('.rdgAssistantDotBtn[data-assistant-mini]');
        for (var i = 0; i < dotButtons.length; i++) dotButtons[i].classList.remove('active');
    });
}

function rdgAssistantHandleOutputMessage(txt) {
    if (!rdgAssistantState || !rdgAssistantState.run) return;
    var rawMessage = String(txt || '').trim();
    if (!rawMessage) return;
    var cleanMessage = rawMessage.replace(/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} - /, '').trim();
    if (!cleanMessage) return;
    if (cleanMessage.indexOf('[Assistente]') !== 0) {
        var runtimeStatuses = ['running', 'waiting_instagram', 'resting', 'paused'];
        if (runtimeStatuses.indexOf(rdgAssistantState.run.status) > -1) {
            rdgAssistantPushRuntimeLog(cleanMessage, rdgAssistantState.run.phase || 'idle');
            rdgAssistantSaveState();
            rdgAssistantRenderProfiles();
            rdgAssistantRenderActivity();
            rdgAssistantRenderLiveLogCard();
        }
    }
    if (rdgAssistantState.run.status !== 'running') return;
    var lower = cleanMessage.toLowerCase();
    var looksLikeRateLimit =
        lower.indexOf('rate limit') > -1 ||
        lower.indexOf('limite de taxa') > -1 ||
        (lower.indexOf('instagram') > -1 && lower.indexOf('limite') > -1) ||
        lower.indexOf('429') > -1;
    if (!looksLikeRateLimit) return;
    if (Date.now() - rdgAssistantLastRateLimitAt < 20000) return;
    rdgAssistantLastRateLimitAt = Date.now();
    rdgAssistantState.run.rateLimitHits = (parseInt(rdgAssistantState.run.rateLimitHits || 0, 10) || 0) + 1;
    if (rdgAssistantState.run.rateLimitHits < 2) {
        rdgAssistantLog('Foi detectado um limite leve do Instagram. O assistente vai tentar continuar sem te parar agora.', 'rate_limit', true);
        return;
    }
    rdgAssistantState.run.status = 'waiting_instagram';
    rdgAssistantState.run.phase = 'waiting_rate_limit';
    rdgAssistantState.run.waitUntil = Date.now() + (12 * 3600000);
    rdgStopAllPendingActions('Assistente pausado para aguardar o Instagram.');
    rdgAssistantLog('Parece que tivemos um limite do Instagram. Vamos aguardar cerca de 12 horas para continuar com seguranca.', 'waiting_rate_limit', true);
    rdgAssistantSaveState();
    rdgAssistantRender();
}

function rdgAssistantFetchTimelinePage(profile, afterCursor) {
    return new Promise(async function(resolve, reject) {
        try {
            var after = '';
            if (afterCursor) after = '%22after%22%3A%22' + afterCursor + '%22%2C';
            const response = await fetch("https://www.instagram.com/graphql/query", {
                headers: {
                    accept: "*/*",
                    "content-type": "application/x-www-form-urlencoded",
                    priority: "u=1, i",
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "same-origin",
                    "x-asbd-id": "129477",
                    "x-csrftoken": getCsrfFromCookie(),
                    "x-fb-friendly-name": "PolarisProfilePostsQuery",
                    "x-ig-app-id": "936619743392459"
                },
                referrer: "https://www.instagram.com/" + profile.username + "/",
                referrerPolicy: "strict-origin-when-cross-origin",
                body: "av=17841400482242408&__d=www&__user=0&__a=1&__req=7&__hs=20028.HYP%3Ainstagram_web_pkg.2.1..0.1&dpr=1&__ccg=EXCELLENT&__rev=1017870321&__s=xc4v6e%3Api17z8%3Awisy8l&__hsi=7432327050990328368&__csr=&__comet_req=7&jazoest=26364&__spin_r=1017870321&__spin_b=trunk&__spin_t=1730473490&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=PolarisProfilePostsQuery&variables=%7B" + after + "%22data%22%3A%7B%22count%22%3A12%2C%22include_relationship_info%22%3Atrue%2C%22latest_besties_reel_media%22%3Atrue%2C%22latest_reel_media%22%3Atrue%7D%2C%22username%22%3A%22" + profile.username + "%22%2C%22__relay_internal__pv__PolarisIsLoggedInrelayprovider%22%3Atrue%2C%22__relay_internal__pv__PolarisFeedShareMenurelayprovider%22%3Atrue%7D&server_timestamps=true&doc_id=8633614153419931",
                method: "POST",
                mode: "cors",
                credentials: "include"
            });
            var jsonData = await response.json();
            resolve(jsonData.data.xdt_api__v1__feed__user_timeline_graphql_connection);
        } catch (e) {
            reject(e);
        }
    });
}

async function rdgAssistantCollectFromLikes(profile, needed, list, seenMap, exclusionMap) {
    var after = '';
    var pageCount = 0;
    while (list.length < needed && pageCount < 10) {
        var page = await rdgAssistantFetchTimelinePage(profile, after);
        if (!page || !page.edges || !page.edges.length) break;
        for (var i = 0; i < page.edges.length && list.length < needed; i++) {
            if (gblOptions.includePinnedPostForLikes === false && page.edges[i].node.timeline_pinned_user_ids && page.edges[i].node.timeline_pinned_user_ids.length > 0) continue;
            var likers = await loadLikesForMedia(page.edges[i]);
            for (var j = 0; j < likers.length && list.length < needed; j++) {
                rdgAssistantPushUniqueAcct(list, seenMap, likers[j], exclusionMap);
            }
        }
        if (!page.page_info || page.page_info.has_next_page !== true) break;
        after = page.page_info.end_cursor;
        pageCount++;
    }
}

async function rdgAssistantCollectFromComments(profile, needed, list, seenMap, exclusionMap) {
    var after = '';
    var pageCount = 0;
    while (list.length < needed && pageCount < 10) {
        var page = await rdgAssistantFetchTimelinePage(profile, after);
        if (!page || !page.edges || !page.edges.length) break;
        for (var i = 0; i < page.edges.length && list.length < needed; i++) {
            if (gblOptions.includePinnedPostForComments === false && page.edges[i].node.timeline_pinned_user_ids && page.edges[i].node.timeline_pinned_user_ids.length > 0) continue;
            var mediaWithComments = await loadMoreCommentsForMedia2(page.edges[i].node);
            var users = allNodes(mediaWithComments.comments || [], 'user');
            for (var j = 0; j < users.length && list.length < needed; j++) {
                rdgAssistantPushUniqueAcct(list, seenMap, users[j], exclusionMap);
            }
        }
        if (!page.page_info || page.page_info.has_next_page !== true) break;
        after = page.page_info.end_cursor;
        pageCount++;
    }
}

function rdgAssistantFetchFollowers(profile, limit) {
    return new Promise(function(resolve) {
        if (typeof fetchRecentFollowers === 'function') {
            fetchRecentFollowers(String(profile.id), limit, 0, function(users) {
                resolve(Array.isArray(users) ? users : []);
            });
            return;
        }
        resolve([]);
    });
}

async function rdgAssistantFillAudienceWithRecentFollowers(profile, targetSize, list, seenMap, exclusionMap) {
    var added = 0;
    var offset = 0;
    var rounds = 0;
    var maxRounds = 8;

    while (list.length < targetSize && rounds < maxRounds) {
        var remaining = targetSize - list.length;
        var requestSize = Math.max(remaining, 50);
        var followers = await new Promise(function(resolve) {
            if (typeof fetchRecentFollowers === 'function') {
                fetchRecentFollowers(String(profile.id), requestSize, offset, function(users) {
                    resolve(Array.isArray(users) ? users : []);
                });
                return;
            }
            resolve([]);
        });

        if (!followers.length) break;

        var before = list.length;
        for (var i = 0; i < followers.length && list.length < targetSize; i++) {
            if (rdgAssistantPushUniqueAcct(list, seenMap, followers[i], exclusionMap)) added++;
        }

        if (list.length >= targetSize) break;
        if (followers.length < requestSize) break;
        if (list.length === before) {
            offset += followers.length;
        } else {
            offset += followers.length;
        }
        rounds++;
    }

    return added;
}

function rdgAssistantBuildAudienceExclusionMap(profile) {
    var excluded = {};
    var processedMap = rdgAssistantEnsureProcessedAudienceMap(profile);
    Object.keys(processedMap).forEach(function(acctId) {
        if (!acctId) return;
        excluded[String(acctId)] = true;
    });
    for (var i = 0; i < acctsPreviouslyAttempted.length; i++) {
        var attempted = acctsPreviouslyAttempted[i] || {};
        var attemptedId = attempted.id || attempted.pk || attempted.user_id || '';
        attemptedId = attemptedId ? String(attemptedId) : '';
        if (!attemptedId) continue;
        excluded[attemptedId] = true;
    }
    return excluded;
}

async function rdgAssistantCollectAudience(profile) {
    var targetSize = parseInt(rdgAssistantState.settings.targetPerProfile || 10, 10) || 10;
    var processedCount = profile && profile.assistant && profile.assistant.processedAudienceIds ? Object.keys(profile.assistant.processedAudienceIds).length : 0;
    var currentRunInteractions = profile && profile.assistant ? (parseInt(profile.assistant.currentRunInteractions || 0, 10) || 0) : 0;
    var remainingNeeded = Math.max(0, targetSize - currentRunInteractions);
    var collectionTarget = Math.max(targetSize, remainingNeeded + Math.min(targetSize, processedCount));
    collectionTarget = Math.min(targetSize * 3, Math.max(collectionTarget, remainingNeeded || targetSize));
    var collected = [];
    var seenMap = {};
    var exclusionMap = rdgAssistantBuildAudienceExclusionMap(profile);
    var beforeComments = collected.length;
    await rdgAssistantCollectFromComments(profile, collectionTarget, collected, seenMap, exclusionMap);
    var commentsAdded = collected.length - beforeComments;
    var beforeLikes = collected.length;
    if (collected.length < collectionTarget) {
        await rdgAssistantCollectFromLikes(profile, collectionTarget, collected, seenMap, exclusionMap);
    }
    var likesAdded = collected.length - beforeLikes;
    var beforeFollowers = collected.length;
    if (collected.length < collectionTarget) {
        await rdgAssistantFillAudienceWithRecentFollowers(profile, collectionTarget, collected, seenMap, exclusionMap);
    }
    var followersAdded = collected.length - beforeFollowers;

    profile.assistant.collectedAudience = collected.slice(0, collectionTarget);
    profile.assistant.audienceSources = {
        likes: likesAdded,
        comments: commentsAdded,
        followers: followersAdded
    };
    profile.assistant.collectedAt = Date.now();
    var visibleSaved = Math.min(targetSize, profile.assistant.collectedAudience.length);
    profile.assistant.totalCollected = visibleSaved;
    if (visibleSaved > 0) {
        profile.assistant.emptyAudienceRetryCount = 0;
        profile.assistant.emptyAudienceSkippedAt = 0;
        if (rdgAssistantState && rdgAssistantState.run && String(rdgAssistantState.run.emptyAudienceRetryProfileId || '') === String(profile.id || '')) {
            rdgAssistantState.run.emptyAudienceRetryAt = 0;
            rdgAssistantState.run.emptyAudienceRetryProfileId = '';
        }
    }
    if (visibleSaved <= 0) {
        rdgAssistantSetProfileStatus(profile, 'Sem publico salvo. Nova tentativa automatica em 10 segundos.');
    } else {
        rdgAssistantSetProfileStatus(profile, 'Publico salvo (' + visibleSaved + ')');
    }
    rdgAssistantLog(
        'Comentarios: ' + commentsAdded + ' | Curtidas: ' + likesAdded + ' | Seguidores recentes: ' + followersAdded + ' | Total final: ' + visibleSaved + (profile.assistant.collectedAudience.length > visibleSaved ? ' | Reserva extra: ' + (profile.assistant.collectedAudience.length - visibleSaved) : ''),
        'collecting',
        true
    );
    if (visibleSaved <= 0) {
        rdgAssistantAddHistory(
            'Sem publico salvo em @' + profile.username,
            'Nenhum publico valido foi encontrado nesta coleta. O assistente vai tentar novamente automaticamente em alguns segundos.'
        );
        rdgAssistantLog('Nenhum publico valido foi encontrado em @' + profile.username + '. Nova tentativa automatica em 10 segundos.', 'collecting', true);
    }
    rdgAssistantAddHistory(
        'Publico salvo de @' + profile.username,
        'Comentarios: ' + commentsAdded + ' | Curtidas: ' + likesAdded + ' | Seguidores recentes: ' + followersAdded + ' | Total final: ' + visibleSaved + (profile.assistant.collectedAudience.length > visibleSaved ? ' | Reserva extra: ' + (profile.assistant.collectedAudience.length - visibleSaved) : '') + '.'
    );
}

function rdgAssistantIsQueueWorking() {
    return $('#btnProcessQueue').hasClass('pulsing') || alreadyLiking === true || (Array.isArray(timeoutsQueue) && timeoutsQueue.length > 0);
}

function rdgAssistantStartInteraction(profile) {
    var build = rdgAssistantBuildInteractionQueue(profile);
    var audience = build.queue;
    if (!Array.isArray(profile.assistant.collectedAudience) || !profile.assistant.collectedAudience.length) {
        rdgAssistantSetProfileStatus(profile, 'Sem publico salvo');
        return false;
    }
    rdgAssistantClearInteractionQueues();
    acctsQueue = audience.map(function(item) { return $.extend(true, {}, item); });
    arrayOfUsersToDiv(acctsQueue, true);
    $('#radioFollowAndLike').prop('checked', true);
    $('#numberFollowLikeLatestPics').val(rdgAssistantState.settings.likesPerUser);
    saveOptions();
    initProcessQueue();
    rdgAssistantState.run.phase = 'interacting';
    rdgAssistantState.run.activeProfileId = String(profile.id);
    rdgAssistantState.run.updatedAt = Date.now();
    rdgAssistantSetLiveProgress('Interagindo com o publico salvo.', profile.username, 0, '');
    rdgAssistantSetProfileStatus(profile, 'Interagindo automaticamente e aguardando o primeiro follow');
    if (build.preProcessedCount > 0) {
        rdgAssistantLog(build.preProcessedCount + ' conta(s) ja tinham historico de interacao e foram descontadas desta lista antes do inicio.', 'interacting', true);
    }
    if (!acctsQueue.length) {
        rdgAssistantSetProfileStatus(profile, 'Lista atual ja estava concluida pelo historico salvo');
    }
    rdgAssistantLog('Agora vamos interagir com o publico de @' + profile.username + '. Permanece ligado e nao atualize a pagina.', 'interacting');
    return true;
}

function rdgAssistantHandleEmptyAudienceRetry(profile) {
    if (!rdgAssistantState || !rdgAssistantState.run || !profile) return false;
    if (!profile.assistant) profile.assistant = rdgAssistantDefaultProfileAssistantState();
    profile.assistant.emptyAudienceRetryCount = (parseInt(profile.assistant.emptyAudienceRetryCount || 0, 10) || 0) + 1;
    profile.assistant.lastUpdatedAt = Date.now();
    if (profile.assistant.emptyAudienceRetryCount >= 3) {
        rdgAssistantClearInteractionQueues();
        profile.assistant.emptyAudienceSkippedAt = Date.now();
        profile.assistant.interactionCompletedAt = Date.now();
        profile.assistant.dmCompletedAt = Date.now();
        profile.assistant.warmingUntil = 0;
        profile.assistant.collectedAudience = [];
        profile.assistant.totalCollected = 0;
        rdgAssistantSetProfileStatus(profile, 'Sem publico valido nesta rodada. Perfil pulado automaticamente.');
        rdgAssistantAddHistory(
            'Perfil sem publico valido',
            '@' + profile.username + ' nao retornou publico valido apos 3 tentativas. O assistente pulou este perfil automaticamente para nao travar a rodada.'
        );
        rdgAssistantLog('Nenhum publico valido foi encontrado em @' + profile.username + ' apos 3 tentativas. O assistente vai pular este perfil automaticamente para continuar a rodada.', 'collecting', true);
        if (rdgAssistantScheduleProfileTransitionDelay(profile) !== true) {
            rdgAssistantState.run.phase = 'collecting';
            rdgAssistantState.run.activeProfileId = '';
            rdgAssistantState.run.updatedAt = Date.now();
            rdgScheduleTimeout(function() {
                if (rdgAssistantState && rdgAssistantState.run && rdgAssistantState.run.status === 'running') {
                    rdgAssistantTick();
                }
            }, 50, 'assistant.empty_audience.skip_continue', { profileId: profile.id || '', username: profile.username || '' });
        }
        rdgAssistantSaveState();
        rdgAssistantRender();
        return true;
    }
    rdgAssistantClearInteractionQueues();
    rdgAssistantState.run.phase = 'collecting';
    rdgAssistantState.run.status = 'running';
    rdgAssistantState.run.activeProfileId = String(profile.id || '');
    rdgAssistantState.run.emptyAudienceRetryAt = Date.now() + 10000;
    rdgAssistantState.run.emptyAudienceRetryProfileId = String(profile.id || '');
    rdgAssistantState.run.updatedAt = Date.now();
    rdgAssistantSetLiveProgress('Nenhum publico salvo nesta coleta. Buscando novamente em 10 segundos.', profile.username, rdgAssistantState.run.emptyAudienceRetryAt, 'Nova coleta');
    rdgAssistantLog('Nenhum publico valido foi encontrado em @' + profile.username + '. Tentativa ' + profile.assistant.emptyAudienceRetryCount + '/3. Nova coleta automatica em 10 segundos.', 'collecting', true);
    rdgScheduleTimeout(function() {
        if (!rdgAssistantState || !rdgAssistantState.run) return;
        if (rdgAssistantState.run.status !== 'running') return;
        if (String(rdgAssistantState.run.emptyAudienceRetryProfileId || '') !== String(profile.id || '')) return;
        rdgAssistantTick();
    }, 10050, 'assistant.empty_audience.retry_collect', {
        profileId: profile.id || '',
        username: profile.username || '',
        retryCount: profile.assistant.emptyAudienceRetryCount
    });
    rdgAssistantSaveState();
    rdgAssistantRender();
    return true;
}

function rdgAssistantFinishInteraction(profile) {
    var warmupDays = parseInt((rdgAssistantState && rdgAssistantState.settings && rdgAssistantState.settings.warmupDays) || 0, 10) || 0;
    var warmupMs = warmupDays * 24 * 3600000;
    profile.assistant.currentRunInteractions = rdgAssistantGetCurrentRunInteractions(profile, true);
    profile.assistant.interactionCompletedAt = Date.now();
    profile.assistant.warmingUntil = warmupMs > 0 ? (Date.now() + warmupMs) : 0;
    if (warmupMs > 0) {
        rdgAssistantSetProfileStatus(profile, 'Janela de aquecimento ate ' + rdgAssistantFormatDate(profile.assistant.warmingUntil));
        rdgAssistantAddHistory(
            'Interacoes concluidas em @' + profile.username,
            'Foram executadas ' + rdgAssistantFormatNumber(profile.assistant.currentRunInteractions || 0) + ' interacoes nesta rodada. O direct so sera liberado quando os 3 publicos terminarem as interacoes e completarem pelo menos ' + warmupDays + ' dia(s) de aquecimento.'
        );
        rdgAssistantLog('Interacoes concluidas no perfil @' + profile.username + '. Agora ele entra em janela de aquecimento de ' + warmupDays + ' dia(s) ate o direct.', 'warming');
        return;
    }
    var targetPerProfile = rdgAssistantGetTargetPerProfile();
    rdgAssistantSetProfileStatus(profile, 'Interacoes concluidas. Aguardando os outros perfis fecharem ' + targetPerProfile + '/' + targetPerProfile + ' para liberar o direct');
    rdgAssistantAddHistory(
        'Interacoes concluidas em @' + profile.username,
        'Foram executadas ' + rdgAssistantFormatNumber(profile.assistant.currentRunInteractions || 0) + ' interacoes nesta rodada. Assim que os 3 perfis fecharem ' + targetPerProfile + '/' + targetPerProfile + ', o direct sera liberado automaticamente.'
    );
    rdgAssistantLog('Interacoes concluidas no perfil @' + profile.username + '. Assim que os 3 perfis fecharem ' + targetPerProfile + '/' + targetPerProfile + ', o assistente libera o direct automaticamente.', 'collecting', true);
}

function rdgAssistantClearProfileTransitionDelay() {
    if (!rdgAssistantState || !rdgAssistantState.run) return false;
    rdgAssistantState.run.profileTransitionAt = 0;
    rdgAssistantState.run.profileTransitionNextProfileId = '';
    rdgAssistantState.run.profileTransitionNextUsername = '';
    rdgAssistantState.run.profileTransitionFromUsername = '';
    return true;
}

function rdgAssistantGetNextPendingProfileForRun(runId, excludeProfileId) {
    if (!rdgAssistantState || !Array.isArray(rdgAssistantState.profiles)) return null;
    var safeRunId = runId ? String(runId) : '';
    var safeExcludeId = excludeProfileId ? String(excludeProfileId) : '';
    for (var i = 0; i < rdgAssistantState.profiles.length; i++) {
        var profile = rdgAssistantState.profiles[i];
        if (!profile || !profile.assistant) continue;
        if (safeRunId && String(profile.assistant.currentRunId || '') !== safeRunId) continue;
        if (safeExcludeId && String(profile.id || '') === safeExcludeId) continue;
        if (profile.assistant.emptyAudienceSkippedAt) continue;
        if (!profile.assistant.interactionCompletedAt) return profile;
    }
    return null;
}

function rdgAssistantScheduleProfileTransitionDelay(finishedProfile) {
    if (!rdgAssistantState || !rdgAssistantState.run || !finishedProfile) return false;
    var nextProfile = rdgAssistantGetNextPendingProfileForRun(rdgAssistantState.run.id, finishedProfile.id);
    if (!nextProfile) {
        rdgAssistantClearProfileTransitionDelay();
        return false;
    }
    var delayMs = 10000;
    var transitionAt = Date.now() + delayMs;
    var fromUsername = finishedProfile.username || '';
    var nextUsername = nextProfile.username || '';
    rdgAssistantState.run.phase = 'collecting';
    rdgAssistantState.run.activeProfileId = '';
    rdgAssistantState.run.pendingInteractionCooldown = false;
    rdgAssistantState.run.profileTransitionAt = transitionAt;
    rdgAssistantState.run.profileTransitionNextProfileId = String(nextProfile.id || '');
    rdgAssistantState.run.profileTransitionNextUsername = nextUsername;
    rdgAssistantState.run.profileTransitionFromUsername = fromUsername;
    rdgAssistantState.run.updatedAt = Date.now();
    rdgAssistantSetLiveProgress('Pagina @' + fromUsername + ' finalizou. Vamos para @' + nextUsername + '.', nextUsername, transitionAt, 'Mudando de perfil');
    rdgAssistantLog('Pagina @' + fromUsername + ' finalizou. Vamos para @' + nextUsername + ' em 10 segundos.', 'collecting', true);
    rdgScheduleTimeout(function() {
        if (!rdgAssistantState || !rdgAssistantState.run) return;
        if (rdgAssistantState.run.status !== 'running') return;
        if ((parseInt(rdgAssistantState.run.profileTransitionAt || 0, 10) || 0) > Date.now()) return;
        rdgAssistantTick();
    }, delayMs + 50, 'assistant.profile.transition.delay', {
        fromUsername: fromUsername,
        nextUsername: nextUsername
    });
    return true;
}

function rdgAssistantGetSuccessfulInteractionIds(profile) {
    var ids = {};
    if (!profile || !profile.assistant || !profile.assistant.processedAudienceIds) return ids;
    Object.keys(profile.assistant.processedAudienceIds).forEach(function(acctId) {
        var meta = profile.assistant.processedAudienceIds[acctId] || {};
        var reason = String(meta.reason || '');
        if (reason.indexOf('follow_ok') === 0) ids[String(acctId)] = true;
    });
    return ids;
}

function rdgAssistantClearInteractionQueues() {
    if (Array.isArray(timeoutsQueue) && timeoutsQueue.length > 0) {
        for (var i = 0; i < timeoutsQueue.length; i++) {
            try { clearTimeout(timeoutsQueue[i]); } catch (eTimeout) {}
        }
    }
    timeoutsQueue = [];
    if (rdgAssistantNextFollowTimerId) {
        try { clearTimeout(rdgAssistantNextFollowTimerId); } catch (eTimer) {}
        rdgAssistantNextFollowTimerId = null;
    }
    alreadyLiking = false;
    rdgLikeVerificationDone = false;
    if (rdgAssistantState && rdgAssistantState.run) {
        rdgAssistantClearPendingNextFollow();
        rdgAssistantState.run.nextActionAt = 0;
        rdgAssistantState.run.nextActionLabel = '';
        rdgAssistantState.run.currentAction = '';
        rdgAssistantState.run.currentTargetUsername = '';
        rdgAssistantState.run.pendingInteractionCooldown = false;
    }
    acctsQueue = [];
    mediaToLike = [];
    currentList = 'acctsQueue';
    try { $('#igBotInjectedContainer *').removeClass('pulsing'); } catch (eUi) {}
    arrayOfUsersToDiv(acctsQueue, true);
    arrayOfMediaToDiv(mediaToLike, true);
}

function rdgAssistantGetRunProfileIds() {
    if (!rdgAssistantState || !rdgAssistantState.run) return {};
    var ids = {};
    rdgAssistantState.profiles.forEach(function(profile) {
        if (profile.assistant && profile.assistant.currentRunId === rdgAssistantState.run.id) {
            ids = $.extend(ids, rdgAssistantGetSuccessfulInteractionIds(profile));
        }
    });
    return ids;
}

function rdgAssistantLoadDmHistoryPromise() {
    return new Promise(function(resolve) {
        if (typeof loadDMHistory === 'function') {
            loadDMHistory(function(history) {
                resolve(history || {});
            });
            return;
        }
        resolve({});
    });
}

function rdgAssistantFetchFollowersForDm(limit) {
    return new Promise(function(resolve) {
        if (typeof fetchRecentFollowers === 'function') {
            fetchRecentFollowers(getLoggedUserId(), limit, 0, function(users) {
                resolve(Array.isArray(users) ? users : []);
            });
            return;
        }
        resolve([]);
    });
}

async function rdgAssistantStartDmPhase() {
    if (!rdgAssistantState || !rdgAssistantState.run) return false;
    var run = rdgAssistantState.run;
    var runProfiles = rdgAssistantGetProfilesForRun(run.id);
    if (!runProfiles.length) {
        rdgAssistantLog('Nao foi possivel abrir o direct porque ainda nao ha perfis vinculados a esta rodada.', 'warming', true);
        return false;
    }
    if (!rdgAssistantAreAllRunProfilesInteractionCompleted(run)) {
        rdgAssistantState.run.phase = 'collecting';
        rdgAssistantLog('O direct ainda nao foi liberado. Primeiro vamos completar as interacoes dos 3 publicos da rodada.', 'collecting', true);
        return false;
    }
    rdgAssistantState.run.phase = 'sending_dm';
    rdgAssistantState.run.dmStarted = true;
    rdgAssistantState.run.dmStatusText = 'Carregando interessados qualificados para o direct automatico.';
    rdgAssistantState.run.dmQueueSize = Math.max(0, parseInt(rdgAssistantState.run.dmQueueSize || 0, 10) || 0);
    rdgAssistantState.run.dmProcessedCount = Math.max(0, parseInt(rdgAssistantState.run.dmProcessedCount || 0, 10) || 0);
    rdgAssistantRenderDmProgressPopup();
    if (run.dmStarted === true) {
        var resumedExistingDm = await rdgAssistantResumeMassDmFromStoragePromise();
        if (resumedExistingDm) {
            rdgAssistantState.run.status = 'running';
            rdgAssistantState.run.dmStatusText = rdgAssistantState.run.dmStatusText || 'Retomando o envio em massa do ponto salvo.';
            rdgAssistantLog('Direct pendente encontrado. Retomando do ponto salvo sem reiniciar as interacoes.', 'sending_dm', true);
            rdgAssistantRenderDmProgressPopup();
            return true;
        }
    }
    rdgAssistantState.run.dmStatusText = 'Carregando interessados qualificados para montar a fila do direct.';
    rdgAssistantRenderDmProgressPopup();
    var runIds = rdgAssistantGetRunProfileIds();
    var dmLimit = Math.max(200, Object.keys(runIds).length);
    var followers = await rdgAssistantFetchFollowersForDm(dmLimit);
    var targets = followers.filter(function(user) {
        return user && runIds[String(user.id || user.pk || '')];
    }).map(rdgAssistantSlimAcct);
    var history = await rdgAssistantLoadDmHistoryPromise();
    targets = targets.filter(function(user) {
        return !history[user.id];
    });

    rdgAssistantState.profiles.forEach(function(profile) {
        if (profile.assistant && profile.assistant.currentRunId === rdgAssistantState.run.id) {
            var collectedIds = rdgAssistantGetSuccessfulInteractionIds(profile);
            var convertedForProfile = 0;
            targets.forEach(function(user) {
                if (user && collectedIds[String(user.id || user.pk || '')]) convertedForProfile++;
            });
            profile.assistant.currentRunConverted = convertedForProfile;
            profile.assistant.totalConverted = Math.max(parseInt(profile.assistant.totalConverted || 0, 10) || 0, convertedForProfile);
            if (convertedForProfile > 0) {
                profile.assistant.currentStatus = 'Convertidos: ' + convertedForProfile + ' aguardando direct';
            }
        }
    });
    rdgAssistantSetLiveProgress('Verificando quem seguiu de volta dos interagidos.', '', 0, '');
    rdgAssistantLog('Convertidos encontrados nesta rodada: ' + targets.length + ' interagido(s) seguiram de volta.', 'warming', true);

    if (!targets.length) {
        rdgAssistantAddHistory('Sem novos seguidores para DM', 'Nenhum interagido recente seguiu de volta nesta rodada.');
        rdgAssistantState.run.phase = 'completed';
        rdgAssistantState.run.status = 'completed';
        rdgAssistantState.run.updatedAt = Date.now();
        rdgAssistantState.run.dmQualifiedCount = 0;
        rdgAssistantState.run.dmSentCount = 0;
        rdgAssistantState.run.dmProcessedCount = 0;
        rdgAssistantState.run.dmStatusText = 'Nenhum interessado qualificado apareceu nesta rodada.';
        rdgAssistantCloseDmProgressPopup();
        rdgAssistantLog('Nenhum novo seguidor interagido foi encontrado para o direct desta rodada.', 'completed');
        var progressSnapshot = rdgAssistantGetRunProgressSnapshot(rdgAssistantState.run);
        rdgAssistantStampActiveCycleCompletion(progressSnapshot.totalInteractions || 0, 0, 0);
        rdgAssistantShowCycleSummaryPopup(progressSnapshot.totalInteractions || 0, 0, 0);
        return true;
    }

    if (typeof renderTableWithHistory === 'function') {
        renderTableWithHistory(targets, history);
    }
    if (typeof initBeta === 'function') initBeta();
    rdgAssistantSyncDirectDmInputs();
    if (typeof startMassDM === 'function') {
        rdgAssistantState.run.dmQualifiedCount = targets.length;
        rdgAssistantState.run.dmQualifiedAt = Date.now();
        rdgAssistantState.run.dmQueueSize = targets.length;
        rdgAssistantState.run.dmHistoryBaselineCount = Object.keys(history).length;
        rdgAssistantState.run.dmSentCount = 0;
        rdgAssistantState.run.dmProcessedCount = 0;
        rdgAssistantState.run.dmStatusText = 'Preparando o envio em massa de mensagens para os interessados qualificados.';
        rdgAssistantShowNoticePopup(
            'Interessados rastreados e qualificados',
            'Foram encontrados ' + rdgAssistantFormatNumber(targets.length) + ' interessado(s) qualificado(s). O assistente iniciou o disparo automatico de mensagens em massa.',
            'Tudo continua no automatico: os 3 perfis ja fecharam as ' + rdgAssistantGetTargetPerProfile() + ' interacoes cada e o progresso do envio aparece aqui mesmo na tela do assistente.',
            {
                badgeText: 'Direct Automatico',
                badgeBg: 'rgba(34,197,94,0.18)',
                badgeColor: '#bbf7d0',
                autoCloseMs: 12000
            }
        );
        rdgAssistantRenderDmProgressPopup();
        rdgAssistantLog('Iniciando o direct em massa para ' + targets.length + ' interagido(s) que seguiram de volta.', 'sending_dm');
        outputMessage('[Assistente] Interessados rastreados e qualificados: ' + targets.length + '. Iniciando disparo automatico de mensagens e mantendo o acompanhamento na tela do assistente.');
        startMassDM();
        return true;
    } else {
        rdgAssistantLog('O modulo de direct ainda nao esta disponivel para finalizar esta etapa.', 'sending_dm', true);
        return false;
    }
}

async function rdgAssistantFinishDmPhaseIfDone() {
    if (!rdgAssistantState || !rdgAssistantState.run || rdgAssistantState.run.phase !== 'sending_dm' || rdgAssistantState.run.dmStarted !== true) return;
    if (typeof isMassDMRunning !== 'undefined' && isMassDMRunning === true) return;
    var history = await rdgAssistantLoadDmHistoryPromise();
    var sentNow = Math.max(0, Object.keys(history).length - (rdgAssistantState.run.dmHistoryBaselineCount || 0));
    var qualified = Math.max(0, parseInt(rdgAssistantState.run.dmQualifiedCount || rdgAssistantState.run.dmQueueSize || 0, 10) || 0);
    var dmRuntime = await rdgAssistantLoadMassDmRuntimePromise();
    var pendingDmCount = 0;
    if (dmRuntime && Array.isArray(dmRuntime.queue) && dmRuntime.queue.length) {
        for (var q = 0; q < dmRuntime.queue.length; q++) {
            var queueUser = dmRuntime.queue[q];
            if (!queueUser) continue;
            var queueUserId = String(queueUser.id || '');
            if (queueUser.processed !== true && !history[queueUserId]) pendingDmCount++;
        }
        rdgAssistantState.run.dmQueueSize = Math.max(parseInt(rdgAssistantState.run.dmQueueSize || 0, 10) || 0, dmRuntime.queue.length);
        rdgAssistantState.run.dmProcessedCount = Math.max(parseInt(rdgAssistantState.run.dmProcessedCount || 0, 10) || 0, dmRuntime.queue.length - pendingDmCount);
    }
    if (pendingDmCount > 0 || (qualified > 0 && sentNow < qualified)) {
        var remaining = pendingDmCount > 0 ? pendingDmCount : Math.max(0, qualified - sentNow);
        rdgAssistantState.run.dmSentCount = sentNow;
        rdgAssistantState.run.dmStatusText = 'Ainda restam ' + remaining + ' interessado(s) pendente(s). Retomando o direct automatico para nao perder ninguem.';
        rdgAssistantLog('Ainda restam ' + remaining + ' interessado(s) pendente(s) no direct. Retomando do ponto salvo.', 'sending_dm', true);
        var resumedPendingDm = await rdgAssistantResumeMassDmFromStoragePromise();
        if (resumedPendingDm) {
            rdgAssistantState.run.status = 'running';
            rdgAssistantSaveState();
            rdgAssistantRender();
            return;
        }
        rdgAssistantSaveState();
        rdgAssistantRender();
        return;
    }
    rdgAssistantState.profiles.forEach(function(profile) {
        if (profile.assistant && profile.assistant.currentRunId === rdgAssistantState.run.id) {
            profile.assistant.totalDmSent = (parseInt(profile.assistant.totalDmSent || 0, 10) || 0) + sentNow;
            profile.assistant.dmCompletedAt = Date.now();
            if (sentNow > 0) profile.assistant.currentStatus = 'Direct finalizado';
        }
    });
    rdgAssistantAddHistory('Direct finalizado', 'Foram enviados ' + sentNow + ' direct(s) nesta rodada automatica do assistente.');
    rdgAssistantState.run.phase = 'completed';
    rdgAssistantState.run.status = 'completed';
    rdgAssistantState.run.updatedAt = Date.now();
    rdgAssistantState.run.dmSentCount = sentNow;
    rdgAssistantState.run.dmProcessedCount = Math.max(parseInt(rdgAssistantState.run.dmProcessedCount || 0, 10) || 0, qualified);
    rdgAssistantState.run.dmStatusText = 'Envio em massa concluido. Todos os interessados processados.';
    rdgAssistantRestoreManualDelays();
    rdgAssistantCloseDmProgressPopup();
    rdgAssistantLog('Envio em massa concluido. Abordamos ' + sentNow + ' pessoa(s). Interessados identificados e qualificados: ' + qualified + '. Voce pode iniciar um novo ciclo agora mesmo.', 'completed', true);
    outputMessage('[Assistente] Envio em massa concluido. Abordamos ' + sentNow + ' pessoa(s). Interessados qualificados: ' + qualified + '.');
    var progressSnapshot = rdgAssistantGetRunProgressSnapshot(rdgAssistantState.run);
    rdgAssistantStampActiveCycleCompletion(progressSnapshot.totalInteractions || 0, qualified, sentNow);
    rdgAssistantShowCycleSummaryPopup(progressSnapshot.totalInteractions || 0, qualified, sentNow);
    rdgAssistantSaveState();
    rdgAssistantRender();
}

async function rdgAssistantTick() {
    if (rdgAssistantBusy || !rdgAssistantState) return;
    if (!rdgCanShowUnlockedAutomationUi()) {
        rdgAssistantCloseDmProgressPopup();
        rdgAssistantCloseRunPopup(false);
        return;
    }
    try {
        var currentScopeId = rdgAssistantGetStorageScopeId();
        if (currentScopeId && rdgAssistantState.accountScopeId && String(rdgAssistantState.accountScopeId) !== String(currentScopeId)) {
            rdgAssistantBusy = true;
            rdgAssistantLoadState(function() {
                rdgLoadScopedLogIntoConsole();
                rdgAssistantBusy = false;
                rdgAssistantRender();
            });
            return;
        }
    } catch (eScope) {}
    if (!rdgAssistantState.run) return;
    try {
        rdgAssistantHydrateAccountRestLockFromRun(rdgAssistantState.run);
    } catch (eHydrateTick) {}
    try {
        if (rdgAssistantAutoRecoverInvalidLongPause('Pausa longa invalida corrigida automaticamente apos recalculo do tempo ativo da conta.')) {
            rdgAssistantSaveState();
            rdgAssistantRender();
            setTimeout(function() {
                try { rdgAssistantTick(); } catch (eRetryTick) {}
            }, 250);
            return;
        }
    } catch (eAutoRecoverTick) {}
    if (['completed', 'idle', 'stopped', 'paused'].indexOf(rdgAssistantState.run.status) > -1) {
        rdgAssistantRender();
        return;
    }
    if (rdgAssistantHasAccountRestLock() && rdgAssistantState.run.status !== 'resting' && rdgAssistantState.run.status !== 'paused' && rdgAssistantState.run.status !== 'stopped') {
        rdgAssistantApplyAccountRestLockToCurrentRun();
        rdgAssistantSaveState();
        rdgAssistantRender();
        return;
    }

    if (rdgAssistantState.run.status === 'waiting_instagram') {
        rdgAssistantSetLiveProgress('Assistente aguardando para retomar com seguranca.', '', rdgAssistantState.run.waitUntil, 'Retomada automatica');
        if (rdgAssistantState.run.waitUntil > Date.now()) {
            rdgAssistantRender();
            return;
        }
        var resumePhase = rdgAssistantState.run.resumePhase || '';
        rdgAssistantRestoreManualDelays();
        rdgAssistantResumeAutomaticallyFromWait(resumePhase, 'A pausa tecnica terminou. O assistente retomou automaticamente do ponto salvo.');
        rdgAssistantSaveState();
        rdgAssistantRender();
        return;
    }

    if (rdgAssistantState.run.status === 'resting') {
        if (rdgAssistantHasAccountRestLock()) {
            rdgAssistantState.run.waitUntil = Math.max(parseInt(rdgAssistantState.run.waitUntil || 0, 10) || 0, rdgAssistantGetAccountRestUntil());
        }
        rdgAssistantSetLiveProgress('Assistente em descanso para proteger o algoritmo.', '', rdgAssistantState.run.waitUntil, 'Fim do descanso');
        if (rdgAssistantState.run.waitUntil > Date.now()) {
            rdgAssistantRender();
            return;
        }
        var resumePhase = rdgAssistantState.run.resumePhase || '';
        rdgAssistantCloseNoticePopup();
        rdgAssistantResetAccountWorkWindow(Date.now());
        var accountRuntime = rdgAssistantGetAccountRuntime();
        if (accountRuntime) accountRuntime.restStartedAt = 0;
        rdgAssistantRestoreManualDelays();
        rdgAssistantResumeAutomaticallyFromWait(resumePhase, 'O descanso terminou. O assistente retomou automaticamente a campanha.');
        rdgAssistantSaveState();
        rdgAssistantRender();
        return;
    }

    if (rdgAssistantState.run.status === 'paused') {
        rdgAssistantRender();
        return;
    }

    if (rdgAssistantState.run.status === 'running') {
        var now = Date.now();
        var limitMs = (parseInt(rdgAssistantState.settings.workHoursPerDay || 10, 10) || 10) * 3600000;
        var restMs = (parseInt(rdgAssistantState.settings.restHoursPerDay || 10, 10) || 10) * 3600000;
        var runtime = rdgAssistantGetAccountRuntime();
        if (!runtime.workWindowStartedAt) runtime.workWindowStartedAt = now;
        if (!runtime.workLastTickAt) runtime.workLastTickAt = now;
        var delta = now - runtime.workLastTickAt;
        if (delta < 0 || delta > 600000) delta = 0;
        runtime.workMsInWindow = (parseInt(runtime.workMsInWindow || 0, 10) || 0) + delta;
        runtime.workLastTickAt = now;
        runtime.lastUpdatedAt = now;
        rdgAssistantSyncRunWorkCounters(rdgAssistantState.run);
        if (runtime.workMsInWindow >= limitMs) {
            rdgAssistantState.run.resumePhase = rdgAssistantState.run.phase && rdgAssistantState.run.phase !== 'resting' ? rdgAssistantState.run.phase : '';
            rdgAssistantState.run.status = 'resting';
            rdgAssistantState.run.phase = 'resting';
            rdgAssistantState.run.waitUntil = now + restMs;
            rdgAssistantSetAccountRestLock(rdgAssistantState.run.waitUntil, now);
            rdgAssistantSetLiveProgress('Descanso iniciado apos a janela de trabalho.', '', rdgAssistantState.run.waitUntil, 'Fim do descanso');
            rdgStopAllPendingActions('Assistente pausado para descansar.');
            try {
                if (typeof stopMassDM === 'function') stopMassDM();
            } catch (e2) {}
            var restPopupCopy = rdgAssistantBuildRestPopupCopy(rdgAssistantState.run.waitUntil);
            rdgAssistantAddHistory('Descanso do algoritmo', 'O assistente trabalhou por ' + (rdgAssistantState.settings.workHoursPerDay || 10) + 'h hoje. Agora vai descansar e pode retomar em ' + rdgAssistantFormatDate(rdgAssistantState.run.waitUntil) + '.');
            rdgAssistantLog('O assistente atingiu o limite de trabalho do dia. Descansando para proteger o algoritmo do Instagram.', 'resting', true);
            outputMessage('[Assistente] Descanso automatico iniciado apos ' + (rdgAssistantState.settings.workHoursPerDay || 10) + 'h de trabalho. Retomada prevista em ' + rdgAssistantFormatDate(rdgAssistantState.run.waitUntil) + '.');
            rdgAssistantShowNoticePopup(restPopupCopy.title, restPopupCopy.message, restPopupCopy.subMessage);
            rdgAssistantSaveState();
            rdgAssistantRender();
            return;
        }
    }

    rdgAssistantBusy = true;
    try {
        if (rdgAssistantState.run.phase === 'unfollowing') {
            if (rdgAssistantIsQueueWorking()) {
                rdgAssistantSaveState();
                rdgAssistantRender();
                return;
            }
            var targetFollowing = parseInt(rdgAssistantState.run.unfollowTargetFollowing || (rdgAssistantState.settings.assistantUnfollowTargetFollowing || 3000), 10) || 3000;
            var stats = await rdgAssistantFetchMyAccountStats();
            if (stats && stats.following > 0 && stats.following <= targetFollowing) {
                rdgAssistantAddHistory('Unfollow concluido', 'Seguindo atual: ' + stats.following + '. Agora o assistente vai continuar o ciclo normal.');
                rdgAssistantLog('Unfollow concluido. Seguindo atual: ' + stats.following + '. Continuando com as interacoes.', 'collecting', true);
                rdgAssistantState.run.phase = 'collecting';
                rdgAssistantState.run.activeProfileId = '';
                rdgAssistantSaveState();
                rdgAssistantRender();
                return;
            }
            await rdgAssistantStartUnfollowBatch(rdgAssistantState.run.unfollowMode || 'non_followers');
            rdgAssistantSaveState();
            rdgAssistantRender();
            return;
        }

        if (rdgAssistantState.run.phase === 'interacting') {
            var activeProfile = rdgAssistantGetProfileById(rdgAssistantState.run.activeProfileId);
            if (activeProfile && rdgAssistantIsQueueWorking()) {
                rdgAssistantSaveState();
                rdgAssistantRender();
                return;
            }
            if (activeProfile && rdgAssistantRecoverInteractionIfStalled() === true) {
                rdgAssistantSaveState();
                rdgAssistantRender();
                return;
            }
            if (activeProfile && (acctsQueue.length > 0 || mediaToLike.length > 0 || rdgAssistantState.run.pendingNextFollow === true)) {
                rdgAssistantResumeQueuedWorkIfNeeded();
                rdgAssistantSaveState();
                rdgAssistantRender();
                return;
            }
            if (activeProfile) {
                var targetTotal = rdgAssistantGetTargetPerProfile();
                var doneInteractions = rdgAssistantGetCurrentRunInteractions(activeProfile, true);

                if (doneInteractions < targetTotal) {
                    if (rdgAssistantResumeSavedInteractionQueue(activeProfile) === true) {
                        rdgAssistantSaveState();
                        rdgAssistantRender();
                        return;
                    }
                    rdgAssistantState.run.phase = 'collecting';
                    rdgAssistantState.run.activeProfileId = String(activeProfile.id);
                    rdgAssistantClearInteractionQueues();
                    rdgAssistantSetLiveProgress('Recarregando publico para completar ' + targetTotal + ' interacoes.', activeProfile.username, 0, '');
                    rdgAssistantSetProfileStatus(activeProfile, 'Recarregando publico para completar ' + targetTotal + ' interacoes');
                    rdgAssistantLog('A lista atual terminou antes de completar ' + targetTotal + ' interacoes. Recarregando publico para continuar no mesmo perfil.', 'collecting', true);
                    await rdgAssistantCollectAudience(activeProfile);
                    if (rdgAssistantStartInteraction(activeProfile) !== true) {
                        rdgAssistantHandleEmptyAudienceRetry(activeProfile);
                        return;
                    }
                    rdgAssistantSaveState();
                    rdgAssistantRender();
                    return;
                }

                rdgAssistantFinishInteraction(activeProfile);
                rdgAssistantClearInteractionQueues();
                if (rdgAssistantScheduleProfileTransitionDelay(activeProfile) === true) {
                    rdgAssistantSaveState();
                    rdgAssistantRender();
                    return;
                }
                rdgAssistantState.run.phase = 'collecting';
                rdgAssistantState.run.activeProfileId = '';
                rdgAssistantSaveState();
                rdgAssistantRender();
            }
        }

        if (rdgAssistantState.run.phase === 'sending_dm') {
            var resumedPendingDm = await rdgAssistantResumeMassDmFromStoragePromise();
            if (resumedPendingDm) {
                rdgAssistantState.run.status = 'running';
                rdgAssistantState.run.dmStarted = true;
                rdgAssistantState.run.dmStatusText = rdgAssistantState.run.dmStatusText || 'Retomando o envio em massa do ponto salvo.';
                rdgAssistantSaveState();
                rdgAssistantRender();
                return;
            }
            await rdgAssistantFinishDmPhaseIfDone();
            rdgAssistantSaveState();
            rdgAssistantRender();
            return;
        }

        var profileTransitionAt = parseInt(rdgAssistantState.run.profileTransitionAt || 0, 10) || 0;
        if (profileTransitionAt > Date.now()) {
            rdgAssistantRender();
            return;
        }
        if (profileTransitionAt > 0) {
            rdgAssistantClearProfileTransitionDelay();
            rdgAssistantSaveState();
            rdgAssistantRender();
        }

        var emptyAudienceRetryAt = parseInt(rdgAssistantState.run.emptyAudienceRetryAt || 0, 10) || 0;
        if (emptyAudienceRetryAt > Date.now()) {
            rdgAssistantRender();
            return;
        }
        if (emptyAudienceRetryAt > 0) {
            rdgAssistantState.run.emptyAudienceRetryAt = 0;
            rdgAssistantState.run.emptyAudienceRetryProfileId = '';
            rdgAssistantSaveState();
            rdgAssistantRender();
        }

        var pendingProfile = null;
        for (var i = 0; i < rdgAssistantState.profiles.length; i++) {
            var profile = rdgAssistantState.profiles[i];
            if (!profile.assistant || profile.assistant.currentRunId !== rdgAssistantState.run.id) continue;
            if (profile.assistant.emptyAudienceSkippedAt) continue;
            if (!profile.assistant.interactionCompletedAt) {
                pendingProfile = profile;
                break;
            }
        }

        if (pendingProfile) {
            rdgAssistantState.run.activeProfileId = String(pendingProfile.id);
            if (!pendingProfile.assistant.collectedAudience.length) {
                rdgAssistantClearInteractionQueues();
                rdgAssistantState.run.phase = 'collecting';
                rdgAssistantSetLiveProgress('Carregando publico quente da pagina concorrente.', pendingProfile.username, 0, '');
                rdgAssistantSetProfileStatus(pendingProfile, 'Carregando publico quente (' + rdgAssistantGetTargetPerProfile() + ')');
                rdgAssistantLog('Buscando novos publicos de @' + pendingProfile.username + ' para seguir automaticamente no proximo perfil.', 'collecting', true);
                rdgAssistantLog('Carregando publico quente de @' + pendingProfile.username + ' (curtidas, comentarios e seguidores).', 'collecting');
                await rdgAssistantCollectAudience(pendingProfile);
                rdgAssistantLog('Publico de @' + pendingProfile.username + ' carregado. Iniciando automaticamente as interacoes do proximo perfil.', 'interacting', true);
                if (rdgAssistantStartInteraction(pendingProfile) !== true) {
                    rdgAssistantHandleEmptyAudienceRetry(pendingProfile);
                    return;
                }
                rdgAssistantSaveState();
                rdgAssistantRender();
                return;
            }
            rdgAssistantLog('Continuando automaticamente no proximo perfil @' + pendingProfile.username + ' com o publico que ja estava salvo.', 'interacting', true);
            rdgAssistantStartInteraction(pendingProfile);
            rdgAssistantSaveState();
            rdgAssistantRender();
            return;
        }

        var hasDmPending = rdgAssistantGetRunProfilesPendingDm(rdgAssistantState.run).length > 0;

        if (hasDmPending) {
            var dmStarted = await rdgAssistantStartDmPhase();
            if (!dmStarted) {
                rdgAssistantSaveState();
                rdgAssistantRender();
                return;
            }
            rdgAssistantSaveState();
            rdgAssistantRender();
            return;
        }

        rdgAssistantState.run.phase = 'completed';
        rdgAssistantState.run.status = 'completed';
        rdgAssistantState.run.updatedAt = Date.now();
        rdgAssistantRestoreManualDelays();
        rdgAssistantAddHistory('Ciclo concluido', 'Ciclo finalizado. Para refazer, crie um novo ciclo com 3 perfis (concorrentes) e ajuste a mensagem se quiser.');
        rdgAssistantLog('Campanha concluida sem pendencias restantes.', 'completed', true);
        rdgAssistantCloseDmProgressPopup();
        var progressSnapshot = rdgAssistantGetRunProgressSnapshot(rdgAssistantState.run);
        var qualified = Math.max(0, parseInt(rdgAssistantState.run.dmQualifiedCount || 0, 10) || 0);
        var sentCount = Math.max(0, parseInt(rdgAssistantState.run.dmSentCount || 0, 10) || 0);
        rdgAssistantStampActiveCycleCompletion(progressSnapshot.totalInteractions || 0, qualified, sentCount);
        if (rdgAssistantState.run.dmStarted !== true) {
            rdgAssistantShowCycleSummaryPopup(progressSnapshot.totalInteractions || 0, qualified, sentCount);
        }
        rdgAssistantSaveState();
        rdgAssistantRender();
    } catch (e) {
        if (rdgAssistantState && rdgAssistantState.run) {
            var failedPhase = rdgAssistantState.run.phase || rdgAssistantState.run.resumePhase || 'collecting';
            rdgAssistantState.run.phase = failedPhase;
            rdgAssistantScheduleSelfRecovery(
                8000,
                'tick_runtime_error',
                'Foi detectada uma falha na etapa atual. O assistente vai aguardar alguns segundos e tentar retomar sozinho.',
                failedPhase,
                rdgAssistantState.run.currentTargetUsername || ''
            );
            rdgAssistantSaveState();
            rdgAssistantRender();
        }
    } finally {
        rdgAssistantBusy = false;
    }
}

function rdgAssistantInit() {
    if (!document.getElementById('rdgAssistantStart')) return;
    rdgAssistantBindUi();
    if (rdgAssistantState && rdgAssistantState.run && ['waiting_instagram', 'resting'].indexOf(rdgAssistantState.run.status) > -1) {
        rdgAssistantEnsureWaitResumeTimer();
    }
    if (!rdgAssistantEngineInterval) {
        rdgAssistantEngineInterval = setInterval(rdgAssistantTick, 5000);
    }
    if (!rdgAssistantLiveLogInterval) {
        rdgAssistantLiveLogInterval = setInterval(function() {
            if (!rdgAssistantState) return;
            rdgAssistantRenderActivity();
            rdgAssistantRenderLiveLogCard();
            rdgAssistantUpdateActiveHoursBanner();
            rdgAssistantUpdateRestBanner();
        }, 1000);
    }
    if (!rdgAssistantProfileButtonInterval) {
        rdgAssistantProfileButtonInterval = setInterval(rdgAssistantEnsureProfileButton, 1500);
    }
    rdgAssistantLoadState(function() {
        if (rdgAssistantState && rdgAssistantState.run && rdgAssistantState.run.status === 'running' && !rdgAssistantHasSession()) {
            if (rdgHasAuthenticatedRuntime()) {
                rdgAssistantMarkSessionActive();
            } else {
                rdgAssistantState.run.status = 'paused';
                rdgAssistantSetAccountWorkLastTickAt(0);
                rdgAssistantRestoreManualDelays();
                rdgAssistantAddHistory('Pausado por reabrir', 'O assistente foi pausado porque a aba foi reaberta. Clique em Retomar para continuar do ponto salvo.');
                rdgAssistantSaveState();
            }
        }
        rdgAssistantEnsureProfileButton();
        rdgAssistantTick();
    });
}

function bindEvents() {

    // Initialize custom checkbox plugin
    try {
        if (typeof $.fn.checkboxradio === 'function') {
            var checkboxTargets = $('#igBotInjectedContainer input[type="checkbox"]').filter(function() {
                var id = this.id ? String(this.id) : '';
                if ($(this).closest('label').length) return true;
                if (!id) return false;
                return $('label[for="' + id.replace(/"/g, '\\"') + '"]').length > 0;
            });
            if (checkboxTargets.length) {
                gblCheckboxPlugin = checkboxTargets.checkboxradio({
                    icon: false
                });
            } else {
                gblCheckboxPlugin = $();
            }
        }
    } catch (e) {
        console.error('Error initializing checkbox plugin:', e);
    }

    $('#btnAddScheduledAction').off('click.btnAddScheduledAction').on('click.btnAddScheduledAction', btnAddScheduledAction);
    initStoriesPlusUi();

    $('#igBotInjectedContainer #btnProcessQueue').click(initProcessQueue);

    $('#cbrdgWarmupMode, #txtrdgCoffeeMinutes, #txtrdgCoffeeActions').off('change.rdgShield input.rdgShield').on('change.rdgShield input.rdgShield', function() {
        var isWarmup = $('#cbrdgWarmupMode').prop('checked');
        var coffeeMin = parseInt($('#txtrdgCoffeeMinutes').val() || 10, 10);
        var coffeeAct = parseInt($('#txtrdgCoffeeActions').val() || 30, 10);
        
        if (rdgAssistantState && rdgAssistantState.settings) {
            rdgAssistantState.settings.assistantPauseEveryInteractions = coffeeAct;
            rdgAssistantState.settings.assistantPauseMinutesAfterBatch = coffeeMin;
            if (typeof rdgAssistantSaveState === 'function') rdgAssistantSaveState();
        }
        
        if (isWarmup) {
            $('#rdgShieldStatusText').html('● MODO AQUECIMENTO ATIVO (Segurança Máxima)').css('color', '#f59e0b');
            $('#textSecondsBetweenActions').val(90);
            if (typeof gblOptions !== 'undefined') gblOptions.timeDelay = 90000;
        } else {
            $('#rdgShieldStatusText').html('● Operação Humanizada Ativa').css('color', '#10b981');
            if (typeof gblOptions !== 'undefined') {
                if (gblOptions.timeDelay === 90000) {
                    gblOptions.timeDelay = 45000;
                    $('#textSecondsBetweenActions').val(45);
                }
            }
        }
        if (typeof saveOptions === 'function') saveOptions();
    });

    $('#btnApplyWarmup').off('click.rdgShield').on('click.rdgShield', function() {
        $('#cbrdgWarmupMode').trigger('change.rdgShield');
        var isWarmup = $('#cbrdgWarmupMode').prop('checked');
        var msg = isWarmup ? 
            '🛡️ Escudo Anti-Block configurado para MODO AQUECIMENTO! Tempos de espera aumentados para 90s com pausa de ' + $('#txtrdgCoffeeMinutes').val() + ' min a cada ' + $('#txtrdgCoffeeActions').val() + ' ações.' :
            '⚡ Escudo configurado para MODO NORMAL HUMANIZADO com pausa de ' + $('#txtrdgCoffeeMinutes').val() + ' min a cada ' + $('#txtrdgCoffeeActions').val() + ' ações.';
        if (typeof outputMessage === 'function') outputMessage(msg);
        alert(msg);
    });

    $('#igBotInjectedContainer input[type="checkbox"], #igBotInjectedContainer select, #igBotInjectedContainer input[name="likeOnlyLatestPicsCount"]').off('change.checkboxSaveOptions').on('change.checkboxSaveOptions', saveOptions);
    $('#igBotInjectedContainer input[type="text"],#igBotInjectedContainer input[type="number"]').bind('keyup input', saveOptions);
    $('details').off('toggle.detailsToggle').on('toggle.detailsToggle', saveOptions);

    $('#cbLimitQueueSize').off('click.lockLimitQueue change.lockLimitQueue').on('click.lockLimitQueue change.lockLimitQueue', function(e) {
        this.checked = true;
        gblOptions.limitQueue = true;
        saveOptions();
        e.preventDefault();
        e.stopImmediatePropagation();
        return false;
    });

    $('#igBotInjectedContainer #btnStop,#igBotInjectedContainer #btnStop2').click(function() {
        var $btn = $(this);
        var originalText = $btn.attr('data-original-text') || $btn.text();
        if (!$btn.attr('data-original-text')) {
            $btn.attr('data-original-text', originalText);
        }
        $btn.text('Parado! 🛑');
        setTimeout(function() { $btn.text(originalText); }, 2000);

        if (rdgAssistantState && rdgAssistantState.run && ['running', 'waiting_instagram', 'resting'].indexOf(rdgAssistantState.run.status) > -1) {
            rdgAssistantPauseRun('Assistente parado pelo usuario. Clique em Retomar quando quiser continuar do ponto salvo.');
            return;
        }
        try {
            if (typeof stopMassDM === 'function') stopMassDM();
        } catch (e) {}
        rdgStopAllPendingActions('Stopped all pending actions');
    });

    $('#btnLoadAccountsFromMedia').off('click.LoadAccountsFromMedia').on('click.LoadAccountsFromMedia', LoadAccountsFromMedia);

    $('#igBotInjectedContainer #btnLikeFeed').click(ajaxLikeAllPostsFromFeed);

    $('#btnLikeMediaQueue').off('click.likeAllMedia').on('click.likeAllMedia', likeAllMedia);

    $('#btnLoadLocationPosts').off('click.ajaxLoadPostsFromLocation').on('click.ajaxLoadPostsFromLocation', ajaxLoadPostsFromLocation);

    $('#entrarPoId').click(entrarId);
    $('#divUsarKey').click(entrarKey);

    $('#btnLoadPendingRequests').click(ajaxGetPendingFollowRequests);
    $('#btnLoadSavedQueue').click(loadSavedQueue);
    $('#btnViewWhiteList').click(viewWhiteList);
    $('#btnSaveQueueToStorage').click(saveQueueToStorageAndDisk);
    $(document).on('click', '#entrarIdAppButt', verificarNumeroExistente);
    $(document).on('click', '#btnCloseLoginWrapper, #btnEntrarInstagramPrimeiro', function() {
        const dlw = document.getElementById('divLoginWrapper');
        if (dlw) {
            dlw.classList.add('rdg-hidden');
            dlw.style.setProperty('display', 'none', 'important');
        }
    });
    $(document).on('click', '#verificarChave', verificarNumeroExistente);
    $(document).on('keypress', '#txtChaveLicenca, #inputLicenca, #numeroInsta', function(e) {
        if (e.which === 13 || e.keyCode === 13) {
            e.preventDefault();
            verificarNumeroExistente();
        }
    });
    $(document).on('click', '#btnExportQueue', exportQueue);
    $('#btnExportQueue').off('click.exportQueue').on('click.exportQueue', exportQueue);


    if (getCurrentPageUsername() != '') {
        setCurrentPageUsername();
    } else {
        $('#igBotInjectedContainer #btnGetAllUsersFollowers').off('click.setCurrentPageUsername').on('click.setCurrentPageUsername', setCurrentPageUsername);
        $('#igBotInjectedContainer #btnGetAllUsersFollowing').off('click.setCurrentPageUsername').on('click.setCurrentPageUsername', setCurrentPageUsername);
    }

    setCurrentPageHashtag();


    $('#btnApplyFilter').off('click.ApplyFilter').on('click.ApplyFilter', function() {
        $('li.tab1').click();
        applyFiltersManually();
    });

    $('#btnFindSubscription').off('click.relinkSubscription').on('click.relinkSubscription', relinkSubscription);

    $('#igBotMediaQueueContainer').off('click.setCurrentList').on('click.setCurrentList', function() {
        currentList = 'mediaToLike';
    });
    $('#igBotQueueContainer').off('click.setCurrentList').on('click.setCurrentList', function() {
        if (currentList != 'acctsWhiteList') {
            currentList = 'acctsQueue';
        }
    });


    $(document).on('click.convenienceUnFollow', 'a.igBotInjectedLinkUnfollow', function() {
        $(this).off('click.convenienceUnFollow').css({
            "color": "white"
        }).append('<div class="igBotLoader"></div>');
        convenienceLinkUnfollowAcct($(this).attr('data-username'));
    });

    $(document).on('click.convenienceWhitelist', 'a.igBotInjectedLinkWhitelist', function() {
        $(this).off('click.convenienceWhitelist').css({
            "color": "white"
        }).append('<div class="igBotLoader"></div>');
        convenienceLinkWhitelistAcct($(this).attr('data-username'));
    });

    $('li.tab5').off('click.scrollLog').on('click.scrollLog', scrollLog);

    $('#btnTrimLog').off('click.trimLog').on('click.trimLog', trimLog);
    $('#btnSaveLog').off('click.saveLog').on('click.saveLog', rdgSaveCurrentLogToFile);

    $('#btnWatchReels').off('click.watchReels').on('click.watchReels', watchReels);

    $('#btnLoadThisPost').off('click.LoadThisPost').on('click.LoadThisPost', loadCurrentPostAsMedia);


    $('nav ul li').off('click.rememberTab').on('click.rememberTab', function() {
        gblOptions.lastTab = $(this).attr('class');
        saveOptions();
    });

}

function applyTooltips() {
    // ─── Mapa completo de explicações (Para que serve / Como usar) por ID ───
    var idTitles = {
        // ── Header / Global ──
        'btnMinimizeRdg': 'Minimizar ou expandir a janela do painel RDG instaPRO na sua tela.',
        'igBotStatusDiv': 'Status operacional do robô em tempo real (Ativo, Pausa para Café ou Standby).',
        'h2FreeTrialTimeLeft': 'Informações sobre a validade e status da sua licença de uso do sistema.',

        // ── Executive Dashboard ──
        'rdgStatQueue': 'Quantidade total de perfis carregados na fila prontos para receberem ações.',
        'rdgExecutiveDashboard': 'Painel executivo de métricas gerais e velocidade em tempo real da sua automação.',

        // ── Tab Labels ──
        'rdg_tab1': 'Aba Alvos & Ações — Importe perfis de seguidores/curtidores, filtre e execute estratégias em massa.',
        'rdg_tab2': 'Aba Mídia & Reels — Importe postagens por hashtag ou feed e programe curtidas ou visualização de Reels.',
        'rdg_tab3': 'Aba Público-Alvo — Defina filtros de qualidade (foto, bio, seguidores, conta comercial) antes de interagir.',
        'rdg_tab4': 'Aba Preferências — Ajuste o tempo de espera (delay) entre ações, pausas anti-bloqueio e limites de segurança.',
        'rdg_tab5': 'Aba Monitor — Acompanhe segundo a segundo o log de execuções do robô e exporte relatórios do dia.',
        'rdg_tab6': 'Aba Piloto Automático — O assistente autônomo que roda rotinas inteligentes de engajamento sozinho.',
        'rdg_tab7': 'Aba Direct em Massa — Envie mensagens privadas no Direct em lote com rotação de até 3 textos.',
        'rdg_tab9': 'Aba Stories+ — Recursos extras de visualização e engajamento em massa com Stories.',
        'rdg_tab10': 'Aba Prospecção IA — Descubra novos alvos com 1-Click e avalie a qualidade da fila com a Qualificação Ouro.',

        // ── Tab 1: Alvos & Ações ──
        'btnLoadMenu': 'Menu de Coleta: Clique para escolher de onde extrair os perfis (Seguidores da página, Curtidores ou Comentadores).',
        'btnGetLikers': 'Extrai e importa para a sua fila todos os perfis que curtiram a publicação aberta na tela do Instagram no momento.',
        'btnGetCommenters': 'Extrai e importa para a sua fila todos os perfis que deixaram comentários na publicação aberta na tela no momento.',
        'btnGetAllUsersFollowing': 'Extrai e importa para a sua fila todas as contas que o perfil aberto na tela está seguindo.',
        'btnGetAllUsersFollowers': 'Extrai e importa para a sua fila todos os seguidores do perfil/concorrente que você está visitando no momento.',
        'btnPasteCustomQueueTab1': 'Abre uma caixa para você colar a sua própria lista personalizada de @usuários (ex: de uma planilha ou bloco de notas).',
        'btnFilterQueueByGender': 'Filtra por Gênero: Mantém apenas homens ou mulheres na tabela e remove contas do gênero oposto ou sem identificação.',
        'btnSelectionMenu': 'Menu de Seleção: Opções em lote para marcar, desmarcar, inverter seleção ou excluir perfis marcados da tabela.',
        'btnInvertSelection': 'Inverte a marcação da tabela: desmarca quem está selecionado e marca quem estava desmarcado.',
        'btnSelectNone': 'Desmarca a caixa de seleção de todos os perfis na tabela atual.',
        'btnSelectAll': 'Marca a caixa de seleção de absolutamente todos os perfis visíveis na tabela para ação ou remoção em lote.',
        'btnRemoveSelected': 'Exclui da sua fila de trabalho todos os perfis que estiverem com a caixa de seleção marcada.',
        'btnProcessQueueHolder': 'Área de Disparo: Escolha a estratégia abaixo (Seguir, Curtir, DM, Unfollow) e clique aqui para iniciar o processamento.',
        'btnProcessQueue': 'INICIAR AUTOMAÇÃO: Dispara a estratégia escolhida para todos os perfis da fila respeitando o tempo de espera (delay).',
        'btnSaveQueueToStorage': 'Salva a lista de perfis atual na memória do seu navegador para você continuar depois sem perder o progresso.',
        'btnExportQueue': 'Baixa uma planilha Excel (.csv) para o seu computador com os dados de todos os perfis que estão na fila.',
        'btnSaveWhiteList': 'Salva a sua Lista Branca de contas protegidas para que o sistema nunca dê Unfollow em clientes ou amigos.',
        'btnStop': 'PARAR AUTOMAÇÃO: Interrompe imediatamente qualquer ação de seguir, curtir, extrair ou enviar direct em andamento.',
        'btnApplyWarmup': 'Salva e ativa as configurações do Escudo Anti-Block (Pausa para café e Modo Aquecimento).',

        // ── Ações de seguir / Estratégias ──
        'radioFollow': 'Estratégia: Apenas clicar no botão Seguir de cada perfil da fila no ritmo seguro configurado.',
        'radioFollowAndLike': 'Estratégia Dupla: Entra no perfil do alvo, segue a conta e curte automaticamente as últimas fotos para dobrar a notificação.',
        'radioFollowLikeAndDM': 'Funil VIP em Cadeia (Estratégia Tripla): Segue o perfil, curte as fotos recentes E envia uma mensagem Direct sem precisar trocar de aba!',
        'radioLikeOnly': 'Estratégia: Apenas curte as postagens recentes do perfil sem seguir a conta, gerando atenção orgânica sutil.',
        'radioUnFollow': 'Estratégia: Deixa de seguir (Unfollow) as contas da fila. Contas na sua Lista Branca (🛡️) serão puladas automaticamente.',
        'radioRemoveFromFollowers': 'Estratégia: Remove o perfil da sua lista de seguidores do Instagram, fazendo com que ele pare de te seguir.',
        'radioBlock': 'Estratégia: Bloqueia a conta no Instagram para que o usuário não possa mais ver seu perfil ou mandar mensagens.',
        'radioViewStory': 'Estratégia: Visualiza automaticamente os Stories de cada perfil da fila para gerar notificações de visualização no alvo.',
        'cbViewStoryLike': 'Quando marcado, o robô curte automaticamente o Story do usuário no momento em que estiver visualizando.',
        'radioGetMoreData': 'Estratégia: Consulta o Instagram em segundo plano para extrair dados avançados como número de seguidores, seguindo e bio.',
        'numberFollowLikeLatestPics': 'Quantidade de fotos recentes do alvo que serão curtidas durante a ação de Seguir + Curtir.',
        'numberChainPics': 'Quantidade de fotos que serão curtidas antes de disparar o Direct no Funil VIP em Cadeia.',
        'cbLimitQueueSize': 'Quando marcado, limita a quantidade máxima de perfis extraídos em cada coleta para evitar listas gigantescas.',
        'txtLimitQueueSize': 'Digite o limite máximo de contas que deseja carregar ao importar seguidores, curtidores ou comentadores.',

        // ── Funil em Cadeia DM ──
        'btnToggleChainDmBox': 'Clique para abrir e personalizar a mensagem automática do Direct do Funil VIP em Cadeia.',
        'txtChainDmMessage': 'Mensagem Principal: Texto enviado no Direct após seguir e curtir. Use {username} para inserir o nome do cliente.',
        'txtChainDmMessage2': 'Variação 2 da mensagem: O sistema alternará aleatoriamente entre as mensagens para evitar bloqueios de spam.',
        'txtChainDmMessage3': 'Variação 3 da mensagem: Terceira opção de texto para máxima variação e humanização do envio.',
        'btnChainInsertUsername': 'Insere a tag {username} na mensagem, que será substituída automaticamente pelo @ ou nome da pessoa ao enviar.',
        'btnChainAiImprove': 'Usa Inteligência Artificial para reescrever sua mensagem com uma comunicação mais clara, natural e persuasiva.',
        'btnChainAiCorrect': 'Usa Inteligência Artificial para revisar e corrigir erros de ortografia e gramática na sua mensagem.',
        'btnChainAiEmojify': 'Usa Inteligência Artificial para adicionar emojis estratégicos e harmoniosos ao longo do texto.',
        'btnChainAiPersuasive': 'Usa Inteligência Artificial para aplicar técnicas de copywriting e persuasão focadas em conversão e vendas.',
        'cbUseMassDmTemplates': 'Quando marcado, inclui na rotação de envios também os modelos cadastrados na Aba 7 (Direct em Massa).',
        'btnConfirmChainDmConfig': 'Salva as mensagens cadastradas e deixa o Funil VIP em Cadeia pronto e ativado para rodar.',
        'btnCloseChainDmBox': 'Fecha a janela de configuração da mensagem de Direct em Cadeia.',

        // ── Tab 2: Mídia / Reels ──
        'btnLoadThisPost': 'Carrega a publicação ou foto aberta na sua tela atual diretamente para a fila de curtidas.',
        'btnLikeHashtag': 'Abre busca para extrair as postagens mais recentes de uma #hashtag específica do seu nicho.',
        'btnLikeFeed': 'Carrega as postagens recentes do seu feed principal do Instagram para curtir automaticamente.',
        'includeSuggestedPostsFromFeed': 'Quando marcado, curte também as publicações sugeridas pelo algoritmo do Instagram no seu feed.',
        'btnLoadLocationPosts': 'Carrega todas as fotos publicadas na página de geolocalização que você está acessando no momento.',
        'btnMediaInvertSelection': 'Inverte a seleção de publicações na tabela: desmarca o que está marcado e marca o restante.',
        'btnMediaSelectNone': 'Desmarca todas as postagens na tabela da fila de mídia.',
        'btnMediaSelectAll': 'Marca todas as postagens da tabela de mídia para curtida rápida.',
        'btnMediaRemoveSelected': 'Exclui da fila todas as postagens que estiverem marcadas.',
        'btnLikeMediaQueue': 'INICIAR CURTIDAS: Curte automaticamente todas as postagens da fila de mídia respeitando o delay configurado.',
        'btnWatchReels': 'PILOTO REELS: Abre abas automaticamente assistindo vídeos do Reels de forma orgânica para engajar sua conta.',
        'LikeWhenWatchingReel': 'Curte automaticamente cada vídeo do Reels depois de assistir a pelo menos 75% da duração dele.',
        'SaveWhenWatchingReel': 'Salva no seu perfil cada vídeo do Reels assistido, enviando forte sinal de engajamento para o algoritmo.',
        'btnStop2': 'PARAR: Interrompe imediatamente o processamento da fila de mídia ou dos Reels.',

        // ── Tab 3: Público-Alvo (Filtros) ──
        'followersMin': 'Número mínimo de seguidores que uma conta precisa ter para ser aceita na sua prospecção.',
        'followersMax': 'Número máximo de seguidores (evita interagir com perfis de celebridades ou inalcançáveis).',
        'followingMin': 'Número mínimo de pessoas que a conta precisa estar seguindo para ser aceita.',
        'followingMax': 'Número máximo de pessoas seguindo (evita perfis de spam que seguem milhares de contas).',
        'postsMin': 'Número mínimo de postagens publicadas pelo perfil (filtra contas novas, fakes ou inativas).',
        'postsMax': 'Número máximo de postagens para filtrar contas aceitáveis.',
        'cbFilterNoProfilePic': 'Se marcado, ACEITA perfis sem foto (foto cinza padrão). Desmarque se quiser apenas pessoas com foto real.',
        'cbFilterProfilePic': 'Se marcado, ACEITA na lista perfis que tenham foto de perfil configurada.',
        'cbFollowPrivateAccounts': 'Se marcado, ACEITA interagir com contas privadas (que exigem aprovação para seguir).',
        'cbFilterNonPrivate': 'Se marcado, ACEITA interagir com contas públicas (abertas para qualquer pessoa ver).',
        'cbFilterVerified': 'Se marcado, ACEITA interagir com contas verificadas que possuem o selo azul oficial.',
        'cbFilterNonVerified': 'Se marcado, ACEITA interagir com contas comuns não verificadas.',
        'cbFilterJoinedRecently': 'Se marcado, ACEITA perfis criados recentemente no Instagram.',
        'cbFilterNonJoinedRecently': 'Se marcado, ACEITA perfis antigos e consolidados.',
        'cbFilterBusiness': 'Se marcado, ACEITA na lista perfis de empresas, comércios, criadores ou contas profissionais.',
        'cbFilterNonBusiness': 'Se marcado, ACEITA na lista perfis de uso pessoal comuns.',
        'cbFollowsMe': 'Se marcado, ACEITA interagir com perfis que JÁ seguem você no Instagram.',
        'cbNonFollowsMe': 'Se marcado, ACEITA interagir com perfis que NÃO te seguem (ideal para prospecção de novos leads).',
        'cbFollowedByMe': 'Se marcado, ACEITA perfis que você JÁ segue no momento.',
        'cbNonFollowedByMe': 'Se marcado, ACEITA apenas perfis que você ainda NÃO segue.',
        'btnResetFilter': 'Reseta todas as opções de filtro para a configuração original de fábrica.',
        'btnApplyFilter': 'APLICAR FILTROS: Analisa toda a sua Fila atual e remove da tabela quem não atender aos critérios acima.',

        // ── Tab 4: Preferências & Escudo Anti-Block ──
        'textSecondsBetweenActions': 'TEMPO DE ESPERA (Delay): Segundos que a extensão aguarda entre cada ação. Para máxima segurança, use 45 a 90s.',
        'textSecondsAfterSkip': 'Segundos de pausa rápida quando o sistema pula um perfil (ex: por já estar seguido ou por filtro de gênero).',
        'cbRandomizeTimeDelay': 'ALEATORIZAR DELAY: Varia o tempo de espera aleatoriamente para o robô imitar perfeitamente o ritmo de um ser humano.',
        'igBotPercentRandomTimeDelay': 'Porcentagem máxima de variação no tempo de espera (ex: 70% significa variação ampla e segura a cada rodada).',
        'textMinutesAfterSoftRateLimit': 'Minutos de pausa automática caso o Instagram avise que as requisições estão rápidas demais.',
        'textHoursAfterHardRateLimit': 'Horas de repouso de segurança caso a conta atinja o limite máximo temporário do Instagram.',
        'textMinutesAfter429RateLimit': 'Minutos de repouso quando o Instagram retorna alerta de tráfego (Erro 429). Protege sua conta contra bloqueios.',
        'cbShowStamps': 'Exibe carimbos coloridos (Seguido, Curtido, Erro) na linha de cada perfil dentro da tabela da fila.',
        'cbConvenienceLinks': 'Adiciona botões rápidos de Lista Branca e Unfollow diretamente nas páginas e perfis que você visita no Instagram.',
        'cbShowQueueOnScreen': 'Mantém a tabela visual da fila de perfis exibida na tela da extensão enquanto o processamento rodar.',
        'cbRemoveUnusedColumns': 'Limpa a tabela escondendo colunas secundárias para deixar a visualização mais leve e organizada.',
        'cbShowLikesInQueue': 'Exibe na tabela uma coluna mostrando quantas curtidas foram dadas em cada perfil da fila.',
        'cbShowProfilePicInQueue': 'Carrega as fotos de perfil em miniatura de cada usuário diretamente nas linhas da tabela da fila.',
        'cbClickNotNow': 'Fecha automaticamente popups do Instagram como "Ativar Notificações" ou "Salvar Informações de Login".',
        'cbLoadQueueOnStartup': 'Carrega automaticamente a última fila de perfis salva sempre que você abrir a extensão ou reiniciar o navegador.',
        'cbAutoSaveQueue': 'Salva a fila automaticamente a cada conta processada, protegendo seu progresso em quedas de energia ou fechamento do PC.',
        'cbFollowAlreadyAttempted': 'Permite tentar seguir novamente perfis que já foram tentados em rodadas anteriores.',
        'cbApplyFilterAutomatically': 'Sempre que você clicar em Processar, o robô aplicará os filtros da Aba 3 automaticamente antes de rodar.',
        'cbDontUnfollowFollowers': 'PROTEÇÃO DE SEGUIDORES: Garante que você NUNCA dê Unfollow em pessoas que seguem você de volta.',
        'cbDontRemoveOrBlockFilters': 'Protege os perfis que passaram no seu filtro contra remoções ou bloqueios acidentais.',
        'cbLimitActions': 'LIMITE DE LOTES: Ativa um descanso prolongado (ex: pausar 0.40h após 20 ações) para simular turnos humanizados.',
        'textLimitActionsPerTime': 'Horas de intervalo ou repouso após atingir o lote máximo configurado ao lado.',
        'textLimitActionsPer': 'Quantidade de ações permitidas em cada lote antes da pausa de descanso humanizado.',
        'cbrdgWarmupMode': 'MODO AQUECIMENTO (Warm-up): Reduz a velocidade inicial e aumenta progressivamente o ritmo de ações. Proteção total!',
        'txtrdgCoffeeMinutes': 'Tempo em minutos que o robô vai ficar parado descansando e tomando "café" durante a Pausa para Café.',
        'txtrdgCoffeeActions': 'Número de ações executadas que ativam a Pausa para Café (ex: pausar 10 min a cada 30 ações).',

        // ── Tab 5: Monitor / Produtividade ──
        'txtConsole': 'LOG DE MONITORAMENTO: Registro detalhado em tempo real mostrando cada @usuário seguido, curtido, erros e alertas.',
        'btnTrimLog': 'Limpa as linhas antigas do log do monitor para manter a memória do navegador leve e rápida.',
        'btnSaveLog': 'Salva e faz o download de um arquivo de texto (.txt) com o histórico completo de ações registradas no log.',
        'btnRdgExportReport': 'RELATÓRIO PDF/CSV: Gera um relatório profissional com estatísticas de seguidos, curtidos e vendas fechadas no dia!',
        'btnIncSale': 'Adiciona +1 venda ao contador financeiro do dia. Excelente para metrificar o retorno real gerado pela ferramenta!',
        'btnDecSale': 'Subtrai -1 venda do contador diário em caso de cancelamento ou ajuste manual.',

        // ── Tab 6: Piloto Automático ──
        'rdgAssistantStatusBadge': 'Indicador de status do Piloto Automático: mostra se o assistente está operando em segundo plano ou em repouso.',
        'rdgAssistantGlowBar': 'Barra de atividade neural: quando iluminada, confirma que o Piloto Automático está executando ações inteligentemente.',

        // ── Tab 7: Direct em Massa ──
        'btnPasteCustomQueue': 'Abre uma janela para você colar uma lista personalizada de @usuários para receberem as mensagens no Direct.',
        'txtMassDmMessage': 'Mensagem Principal 1 do Direct: Escreva sua primeira opção de texto. Use {username} para citar o nome da pessoa.',
        'txtMassDmMessage2': 'Mensagem Variação 2: Segunda opção de texto. A extensão alternará entre as mensagens para não gerar bloqueio por spam.',
        'txtMassDmMessage3': 'Mensagem Variação 3: Terceira opção de texto. Quanto mais variações, mais natural e humanizado será o envio!',

        // ── Tab 10: Prospecção IA & Qualificação Ouro ──
        'txtAutoDiscoveryKeyword': 'Barra 1-Click: Digite o termo do seu nicho (ex: Estética, Academia, Petshop) para encontrar clientes no piloto automático.',
        'btnRunAutoDiscovery': 'DESCOBERTA 1-CLICK: Varre o Instagram no nicho digitado, encontra concorrentes e hashtags e importa a melhor audiência!',
        'txtNicheInput': 'Descreva com suas palavras o seu negócio, produto ou serviço para receber sugestões de prospecção da Inteligência Artificial.',
        'btnAskNicheAi': 'CONSULTOR IA: Nossa IA analisa seu negócio e recomenda quais perfis, hashtags e estratégias trarão mais vendas.',
        'btnAddNicheTargetsToQueue': 'Envia todos os perfis e alvos recomendados pela IA diretamente para a tabela da Aba 1 prontos para ação!',
        'btnRunGoldScoring': 'QUALIFICAÇÃO OURO: A IA avalia cada perfil da fila dando nota de 0 a 100 baseada em bio, foto e engajamento sem gastar ações!',
        'btnCleanLowScore': 'LIMPAR CONTAS RUINS: Remove de uma só vez da sua fila todos os perfis com nota abaixo de 50 pontos (fakes ou inativos).',
        'txtGoldKeywords': 'Palavras-chave Ouro: Se o perfil tiver essas palavras no nome ou bio, ganha pontos extras na nota da Qualificação Ouro.',
        'txtGoldLocation': 'Filtro Regional Ouro: Se o perfil ou bio tiver essa cidade ou estado, ganha pontos extras na nota da Qualificação Ouro.',
        'ruleCbBusiness': 'Critério de qualificação: Soma +15 pontos se a conta analisada for Comercial ou de Criador de Conteúdo.',
        'ruleCbWhatsapp': 'Critério de qualificação: Soma +20 pontos se a conta possuir link ou número de WhatsApp disponível para contato.',
        'ruleCbEmail': 'Critério de qualificação: Soma +15 pontos se a conta possuir e-mail público de contato comercial.',
        'ruleCbProfilePic': 'Critério de qualificação: Soma +10 pontos se o usuário possuir uma foto real no perfil.',
        'ruleCbRecentPosts': 'Critério de qualificação: Soma +10 pontos se a conta tiver publicado postagens ou reels nos últimos dias.',
        'ruleCbEngaged': 'Critério de qualificação: Soma +10 pontos se as publicações da conta tiverem bom engajamento e comentários.',
        'ruleCbFollowRatio': 'Critério de qualificação: Soma +10 pontos para proporção saudável entre seguidores e seguindo.',
        'ruleCbKeywords': 'Critério de qualificação: Soma +15 pontos caso o perfil contenha as palavras-chave Ouro definidas acima.',
        'ruleCbCategory': 'Critério de qualificação: Soma +10 pontos caso a categoria profissional do perfil combine com o nicho.',
        'ruleCbLocation': 'Critério de qualificação: Soma +10 pontos caso a localização/cidade do perfil combine com a região desejada.',

        // ── FAQ / Global / Paginação ──
        'rdgHelpSearchInput': 'Barra de Pesquisa FAQ: Digite qualquer dúvida ou nome de botão para encontrar a explicação instantaneamente.',
        'closeHelpModalBtn': 'Fecha a janela da Central de Ajuda e FAQ e retorna à tela principal da extensão.',
        'rdgFloatingHelpBtn': 'Central de Ajuda & FAQ: Abra para tirar dúvidas, consultar tutoriais ou pesquisar como funciona qualquer recurso.',
        'paginationLimit': 'Tamanho da Página: Escolha quantos perfis aparecem ao mesmo tempo na tabela (10, 50, 100, 500 ou Todos).',
        'mediapaginationLimit': 'Tamanho da Página de Mídia: Escolha quantas postagens/fotos aparecem ao mesmo tempo na tabela da Aba 2.'
    };

    // 1. Aplicar explicações por ID (sobrescrevendo qualquer title básico que apenas repita o texto do botão)
    for (var id in idTitles) {
        var el = document.getElementById(id);
        if (el) {
            el.setAttribute('title', idTitles[id]);
            // Se for um label ou div que encapsula input, garantir que o title também se aplique ao elemento interativo
            $(el).attr('title', idTitles[id]);
        }
    }

    // 2. Mapa de explicações textuais dinâmicas para botões ou labels que não possuam ID próprio
    var textExplanations = [
        { key: 'Filtrar Gênero', desc: 'Filtra a fila atual e mantém apenas perfis do gênero escolhido (homens ou mulheres), removendo o sexo oposto ou desconhecido.' },
        { key: 'Filtrar Homens', desc: 'Mantém apenas perfis identificados como masculinos na sua fila, removendo perfis femininos ou sem identificação.' },
        { key: 'Filtrar Mulheres', desc: 'Mantém apenas perfis identificados como femininos na sua fila, removendo perfis masculinos ou sem identificação.' },
        { key: 'Inverter seleção', desc: 'Inverte a marcação dos perfis na tabela: quem está selecionado é desmarcado, e quem não está selecionado é marcado.' },
        { key: 'Selecionar Todos', desc: 'Marca a caixa de seleção de absolutamente todos os perfis visíveis na tabela para processamento ou exclusão em lote.' },
        { key: 'Selecionar Nenhum', desc: 'Desmarca todas as caixas de seleção que estiverem marcadas na tabela atual.' },
        { key: 'Remover selecionados', desc: 'Exclui da sua fila de trabalho todos os perfis que estiverem com a caixa de seleção marcada.' },
        { key: 'Salvar Fila', desc: 'Armazena a lista atual de perfis na memória interna do seu navegador para você continuar depois sem perder o progresso.' },
        { key: 'Exportar Fila', desc: 'Baixa uma planilha (.csv) para o seu computador com os dados de todos os perfis que estão na fila.' },
        { key: 'Colar @Usuários', desc: 'Abre uma caixa para você colar uma lista de nomes de usuário (@cliente1, @cliente2) copiados de planilhas ou notas.' },
        { key: 'Carregar Curtidores', desc: 'Extrai todos os perfis que curtiram a publicação que você está visualizando no Instagram no momento.' },
        { key: 'Carregar Comentadores', desc: 'Extrai todos os perfis que deixaram comentários na publicação atualmente aberta no Instagram.' },
        { key: 'Carregar Seguidores', desc: 'Extrai a lista de seguidores do perfil (concorrente ou página) que você está acessando no momento.' },
        { key: 'Carregar Seguindo', desc: 'Extrai a lista de contas que o perfil atual está seguindo no Instagram.' },
        { key: 'Processar Fila', desc: 'INICIAR AUTOMAÇÃO: Dispara a estratégia escolhida (Seguir, Curtir, Direct, Unfollow) para todos os perfis da fila respeitando os delays.' },
        { key: 'Limpar (< 50 pts)', desc: 'Remove da fila todos os perfis avaliados com nota baixa pela Qualificação Ouro (contas fakes, inativas ou sem foto).' },
        { key: 'Rodar Qualificação Ouro', desc: 'A IA analisa cada perfil da fila atribuindo uma nota de 0 a 100 baseada em foto, bio, engajamento e contato sem gastar ações!' },
        { key: 'Descoberta 1-Click', desc: 'Varre o Instagram no nicho digitado, encontra principais concorrentes, posts e hashtags e importa a melhor audiência!' },
        { key: 'Salvar Escudo', desc: 'Salva suas configurações de Pausa para Café, Modo Aquecimento e tempos de espera para máxima proteção contra bloqueios.' },
        { key: 'Pausa para Café', desc: 'Pausa a automação por alguns minutos após realizar certo número de ações, simulando o descanso natural de um ser humano.' },
        { key: 'Modo Aquecimento', desc: 'Reduz a velocidade inicial e aumenta progressivamente o ritmo de ações para aquecer a conta com máxima segurança anti-block.' },
        { key: 'Aleatorizar tempo', desc: 'Varia aleatoriamente o tempo de espera entre cada ação para o robô não criar padrões robóticos detectáveis pelo algoritmo.' },
        { key: 'Seguir + Curtir', desc: 'Entra no perfil do alvo, segue a conta e curte automaticamente as últimas fotos dele para dobrar a notificação!' },
        { key: 'Funil em Cadeia', desc: 'A automação tripla mais potente: Segue o alvo, curte fotos recentes e envia uma mensagem Direct sem precisar trocar de aba!' },
        { key: 'Apenas Curtir', desc: 'Curte as últimas publicações do perfil sem seguir a conta, excelente para chamar atenção de forma leve e orgânica.' },
        { key: 'Deixar de Seguir', desc: 'Deixa de seguir (Unfollow) as contas da fila. Contas na sua Lista Branca (🛡️) serão protegidas e puladas automaticamente.' },
        { key: 'Remover Seguidor', desc: 'Remove a pessoa da sua lista de seguidores do Instagram, fazendo com que ela pare de te seguir.' },
        { key: 'Bloquear', desc: 'Bloqueia a conta no Instagram para que o usuário não possa mais ver seu perfil ou interagir com você.' },
        { key: 'Ver História', desc: 'Visualiza automaticamente os Stories de cada perfil na fila para gerar notificações de visualização no alvo.' },
        { key: 'Obter Mais Dados', desc: 'Consulta o Instagram em segundo plano para extrair dados avançados como número de seguidores, seguindo, bio e status privado.' },
        { key: 'Direct em Massa', desc: 'Envie mensagens privadas no Direct em lote com rotação de até 3 textos diferentes para evitar detecção de spam.' },
        { key: 'Exportar Relatório', desc: 'Gera um relatório executivo profissional em PDF ou CSV com todas as métricas do dia para apresentar a clientes ou salvar.' },
        { key: 'Revincular Assinatura', desc: 'Ferramenta para atualizar os dados de pagamento ou revincular o cartão de crédito da sua assinatura ativa.' },
        { key: 'Encontrar Assinatura', desc: 'Localiza sua licença e assinatura ativa no sistema através do e-mail e últimos dígitos do cartão cadastrado.' }
    ];

    // 3. Aplicar explicações em botões, abas e labels que não tenham ID ou cujo title atual seja apenas o próprio texto
    $('#igBotInjectedContainer button, #igBotInjectedContainer .igBotInjectedButton, #igBotInjectedContainer label, #igBotInjectedContainer .rdg-toggle-pill, #igBotInjectedContainer .rdg-btn-compact, #igBotInjectedContainer summary').each(function() {
        var $el = $(this);
        var currentTitle = $el.attr('title') || '';
        var rawText = $el.clone().children('.hiddenHover').remove().end().text().trim();

        // Se ainda não tem title ou se o title atual é igual/muito parecido com o texto do botão (o que tornava inútil)
        if (!currentTitle || currentTitle === rawText || rawText.indexOf(currentTitle) !== -1 || currentTitle.indexOf(rawText) !== -1) {
            // Verificar no mapa textual dinâmico
            var matchedDesc = null;
            for (var i = 0; i < textExplanations.length; i++) {
                if (rawText.toLowerCase().indexOf(textExplanations[i].key.toLowerCase()) !== -1) {
                    matchedDesc = textExplanations[i].desc;
                    break;
                }
            }

            if (matchedDesc) {
                $el.attr('title', matchedDesc);
            } else if ($el.is('label') && $el.find('input[type="checkbox"], input[type="radio"]').length) {
                // Se for um checkbox ou radio sem explicação específica, não duplicar o texto do botão
                // Se o elemento não teve match, evitar colocar rawText para não gerar legenda inútil
            }
        }
    });

    // 4. Placeholder explicativo em inputs e textareas que não possuam title
    $('#igBotInjectedContainer textarea, #igBotInjectedContainer input[type="text"], #igBotInjectedContainer input[type="number"]').each(function() {
        var $input = $(this);
        if (!$input.attr('title') && $input.attr('placeholder')) {
            $input.attr('title', 'Preencha: ' + $input.attr('placeholder'));
        }
    });

    // 5. Inicializar e recriar o jQuery UI Tooltip em todos os elementos explicativos do painel
    try {
        $('#igBotInjectedContainer *[title]').each(function() {
            var $el = $(this);
            if ($el.data('ui-tooltip')) {
                $el.tooltip('destroy');
            }
        });
    } catch(e) {}

    $('#igBotInjectedContainer *[title], #instabotIcon').tooltip({
        show: { effect: "fadeIn", duration: 150 },
        track: true,
        hide: { effect: "fadeOut", duration: 100 }
    });

    // Eventos globais anti-CSP (Instagram bloqueia onclick inline no HTML injetado)
    $(document).off('click.rdgHelp').on('click.rdgHelp', '.rdg-help-toggle', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $box = null;
        if ($btn.next('.rdg-help-box').length) {
            $box = $btn.next('.rdg-help-box');
        } else if ($btn.parent().next('.rdg-help-box').length) {
            $box = $btn.parent().next('.rdg-help-box');
        } else if ($btn.parent().parent().next('.rdg-help-box').length) {
            $box = $btn.parent().parent().next('.rdg-help-box');
        } else if (document.getElementById('helpMassDmBox') && $btn.closest('.tab7').length) {
            $box = $('#helpMassDmBox');
        }
        if ($box && $box.length) {
            $box.slideToggle(200);
        }
    });

    $(document).off('click.rdgMsgTab').on('click.rdgMsgTab', '.rdg-msg-tab-btn', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $parent = $btn.parent();
        $parent.find('.rdg-msg-tab-btn').removeClass('active');
        $btn.addClass('active');
        var idx = $btn.index() + 1;
        if ($btn.closest('.tab1').length) {
            $('#divChainMsg1, #divChainMsg2, #divChainMsg3').hide();
            $('#divChainMsg' + idx).fadeIn(150);
        } else if ($btn.closest('.tab7').length) {
            $('#divMassMsg1, #divMassMsg2, #divMassMsg3').hide();
            $('#divMassMsg' + idx).fadeIn(150);
        }
    });

    $(document).off('click.rdgNavTabs').on('click.rdgNavTabs', '.rdg-goto-tab4', function(e) {
        e.preventDefault();
        $('li.tab3 label').click();
    }).on('click.rdgNavTabs', '.rdg-goto-tab1', function(e) {
        e.preventDefault();
        $('li.tab1 label').click();
    }).on('click.rdgNavTabs', '.rdg-goto-tab6', function(e) {
        e.preventDefault();
        $('li.tab6 label').click();
    });
}

async function applyFiltersManually() {

    if (isAdditionalDataFullyLoaded(acctsQueue) === false && acctsQueue.length > 50 && gblOptions.useTimeDelayAfterAdditionalInfo == false) {
        if (!window.confirm('Applying filters requires loading additional data about each account.\n\nLoading this data can trigger rate limits from instagram.\n\nYou should strongly consider setting a delay in the Settings.\n\nProceed with filtering anyway?')) {
            return false;
        }
    }

    // --- POPUP START (User Request) ---
    var totalSeconds = acctsQueue.length * 7;
    var minutes = Math.floor(totalSeconds / 60);
    var seconds = totalSeconds % 60;
    var estimatedTimeMsg = minutes + " minutos e " + seconds + " segundos";

    // Create custom overlay
    var overlay = document.createElement('div');
    overlay.id = 'filterProcessingOverlay';
    overlay.style.cssText = 'position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); z-index:999999; display:flex; flex-direction:column; justify-content:center; align-items:center; color:#ffcc00; font-family:sans-serif; text-align:center;';
    
    var content = document.createElement('div');
    content.style.cssText = 'background:#1a1a1a; padding:40px; border-radius:15px; border:2px solid #ffcc00; max-width:500px; box-shadow:0 0 20px rgba(255,204,0,0.3); position:relative;';
    
    // Add spinner style
    var style = document.createElement('style');
    style.innerHTML = '@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }';
    document.head.appendChild(style);

    var spinner = document.createElement('div');
    spinner.className = 'igBotLoaderCustom';
    spinner.style.cssText = 'margin:0 auto 20px auto; width:40px; height:40px; border:4px solid #333; border-top:4px solid #ffcc00; border-radius:50%; animation:spin 1s linear infinite;';
    
    var title = document.createElement('h2');
    title.innerText = 'Aplicando Filtros...';
    title.style.cssText = 'margin-top:0; color:#ffcc00; margin-bottom:15px; font-size:22px;';
    
    var msg = document.createElement('p');
    msg.innerHTML = 'Carregando pessoas...<br>Tempo estimado: ' + estimatedTimeMsg;
    msg.style.cssText = 'color:#fff; font-size:16px; line-height:1.5; margin-bottom:0;';
    
    var logMsg = document.createElement('div');
    logMsg.style.cssText = 'color:#ffcc00; font-size:14px; margin-top:15px; font-family:monospace; background:rgba(0,0,0,0.3); padding:5px 10px; border-radius:4px; border:1px solid #333; width:100%; box-sizing:border-box; text-align:center;';
    logMsg.innerText = 'Iniciando...';

    content.appendChild(spinner);
    content.appendChild(title);
    content.appendChild(msg);
    content.appendChild(logMsg);
    overlay.appendChild(content);
    document.body.appendChild(overlay);

    // Allow UI to render
    await new Promise(r => setTimeout(r, 100));
    // --- POPUP END ---

    for (let i = acctsQueue.length - 1; i > -1; i--) {

        // Update Log and Time (Real-time)
        var currentUsername = acctsQueue[i].username || 'Usuário';
        logMsg.innerText = 'Processando: ' + currentUsername;
        
        var remainingSeconds = (i + 1) * 7;
        var remMin = Math.floor(remainingSeconds / 60);
        var remSec = remainingSeconds % 60;
        msg.innerHTML = 'Carregando pessoas...<br>Tempo estimado: ' + remMin + " minutos e " + remSec + " segundos";

        // Allow UI update
        await new Promise(r => setTimeout(r, 10));

        if (await filterCriteriaMet(acctsQueue[i]) === false) {
            outputMessage(acctsQueue[i].username + ' removed from queue (did not match your filters)');
            addStamp(acctsQueue[i].id, 'stamp-div-grey', 'REMOVIDO');
            acctsQueue.splice(i, 1);
        }
    }

    outputMessage('Filters applied.');
    
    // --- POPUP FINISH (User Request) ---
    spinner.style.display = 'none';
    title.innerText = 'Filtro Aplicado!';
    
    // New warning message
    msg.innerHTML = 'ATENÇÃO: Não faça isso muitas vezes. Pode sobrecarregar seu perfil do Instagram e acabar limitando ao ponto de precisar aguardar algumas horas ou até 1 dia para descansar o algoritmo.';
    msg.style.cssText = 'color:red; font-size:18px; line-height:1.6; margin-bottom:0; font-weight:bold;';

    // Auto-close popup after a delay
    setTimeout(function() {
        if (document.body.contains(overlay)) {
            document.body.removeChild(overlay);
        }
        saveQueueToStorage(); 
        $('li.tab1').click();
    }, 8000); // 8-second delay before closing
    // --- POPUP FINISH END ---

}

function getExtendedDataInfoForAccount(a) {

    return new Promise(function(resolve, reject) {

        $.ajax({
                url: 'https://i.instagram.com/api/v1/users/' + a.id + '/info/',
                method: 'GET',
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                    xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                    xhr.setRequestHeader('x-asbd-id', '129477');
                    xhr.setRequestHeader('x-ig-app-id', '936619743392459');
                },
                xhrFields: {
                    withCredentials: true
                }
            })
            .done(function(r) {


                outputMessage('Loaded user info for ' + a.username + ' to get email address');

                for (var key in r.user) {
                    if (a.hasOwnProperty(key) === false) {
                        a[key] = r.user[key];
                    }
                }

                resolve(a);


            }).fail(function(data) {
                if (data.status == 403) {
                    rdgAssistantTryContinuePendingLikes('extended_info_soft_rate_limit');
                    printMessage(chrome.i18n.getMessage('RateLimitSoft', [(gblOptions.timeDelayAfterSoftRateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(function() {
                        resolve(getExtendedDataInfoForAccount(a));
                    }, gblOptions.timeDelayAfterSoftRateLimit));
                } else if (data.status == 400) {
                    rdgAssistantTryContinuePendingLikes('extended_info_hard_rate_limit');
                    printMessage(chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]));
                    showRateLimitPopup();
                    timeoutsQueue.push(setTimeout(function() {
                        resolve(getExtendedDataInfoForAccount(a));
                    }, gblOptions.timeDelayAfterHardRateLimit));
                } else if (data.status == 429) {
                    rdgAssistantTryContinuePendingLikes('extended_info_429_rate_limit');
                    printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(function() {
                        resolve(getExtendedDataInfoForAccount(a));
                    }, gblOptions.timeDelayAfter429RateLimit));
                } else if (data.status == 404) {
                    gbl404attempt++;
                    if (gbl404attempt < (gblOptions.retriesAfterAdditionalInfo404 + 1)) {
                        rdgAssistantTryContinuePendingLikes('extended_info_404_retry');
                        outputMessage('404 possible rate limit, retry in ' + (gblOptions.timeDelayAfterAdditionalInfo / 1000) + ' seconds (attempt ' + gbl404attempt + ' of ' + gblOptions.retriesAfterAdditionalInfo404 + ')');
                        timeoutsQueue.push(setTimeout(function() {
                            resolve(getExtendedDataInfoForAccount(a));
                        }, gblOptions.timeDelayAfterAdditionalInfo));
                        return false;
                    } else {
                        outputMessage('404 account ' + a.username + ' assumed  missing after ' + gblOptions.retriesAfterAdditionalInfo404 + ' attempts');
                        a.assumedDeleted = true;
                        gbl404attempt = 0
                        resolve(a);
                    }
                } else {
                    rdgAssistantTryContinuePendingLikes('extended_info_generic_retry');
                    outputMessage('' + data.status + ' error, trying again in 5 seconds');
                    timeoutsQueue.push(setTimeout(function() {
                        resolve(getExtendedDataInfoForAccount(a));
                    }, 5000));
                }
                gbl404attempt = 0;
            });
    });
}



// should do this if Last Posted Filter is enabled or Like mode is enabled
function getTimelineForAcct(a) {

    return new Promise(function(resolve, reject) {

        $.ajax({
                url: 'https://www.instagram.com/api/v1/feed/user/' + a.username + '/username/?count=12',
                method: 'GET',
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                    xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                    xhr.setRequestHeader('x-asbd-id', '129477');
                    xhr.setRequestHeader('x-ig-app-id', '936619743392459');
                },
                xhrFields: {
                    withCredentials: true
                }
            })
            .done(function(r) {


                outputMessage('Loaded post data for ' + a.username + ' to determine last post date');

                a.edge_owner_to_timeline_media.edges = r.items;

                resolve(a);

            }).fail(function(data) {
                if (data.status == 403) {
                    rdgAssistantTryContinuePendingLikes('timeline_soft_rate_limit');
                    printMessage(chrome.i18n.getMessage('RateLimitSoft', [(gblOptions.timeDelayAfterSoftRateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(function() {
                        resolve(getTimelineForAcct(a));
                    }, gblOptions.timeDelayAfterSoftRateLimit));
                } else if (data.status == 400) {
                    rdgAssistantTryContinuePendingLikes('timeline_hard_rate_limit');
                    printMessage(chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]));
                    showRateLimitPopup();
                    timeoutsQueue.push(setTimeout(function() {
                        resolve(getTimelineForAcct(a));
                    }, gblOptions.timeDelayAfterHardRateLimit));
                } else if (data.status == 429) {
                    rdgAssistantTryContinuePendingLikes('timeline_429_rate_limit');
                    printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(function() {
                        resolve(getTimelineForAcct(a));
                    }, gblOptions.timeDelayAfter429RateLimit));
                } else if (data.status == 404) {
                    gbl404attempt++;
                    if (gbl404attempt < (gblOptions.retriesAfterAdditionalInfo404 + 1)) {
                        rdgAssistantTryContinuePendingLikes('timeline_404_retry');
                        outputMessage('404 possible rate limit, retry in ' + (gblOptions.timeDelayAfterAdditionalInfo / 1000) + ' seconds (attempt ' + gbl404attempt + ' of ' + gblOptions.retriesAfterAdditionalInfo404 + ')');
                        timeoutsQueue.push(setTimeout(function() {
                            resolve(getTimelineForAcct(a));
                        }, gblOptions.timeDelayAfterAdditionalInfo));
                        return false;
                    } else {
                        outputMessage('404 account ' + a.username + ' assumed  missing after ' + gblOptions.retriesAfterAdditionalInfo404 + ' attempts');
                        a.assumedDeleted = true;
                        gbl404attempt = 0
                        resolve(a);
                    }
                } else {
                    rdgAssistantTryContinuePendingLikes('timeline_generic_retry');
                    outputMessage('' + data.status + ' error, trying again in 5 seconds');
                    timeoutsQueue.push(setTimeout(function() {
                        resolve(getTimelineForAcct(a));
                    }, 5000));
                }
                gbl404attempt = 0;
            });
    });
}


function getAdditionalDataForAcct(a, urlprefix, forceFetch) {
    if (!urlprefix) urlprefix = urlAcctInfo;
    return new Promise(function(resolve, reject) {

        if (forceFetch !== true && typeof a.follows_viewer === 'boolean' && (a.edge_followed_by || a["edge_followed_by.count"])) {
            a = appendFollowersRatioToAcct(a);
            a = appendLastPostDateToAcct(a);
            resolve(a);
            return a;
        }

        $.ajax({
                url: '' + urlprefix + a.username,
                method: 'GET',
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                    xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                    xhr.setRequestHeader('x-asbd-id', '129477');
                    xhr.setRequestHeader('x-ig-app-id', '936619743392459');
                },
                xhrFields: {
                    withCredentials: true
                }
            })
            .done(async function(r) {
                var u = extractJSONfromUserPageHTML(r);

                if (u == false) {
                    gbl404attempt++;
                    if (gbl404attempt < (gblOptions.retriesAfterAdditionalInfo404 + 1)) {
                        rdgAssistantTryContinuePendingLikes('additional_info_parse_retry');
                        outputMessage('Could not load more info, retry in ' + (gblOptions.timeDelayAfterAdditionalInfo / 1000) + ' (attempt ' + gbl404attempt + ' of ' + gblOptions.retriesAfterAdditionalInfo404 + ')');
                        timeoutsQueue.push(setTimeout(function() {
                            resolve(getAdditionalDataForAcct(a));
                        }, gblOptions.timeDelayAfterAdditionalInfo));
                        return false;
                    } else {
                        outputMessage('Could not load more info, account assumed missing after ' + gblOptions.retriesAfterAdditionalInfo404 + ' attempts');
                        a.assumedDeleted = true;
                        gbl404attempt = 0;
                        resolve(a);
                        return false;
                    }

                }

                a = u;

                a = appendFollowersRatioToAcct(a);
                a = await appendLastPostDateToAcct(a);

                if (gblOptions.getExtendedData == true) {
                    a = await getExtendedDataInfoForAccount(a);
                }

                outputMessage('Loaded additional data for ' + a.username);

                if (gblOptions.useTimeDelayAfterAdditionalInfo == true) {
                    setTimeout(function() {
                        resolve(a);
                    }, gblOptions.timeDelayAfterAdditionalInfo);
                    printMessage(chrome.i18n.getMessage('TimeDelay', [(gblOptions.timeDelayAfterAdditionalInfo / 1000)]));
                    timeoutsQueue.push(setTimeout(function() {
                        resolve(a);
                    }, gblOptions.timeDelayAfterAdditionalInfo));
                } else {
                    resolve(a);
                }

                gbl404attempt = 0;

            }).fail(function(data) {
                if (data.status == 403) {
                    rdgAssistantTryContinuePendingLikes('additional_info_soft_rate_limit');
                    printMessage(chrome.i18n.getMessage('RateLimitSoft', [(gblOptions.timeDelayAfterSoftRateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(function() {
                        resolve(getAdditionalDataForAcct(a));
                    }, gblOptions.timeDelayAfterSoftRateLimit));
                } else if (data.status == 400) {
                    rdgAssistantTryContinuePendingLikes('additional_info_hard_rate_limit');
                    printMessage(chrome.i18n.getMessage('RateLimitHard', [(gblOptions.timeDelayAfterHardRateLimit / 3600000)]));
                    showRateLimitPopup();
                    timeoutsQueue.push(setTimeout(function() {
                        resolve(getAdditionalDataForAcct(a));
                    }, gblOptions.timeDelayAfterHardRateLimit));
                } else if (data.status == 429) {
                    rdgAssistantTryContinuePendingLikes('additional_info_429_rate_limit');
                    printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                    timeoutsQueue.push(setTimeout(function() {
                        resolve(getAdditionalDataForAcct(a));
                    }, gblOptions.timeDelayAfter429RateLimit));
                } else if (data.status == 404) {
                    gbl404attempt++;
                    if (gbl404attempt < (gblOptions.retriesAfterAdditionalInfo404 + 1)) {
                        rdgAssistantTryContinuePendingLikes('additional_info_404_retry');
                        outputMessage('404 possible rate limit, retry in ' + (gblOptions.timeDelayAfterAdditionalInfo / 1000) + ' seconds (attempt ' + gbl404attempt + ' of ' + gblOptions.retriesAfterAdditionalInfo404 + ')');
                        timeoutsQueue.push(setTimeout(function() {
                            resolve(getAdditionalDataForAcct(a));
                        }, gblOptions.timeDelayAfterAdditionalInfo));
                        return false;
                    } else {
                        outputMessage('404 account ' + a.username + ' assumed  missing after ' + gblOptions.retriesAfterAdditionalInfo404 + ' attempts');
                        a.assumedDeleted = true;
                        gbl404attempt = 0
                        resolve(a);
                    }
                } else {
                    rdgAssistantTryContinuePendingLikes('additional_info_generic_retry');
                    outputMessage('' + data.status + ' error, trying again in 5 seconds');
                    timeoutsQueue.push(setTimeout(function() {
                        resolve(getAdditionalDataForAcct(a));
                    }, 5000));
                }
                gbl404attempt = 0;
            });
    });
}


async function filterCriteriaMet(acct) {

    var filtered = false;

    if (acct.profile_pic_url && acct.profile_pic_url.indexOf(igExternalVars.emptyProfilePicUrl) > -1 && gblOptions.filterOptions.no_profile_pic == false) {
        outputMessage(acct.username + ' filtered - has no profile picture')
        filtered = true;
    }

    if (acct.profile_pic_url && acct.profile_pic_url.indexOf(igExternalVars.emptyProfilePicUrl) == -1 && gblOptions.filterOptions.profile_pic == false) {
        outputMessage(acct.username + ' filtered - has profile picture')
        filtered = true;
    }

    if (acct.followed_by_viewer == true && gblOptions.filterOptions.followed_by_me == false) {
        outputMessage(acct.username + ' filtered - account is followed by you')
        filtered = true;
    }

    if (acct.followed_by_viewer == false && gblOptions.filterOptions.non_followed_by_me == false) {
        outputMessage(acct.username + ' filtered - account is not followed by you')
        filtered = true;
    }

    if (acct.is_verified == true && gblOptions.filterOptions.verified == false) {
        outputMessage(acct.username + ' filtered - account is verified')
        filtered = true;
    }
    if (acct.is_verified == false && gblOptions.filterOptions.non_verified == false) {
        outputMessage(acct.username + ' filtered - account is not verified')
        filtered = true;
    }

    if (filtered === true) {
        return false;
    }

    if (!acct.edge_followed_by || ((gblOptions.filterOptions.follows_me == false || gblOptions.filterOptions.non_follows_me == false) && typeof acct.follows_viewer !== 'boolean')) {
        acct = await getAdditionalDataForAcct(acct, null, (gblOptions.filterOptions.follows_me == false || gblOptions.filterOptions.non_follows_me == false) && typeof acct.follows_viewer !== 'boolean');
    }

    if (acct.assumedDeleted) {
        outputMessage('Account may have been deleted');
        return false;
    }

    if (acct.edge_followed_by.count < gblOptions.filterOptions.followers[0]) {
        outputMessage(acct.username + ' filtered - too few followers')
        filtered = true;
    }
    if (acct.edge_followed_by.count > gblOptions.filterOptions.followers[1]) {
        outputMessage(acct.username + ' filtered - too many followers')
        filtered = true;
    }
    if (acct.edge_follow.count < gblOptions.filterOptions.following[0]) {
        outputMessage(acct.username + ' filtered - too few following')
        filtered = true;
    }
    if (acct.edge_follow.count > gblOptions.filterOptions.following[1]) {
        outputMessage(acct.username + ' filtered - too many following')
        filtered = true;
    }
    if (acct.edge_mutual_followed_by.count < gblOptions.filterOptions.mutualFollowedBy[0]) {
        outputMessage(acct.username + ' filtered - too few mutual followers')
        filtered = true;
    }
    if (acct.edge_mutual_followed_by.count > gblOptions.filterOptions.mutualFollowedBy[1]) {
        outputMessage(acct.username + ' filtered - too many mutual followers')
        filtered = true;
    }

    if (acct.followRatio < gblOptions.filterOptions.followRatio[0]) {
        outputMessage(acct.username + ' filtered - follow ratio too low')
        filtered = true;
    }
    if (acct.followRatio > gblOptions.filterOptions.followRatio[1]) {
        outputMessage(acct.username + ' filtered - follow ratio too high')
        filtered = true;
    }
    if (acct.edge_owner_to_timeline_media.count < gblOptions.filterOptions.posts[0]) {
        outputMessage(acct.username + ' filtered - too few posts')
        filtered = true;
    }
    if (acct.edge_owner_to_timeline_media.count > gblOptions.filterOptions.posts[1]) {
        outputMessage(acct.username + ' filtered - too many posts')
        filtered = true;
    }
    if (acct.lastPostDateInDays < gblOptions.filterOptions.lastPosted[0]) {
        outputMessage(acct.username + ' filtered - posted too recently')
        filtered = true;
    }

    // data doesn't exit properly for private accounts, so skip this filter if account is private
    if (acct.lastPostDateInDays > gblOptions.filterOptions.lastPosted[1] && (acct.is_private == false || acct.followed_by_viewer == true)) {
        outputMessage(acct.username + ' filtered - posted too long ago')
        filtered = true;
    }
    if (acct.is_private == true && gblOptions.filterOptions.private == false) {
        outputMessage(acct.username + ' filtered - account is private')
        filtered = true;
    }
    if (acct.is_private == false && gblOptions.filterOptions.non_private == false) {
        outputMessage(acct.username + ' filtered - account is public')
        filtered = true;
    }

    if (acct.follows_viewer == true && gblOptions.filterOptions.follows_me == false) {
        outputMessage(acct.username + ' filtered - account follows you')
        filtered = true;
    }
    if (acct.follows_viewer == false && gblOptions.filterOptions.non_follows_me == false) {
        outputMessage(acct.username + ' filtered - account does not follow you')
        filtered = true;
    }
    if (acct.is_business_account == true && gblOptions.filterOptions.is_business_account == false) {
        outputMessage(acct.username + ' filtered - account is a business account')
        filtered = true;
    }
    if (acct.is_business_account == false && gblOptions.filterOptions.non_is_business_account == false) {
        outputMessage(acct.username + ' filtered - account is not a business account')
        filtered = true;
    }
    if (acct.is_joined_recently == true && gblOptions.filterOptions.is_joined_recently == false) {
        outputMessage(acct.username + ' filtered - account joined recently')
        filtered = true;
    }
    if (acct.is_joined_recently == false && gblOptions.filterOptions.non_is_joined_recently == false) {
        outputMessage(acct.username + ' filtered - account did not join recently')
        filtered = true;
    }

    if (gblOptions.filterOptions.bio_contains == true) {
        var bioContains = false;

        if (acct.biography) {
            var bioContainsStrings = gblOptions.filterOptions.bio_contains_text.split(',');
            for (var i = 0; i < bioContainsStrings.length; i++) {
                if (acct.biography.toLowerCase().indexOf(bioContainsStrings[i].toLowerCase()) > -1) {
                    bioContains = true;
                }
            }
        }

        if (bioContains == false) {
            filtered = true;
            outputMessage(acct.username + ' filtered - bio does not contain ' + gblOptions.filterOptions.bio_contains_text);
        }
    }

    if (gblOptions.filterOptions.bio_not_contains == true) {
        var bioContains = false;

        if (acct.biography) {
            var bioContainsStrings = gblOptions.filterOptions.bio_not_contains_text.split(',');
            for (var i = 0; i < bioContainsStrings.length; i++) {
                if (acct.biography.toLowerCase().indexOf(bioContainsStrings[i].toLowerCase()) > -1) {
                    bioContains = true;
                    outputMessage(acct.username + ' filtered - bio contains ' + bioContainsStrings[i].toLowerCase());
                }
            }
        }

        if (bioContains == true) {
            filtered = true;
        }
    }


    if (gblOptions.filterOptions.external_url_contains == true) {
        var externalUrlContains = false;

        if (acct.external_url) {
            var externalUrlContainsStrings = gblOptions.filterOptions.external_url_contains_text.split(',');
            for (var i = 0; i < externalUrlContainsStrings.length; i++) {
                if (acct.external_url.toLowerCase().indexOf(externalUrlContainsStrings[i].toLowerCase()) > -1) {
                    externalUrlContains = true;
                }
            }
        }

        if (externalUrlContains == false) {
            filtered = true;
            outputMessage(acct.username + ' filtered - external url does not contain ' + gblOptions.filterOptions.external_url_contains_text);
        }
    }

    if (gblOptions.filterOptions.external_url_not_contains == true) {
        var externalUrlContains = false;

        if (acct.external_url) {
            var externalUrlNotContainsStrings = gblOptions.filterOptions.external_url_not_contains_text.split(',');
            for (var i = 0; i < externalUrlNotContainsStrings.length; i++) {
                if (acct.external_url.toLowerCase().indexOf(externalUrlNotContainsStrings[i].toLowerCase()) > -1) {
                    externalUrlContains = true;
                    outputMessage(acct.username + ' filtered - external url contains ' + externalUrlNotContainsStrings[i].toLowerCase());
                }
            }
        }

        if (externalUrlContains == true) {
            filtered = true;
        }
    }

    if (gblOptions.filterOptions.business_category_name_contains == true) {
        var BusinessCategoryNameContains = false;

        if (acct.business_category_name) {
            var businessCategoryNameContainsStrings = gblOptions.filterOptions.business_category_name_contains_text.split(',');
            for (var i = 0; i < businessCategoryNameContainsStrings.length; i++) {
                if (acct.business_category_name.toLowerCase().indexOf(businessCategoryNameContainsStrings[i].toLowerCase()) > -1) {
                    BusinessCategoryNameContains = true;
                }
            }
        }

        if (BusinessCategoryNameContains == false) {
            filtered = true;
            outputMessage(acct.username + ' filtered - business category name does not contain ' + gblOptions.filterOptions.business_category_name_contains_text);
        }
    }

    if (gblOptions.filterOptions.business_category_name_not_contains == true) {
        var BusinessCategoryNameContains = false;

        if (acct.business_category_name) {
            var businessCategoryNameContainsStrings = gblOptions.filterOptions.business_category_name_not_contains_text.split(',');
            for (var i = 0; i < businessCategoryNameContainsStrings.length; i++) {
                if (acct.business_category_name.toLowerCase().indexOf(businessCategoryNameContainsStrings[i].toLowerCase()) > -1) {
                    BusinessCategoryNameContains = true;
                    outputMessage(acct.username + ' filtered - business category name contains ' + businessCategoryNameContainsStrings[i].toLowerCase());
                }
            }
        }

        if (BusinessCategoryNameContains == true) {
            filtered = true;
        }
    }


    if (filtered === true) {
        return false;
    } else {
        return true;
    }

}

async function filterCriteriaMetForUnfollowing(acct) {

    if (gblOptions.unFollowFresh === false || gblOptions.dontUnFollowNonRdg === true || gblOptions.unFollowIfOld === true) {
        var acctFromStorage = alreadyAttempted(acct);

        if (gblOptions.dontUnFollowNonRdg === true && acctFromStorage === false) {
            outputMessage(acct.username + ' was followed outside of RDG, skipping');
            addStamp(acct.id, 'stamp-div-grey', 'EXTERNO');
            return false;
        }

        var timeSinceFollowed = today - acctFromStorage.followAttemptDate;

        if (acctFromStorage != false && acctFromStorage.followAttemptDate && gblOptions.unFollowFresh == false && timeSinceFollowed < gblOptions.unFollowDelay) {
            outputMessage(acct.username + ' was followed too recently to unfollow ' + millisecondsToHumanReadable(timeSinceFollowed, true));
            addStamp(acct.id, 'stamp-div-grey', 'RECENTE');
            return false;
        }
    }

    if (gblOptions.dontUnFollowFilters === true) {

        var filtered = false;

        if (acct.profile_pic_url.indexOf(igExternalVars.emptyProfilePicUrl) > -1 && gblOptions.filterOptions.no_profile_pic == false) {
            outputMessage(acct.username + ' filtered - has no profile picture')
            filtered = true;
        }

        if (acct.profile_pic_url.indexOf(igExternalVars.emptyProfilePicUrl) == -1 && gblOptions.filterOptions.profile_pic == false) {
            outputMessage(acct.username + ' filtered - has profile picture')
            filtered = true;
        }

        if (acct.is_verified == true && gblOptions.filterOptions.verified == false) {
            outputMessage(acct.username + ' filtered - account is verified')
            filtered = true;
        }
        if (acct.is_verified == false && gblOptions.filterOptions.non_verified == false) {
            outputMessage(acct.username + ' filtered - account is not verified')
            filtered = true;
        }
    }


    if (!acct.edge_followed_by || typeof acct.follows_viewer !== 'boolean') {
        acct = await getAdditionalDataForAcct(acct, null, typeof acct.follows_viewer !== 'boolean');
    }

    if (gblOptions.dontUnFollowFollowers === true) {
        if (acct.follows_viewer === true || acct.follows_me === true) {
            if (gblOptions.unFollowIfOld == true && timeSinceFollowed > gblOptions.unFollowIfOlderThan) {
                outputMessage(acct.username + ' was followed more than ' + millisecondsToHumanReadable(gblOptions.unFollowIfOlderThan, false).days + ' days ago, OK to unfollow');
                return true;
            } else {
                outputMessage(acct.username + ' is one of your followers, skipping');
                addStamp(acct.id, 'stamp-div-grey', 'SEGUE VOCÊ');
                return false;
            }
        } else if (typeof acct.follows_viewer !== 'boolean' && typeof acct.follows_me !== 'boolean') {
            outputMessage(acct.username + ' relationship data missing (API limit?), skipping to protect followers');
            addStamp(acct.id, 'stamp-div-grey', 'INCERTO');
            return false;
        }
    }


    if (acct.assumedDeleted) return false;

    if (gblOptions.dontUnFollowFilters === true) {

        if (acct.edge_followed_by.count < gblOptions.filterOptions.followers[0]) {
            outputMessage(acct.username + ' filtered - too few followers')
            filtered = true;
        }
        if (acct.edge_followed_by.count > gblOptions.filterOptions.followers[1]) {
            outputMessage(acct.username + ' filtered - too many followers')
            filtered = true;
        }
        if (acct.edge_follow.count < gblOptions.filterOptions.following[0]) {
            outputMessage(acct.username + ' filtered - too few following')
            filtered = true;
        }
        if (acct.edge_follow.count > gblOptions.filterOptions.following[1]) {
            outputMessage(acct.username + ' filtered - too many following')
            filtered = true;
        }
        if (acct.edge_mutual_followed_by.count < gblOptions.filterOptions.mutualFollowedBy[0]) {
            outputMessage(acct.username + ' filtered - too few mutual followers')
            filtered = true;
        }
        if (acct.edge_mutual_followed_by.count > gblOptions.filterOptions.mutualFollowedBy[1]) {
            outputMessage(acct.username + ' filtered - too many mutual followers')
            filtered = true;
        }
        if (acct.followRatio < gblOptions.filterOptions.followRatio[0]) {
            outputMessage(acct.username + ' filtered - follow ratio too low')
            filtered = true;
        }
        if (acct.followRatio > gblOptions.filterOptions.followRatio[1]) {
            outputMessage(acct.username + ' filtered - follow ratio too high')
            filtered = true;
        }
        if (acct.edge_owner_to_timeline_media.count < gblOptions.filterOptions.posts[0]) {
            outputMessage(acct.username + ' filtered - too few posts')
            filtered = true;
        }
        if (acct.edge_owner_to_timeline_media.count > gblOptions.filterOptions.posts[1]) {
            outputMessage(acct.username + ' filtered - too many posts')
            filtered = true;
        }
        if (acct.lastPostDateInDays < gblOptions.filterOptions.lastPosted[0]) {
            outputMessage(acct.username + ' filtered - posted too recently')
            filtered = true;
        }
        if (acct.lastPostDateInDays > gblOptions.filterOptions.lastPosted[1] && (acct.is_private == false || acct.followed_by_viewer == true)) {
            outputMessage(acct.username + ' filtered - posted too long ago')
            filtered = true;
        }
        if (acct.is_private == true && gblOptions.filterOptions.private == false) {
            outputMessage(acct.username + ' filtered - account is private')
            filtered = true;
        }
        if (acct.is_private == false && gblOptions.filterOptions.non_private == false) {
            outputMessage(acct.username + ' filtered - account is public')
            filtered = true;
        }
        if (acct.is_business_account == true && gblOptions.filterOptions.is_business_account == false) {
            outputMessage(acct.username + ' filtered - account is a business account')
            filtered = true;
        }
        if (acct.is_business_account == false && gblOptions.filterOptions.non_is_business_account == false) {
            outputMessage(acct.username + ' filtered - account is not a business account')
            filtered = true;
        }
        if (acct.is_joined_recently == true && gblOptions.filterOptions.is_joined_recently == false) {
            outputMessage(acct.username + ' filtered - account joined recently')
            filtered = true;
        }
        if (acct.is_joined_recently == false && gblOptions.filterOptions.non_is_joined_recently == false) {
            outputMessage(acct.username + ' filtered - account did not join recently')
            filtered = true;
        }

        if (gblOptions.filterOptions.bio_contains == true) {
            var bioContains = false;

            if (acct.biography) {
                var bioContainsStrings = gblOptions.filterOptions.bio_contains_text.split(',');
                for (var i = 0; i < bioContainsStrings.length; i++) {
                    if (acct.biography.toLowerCase().indexOf(bioContainsStrings[i].toLowerCase()) > -1) {
                        bioContains = true;
                    }
                }
            }

            if (bioContains == false) {
                filtered = true;
                outputMessage(acct.username + ' filtered - bio does not contain ' + gblOptions.filterOptions.bio_contains_text);
            }
        }

        if (gblOptions.filterOptions.bio_not_contains == true) {
            var bioContains = false;

            if (acct.biography) {
                var bioContainsStrings = gblOptions.filterOptions.bio_not_contains_text.split(',');
                for (var i = 0; i < bioContainsStrings.length; i++) {
                    if (acct.biography.toLowerCase().indexOf(bioContainsStrings[i].toLowerCase()) > -1) {
                        bioContains = true;
                        outputMessage(acct.username + ' filtered - bio contains ' + bioContainsStrings[i].toLowerCase());
                    }
                }
            }

            if (bioContains == true) {
                filtered = true;
            }
        }


        if (gblOptions.filterOptions.external_url_contains == true) {
            var externalUrlContains = false;

            if (acct.external_url) {
                var externalUrlContainsStrings = gblOptions.filterOptions.external_url_contains_text.split(',');
                for (var i = 0; i < externalUrlContainsStrings.length; i++) {
                    if (acct.external_url.toLowerCase().indexOf(externalUrlContainsStrings[i].toLowerCase()) > -1) {
                        externalUrlContains = true;
                    }
                }
            }

            if (externalUrlContains == false) {
                filtered = true;
                outputMessage(acct.username + ' filtered - external url does not contain ' + gblOptions.filterOptions.external_url_contains_text);
            }
        }

        if (gblOptions.filterOptions.external_url_not_contains == true) {
            var externalUrlContains = false;

            if (acct.external_url) {
                var externalUrlNotContainsStrings = gblOptions.filterOptions.external_url_not_contains_text.split(',');
                for (var i = 0; i < externalUrlNotContainsStrings.length; i++) {
                    if (acct.external_url.toLowerCase().indexOf(externalUrlNotContainsStrings[i].toLowerCase()) > -1) {
                        externalUrlContains = true;
                        outputMessage(acct.username + ' filtered - external url contains ' + externalUrlNotContainsStrings[i].toLowerCase());
                    }
                }
            }

            if (externalUrlContains == true) {
                filtered = true;
            }
        }


        if (gblOptions.filterOptions.business_category_name_contains == true) {
            var BusinessCategoryNameContains = false;

            if (acct.business_category_name) {
                var businessCategoryNameContainsStrings = gblOptions.filterOptions.business_category_name_contains_text.split(',');
                for (var i = 0; i < businessCategoryNameContainsStrings.length; i++) {
                    if (acct.business_category_name.toLowerCase().indexOf(businessCategoryNameContainsStrings[i].toLowerCase()) > -1) {
                        BusinessCategoryNameContains = true;
                    }
                }
            }

            if (BusinessCategoryNameContains == false) {
                filtered = true;
                outputMessage(acct.username + ' filtered - business category name does not contain ' + gblOptions.filterOptions.business_category_name_contains_text);
            }
        }

        if (gblOptions.filterOptions.business_category_name_not_contains == true) {
            var BusinessCategoryNameContains = false;

            if (acct.business_category_name) {
                var businessCategoryNameContainsStrings = gblOptions.filterOptions.business_category_name_not_contains_text.split(',');
                for (var i = 0; i < businessCategoryNameContainsStrings.length; i++) {
                    if (acct.business_category_name.toLowerCase().indexOf(businessCategoryNameContainsStrings[i].toLowerCase()) > -1) {
                        BusinessCategoryNameContains = true;
                        outputMessage(acct.username + ' filtered - business category name contains ' + businessCategoryNameContainsStrings[i].toLowerCase());
                    }
                }
            }

            if (BusinessCategoryNameContains == true) {
                filtered = true;
            }
        }


    }

    return filtered;

}

async function filterCriteriaMetForRemoveOrBlock(acct) {

    var filtered = false;

    if (acct.profile_pic_url.indexOf(igExternalVars.emptyProfilePicUrl) > -1 && gblOptions.filterOptions.no_profile_pic == false) {
        outputMessage(acct.username + ' filtered - has no profile picture')
        filtered = true;
    }

    if (acct.profile_pic_url.indexOf(igExternalVars.emptyProfilePicUrl) == -1 && gblOptions.filterOptions.profile_pic == false) {
        outputMessage(acct.username + ' filtered - has profile picture')
        filtered = true;
    }

    if (acct.followed_by_viewer == true && gblOptions.filterOptions.followed_by_me == false) {
        outputMessage(acct.username + ' filtered - account is followed by you')
        filtered = true;
    }

    if (acct.followed_by_viewer == false && gblOptions.filterOptions.non_followed_by_me == false) {
        outputMessage(acct.username + ' filtered - account is not followed by you')
        filtered = true;
    }

    if (acct.is_verified == true && gblOptions.filterOptions.verified == false) {
        outputMessage(acct.username + ' filtered - account is verified')
        filtered = true;
    }
    if (acct.is_verified == false && gblOptions.filterOptions.non_verified == false) {
        outputMessage(acct.username + ' filtered - account is not verified')
        filtered = true;
    }

    if (!acct.edge_followed_by || ((gblOptions.filterOptions.follows_me == false || gblOptions.filterOptions.non_follows_me == false) && typeof acct.follows_viewer !== 'boolean')) {
        acct = await getAdditionalDataForAcct(acct, null, (gblOptions.filterOptions.follows_me == false || gblOptions.filterOptions.non_follows_me == false) && typeof acct.follows_viewer !== 'boolean');
    }

    if (acct.assumedDeleted) return false;

    if (acct.edge_followed_by.count < gblOptions.filterOptions.followers[0]) {
        outputMessage(acct.username + ' filtered - too few followers')
        filtered = true;
    }
    if (acct.edge_followed_by.count > gblOptions.filterOptions.followers[1]) {
        outputMessage(acct.username + ' filtered - too many followers')
        filtered = true;
    }
    if (acct.edge_follow.count < gblOptions.filterOptions.following[0]) {
        outputMessage(acct.username + ' filtered - too few following')
        filtered = true;
    }
    if (acct.edge_follow.count > gblOptions.filterOptions.following[1]) {
        outputMessage(acct.username + ' filtered - too many following')
        filtered = true;
    }
    if (acct.edge_mutual_followed_by.count < gblOptions.filterOptions.mutualFollowedBy[0]) {
        outputMessage(acct.username + ' filtered - too few mutual followers')
        filtered = true;
    }
    if (acct.edge_mutual_followed_by.count > gblOptions.filterOptions.mutualFollowedBy[1]) {
        outputMessage(acct.username + ' filtered - too many mutual followers')
        filtered = true;
    }
    if (acct.followRatio < gblOptions.filterOptions.followRatio[0]) {
        outputMessage(acct.username + ' filtered - follow ratio too low')
        filtered = true;
    }
    if (acct.followRatio > gblOptions.filterOptions.followRatio[1]) {
        outputMessage(acct.username + ' filtered - follow ratio too high')
        filtered = true;
    }
    if (acct.edge_owner_to_timeline_media.count < gblOptions.filterOptions.posts[0]) {
        outputMessage(acct.username + ' filtered - too few posts')
        filtered = true;
    }
    if (acct.edge_owner_to_timeline_media.count > gblOptions.filterOptions.posts[1]) {
        outputMessage(acct.username + ' filtered - too many posts')
        filtered = true;
    }
    if (acct.lastPostDateInDays < gblOptions.filterOptions.lastPosted[0]) {
        outputMessage(acct.username + ' filtered - posted too recently')
        filtered = true;
    }
    if (acct.lastPostDateInDays > gblOptions.filterOptions.lastPosted[1] && (acct.is_private == false || acct.followed_by_viewer == true)) {
        outputMessage(acct.username + ' filtered - posted too long ago')
        filtered = true;
    }
    if (acct.is_private == true && gblOptions.filterOptions.private == false) {
        outputMessage(acct.username + ' filtered - account is private')
        filtered = true;
    }
    if (acct.is_private == false && gblOptions.filterOptions.non_private == false) {
        outputMessage(acct.username + ' filtered - account is public')
        filtered = true;
    }
    if (acct.is_business_account == true && gblOptions.filterOptions.is_business_account == false) {
        outputMessage(acct.username + ' filtered - account is a business account')
        filtered = true;
    }
    if (acct.is_business_account == false && gblOptions.filterOptions.non_is_business_account == false) {
        outputMessage(acct.username + ' filtered - account is not a business account')
        filtered = true;
    }
    if (acct.is_joined_recently == true && gblOptions.filterOptions.is_joined_recently == false) {
        outputMessage(acct.username + ' filtered - account joined recently')
        filtered = true;
    }
    if (acct.is_joined_recently == false && gblOptions.filterOptions.non_is_joined_recently == false) {
        outputMessage(acct.username + ' filtered - account did not join recently')
        filtered = true;
    }

    if (gblOptions.filterOptions.bio_contains == true) {
        var bioContains = false;

        if (acct.biography) {
            var bioContainsStrings = gblOptions.filterOptions.bio_contains_text.split(',');
            for (var i = 0; i < bioContainsStrings.length; i++) {
                if (acct.biography.toLowerCase().indexOf(bioContainsStrings[i].toLowerCase()) > -1) {
                    bioContains = true;
                }
            }
        }

        if (bioContains == false) {
            filtered = true;
            outputMessage(acct.username + ' filtered - bio does not contain ' + gblOptions.filterOptions.bio_contains_text);
        }
    }

    if (gblOptions.filterOptions.bio_not_contains == true) {
        var bioContains = false;

        if (acct.biography) {
            var bioContainsStrings = gblOptions.filterOptions.bio_not_contains_text.split(',');
            for (var i = 0; i < bioContainsStrings.length; i++) {
                if (acct.biography.toLowerCase().indexOf(bioContainsStrings[i].toLowerCase()) > -1) {
                    bioContains = true;
                    outputMessage(acct.username + ' filtered - bio contains ' + bioContainsStrings[i].toLowerCase());
                }
            }
        }

        if (bioContains == true) {
            filtered = true;
        }
    }

    if (gblOptions.filterOptions.external_url_contains == true) {
        var externalUrlContains = false;

        if (acct.external_url) {
            var externalUrlContainsStrings = gblOptions.filterOptions.external_url_contains_text.split(',');
            for (var i = 0; i < externalUrlContainsStrings.length; i++) {
                if (acct.external_url.toLowerCase().indexOf(externalUrlContainsStrings[i].toLowerCase()) > -1) {
                    externalUrlContains = true;
                }
            }
        }

        if (externalUrlContains == false) {
            filtered = true;
            outputMessage(acct.username + ' filtered - external url does not contain ' + gblOptions.filterOptions.external_url_contains_text);
        }
    }

    if (gblOptions.filterOptions.external_url_not_contains == true) {
        var externalUrlContains = false;

        if (acct.external_url) {
            var externalUrlContainsStrings = gblOptions.filterOptions.bio_not_contains_text.split(',');
            for (var i = 0; i < bioContainsStrings.length; i++) {
                if (acct.external_url.toLowerCase().indexOf(externalUrlContainsStrings[i].toLowerCase()) > -1) {
                    externalUrlContains = true;
                    outputMessage(acct.username + ' filtered - external url contains ' + externalUrlContainsStrings[i].toLowerCase());
                }
            }
        }

        if (externalUrlContains == true) {
            filtered = true;
        }
    }



    if (gblOptions.filterOptions.business_category_name_contains == true) {
        var BusinessCategoryNameContains = false;

        if (acct.business_category_name) {
            var businessCategoryNameContainsStrings = gblOptions.filterOptions.business_category_name_contains_text.split(',');
            for (var i = 0; i < businessCategoryNameContainsStrings.length; i++) {
                if (acct.business_category_name.toLowerCase().indexOf(businessCategoryNameContainsStrings[i].toLowerCase()) > -1) {
                    BusinessCategoryNameContains = true;
                }
            }
        }

        if (BusinessCategoryNameContains == false) {
            filtered = true;
            outputMessage(acct.username + ' filtered - business category name does not contain ' + gblOptions.filterOptions.business_category_name_contains_text);
        }
    }

    if (gblOptions.filterOptions.business_category_name_not_contains == true) {
        var BusinessCategoryNameContains = false;

        if (acct.business_category_name) {
            var businessCategoryNameContainsStrings = gblOptions.filterOptions.business_category_name_not_contains_text.split(',');
            for (var i = 0; i < businessCategoryNameContainsStrings.length; i++) {
                if (acct.business_category_name.toLowerCase().indexOf(businessCategoryNameContainsStrings[i].toLowerCase()) > -1) {
                    BusinessCategoryNameContains = true;
                    outputMessage(acct.username + ' filtered - business category name contains ' + businessCategoryNameContainsStrings[i].toLowerCase());
                }
            }
        }

        if (BusinessCategoryNameContains == true) {
            filtered = true;
        }
    }


    return filtered;

}


function bindFilterInputs() {

    var inputMappings = [
        { key: 'followers', minId: 'followersMin', maxId: 'followersMax' },
        { key: 'following', minId: 'followingMin', maxId: 'followingMax' },
        { key: 'followRatio', minId: 'followRatioMin', maxId: 'followRatioMax' },
        { key: 'mutualFollowedBy', minId: 'mutualFollowedByMin', maxId: 'mutualFollowedByMax' },
        { key: 'posts', minId: 'postsMin', maxId: 'postsMax' },
        { key: 'lastPosted', minId: 'lastPostedMin', maxId: 'lastPostedMax' }
    ];

    function updateFilterFromInputs() {
        inputMappings.forEach(function(mapping) {
            var minInput = document.getElementById(mapping.minId);
            var maxInput = document.getElementById(mapping.maxId);
            
            var minVal = parseFloat(minInput.value);
            var maxVal = parseFloat(maxInput.value);
            
            if (isNaN(minVal)) minVal = defaultFilterOptions[mapping.key][0]; 
            if (isNaN(maxVal)) maxVal = defaultFilterOptions[mapping.key][1];

            gblOptions.filterOptions[mapping.key] = [minVal, maxVal];
        });
        saveOptions();
    }

    inputMappings.forEach(function(mapping) {
        var minInput = document.getElementById(mapping.minId);
        var maxInput = document.getElementById(mapping.maxId);

        if (!minInput || !maxInput) return;

        var currentValues = gblOptions.filterOptions[mapping.key];
        if (!currentValues || !Array.isArray(currentValues)) {
            currentValues = defaultFilterOptions[mapping.key];
        }
        
        minInput.value = currentValues[0];
        maxInput.value = currentValues[1];

        minInput.addEventListener('change', updateFilterFromInputs);
        maxInput.addEventListener('change', updateFilterFromInputs);
    });

    $('#btnResetFilter').off('click').click(function() {
        inputMappings.forEach(function(mapping) {
            var defaults = defaultFilterOptions[mapping.key];
            var minInput = document.getElementById(mapping.minId);
            var maxInput = document.getElementById(mapping.maxId);
            
            if (minInput && maxInput) {
                minInput.value = defaults[0];
                maxInput.value = defaults[1];
            }
        });
        updateFilterFromInputs();
    });

}

function setCurrentPageUsername() {
    if (getCurrentPageUsername() != '') {
        $('#btnGetAllUsersFollowers')
            .removeClass('inactive')
            .text(chrome.i18n.getMessage('LoadCurrentFollowers', getCurrentPageUsername()))
            .off('click.ajaxGetAllUsersFollowers')
            .on('click.ajaxGetAllUsersFollowers', ajaxGetAllUsersFollowers);
        $('#btnGetAllUsersFollowing')
            .removeClass('inactive')
            .text(chrome.i18n.getMessage('LoadCurrentFollowing', getCurrentPageUsername()))
            .off('click.ajaxLoadFollowing')
            .on('click.ajaxLoadFollowing', ajaxLoadFollowing);

        $('#btnGetCommenters').removeClass('inactive')
            .text(chrome.i18n.getMessage('LoadCommenters', getCurrentPageUsername()))
            .off('click.getCommenters')
            .on('click.getCommenters', ajaxLoadAllUsersCommenters);

        $('#btnGetLikers')
            .removeClass('inactive')
            .text(chrome.i18n.getMessage('LoadLikers', getCurrentPageUsername()))
            .off('click.getLikers')
            .on('click.getLikers', ajaxLoadAllUsersLikers);

    } else {

        $('#igBotInjectedContainer #btnGetAllUsersFollowers,#igBotInjectedContainer #btnGetAllUsersFollowing')
            .off('click') // Remove any previous click handlers
            .click(function() {
            outputMessage('Error: must be on an instagram user page (or try reloading).');
            showProfileRequiredPopup();
        }).addClass('inactive');
    }
}

function checkUsernameFreshness() {
    if ($(igExternalVars.qsForProfilePageUsername).text() != getCurrentPageUsername()) {
        ajaxGetCurrentPageUserInfo();
        return false;
    }
    return true;
}


function rdgGetInstagramUsernameFromPage() {
    // 1. Primary Authority: Clean URL Pathname
    try {
        var parts = window.location.pathname.split('/').filter(Boolean);
        if (parts.length >= 1) {
            var first = parts[0].trim().replace(/^@/, '');
            var reserved = ['p', 'reel', 'reels', 'explore', 'direct', 'stories', 'accounts', 'tags', 'developer', 'about', 'legal', 'privacy', 'terms', 'api', 'help', 'emails', 'create', 'challenge', 'shop'];
            if (first && reserved.indexOf(first.toLowerCase()) === -1 && /^[a-zA-Z0-9_.]+$/.test(first)) {
                return first;
            }
        }
    } catch (e0) {}

    if (typeof currentProfilePage !== 'undefined' && currentProfilePage && currentProfilePage !== false && currentProfilePage.username) {
        return String(currentProfilePage.username).trim();
    }

    try {
        var headings = document.querySelectorAll('main header h2, main header h1, header section h2, header section h1, header h2, header h1');
        for (var i = 0; i < headings.length; i++) {
            var txt = (headings[i].innerText || headings[i].textContent || '').trim().replace(/^@/, '').split('\n')[0].trim();
            if (txt && !/\s/.test(txt) && /^[a-zA-Z0-9_.]+$/.test(txt) && txt.length >= 1 && txt.length <= 30) {
                return txt;
            }
        }
    } catch (e1) {}

    return '';
}


function getCurrentPageUsername() {
    var username = rdgGetInstagramUsernameFromPage();
    if (username && username !== '') {
        if (typeof currentProfilePage === 'undefined' || !currentProfilePage || currentProfilePage === false) {
            currentProfilePage = { username: username };
        }
        return username;
    }
    return '';
}

function getQueryParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function shortcodeToInstaID(Shortcode) {
    var char;
    var id = BigInt(0);
    var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
    for (var i = 0; i < Shortcode.length; i++) {
        char = Shortcode[i];
        var mul = BigInt(BigInt(id) * BigInt(64));
        id = BigInt(BigInt(mul) + BigInt(alphabet.indexOf(char)));
    }

    var stringId = id.toString().replace('n', '');

    return stringId;
}


async function loadCurrentPostAsMedia() {

    var url = window.location.href;

    var shorty;

    if (url.indexOf('/p/') > 0) {
        shorty = url.substring(url.indexOf('/p/') + 3, url.length);
    } else if (url.indexOf('/reel/') > 0) {
        shorty = url.substring(url.indexOf('/reel/') + 6, url.length);
    } else {
        printMessage('Error: must be on post page');
        return false;
    }

    shorty = shorty.substring(0, shorty.indexOf('/'));


    var mediaId = shortcodeToInstaID(shorty);
    if (shorty.length > 15) {
        const response = await fetch(url);
        var HTML_String = await response.text();
        HTML_String = HTML_String.substring(HTML_String.indexOf('instagram://media?id=') + 21, HTML_String.length)
        mediaId = HTML_String.substring(0, HTML_String.indexOf('"'));
    }

    $.ajax({
            url: "https://www.instagram.com/api/v1/media/" + mediaId + "/info/",
            method: 'GET',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        })
        .done(function(r) {

            if (r && r.items && r.items[0]) {


                $.ajax({
                        url: "https://www.instagram.com/api/v1/media/" + mediaId + "/comments/?can_support_threading=true&permalink_enabled=false",
                        method: 'GET',
                        beforeSend: function(xhr) {
                            xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                            xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                            xhr.setRequestHeader('x-asbd-id', '129477');
                            xhr.setRequestHeader('x-ig-app-id', '936619743392459');
                        },
                        xhrFields: {
                            withCredentials: true
                        }
                    })
                    .done(function(c) {

                        r.items[0].comments = c.comments;

                        mediaToLike.push(r.items[0]);
                        arrayOfMediaToDiv(mediaToLike, true);
                        printMessage('Loaded media: ' + shorty);

                    });



            }

        }).fail(function(f) {
            if (f.status == 429) {
                printMessage(chrome.i18n.getMessage('RateLimit429', [(gblOptions.timeDelayAfter429RateLimit / 60000)]));
                timeoutsQueue.push(setTimeout(loadCurrentPostAsMedia, gblOptions.timeDelayAfter429RateLimit));
            }
        });


}



async function getUserInfoFromGraphQL(username) {

    return new Promise(async function(resolve, reject) {
        try {
        const fetch1 = await fetch("https://www.instagram.com/graphql/query", {
            "headers": {
                "accept": "*/*",
                "accept-language": "en-US,en;q=0.9",
                "content-type": "application/x-www-form-urlencoded",
                "priority": "u=1, i",
                "sec-ch-prefers-color-scheme": "dark",
                "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\", \"Google Chrome\";v=\"132\"",
                "sec-ch-ua-full-version-list": "\"Not A(Brand\";v=\"8.0.0.0\", \"Chromium\";v=\"132.0.6834.159\", \"Google Chrome\";v=\"132.0.6834.159\"",
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-model": "\"\"",
                "sec-ch-ua-platform": "\"Linux\"",
                "sec-ch-ua-platform-version": "\"6.9.3\"",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
                "x-asbd-id": "359341",
                "x-bloks-version-id": "23752fb6fb4723f14bd2bdee662385d5f3ba28ce6d8f947ffffcf2a3d65d68d9",
                "x-csrftoken": "IKL8mnfOjDdCP68pjN3ri0mGwjMLu7oX",
                "x-fb-friendly-name": "PolarisProfilePostsQuery",
                "x-fb-lsd": "4siT1eZbAd-QxQohn6AUsd",
                "x-ig-app-id": "936619743392459"
            },
            "referrer": "https://www.instagram.com/" + username + "/",
            "referrerPolicy": "strict-origin-when-cross-origin",
            "body": "av=17841461843508115&__d=www&__user=0&__a=1&__req=8&__hs=20159.HYP%3Ainstagram_web_pkg.2.1...1&dpr=1&__ccg=EXCELLENT&__rev=1020831374&__s=sblxde%3Agvogj7%3A6ksx3t&__hsi=7481052854246233508&__dyn=7xe5WwlEnwn8K2Wmm1twpUnwgU7S6EeUaUco38w5ux609vCwjE1EE2Cw8G11wBw5Zx62G3i1ywOwa90Fw4Hw9O0Lbwae4UaEW2G0AEco5G0zEnwhE3Mw5NyES1Twoob82ZwrUdUbGw4mwr86C1mwrd6goK10xKi2K7E5y4UrwHwcObBxm&__csr=g_3cL2JihsigvTiui8F5JRQrHQCJrjLV8yquiGyk-KVuQiii_wHxox5rHGEWmBzrJd2ECi9gKErBGV8CVoO5-5oW699VpU6uq6bBCyUlzEdovAUdmWxa5oaU9U5R004KuwiU0NkwK0OU22w8O24kp2pE0A1wc-04i80kdw8il2Fo4LgN01gK1Dg2jcEgw48x6GiAhE22w3LQ01B_w1hW&__hsdp=&__hblp=&__comet_req=7&fb_dtsg=NAcPCmP-EEq_Rbc89EVRSm4BOrircFgwFKNR9tas_4ZL5FHDS4_QMcQ%3A17843708194158284%3A1741815227&jazoest=26075&lsd=4siT1eZbAd-QxQohn6AUsd&__spin_r=1020831374&__spin_b=trunk&__spin_t=1741818351&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=PolarisProfilePostsQuery&variables=%7B%22data%22%3A%7B%22count%22%3A12%2C%22include_reel_media_seen_timestamp%22%3Atrue%2C%22include_relationship_info%22%3Atrue%2C%22latest_besties_reel_media%22%3Atrue%2C%22latest_reel_media%22%3Atrue%7D%2C%22username%22%3A%22" + username + "%22%2C%22__relay_internal__pv__PolarisIsLoggedInrelayprovider%22%3Atrue%2C%22__relay_internal__pv__PolarisShareSheetV3relayprovider%22%3Atrue%7D&server_timestamps=true&doc_id=9507655305965624",
            "method": "POST",
            "mode": "cors",
            "credentials": "include"
        });

        if (!fetch1 || !fetch1.ok) {
            resolve(false);
            return;
        }
        const fetch1Text = await fetch1.text();
        if (!fetch1Text || fetch1Text[0] === '<') {
            resolve(false);
            return;
        }
        const jsondata1 = JSON.parse(fetch1Text);

        const userid = jsondata1.data.xdt_api__v1__feed__user_timeline_graphql_connection.edges[0].node.owner.pk;



        const fetched = await fetch("https://www.instagram.com/graphql/query", {
            "headers": {
                "accept": "*/*",
                "accept-language": "en-US,en;q=0.9",
                "content-type": "application/x-www-form-urlencoded",
                "priority": "u=1, i",
                "sec-ch-prefers-color-scheme": "dark",
                "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\", \"Google Chrome\";v=\"132\"",
                "sec-ch-ua-full-version-list": "\"Not A(Brand\";v=\"8.0.0.0\", \"Chromium\";v=\"132.0.6834.159\", \"Google Chrome\";v=\"132.0.6834.159\"",
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-model": "\"\"",
                "sec-ch-ua-platform": "\"Linux\"",
                "sec-ch-ua-platform-version": "\"6.9.3\"",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
                "x-asbd-id": "359341",
                "x-bloks-version-id": "23752fb6fb4723f14bd2bdee662385d5f3ba28ce6d8f947ffffcf2a3d65d68d9",
                "x-csrftoken": "IKL8mnfOjDdCP68pjN3ri0mGwjMLu7oX",
                "x-fb-friendly-name": "PolarisProfilePageContentQuery",
                "x-fb-lsd": "4siT1eZbAd-QxQohn6AUsd",
                "x-ig-app-id": "936619743392459"
            },
            "referrer": "https://www.instagram.com/" + username + "/",
            "referrerPolicy": "strict-origin-when-cross-origin",
            "body": "av=17841461843508115&__d=www&__user=0&__a=1&__req=4&__hs=20159.HYP%3Ainstagram_web_pkg.2.1...1&dpr=1&__ccg=EXCELLENT&__rev=1020831374&__s=sblxde%3Agvogj7%3A6ksx3t&__hsi=7481052854246233508&__dyn=7xe5WwlEnwn8K2Wmm1twpUnwgU7S6EeUaUco38w5ux609vCwjE1EE2Cw8G11wBw5Zx62G3i1ywOwa90Fw4Hw9O0Lbwae4UaEW2G0AEco5G0zEnwhE3Mw5NyES1Twoob82ZwrUdUbGw4mwr86C1mwrd6goK10xKi2K7E5y4UrwHwcObBxm&__csr=g_3cL2JihsigvTiui8F5JRQrHQCJrjLV8yquiGyk-KVuQiii_wHxox5rHGEWmBzrJd2ECi9gKErBGV8CVoO5-5oW699VpU6uq6bBCyUlzEdovAUdmWxa5oaU9U5R004KuwiU0NkwK0OU22w8O24kp2pE0A1wc-04i80kdw8il2Fo4LgN01gK1Dg2jcEgw48x6GiAhE22w3LQ01B_w1hW&__hsdp=&__hblp=&__comet_req=7&fb_dtsg=NAcPCmP-EEq_Rbc89EVRSm4BOrircFgwFKNR9tas_4ZL5FHDS4_QMcQ%3A17843708194158284%3A1741815227&jazoest=26075&lsd=4siT1eZbAd-QxQohn6AUsd&__spin_r=1020831374&__spin_b=trunk&__spin_t=1741818351&fb_api_caller_class=RelayModern&fb_api_req_friendly_name=PolarisProfilePageContentQuery&variables=%7B%22id%22%3A%22" + userid + "%22%2C%22render_surface%22%3A%22PROFILE%22%7D&server_timestamps=true&doc_id=28812098038405011",
            "method": "POST",
            "mode": "cors",
            "credentials": "include"
        });

        if (!fetched || !fetched.ok) {
            resolve(false);
            return;
        }
        const fetchedText = await fetched.text();
        if (!fetchedText || fetchedText[0] === '<') {
            resolve(false);
            return;
        }
        const jsondata = JSON.parse(fetchedText);

        resolve(jsondata && jsondata.data ? jsondata.data.user : false);
        } catch (e) {
            resolve(false);
        }
    });
}



function ajaxGetCurrentPageUserInfo(urlprefix) {
    if (!urlprefix) {
        urlprefix = urlAcctInfo;
    }
    var username = rdgGetInstagramUsernameFromPage();
    if (!username) return;

    if (username.indexOf('Edit Profile') > -1) username = username.replace('Edit Profile', '').trim();

    if ((typeof currentProfilePage === 'undefined' || currentProfilePage == false && username != '') || (username != '' && currentProfilePage.username != username)) {
        currentProfilePage = { username: username };
        $.ajax({
            url: '' + urlprefix + username,
            method: 'GET',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        }).fail(async function(err) {
            try {
                var gqlData = await getUserInfoFromGraphQL(username);
                if (gqlData && gqlData !== false) {
                    currentProfilePage = gqlData;
                }
            } catch(eGql) {}
            setCurrentPageUsername();
            startUserNameFreshnessInterval();
            outputMessage('Perfil Logado: ' + username);
        }).done(function(data) {
            var extracted = extractJSONfromUserPageHTML(data);
            if (extracted !== false && extracted) {
                currentProfilePage = extracted;
            }
            setCurrentPageUsername();
            startUserNameFreshnessInterval();
            outputMessage('Perfil Logado: ' + username);
        });
    }
}

function getUsernameFromPostHtml() {
    return $('header._aaqw a.x1i10hfl:first').text();
}

function extractJSONfromUserPageHTML(data) {
    try {
        var pureJSON = data && data.data;
        if (pureJSON && pureJSON.user) {
            return pureJSON.user;
        }

        if (data && data.user) {
            return data.user;
        }

        if (typeof data !== 'string' || !data) {
            return false;
        }

        // HTML Regex Fallback for Instagram 2026 JSON payload
        var idMatch = data.match(/"user_id":"(\d+)"/) || data.match(/"target_id":"(\d+)"/) || data.match(/"profile_id":"(\d+)"/) || data.match(/"owner":\{"id":"(\d+)"/);
        var userMatch = data.match(/"username":"([a-zA-Z0-9_.]+)"/);
        if (idMatch && idMatch[1] && userMatch && userMatch[1]) {
            var followerMatch = data.match(/"edge_followed_by":\{"count":(\d+)\}/) || data.match(/"follower_count":(\d+)/);
            var followingMatch = data.match(/"edge_follow":\{"count":(\d+)\}/) || data.match(/"following_count":(\d+)/);
            return {
                id: idMatch[1],
                pk: idMatch[1],
                username: userMatch[1],
                edge_followed_by: { count: followerMatch ? parseInt(followerMatch[1], 10) : 0 },
                edge_follow: { count: followingMatch ? parseInt(followingMatch[1], 10) : 0 }
            };
        }

        if (data.indexOf('<script type="text/javascript">window._sharedData = ') > -1) {
            var sharedStart = data.indexOf('<script type="text/javascript">window._sharedData = ') + 52;
            var sharedEnd = data.indexOf(';</script>', sharedStart);
            if (sharedStart > 51 && sharedEnd > sharedStart) {
                var sharedData = JSON.parse(data.substring(sharedStart, sharedEnd));
                if (sharedData && sharedData.entry_data && sharedData.entry_data.ProfilePage && sharedData.entry_data.ProfilePage.length > 0 && sharedData.entry_data.ProfilePage[0].graphql && sharedData.entry_data.ProfilePage[0].graphql.user) {
                    return sharedData.entry_data.ProfilePage[0].graphql.user;
                }
            }
        }
    } catch (e) {}
    return false;
}


function setCurrentPageHashtag() {
    var hashtagFromUrl = getHashtagFromUrl();

    if (hashtagFromUrl != '') {

        $('#igBotInjectedContainer #btnLikeHashtag')
            .removeClass('inactive')
            .off('click.hashtagButtonError')
            .off('click.ajaxLoadPostsFromHashtag')
            .on('click.ajaxLoadPostsFromHashtag', ajaxLoadPostsFromHashtag)
            .text('Load Posts from #' + hashtagFromUrl);

    } else {


        $('#igBotInjectedContainer #btnLikeHashtag')
            .addClass('inactive')
            .off('click.ajaxLoadPostsFromHashtag')
            .off('click.hashtagButtonError')
            .on('click.hashtagButtonError', function() {
                outputMessage('Error: must be on an instagram hashtag page');
            });
    }
}



function setCurrentPageLocation() {
    var locationFromUrl = getLocationFromUrl();

    if (locationFromUrl != '') {

        $('#igBotInjectedContainer #btnLoadLocationPosts')
            .removeClass('inactive')
            .off('click.locationButtonError')
            .off('click.ajaxLoadPostsFromLocation')
            .on('click.ajaxLoadPostsFromLocation', ajaxLoadPostsFromLocation);


    } else {

        $('#igBotInjectedContainer #btnLoadLocationPosts')
            .addClass('inactive')
            .off('click.ajaxLoadPostsFromLocation')
            .off('click.locationButtonError')
            .on('click.locationButtonError', function() {
                outputMessage('Error: must be on an instagram location page');
            });
    }
}

function getHashtagFromUrl() {

    if ((window.location.href.indexOf('/explore/tags/') == -1) && (window.location.href.indexOf('/explore/search/keyword/?q=%23') == -1)) {
        return '';
    }

    var tagFromUrl = window.location.href;

    if (tagFromUrl.indexOf('/explore/tags/') > -1) {
        tagFromUrl = tagFromUrl.replace('https://www.instagram.com/explore/tags/', '');
        tagFromUrl = tagFromUrl.slice(0, tagFromUrl.indexOf('/'));
    }

    if (tagFromUrl.indexOf('/explore/search/keyword/?q=%23') > -1) {
        tagFromUrl = tagFromUrl.replace('https://www.instagram.com/explore/search/keyword/?q=%23', '');
    }

    tagFromUrl = decodeURIComponent(tagFromUrl);

    return tagFromUrl;
}


function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function saveHiddenStatus(hiddenStatus) {
    chrome.storage.sync.set({
        'igBotHidden': hiddenStatus
    });
}

function getHiddenStatus(callback) {

    chrome.storage.sync.get('igBotHidden', function(object) {

        var hiddenStatus = false;

        if (typeof object['igBotHidden'] != 'undefined') {
            hiddenStatus = object['igBotHidden'];
        } else {
            hiddenStatus = false;
        }

        callback(hiddenStatus);

    });

}

function hiddenStatusCallback(hiddenStatus) {
    if (hiddenStatus == true) {
        hideControlsDiv();
    } else {
        openControlsDiv();
    }
}


$.fn.shake = function shake(interval, distance, times) {
    interval = interval || 100;
    distance = distance || 10;
    times = times || 4;

    for (var iter = 0; iter < (times + 1); iter++) {
        //this.animate({ left: ((iter%2==0 ? distance : distance*-1))}, interval);
        this.animate({
            top: ((iter % 2 == 0 ? distance : distance * -1))
        }, interval);
        this.animate({
            top: ''
        }, interval);
    }
}

function userUpdateListener() {
    chrome.runtime.onMessage.addListener(
        function(request, sender, sendResponse) {

            if (request.clickSomething) {
                // TO DO, keep selectors here instead of sending "parent" request from backgroundscript
                if (request.clickViewStory) {

                    var tabId = request.tabId;

                    var intervalCloseWhenDone = setInterval(function() {

                        var currentUrl = window.location.href;

                        if (currentUrl.indexOf('/stories/') == -1) {
                            clearInterval(intervalCloseWhenDone);

                            chrome.runtime.sendMessage({
                                "closeStoryTab": {
                                    "tabId": tabId
                                }
                            });
                        }
                    }, 250);

                    var intervalClickViewStory = setInterval(function() {
                        var currentUrl = window.location.href;
                        var matchingElement = $('div[role="button"]:not(:has(svg))');

                        if (currentUrl.indexOf('/stories/') > -1 && matchingElement.length > 0) {
                            clearInterval(intervalClickViewStory);
                            matchingElement.click();

                            chrome.runtime.sendMessage({
                                "viewedStory": true
                            });
                            console.log('clicked view story');
                        }
                    }, 250);

                } else if (request.parent) {
                    $(request.clickSomething).parents(request.parent).click();
                    console.log('clicked  ' + request.clickSomething + ' parent');
                } else {
                    $(request.clickSomething).click();
                    console.log('clicked  ' + request.clickSomething);
                }

                return true;
            }

            if (request.closedStory) {
                closedStoryTab(request);
            }

            if (request.instabot_has_license) {
                instabot_has_license = request.instabot_has_license;

                if (request.igBotUser) {
                    localStorage['gbUserGuid'] = request.igBotUser.user_guid;
                    localStorage['gbFTover'] = false;

                    // ('set localStorage to licensed guid (has a license');
                }
            }

            if (request.instabot_install_date || request.instabot_free_trial_time) {
                instabot_install_date = request.instabot_install_date;
                instabot_free_trial_time = request.instabot_free_trial_time;
                clearInterval(freeTrialInterval);
                freeTrialInterval = setInterval(displayFreeTrialTimeLeft, 500);
            }

            if (request.igBotUser) {
                var guidStorage = request.igBotUser.user_guid;
                var ftOver = localStorage['gbFTover'];

                if (guidCookie) {
                    if (guidCookie !== guidStorage) {
                        chrome.runtime.sendMessage({
                            "guidCookie": guidCookie,
                            "ftOver": ftOver
                        });
                    }
                }

                if (ftOver == true && $('#iframePurchase').length == 0) {
                    $('#h2FreeTrialTimeLeft').hide();

                    chrome.extension.sendMessage({
                        "ftOver": ftOver
                    });
                }

                if (window.location.href.indexOf('rdgforfollowers.com') > -1 && window.location.href.indexOf('update_payment_info=true') > -1 && window.location.href.indexOf('guid') == -1) {
                    window.location.href = window.location.href + '&buyscreen=true&guid=' + guidStorage;
                }

            }

            if (request.openBuyScreen == true && request.igBotUser) {

                if (request.igBotUser.user_guid) {
                    var guid = request.igBotUser.user_guid;
                } else {
                    var guid = JSON.parse(request.igBotUser).user_guid;
                }

                // must make it so this is not set when clicking the subscribe now link
                localStorage['gbFTover'] = true;


                if (localStorage['gbUserGuid']) {
                    localStorage['gbUserGuid'] = guid;
                    //.log('set localStorage to guid (opening buy screen');
                }

                $('#iframePurchase').remove();
                $('#igBotMediaQueueContainer').hide();
                $('#igBotQueueContainer').hide().before('<iframe id="iframePurchase" src="https://www.rdgforfollowers.com/?buyscreen=true&guid=' + guid + '"></iframe><div style="text-align:center; margin: 10px;">If there is an error above, please <a target="_blank" class="purchaseTextLink" href="https://www.rdgforfollowers.com/?buyscreen=true&guid=' + guid + '">click here to Subscribe</a> or <a href="javascript:void(0);" id="aRelinkSubscription" class="purchaseTextLink">Re-Link your Subscription</a>.</div>');
                $('#aRelinkSubscription').off('click.showRelink').on('click.showRelink', showRelink);
                $('.igBotInjectedButton').off('click').addClass('disabled');
                $('li.tab1 label').click();
            }

            if (request.toggleRdg == true) {
                toggleControlsDiv();
            }

            if (request.openRdg == true) {
                openControlsDiv();
            }

            if (request.hideRdg == true) {
                hideControlsDiv(false); // don't save the hidden status
            }

            sendResponse({
                response: 'beep beep'
            });
        }
    );
}


function getObjectWithKey(theObject, theKey) {
    var result = null;
    if (theObject instanceof Array) {
        for (var i = 0; i < theObject.length; i++) {
            result = getObjectWithKey(theObject[i], theKey);
            if (result) {
                break;
            }
        }
    } else {
        for (var prop in theObject) {
            if (prop == theKey) {
                //if(theObject[prop] == 1) {
                return theObject;
                // }
            }
            if (theObject[prop] instanceof Object || theObject[prop] instanceof Array) {
                result = getObjectWithKey(theObject[prop], theKey);
                if (result) {
                    break;
                }
            }
        }
    }
    return result;
}

function getObjectWithKeyAndValue(theObject, theKey, theValue) {
    var result = null;
    if (theObject instanceof Array) {
        for (var i = 0; i < theObject.length; i++) {
            result = getObjectWithKeyAndValue(theObject[i], theKey, theValue);
            if (result) {
                break;
            }
        }
    } else {
        for (var prop in theObject) {
            if (prop == theKey) {
                if (theObject[prop] == theValue) {

                    return theObject;
                }
            }
            if (theObject[prop] instanceof Object || theObject[prop] instanceof Array) {
                result = getObjectWithKeyAndValue(theObject[prop], theKey, theValue);
                if (result) {
                    break;
                }
            }
        }
    }
    return result;
}

function extractUserInfoFromScriptTags() {
    var scriptTags = document.getElementsByTagName('script');
    for (var i = 0; i < scriptTags.length; i++) {
        if (scriptTags[i].innerHTML.indexOf('"username":"') > -1) {
            var foundObject = getObjectWithKeyAndValue(JSON.parse(scriptTags[i].innerHTML), 'id', getCookie('ds_user_id'));
            if (foundObject && foundObject.username) {
                user = {
                    "csrf_token": getCookie('csrftoken'),
                    "viewer": foundObject,
                    "viewerId": foundObject.id
                }
                return true;
            }
        }
    }

    return false;
}


function getBackgroundInfo() {
    if (user && user.viewer && user.viewer.username != null) {
        // don't need to do anything
    } else {
        if (extractUserInfoFromScriptTags() === false) {
            //outputMessage('Error loading your account.  You may be temporarily blocked by Instagram, or not loggedin in.  You can try refreshing the page.  If that does not work, please take a break from using RDG for at least 48 hours.');
            return false;
        }
    }

    $.ajax({
            url: '' + urlAcctInfo + user.viewer.username,
            method: 'GET',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-Csrftoken', getCsrfFromCookie());
                xhr.setRequestHeader('x-instagram-ajax', '1010212815');
                xhr.setRequestHeader('x-asbd-id', '129477');
                xhr.setRequestHeader('x-ig-app-id', '936619743392459');
            },
            xhrFields: {
                withCredentials: true
            }
        })
        .done(function(r) {
            var u = extractJSONfromUserPageHTML(r);

            if (!u.edge_followed_by) {
                outputMessage('Erro ao carregar sua conta. Você pode estar temporariamente Limitado pelo Instagram. Tente atualizar a página. Se isso não funcionar, interrompa o uso do RDG por pelo menos 48 horas.');
                return false;
            } else {
                outputMessage('Perfil do instagram: ' + u.username);
                var statusDiv = document.getElementById('igBotStatusDiv');
                statusDiv.innerHTML = statusDiv.innerHTML.replace(u.username, '<a href="https://www.instagram.com/' + u.username + '/">' + u.username + '</a>');
            }

            chrome.runtime.sendMessage({
                "updatewanted": true,
                "ig_user": user.viewer,
                "ig_user_account_stats": {
                    "date": new Date().toUTCString(),
                    "followers": u.edge_followed_by.count,
                    "following": u.edge_follow.count,
                    "posts": u.edge_owner_to_timeline_media.count
                }
            });
        })
        .fail(function(data) {
            chrome.runtime.sendMessage({
                "updatewanted": true,
                "ig_user": user.viewer,
                "ig_user_account_stats": {}
            });
        });


}

function dialog(messages, yesCallback, noCallback) {

    $('#igBotDialogQuestion').html(messages.question);

    $('#btnDialogOK').text(messages.yes).off('click.dialogyes').on('click.dialogyes', function() {
        yesCallback();
        document.getElementById('igBotDialog').style.display = 'none'
    });
    $('#btnDialogCancel').text(messages.no).off('click.dialogcancel').on('click.dialogcancel', function() {
        noCallback();
        document.getElementById('igBotDialog').style.display = 'none'
    });

    document.getElementById('igBotDialog').style.display = 'block'
}

(function(global, factory) {
    if (typeof define === "function" && define.amd) {
        define([], factory);
    } else if (typeof exports !== "undefined") {
        factory();
    } else {
        var mod = {
            exports: {}
        };
        factory();
        global.FileSaver = mod.exports;
    }
})(this, function() {
    "use strict";

    /*
     * FileSaver.js
     * A saveAs() FileSaver implementation.
     *
     * By Eli Grey, http://eligrey.com
     *
     * License : https://github.com/eligrey/FileSaver.js/blob/master/LICENSE.md (MIT)
     * source  : http://purl.eligrey.com/github/FileSaver.js
     */
    // The one and only way of getting global scope in all environments
    // https://stackoverflow.com/q/3277182/1008999
    var _global = typeof window === 'object' && window.window === window ? window : typeof self === 'object' && self.self === self ? self : typeof global === 'object' && global.global === global ? global : void 0;

    function bom(blob, opts) {
        if (typeof opts === 'undefined') opts = {
            autoBom: false
        };
        else if (typeof opts !== 'object') {
            console.warn('Depricated: Expected third argument to be a object');
            opts = {
                autoBom: !opts
            };
        } // prepend BOM for UTF-8 XML and text/* types (including HTML)
        // note: your browser will automatically convert UTF-16 U+FEFF to EF BB BF

        if (opts.autoBom && (/^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i).test(blob.type)) {
            return new Blob([String.fromCharCode(0xFEFF), blob], {
                type: blob.type
            });
        }

        return blob;
    }

    function download(url, name, opts) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url);
        xhr.responseType = 'blob';

        xhr.onload = function() {
            saveAs(xhr.response, name, opts);
        };

        xhr.onerror = function() {
            console.error('could not download file');
        };

        xhr.send();
    }

    function corsEnabled(url) {
        var xhr = new XMLHttpRequest(); // use sync to avoid popup blocker

        xhr.open('HEAD', url, false);
        xhr.send();
        return xhr.status >= 200 && xhr.status <= 299;
    } // `a.click()` doesn't work for all browsers (#465)


    function click(node) {
        try {
            node.dispatchEvent(new MouseEvent('click'));
        } catch (e) {
            var evt = document.createEvent('MouseEvents');
            evt.initMouseEvent('click', true, true, window, 0, 0, 0, 80, 20, false, false, false, false, 0, null);
            node.dispatchEvent(evt);
        }
    }

    var saveAs = _global.saveAs || ( // probably in some web worker
        typeof window !== 'object' || window !== _global ? function saveAs() {}
        /* noop */
        // Use download attribute first if possible (#193 Lumia mobile)
        :
        'download' in HTMLAnchorElement.prototype ? function saveAs(blob, name, opts) {
            var URL = _global.URL || _global.webkitURL;
            var a = document.createElement('a');
            name = name || blob.name || 'download';
            a.download = name;
            a.rel = 'noopener'; // tabnabbing
            // detect chrome extensions & packaged apps
            // a.target = '_blank'

            if (typeof blob === 'string') {
                // Support regular links
                a.href = blob;

                if (a.origin !== location.origin) {
                    corsEnabled(a.href) ? download(blob, name, opts) : click(a, a.target = '_blank');
                } else {
                    click(a);
                }
            } else {
                // Support blobs
                a.href = URL.createObjectURL(blob);
                setTimeout(function() {
                    URL.revokeObjectURL(a.href);
                }, 4E4); // 40s

                setTimeout(function() {
                    click(a);
                }, 0);
            }
        } // Use msSaveOrOpenBlob as a second approach
        :
        'msSaveOrOpenBlob' in navigator ? function saveAs(blob, name, opts) {
            name = name || blob.name || 'download';

            if (typeof blob === 'string') {
                if (corsEnabled(blob)) {
                    download(blob, name, opts);
                } else {
                    var a = document.createElement('a');
                    a.href = blob;
                    a.target = '_blank';
                    setTimeout(function() {
                        click(a);
                    });
                }
            } else {
                navigator.msSaveOrOpenBlob(bom(blob, opts), name);
            }
        } // Fallback to using FileReader and a popup
        :
        function saveAs(blob, name, opts, popup) {
            // Open a popup immediately do go around popup blocker
            // Mostly only avalible on user interaction and the fileReader is async so...
            popup = popup || open('', '_blank');

            if (popup) {
                popup.document.title = popup.document.body.innerText = 'downloading...';
            }

            if (typeof blob === 'string') return download(blob, name, opts);
            var force = blob.type === 'application/octet-stream';

            var isSafari = /constructor/i.test(_global.HTMLElement) || _global.safari;

            var isChromeIOS = /CriOS\/[\d]+/.test(navigator.userAgent);

            if ((isChromeIOS || force && isSafari) && typeof FileReader === 'object') {
                // Safari doesn't allow downloading of blob urls
                var reader = new FileReader();

                reader.onloadend = function() {
                    var url = reader.result;
                    url = isChromeIOS ? url : url.replace(/^data:[^;]*;/, 'data:attachment/file;');
                    if (popup) popup.location.href = url;
                    else location = url;
                    popup = null; // reverse-tabnabbing #460
                };

                reader.readAsDataURL(blob);
            } else {
                var URL = _global.URL || _global.webkitURL;
                var url = URL.createObjectURL(blob);
                if (popup) popup.location = url;
                else location.href = url;
                popup = null; // reverse-tabnabbing #460

                setTimeout(function() {
                    URL.revokeObjectURL(url);
                }, 4E4); // 40s
            }
        });
    _global.saveAs = saveAs.saveAs = saveAs;

    if (typeof module !== 'undefined') {
        module.exports = saveAs;
    }
});

function monitorButtonConditions() {
    var curUsername = getCurrentPageUsername();
    if (curUsername !== '' && (typeof window._lastSetUsername === 'undefined' || window._lastSetUsername !== curUsername)) {
        window._lastSetUsername = curUsername;
        setCurrentPageUsername();
    }

    if ($('#rdgStatQueue').length) {
        var qLen = (typeof acctsQueue !== 'undefined' && acctsQueue) ? acctsQueue.length : 0;
        var targetText = qLen > 0 ? qLen + ' na fila' : 'Pronta para Ação';
        var targetColor = qLen > 0 ? '#10b981' : '#f8fafc';
        
        if ($('#rdgStatQueue').text() !== targetText) {
            $('#rdgStatQueue').text(targetText).css('color', targetColor);
        }
    }

    if (acctsQueue.length > 0 || currentList == 'acctsWhiteList') {
        if ($('.needsQueueAccts').hasClass('inactive')) {
            $('.needsQueueAccts').removeClass('inactive');
        }

        if (currentList == 'acctsWhiteList') {
            $('#btnSaveQueueToStorage, #btnExportQueue').hide();
            if ($('#btnSaveWhiteList').css('display') !== 'flex') {
                $('#btnSaveWhiteList').css({'display': 'flex'});
            }
        } else {
            if ($('#btnSaveQueueToStorage').css('display') !== 'flex') {
                $('#btnSaveQueueToStorage, #btnExportQueue').css({'display': 'flex'});
            }
            $('#btnSaveWhiteList').hide();
        }

        if ($('#igBotQueueContainer input:checked').length > 0) {
            if ($('.needsSelectedAccts').hasClass('inactive')) {
                $('.needsSelectedAccts').removeClass('inactive');
            }
        } else {
            if (!$('.needsSelectedAccts').hasClass('inactive')) {
                $('.needsSelectedAccts').addClass('inactive');
            }
        }
    } else {
        $('#btnSaveQueueToStorage, #btnExportQueue').hide();
        if (!$('.needsQueueAccts').hasClass('inactive')) {
            $('.needsQueueAccts,.needsSelectedAccts').addClass('inactive');
        }
        $('#queueQuantityRow').hide();
    }

    if (mediaToLike.length > 0) {
        $('.needsMedia').removeClass('inactive');

        if ($('#igBotMediaQueueContainer input:checked').length > 0) {
            $('.needsSelectedMedia').removeClass('inactive');
        } else {
            $('.needsSelectedMedia').addClass('inactive');
        }
    } else {
        $('.needsMedia,.needsSelectedMedia').addClass('inactive');
    }


    if (window.location.href.indexOf("/p/") > -1 || window.location.href.indexOf("/reel/") > -1) {
        $('#btnLoadThisPost').removeClass('inactive');
    } else {
        $('#btnLoadThisPost').addClass('inactive');
    }


    if (timeoutsQueue.length > 0) {
        $('#btnStop,#igBotInjectedContainer #btnStop2').removeClass('inactive').show();
    } else {
        $('#btnStop,#igBotInjectedContainer #btnStop2').addClass('inactive').hide();
    }

    setCurrentPageHashtag();
    setCurrentPageLocation();

    clickNotNow();

    applyTooltips();

}

function showRelink() {
    $('li.tab4 label').click();
    $('#relinkSubscription').attr('open', 'open');
}

function startUserNameFreshnessInterval() {
    clearInterval(usernameCheckInterval);
    usernameCheckInterval = setInterval(function() {

        if ($('#instabotIcon').length == 0) {
            injectIcon();
            shakeInstabotIcon();
        }

        if ($('#igBotInjectedContainer .pulsing').length > 0) {
            $('#instabotIcon').addClass('pulsing');
        } else {
            $('#instabotIcon').removeClass('pulsing');
        }

        checkUsernameFreshness();
    }, 2000);
}

function clickNotNow(override) {
    if (gblOptions.clickNotNow == true || override) {
        var NotNow = $('button:contains("Not Now")');
        if (NotNow.length > 0) {
            outputMessage('Clicked "Not Now" on notifications question');
            NotNow.click();
        }

        NotNow = $('div[role="button"]:contains("Not now")');
        if (NotNow.length > 0) {
            outputMessage('Clicked "Not Now" on save account question');
            NotNow.click();
        }
    }
}

function relinkSubscription() {
    $.post('https://www.rdgforfollowers.com/find_subscription2.php', $('#formRelinkSubscription').serialize()).done(function(data) {
        if (data && data[0] && data[0].subscriptions && data[0].subscriptions.data && data[0].subscriptions.data.length > 0) {
            var guidFromServer = data[0].id;
            chrome.runtime.sendMessage({
                "guidCookie": guidFromServer
            }, function() {
                $('#resultFindSubscription').text('Subscription updated.  Please reload the page.');
            });
        } else {
            $('#resultFindSubscription').text('Não foi possível encontrar a assinatura. Por favor, contate suporte@rdgsolucoes.com.br para assistência.');
        }

    });
}


async function arrayOfUsersToDiv(q, clearDiv, skipAutoSave) {

    if (typeof clearDiv == 'undefined') clearDiv = true;

    if (skipAutoSave !== true && Array.isArray(q)) {
        chrome.storage.local.set({ acctsQueue: q });
    }
    if (Array.isArray(q) && currentList !== 'acctsWhiteList') {
        acctsQueue = q;
    }

    if (clearDiv === true) {
        $('#igBotQueueContainer').children().remove();
    } else {
        $('#igBotQueueContainer').children().not('.igBotQueueAcct').remove();
    }

    if (gblOptions.cbRemoveUnusedColumns == true) {
        for (var i = 0; i < q.length; i++) {
            q[i] = removeAccountPropertiesByColumnCheckboxes(q[i]);
        }
    }

    if (gblOptions.cbShowQueueOnScreen == false) {
        $('#igBotQueueContainer').append('<div style="text-align:center;">You have turned off "Show queue on screen" in Settings.  Your queue is loaded in the background.</div>');
        return false;
    }


    $('#igBotQueueContainer').append('<table id="gridjsAcctsQueueWrapper"></table>');



    var columns = gblOptions.queueColumns;
    columns = columns.filter(e => e.visible !== false);


    var sb = '<thead><tr>';

    for (var i = 0; i < columns.length; i++) {
        sb = sb + '<th data-prop="' + columns[i].data + '" style="width:' + (columns[i].width || '60px') + ';">' + columns[i].name + '</th>';
    }

    sb = sb + '</tr></thead><tbody></tbody>';
    $('#gridjsAcctsQueueWrapper').append(sb);



    var allRowsHtml = '';
    for (var i = 0; i < q.length; i++) {
        sb = '<tr>';
        for (var j = 0; j < columns.length; j++) {


            if (columns[j].width) {
                sb = sb + '<td column-data="' + columns[j].data + '" style="width:' + columns[j].width + ';">';
            } else {
                sb = sb + '<td column-data="' + columns[j].data + '">';
            }


            if (columns[j].data) {
                var props = columns[j].data.split('.');


                if (props[1] == 'count' && typeof q[i].edge_followed_by != 'object') {

                    if (q[i][columns[j].data]) {
                        sb = sb + q[i][columns[j].data] + '</td>';

                    } else {
                        sb = sb + '0</td>';

                    }


                } else if (props[1] && q[i].edge_followed_by) {
                    if (q[i][props[0]] && q[i][props[0]][props[1]]) {
                        sb = sb + q[i][props[0]][props[1]] + '</td>';
                    } else {
                        sb = sb + '-</td>';
                    }
                } else {

                    if (typeof q[i][props[0]] != 'undefined' && q[i][props[0]] !== null) {
                        if (columns[j].formatter) {
                            sb = sb + columns[j].formatter.replace(/\${ig_id}/g, q[i].id).replace(/\${cell}/g, q[i][columns[j].data]) + '</td>';
                        } else {

                            var dataString = q[i][props[0]];

                            if (columns[j].data == 'biography' && !q[i].languageCode) {

                                var langString = dataString;

                                if (q[i].edge_owner_to_timeline_media && q[i].edge_owner_to_timeline_media.edges && q[i].edge_owner_to_timeline_media.edges.length > 0) {
                                    for (var ci = 0; ci < q[i].edge_owner_to_timeline_media.edges.length; ci++) {

                                        if (q[i].edge_owner_to_timeline_media.edges[ci] && q[i].edge_owner_to_timeline_media.edges[ci].caption && q[i].edge_owner_to_timeline_media.edges[ci].caption.text) {
                                            langString = langString + ' ' + q[i].edge_owner_to_timeline_media.edges[ci].caption.text;
                                        }

                                    }
                                }


                                q[i] = await detectLanguage(langString, q[i]);
                            }

                            if (typeof dataString === 'number' && dataString.toString().indexOf('.') > -1) {
                                dataString = dataString.toFixed(3);
                            }

                            if (columns[j].data == 'username' && q[i].goldBadge) {
                                var badgeClass = q[i].goldScore >= 75 ? 'gold-badge-vip' : (q[i].goldScore >= 50 ? 'gold-badge-med' : 'gold-badge-low');
                                dataString += ' <span class="' + badgeClass + '" title="Score de Ouro RDG: ' + (q[i].goldScore || 0) + ' pts">' + q[i].goldBadge + ' (' + (q[i].goldScore || 0) + ' pts)</span>';
                            }
                            if (columns[j].data == 'username' && q[i].genderWarning) {
                                dataString += ' <span title="Gênero não identificado. Decida se mantém ou exclui da fila." style="font-size:16px; margin-left:5px; cursor:help;">⚠️</span>';
                                dataString += ' <span style="font-size:11px; color:#facc15; margin-left:3px; font-weight:600;">Gênero não identificado, decida se mantém ou exclui da fila</span>';
                            }

                            sb = sb + dataString + '</td>';
                        }
                    } else {
                        sb = sb + '-</td>';
                    }
                }


            }
        }
        sb = sb + '</tr>';
        allRowsHtml += sb;
    }
    $('#gridjsAcctsQueueWrapper tbody').append(allRowsHtml);



    $('#gridjsAcctsQueueWrapper').tablesorter({

        // *** APPEARANCE ***
        // Add a theme - 'blackice', 'blue', 'dark', 'default', 'dropbox',
        // 'green', 'grey' or 'ice' stylesheets have all been loaded
        // to use 'bootstrap' or 'jui', you'll need to include 'uitheme'
        // in the widgets option - To modify the class names, extend from
        // themes variable. Look for '$.extend($.tablesorter.themes.jui'
        // at the bottom of this window
        // this option only adds a table class name 'tablesorter-{theme}'
        theme: 'blue',

        // fix the column widths
        widthFixed: true,

        // Show an indeterminate timer icon in the header when the table
        // is sorted or filtered
        showProcessing: true,

        // header layout template (HTML ok); {content} = innerHTML,
        // {icon} = <i/> (class from cssIcon)
        headerTemplate: '{content}{icon}',

        // return the modified template string
        onRenderTemplate: null, // function(index, template){ return template; },

        // called after each header cell is rendered, use index to target the column
        // customize header HTML
        onRenderHeader: function(index) {
            // the span wrapper is added by default
            $(this).find('div.tablesorter-header-inner').addClass('roundedCorners');
        },

        // *** FUNCTIONALITY ***
        // prevent text selection in header
        cancelSelection: true,

        // add tabindex to header for keyboard accessibility
        tabIndex: true,

        // other options: 'ddmmyyyy' & 'yyyymmdd'
        dateFormat: 'yyyymmdd',

        // The key used to select more than one column for multi-column
        // sorting.
        sortMultiSortKey: 'shiftKey',

        // key used to remove sorting on a column
        sortResetKey: 'ctrlKey',

        // false for German '1.234.567,89' or French '1 234 567,89'
        usNumberFormat: true,

        // If true, parsing of all table cell data will be delayed
        // until the user initializes a sort
        delayInit: false,

        // if true, server-side sorting should be performed because
        // client-side sorting will be disabled, but the ui and events
        // will still be used.
        serverSideSorting: false,

        // default setting to trigger a resort after an 'update',
        // 'addRows', 'updateCell', etc has completed
        resort: true,

        // *** SORT OPTIONS ***
        // These are detected by default,
        // but you can change or disable them
        // these can also be set using data-attributes or class names
        headers: {
            // set 'sorter : false' (no quotes) to disable the column
            0: {
                sorter: 'text'
            },
            1: {
                sorter: false
            },
        },

        // ignore case while sorting
        ignoreCase: true,

        // forces the user to have this/these column(s) sorted first
        sortForce: null,
        // initial sort order of the columns, example sortList: [[0,0],[1,0]],
        // [[columnIndex, sortDirection], ... ]
        // sortList: [
        //     [0, 0],
        //     [1, 0],
        //     [2, 0]
        // ],
        sortList: [],
        // default sort that is added to the end of the users sort
        // selection.
        sortAppend: null,

        // when sorting two rows with exactly the same content,
        // the original sort order is maintained
        sortStable: false,

        // starting sort direction 'asc' or 'desc'
        sortInitialOrder: 'asc',

        // Replace equivalent character (accented characters) to allow
        // for alphanumeric sorting
        sortLocaleCompare: false,

        // third click on the header will reset column to default - unsorted
        sortReset: true,

        // restart sort to 'sortInitialOrder' when clicking on previously
        // unsorted columns
        sortRestart: false,

        // sort empty cell to bottom, top, none, zero, emptyMax, emptyMin
        emptyTo: 'bottom',

        // sort strings in numerical column as max, min, top, bottom, zero
        stringTo: 'zero',

        // extract text from the table
        textExtraction: {
            0: function(node, table) {
                // this is how it is done by default
                return $(node).attr(table.config.textAttribute) ||
                    node.textContent ||
                    node.innerText ||
                    $(node).text() ||
                    '';
            },
            1: function(node) {
                return $(node).text();
            }
        },

        // data-attribute that contains alternate cell text
        // (used in default textExtraction function)
        textAttribute: 'data-text',

        // use custom text sorter
        // function(a,b){ return a.sort(b); } // basic sort
        textSorter: null,

        // choose overall numeric sorter
        // function(a, b, direction, maxColumnValue)
        numberSorter: null,

        // *** WIDGETS ***
        // apply widgets on tablesorter initialization
        initWidgets: true,

        // table class name template to match to include a widget
        widgetClass: 'widget-{name}',

        // include zebra and any other widgets, options:
        // 'columns', 'filter', 'stickyHeaders' & 'resizable'
        // 'uitheme' is another widget, but requires loading
        // a different skin and a jQuery UI theme.
        widgets: ['pager', 'stickyHeaders', 'storage', 'zebra', 'columns', 'filter'],

        widgetOptions: {

            // zebra widget: adding zebra striping, using content and
            // default styles - the ui css removes the background
            // from default even and odd class names included for this
            // demo to allow switching themes
            // [ 'even', 'odd' ]
            zebra: [
                'ui-widget-content even',
                'ui-state-default odd'
            ],

            // columns widget: change the default column class names
            // primary is the 1st column sorted, secondary is the 2nd, etc
            columns: [
                'primary',
                'secondary',
                'tertiary'
            ],

            // columns widget: If true, the class names from the columns
            // option will also be added to the table tfoot.
            columns_tfoot: true,

            // columns widget: If true, the class names from the columns
            // option will also be added to the table thead.
            columns_thead: true,

            // filter widget: If there are child rows in the table (rows with
            // class name from 'cssChildRow' option) and this option is true
            // and a match is found anywhere in the child row, then it will make
            // that row visible; default is false
            filter_childRows: false,

            // filter widget: If true, a filter will be added to the top of
            // each table column.
            filter_columnFilters: true,

            // filter widget: css class name added to the filter cell
            // (string or array)
            filter_cellFilter: '',

            // filter widget: css class name added to the filter row & each
            // input in the row (tablesorter-filter is ALWAYS added)
            filter_cssFilter: '',

            // filter widget: add a default column filter type
            // '~{query}' to make fuzzy searches default;
            // '{q1} AND {q2}' to make all searches use a logical AND.
            filter_defaultFilter: {},

            // filter widget: filters to exclude, per column
            filter_excludeFilter: {},

            // filter widget: jQuery selector string (or jQuery object)
            // of external filters
            filter_external: '',

            // filter widget: class added to filtered rows;
            // needed by pager plugin
            filter_filteredRow: 'filtered',

            // filter widget: add custom filter elements to the filter row
            filter_formatter: null,

            // filter widget: Customize the filter widget by adding a select
            // dropdown with content, custom options or custom filter functions
            // see http://goo.gl/HQQLW for more details
            filter_functions: null,

            // filter widget: hide filter row when table is empty
            filter_hideEmpty: true,

            // filter widget: Set this option to true to hide the filter row
            // initially. The rows is revealed by hovering over the filter
            // row or giving any filter input/select focus.
            filter_hideFilters: false,

            // filter widget: Set this option to false to keep the searches
            // case sensitive
            filter_ignoreCase: true,

            // filter widget: if true, search column content while the user
            // types (with a delay)
            filter_liveSearch: true,

            // filter widget: a header with a select dropdown & this class name
            // will only show available (visible) options within the drop down
            filter_onlyAvail: 'filter-onlyAvail',

            // filter widget: default placeholder text
            // (overridden by any header 'data-placeholder' setting)
            filter_placeholder: {
                search: '',
                select: ''
            },

            // filter widget: jQuery selector string of an element used to
            // reset the filters.
            filter_reset: null,

            // filter widget: Use the $.tablesorter.storage utility to save
            // the most recent filters
            filter_saveFilters: false,

            // filter widget: Delay in milliseconds before the filter widget
            // starts searching; This option prevents searching for every character
            // while typing and should make searching large tables faster.
            filter_searchDelay: 300,

            // filter widget: allow searching through already filtered rows in
            // special circumstances; will speed up searching in large tables if true
            filter_searchFiltered: true,

            // filter widget: include a function to return an array of values to be
            // added to the column filter select
            filter_selectSource: null,

            // filter widget: Set this option to true if filtering is performed on
            // the server-side.
            filter_serversideFiltering: false,

            // filter widget: Set this option to true to use the filter to find
            // text from the start of the column. So typing in 'a' will find
            // 'albert' but not 'frank', both have a's; default is false
            filter_startsWith: false,

            // filter widget: If true, ALL filter searches will only use parsed
            // data. To only use parsed data in specific columns, set this option
            // to false and add class name 'filter-parsed' to the header
            filter_useParsedData: false,

            // filter widget: data attribute in the header cell that contains
            // the default filter value
            filter_defaultAttrib: 'data-value',

            // filter widget: filter_selectSource array text left of the separator
            // is added to the option value, right into the option text
            filter_selectSourceSeparator: '|',

            // starting page of the pager (zero based index)
            pager_startPage: 0,

            // Number of visible rows - default is 10
            pager_size: gblOptions.paginationLimit,

            // reset pager after filtering; set to desired page #
            // set to false to not change page at filter start
            pager_pageReset: 0,

            // output string - default is '{page}/{totalPages}';
            // possible variables:
            // {page}, {totalPages}, {startRow}, {endRow} and {totalRows}
            // pager_output: '{startRow} to {endRow} ({totalRows})',
            pager_output: '{startRow} - {endRow} / {filteredRows} ({totalRows})',

            // apply disabled classname to the pager arrows when the rows at
            // either extreme is visible - default is true
            pager_updateArrows: true,

            // Number of options to include in the pager number selector
            pager_maxOptionSize: 20,

            // Save pager page & size if the storage script is loaded
            // (requires $.tablesorter.storage in jquery.tablesorter.widgets.js)
            pager_savePages: true,

            // defines custom storage key
            pager_storageKey: 'tablesorter-pager',

            // if true, the table will remain the same height no matter how many
            // records are displayed. The space is made up by an empty
            // table row set to a height to compensate; default is false
            pager_fixedHeight: false,

            // count child rows towards the set page size?
            // (set true if it is a visible table row within the pager)
            // if true, child row(s) may not appear to be attached to its
            // parent row, may be split across pages or
            // may distort the table if rowspan or cellspans are included.
            pager_countChildRows: false,

            // remove rows from the table to speed up the sort of large tables.
            // setting this to false, only hides the non-visible rows; needed
            // if you plan to add/remove rows with the pager enabled.
            pager_removeRows: false,

            // css class names used by pager elements
            pager_css: {
                // class added to pager container
                container: 'tablesorter-pager',
                // error information row (don't include period at beginning)
                errorRow: 'tablesorter-errorRow',
                // class added to arrows @ extremes
                // (i.e. prev/first arrows "disabled" on first page)
                disabled: 'disabled'
            },

            // jQuery selectors
            pager_selectors: {
                // target the pager markup
                container: '.pager',
                // go to first page arrow
                first: '.first',
                // previous page arrow
                prev: '.prev',
                // next page arrow
                next: '.next',
                // go to last page arrow
                last: '.last',
                // go to page selector - select dropdown that sets the current page
                gotoPage: '.gotoPage',
                // location of where the "output" is displayed
                pageDisplay: '.pagedisplay',
                // page size selector - select dropdown that sets the "size" option
                pageSize: '.pagesize'
            },

            // Resizable widget: If this option is set to false, resized column
            // widths will not be saved. Previous saved values will be restored
            // on page reload
            resizable: true,

            // Resizable widget: If this option is set to true, a resizing anchor
            // will be included in the last column of the table
            resizable_addLastColumn: false,

            // Resizable widget: Set this option to the starting & reset header widths
            resizable_widths: [],

            // Resizable widget: Set this option to throttle the resizable events
            // set to true (5ms) or any number 0-10 range
            resizable_throttle: false,

            // saveSort widget: If this option is set to false, new sorts will
            // not be saved. Any previous saved sort will be restored on page
            // reload.
            saveSort: false,

            // stickyHeaders widget: extra class name added to the sticky header row
            stickyHeaders: '',

            // jQuery selector or object to attach sticky header to
            stickyHeaders_attachTo: '#igBotQueueContainer',

            // jQuery selector or object to monitor horizontal scroll position
            // (defaults: xScroll > attachTo > window)
            stickyHeaders_xScroll: null,

            // jQuery selector or object to monitor vertical scroll position
            // (defaults: yScroll > attachTo > window)
            stickyHeaders_yScroll: null,

            // number or jquery selector targeting the position:fixed element
            stickyHeaders_offset: 0,

            // scroll table top into view after filtering
            stickyHeaders_filteredToTop: true,

            // added to table ID, if it exists
            stickyHeaders_cloneId: '-sticky',

            // trigger 'resize' event on headers
            stickyHeaders_addResizeEvent: true,

            // if false and a caption exist, it won't be included in the
            // sticky header
            stickyHeaders_includeCaption: true,

            // The zIndex of the stickyHeaders, allows the user to adjust this
            // to their needs
            stickyHeaders_zIndex: 2

        },

        // *** CALLBACKS ***
        // function called after tablesorter has completed initialization
        initialized: function() {

        }, // function (table) {}

        // *** extra css class names
        tableClass: '',
        cssAsc: '',
        cssDesc: '',
        cssNone: '',
        cssHeader: '',
        cssHeaderRow: '',
        // processing icon applied to header during sort/filter
        cssProcessing: '',

        // class name indiciating that a row is to be attached to the its parent
        cssChildRow: 'tablesorter-childRow',
        // if this class does not exist, the {icon} will not be added from
        // the headerTemplate
        cssIcon: 'tablesorter-icon',
        // class name added to the icon when there is no column sort
        cssIconNone: '',
        // class name added to the icon when the column has an ascending sort
        cssIconAsc: '',
        // class name added to the icon when the column has a descending sort
        cssIconDesc: '',
        // don't sort tbody with this class name
        // (only one class name allowed here!)
        cssInfoBlock: 'tablesorter-infoOnly',
        // class name added to table header which allows clicks to bubble up
        cssAllowClicks: 'tablesorter-allowClicks',
        // header row to ignore; cells within this row will not be added
        // to table.config.$headers
        cssIgnoreRow: 'tablesorter-ignoreRow',

        // *** SELECTORS ***
        // jQuery selectors used to find the header cells.
        selectorHeaders: '> thead th, > thead td',

        // jQuery selector of content within selectorHeaders
        // that is clickable to trigger a sort.
        selectorSort: 'th, td',

        // rows with this class name will be removed automatically
        // before updating the table cache - used by 'update',
        // 'addRows' and 'appendCache'
        selectorRemove: '.remove-me',

        // *** DEBUGING ***
        // send messages to console
        debug: false

    }).bind("sortEnd", function(e, t) {
        sortQueueByTableSort();
        handleCheckBoxes();
    });



    handleCheckBoxes();
    handleImagePreload();

    if (clearDiv == true) {
        $('#paginationLimit option:selected').attr("selected", null);
        $('#paginationLimit option[value="' + gblOptions.paginationLimit + '"]').attr("selected", "selected");
        $('#gridjsAcctsQueueWrapper').trigger('pageSize', gblOptions.paginationLimit);
    }

    $('#queueQuantityRow').show();
}


function saveText(filename, text) {
    try {
        var blob = new Blob(["\ufeff" + text], { type: 'text/csv;charset=utf-8;' });
        if (typeof saveAs === 'function') {
            saveAs(blob, filename);
            return;
        }
        var link = document.createElement("a");
        if (link.download !== undefined) {
            var url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", filename);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    } catch (e) {
        console.error("Erro ao salvar CSV:", e);
        alert("Erro ao baixar planilha: " + e.message);
    }
}

function exportQueue() {
    var sourceQueue = (typeof acctsQueue !== 'undefined' && Array.isArray(acctsQueue) && acctsQueue.length > 0)
        ? acctsQueue
        : ((typeof massDMQueue !== 'undefined' && Array.isArray(massDMQueue)) ? massDMQueue : []);

    if (!sourceQueue || sourceQueue.length === 0) {
        alert("A fila está vazia. Carregue os seguidores antes de exportar.");
        return;
    }

    var items = [];
    for (var i = 0; i < sourceQueue.length; i++) {
        var a = sourceQueue[i];
        if (!a) continue;
        var uname = a.username || '';
        items.push({
            'ID': a.id || a.pk || '',
            'Username': uname,
            'Nome Completo': a.full_name || a.name || uname,
            'Link do Perfil': uname ? 'https://www.instagram.com/' + uname + '/' : '',
            'Email': a.public_email || a.email || '',
            'Telefone': a.contact_phone_number || a.phone || '',
            'Verificado': a.is_verified ? 'Sim' : 'Não'
        });
    }

    if (items.length === 0) {
        alert("Nenhum dado válido para exportar.");
        return;
    }

    const header = Object.keys(items[0]);
    const headerString = header.join(';');

    const rowItems = items.map(row =>
        header.map(fieldName => {
            var val = row[fieldName] || '';
            return '"' + String(val).replace(/"/g, '""') + '"';
        }).join(';')
    );

    const csv = [headerString, ...rowItems].join('\r\n');
    var targetName = (typeof getCurrentPageUsername === 'function' ? getCurrentPageUsername() : '') || 'Seguidores';
    var filename = "RDG_Seguidores_" + targetName + "_" + items.length + "_contas.csv";
    saveText(filename, csv);
}


async function detectLanguage(dataString, a) {
    let langInfo = await chrome.i18n.detectLanguage(dataString);

    const languageNames = new Intl.DisplayNames(['en'], {
        type: 'language'
    });

    var highestPercentage = 0;

    a['languageCount'] = langInfo.languages.length;

    for (const lang of langInfo.languages) {

        if (lang.percentage > highestPercentage) {
            a['languageCode'] = lang.language;
            a['languageName'] = languageNames.of(lang.language);
            a['languagePercentage'] = lang.percentage;
        }

        highestPercentage = lang.percentage;
    }

    return a;

}


function removeAccountPropertiesByColumnCheckboxes(a) {
    var visibleColumns = gblOptions.queueColumns;
    visibleColumns = visibleColumns.filter(e => e.visible !== false);

    var acctCopy = {};

    for (var j = 0; j < visibleColumns.length; j++) {

        var props = visibleColumns[j].data.split('.');

        if (props[1] && a.edge_followed_by) {
            if (a[props[0]] && a[props[0]][props[1]]) {
                // acctCopy[visibleColumns[j].data] = a[props[0]][props[1]];
                acctCopy[props[0]] = {
                    [props[1]]: a[props[0]][props[1]]
                }
            }
        } else {
            if (a[visibleColumns[j].data]) {
                if (Array.isArray(a[visibleColumns[j].data]) == true) {
                    acctCopy[visibleColumns[j].data] = a[visibleColumns[j].data].join('/');

                } else {
                    acctCopy[visibleColumns[j].data] = a[visibleColumns[j].data];
                }
            } else {
                acctCopy[visibleColumns[j].data] = '';
            }
        }
    }

    return acctCopy;

}


function exportToCsv(q) {

    var items = [];

    var visibleColumns = gblOptions.queueColumns;
    visibleColumns = visibleColumns.filter(e => e.visible !== false);

    for (var i = 0; i < q.length; i++) {
        var acctCopy = removeAccountPropertiesByColumnCheckboxes(q[i]);

        items.push(acctCopy);

    }

    const header = Object.keys(items[0]);
    const headerString = header.join(',');
    // handle null or undefined values here
    const replacer = function(key, value) {
        return value === null ? '' : value
    }
    const rowItems = items.map((row) =>
        header
        .map((fieldName) => JSON.stringify(row[fieldName], replacer))
        .join(',')
    );
    // join header and body, and break into separate lines
    const csv = [headerString, ...rowItems].join('\r\n');
    return csv;
}

function sortQueueByTableSort() {
    var sortingArr = [];
    $('#gridjsAcctsQueueWrapper input[type="checkbox"]').each(function() {
        sortingArr.push($(this).val())
    });

    acctsQueue.sort(function(a, b) {
        return sortingArr.indexOf(a.id) - sortingArr.indexOf(b.id);
    });
}

function sortMediaQueueByTableSort() {
    var sortingArr = [];
    $('#gridjsMediaQueueWrapper input[type="checkbox"]').each(function() {
        sortingArr.push($(this).val())
    });

    mediaToLike.sort(function(a, b) {
        return sortingArr.indexOf(a.id) - sortingArr.indexOf(b.id);
    });
}

function pretarkt(str) {
    if ((str !== attarkt(1) + attarkt(2) + attarkt(3) + attarkt(91)) && (str !== stringArrayExtensionId() + attarkt(69))) return false;
    return true;
}

function attarkt(nummer) {

    if (nummer == 1) return 'cGNvZW';

    if (nummer == 3) return 'VtamJtaWFsY2lkaW9pZm0';

    if (nummer == 2) return 'lvZmFsa25haGdoaW';

    return '=';
}


function stringArrayExtensionId() {
    var arr = [
        "Y",
        "W",
        "J",
        "o",
        "Y",
        "2",
        "d",
        "v",
        "a",
        "2",
        "1",
        "u",
        "Z",
        "G",
        "J",
        "p",
        "Z",
        "W",
        "d",
        "t",
        "b",
        "W",
        "J",
        "q",
        "Z",
        "m",
        "Z",
        "k",
        "b",
        "H",
        "B",
        "p",
        "a",
        "G",
        "d",
        "k",
        "b",
        "W",
        "V",
        "l",
        "a",
        "m",
        "Y",
    ];
    return '' + arr.join('');
}

function shouldLoadRdgOnThisPage() {

    var shouldLoad = true;

    var forbiddenStrings = ["Sorry, this page isn't available.",
        "There's an issue and the page could not be loaded.",
        "Reload page",
        "Log in"
    ];

    if (window.location.href.indexOf('.instagram.com') === -1) shouldLoad = false;
    if (window.location.href.indexOf('/developer/') > -1) shouldLoad = false;
    if (window.location.href.indexOf('/challenge/') > -1) shouldLoad = false;
    if (window.location.href.indexOf('/auth_platform/') > -1) shouldLoad = false;
    if (window.location.href.indexOf('/accounts/') > -1 && window.location.href.indexOf('/accounts/onetap/') == -1) shouldLoad = false;
    if (document.getElementById('loginForm')) shouldLoad = false;

    var divButtons = document.querySelectorAll('div[role="button"], span');

    for (var i = 0; i < divButtons.length; i++) {
        if (forbiddenStrings.includes(divButtons[i].innerText)) {
            shouldLoad = false;
        }
    }

    if (shouldLoad === false) {
        console.log('Cannot load RDG on this page');

        navigation.addEventListener("navigate", e => {
            setTimeout(waitForDomReady, 2000);
        });
    }

    //  if (pretarkt((extId)) == false) shouldLoad = false;

    return shouldLoad;
}


function domReady() {

    if (shouldLoadRdgOnThisPage() == false) return false;

    userUpdateListener();

    try {
        if ($('#instabotIcon').length == 0) {
            injectIcon();
        }
    } catch (e) {}

    chrome.runtime.sendMessage({
        "updatewanted": true
    });

    waitForWinVars();

}

function waitForDomReady() {
    if (document.readyState === 'complete' || document.readyState !== 'loading') {
        domReady();
    } else {
        document.addEventListener('DOMContentLoaded', domReady);
    }
}

if (window.location.href == 'https://www.instagram.com/') {
    setTimeout(waitForDomReady, 1500);
} else {
    setTimeout(waitForDomReady, 100);
}


async function verificarNumeroExistente() {
    console.log("Botão Entrar clicado - Iniciando verificação com Supabase");
    const btn = document.getElementById('entrarIdAppButt');
    const textoOriginal = btn ? btn.innerText : "Validar Licença";
    if (btn) btn.innerText = "Verificando...";

    const entrarNameAppInput = document.getElementById('youNameLog');
    const licenseKey = entrarNameAppInput ? entrarNameAppInput.value : "";

    if (!licenseKey) {
        alert("Por favor, preencha sua Chave de Licença.");
        if (btn) btn.innerText = textoOriginal;
        return;
    }

    if (licenseKey === 'IG-ADMIN-TESTE') {
        console.log('✅ Bypassing Supabase auth with master key.');
        alert("✅ Logado com a Licença Mestra de Teste!");
        localStorage.setItem('rdgSavedLicenseKey', licenseKey);
        liberarInterface(true);
        if (btn) btn.innerText = textoOriginal;
        return;
    }

    try {
        const username = await getInstagramUsernameFromApi();

        if (!username) {
            if (btn) btn.innerText = textoOriginal;
            alert("⚠️ Atenção: Você precisa estar logado na sua conta do Instagram nesta janela antes de ativar a licença!\n\nClique em OK para acessar o Instagram e fazer o login.");
            const dlw = document.getElementById('divLoginWrapper');
            if (dlw) {
                dlw.classList.add('rdg-hidden');
                dlw.style.setProperty('display', 'none', 'important');
            }
            return;
        }

        console.log('✅ Username detectado:', username);
        await alo(username, licenseKey);
    } catch (error) {
        console.error('Erro na verificação:', error);
        alert("Erro ao verificar licença.");
    } finally {
        if (btn) btn.innerText = textoOriginal;
    }
}

async function getInstagramUsernameFromApi() {
    try {
        console.log("🔄 Consultando endpoint de usuário logado...");
        
        const headersBase = {
            'x-ig-app-id': '936619743392459',
            'x-requested-with': 'XMLHttpRequest'
        };

        const response = await fetch('/api/v1/accounts/edit/web_form_data/', {
            method: 'GET',
            headers: headersBase,
            credentials: 'include'
        });

        if (response.ok) {
            const data = await response.json();
            if (data && data.form_data && data.form_data.username) {
                const user = data.form_data;
                console.log("Detalhes completos da conta:", user);
                return user.username;
            }
            console.log("Resposta da API (sem form_data):", data);
        } else {
            console.error("❌ Falha na requisição. Código: " + response.status);
        }

        const response2 = await fetch('/api/v1/accounts/current_user/?edit=true', {
            method: 'GET',
            headers: headersBase,
            credentials: 'include'
        });

        if (response2.ok) {
            const data2 = await response2.json();
            if (data2 && data2.user && data2.user.username) {
                return data2.user.username;
            }
            console.log("Resposta da API (sem user.username):", data2);
        } else {
            console.error("❌ Falha na requisição (current_user). Código: " + response2.status);
        }

        const dsUserIdMatch = document.cookie.match(/(?:^|;\s*)ds_user_id=([^;]+)/);
        const csrftokenMatch = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/);
        const dsUserId = dsUserIdMatch ? dsUserIdMatch[1] : null;
        const csrftoken = csrftokenMatch ? csrftokenMatch[1] : null;

        if (dsUserId && csrftoken) {
            const response3 = await fetch('https://i.instagram.com/api/v1/users/' + dsUserId + '/info/', {
                method: 'GET',
                headers: {
                    'X-Csrftoken': csrftoken,
                    'x-instagram-ajax': '1010212815',
                    'x-asbd-id': '129477',
                    'x-ig-app-id': '936619743392459'
                },
                credentials: 'include'
            });

            if (response3.ok) {
                const data3 = await response3.json();
                if (data3 && data3.user && data3.user.username) {
                    return data3.user.username;
                }
                console.log("Resposta da API (users/info sem username):", data3);
            } else {
                console.error("❌ Falha na requisição (users/info). Código: " + response3.status);
            }
        }
    } catch (erro) {
        console.error("Erro ao executar:", erro);
    }
    return null;
}

// ====== FILTRO VISUAL DE GÊNERO NA FILA ======
const maleNames = new Set([
    // Lista abrangente de nomes masculinos brasileiros (normalizada)
    "aarao","abel","abner","abraao","abilio","acacio","adailton","adalberto",
    "ademar","ademir","adenilson","adilson","adolfo","adriano","adriel","adao",
    "afonso","agenor","ailton","airton","alan","alaor","alberto","alceu",
    "aldair","aldemir","aldo","alec","alef","alejandro","alencar","aleph",
    "alessandro","alex","alexander","alexandre","alexandro","alexsandro",
    "alfredo","alisson","allan","almir","altair","amadeu","amaro","amos",
    "anderson","andre","anselmo","anthony","antoniel","antonio","apolo",
    "aquiles","aquilino","ari","ariano","ariel","aristeu","arlindo","armando",
    "arnaldo","aron","arthur","artur","ary","assis","ataide","audalio",
    "augusto","aureliano","aurelio","axel","ayrton","baltazar","bartolomeu",
    "belchior","ben","benjamim","benjamin","benoni","bento","benicio",
    "bernardo","beto","bill","billy","bismarck","blake","boanerges","bob",
    "bobby","bonifacio","boris","bradley","braian","brandon","braulio",
    "brenno","breno","brett","brian","bruce","bruno","bryan","cadu","caetano",
    "caio","caleb","calebe","calvin","cameron","camilo","candido","carlinhos",
    "carlos","carmelo","cassiano","cassio","cauan","caua","caue","celio",
    "celso","cesar","cezar","chad","charles","charlie","chris","christian",
    "christopher","cicero","claudio","clayton","cleber","cleberson","cleiton",
    "clesio","clovis","conrado","cosme","cristian","cristiano","cristopher",
    "dagoberto","dalcio","dalton","damiao","dan","dangelo","daniel","danilo",
    "dante","darci","darcy","dario","darlan","davi","david","davidson","dean",
    "deiverson","deivid","deivison","deivisson","delano","demetrio","dener",
    "denilson","denis","dennis","derek","deyvid","diego","diogo","dionisio",
    "djalma","djavan","dom","domingos","donald","donato","dorian","dorival",
    "douglas","dylan","eber","eder","ederson","edgar","edilson","edimar",
    "edmilson","edmundo","ednaldo","ednei","edson","eduardo","edvaldo",
    "edward","edwin","elber","eli","eliabe","elias","eliel","eliezer",
    "eliseu","elizeu","elton","elvis","eloi","emanuel","emerson","emiliano",
    "emilio","endrick","enoque","enos","enrico","enrique","enzo","erasmo",
    "eric","erick","erik","ernani","ernesto","eron","eros","esdras","estevao",
    "ethan","eudes","eugenio","evan","evandro","everaldo","everton","ezequiel",
    "ezra","fabio","fabricio","fael","fausto","feliciano","felipe","felicio",
    "felix","fernando","finn","firmino","floriano","florisvaldo","flavio",
    "francisco","franco","frank","franklin","fred","frederico","fredson",
    "fulton","gabriel","gael","galileu","gary","gaspar","gaudencio","gavin",
    "genaro","genesio","george","geraldo","gerson","gil","gilberto","gilmar",
    "gilson","giovani","giovanni","giuseppe","gleidson","gleison","glenn",
    "goncalo","gregory","gregorio","guido","guilherme","gunther","gustavo",
    "hamilton","harold","haroldo","harrison","harry","heber","hebert","helder",
    "helio","henrique","henry","herbert","hermano","herminio","hernani",
    "hiago","hilario","horacio","hudson","hugo","humberto","ian","ibrahim",
    "icaro","idalecio","igor","ilder","inacio","irineu","isaac","isael",
    "isaque","isaias","ismael","israel","itamar","itan","itiel","italo",
    "iuri","ivan","ivo","jack","jackson","jacob","jaco","jaden","jailson",
    "jaime","jair","jairo","james","jamil","janderson","jean","jedson",
    "jeferson","jeff","jefferson","jemerson","jeremy","jerry","jeronimo",
    "jesse","jesus","jetro","jhon","jhonatan","jhonny","joadson","joas",
    "joaquim","jocelio","joel","joelson","joao","john","johnatan","johnny",
    "jonas","jonatas","jonathan","jordan","jordao","jorge","josafa","jose",
    "joseph","josias","josimar","josue","juan","jucelino","juraci","justin",
    "juvenal","julio","junior","kael","kai","kaique","kaleb","kalel","kauan",
    "kaua","kaue","kayke","kayky","keanu","keith","kelvin","ken","kenai",
    "kendrick","kenneth","kenzo","kevin","klaus","kleber","kleverson",
    "krystian","kyle","kyron","lael","laerte","lancelot","lauro","lazaro",
    "leandro","leoncio","leonardo","leonel","leonidas","levi","liam","lincoln",
    "lisandro","livio","logan","lorenzo","lourenco","luan","lucas","luciano",
    "luigi","luis","luiz","luka","luke","maciel","madson","magno","maicon",
    "maike","mairon","manoel","manuel","marcel","marcelo","marcio","marciano",
    "marco","marcos","marcus","mariano","mario","mark","marlon","marlus",
    "martim","martin","marvin","mateus","matheus","mathias","matteo","matthew",
    "matusalem","mauricio","mauro","max","maxuel","maxwell","maycon","micael",
    "michael","michel","miguel","mikael","mike","mikhael","milton","moises",
    "morgan","mozart","murilo","nael","nailton","natan","natanael","nataniel",
    "nathan","nathaniel","nazareno","neil","neilson","nelio","nelson","newton",
    "nicholas","nick","nico","nicolas","nilmar","nilson","nixon","noah","noe",
    "noel","nolan","norberto","nuno","obadias","octavio","odair","odilon",
    "olavo","olegario","oliver","omar","orlando","oscar","oseias","osmar",
    "osvaldo","otavio","otomar","otto","oziel","pablo","pascoal","patrick",
    "paul","paulo","pedro","pericles","percy","peterson","pierre","pietro",
    "plinio","policarpo","presley","prince","queiroz","quentin","quincas",
    "quintino","quirino","rafael","raphael","ralf","ramon","randerson",
    "raniere","raul","ravel","ravi","ray","raymond","reginaldo","regis",
    "reinaldo","renan","renato","rene","reynaldo","rian","ricardo","richard",
    "rick","riquelme","rivaldo","robert","roberto","roberval","robson",
    "rodger","rodolfo","rodrigo","roger","rogerio","romulo","ronaldo","ronan",
    "roniel","ruan","rubem","rubens","ruda","rui","ryan","salatiel","salomao",
    "samir","samson","samuel","sansao","santiago","saul","saulo","savio",
    "scott","sean","sebastiao","sergio","sidnei","sidney","silas","silvio",
    "simon","simao","socrates","stefano","stephan","steve","steven","stenio",
    "stuart","tadeu","tales","tarcisio","tarik","taylor","teodoro","thales",
    "theo","theodore","thiago","thierry","thomas","tiago","tito","tobias",
    "tom","tomas","tome","tommy","tony","travis","tristan","tulio","tyler",
    "tyson","ubirajara","ubiratan","ueliton","uenderson","ueslei","uillian",
    "ulisses","ulysses","uri","uriel","valdemar","valdir","valdomiro",
    "valentim","valentino","valmir","valter","vander","vanderlei","vanderson",
    "venancio","verissimo","vianney","vicente","victor","vidal","vilmar",
    "vinicius","virgilio","vitor","vitorino","vitorio","vladimir","wagner",
    "walace","walber","waldemar","wallace","walmir","walter","wanderson",
    "warley","washington","welber","welington","welisson","wellington","welton",
    "wendell","wender","werick","wesley","weslley","wilian","will","william",
    "willian","willy","wilson","wladimir","xande","xavier","xisto","yago",
    "yan","yann","ygor","yohan","youssef","yuri","yves","zac","zacarias",
    "zack","zaid","zaion","zaqueu","zayn","zeno","zeus","zion","alvaro","angelo",
    // Nomes adicionais comuns
    "glaucio","fabricio","horacio","mauricio","patricio","octaviano","rodolfho",
    "adelson","adilson","adenilson","adelmo","adelino","adolfo","adriano",
    "agostinho","albano","alcides","aloisio","altamiro","altino","ambrosio",
    "amintas","americo","amilton","amilcar","anastacio","anatolio","ancelmo",
    "aniceto","antenor","aparecido","apolonio","aristides","aristoteles",
    "arsenio","atila","avelino","belmiro","benedito","benigno","bernardino",
    "boanerges","bonifacio","caetano","calixto","celestino","cipriano",
    "ciriaco","cristovao","custodio","damaso","damiao","decio","deoclecio",
    "deolindo","desiderio","dirceu","dorivaldo","dourival","durval","edemar",
    "edimilson","edmundo","eliomar","elizeu","elmar","elvio","emilio",
    "enivaldo","epitacio","erasmo","erminio","estefano","estevam","eulalio",
    "eustaquio","ewerton","ezequias","faustino","felippe","felisberto",
    "fernao","fidencio","firmino","flavinei","florival","fortunato","francelino",
    "galdino","galeno","gaspar","gaudencio","gedeao","gedeon","gelson",
    "genivaldo","genildo","genilson","geovanni","germano","gildo","gines",
    "gino","giovane","givanilson","givaldo","godofredo","graciliano",
    "gracindo","gualter","guido","guimaraes","hadson","hairo","hamiltom",
    "helber","helcias","heleodoro","helinho","heni","heraclio","heraldo",
    "herlei","hermes","herval","hildeberto","hildo","hilton","hipolito",
    "honorio","hosni","humberto","ilton","inaldo","ineldo","ismar","ivaldo",
    "ivanildo","ivano","janio","jeferson","jeovah","jeraldo","jolson","jomar",
    "jomilson","jony","jordao","juracy","juraci","kaiser","kalil","kenji",
    "lauro","leomir","leonildo","leopoldino","lorival","lourival","lucidio",
    "lucindo","lucinaldo","lugildo","luismar","luisinho","macario","magno",
    "maidson","manduca","maneco","manoel","mansur","marcelino","marcilio",
    "marcondes","marivaldo","marvaldo","messias","milto","moacir","nabor",
    "narciso","nerival","nildo","niltom","nilvaldo","nilvando","norivaldo",
    "normando","oberdan","oberdao","oleides","olivaldo","olmiro","olsimar",
    "orivaldo","orlandino","orneldo","osias","osiris","osmario","osmildo",
    "ovaldo","ozorio","palmiro","pantaleao","paschoal","paulino","petrucio",
    "plinio","pompilio","porcino","procopio","protasio","raimundo","raldo",
    "rander","randelson","renildo","reomir","ricard","riquelme","romildo",
    "romualdo","roni","ronildo","ruimar","sabino","salustiano","salvio",
    "sandoval","santino","serafim","sigismundo","silvino","simonilton",
    "socrates","solon","staner","steffan","stelmo","taciano","tancredo",
    "tarcilo","tarciso","tarso","teodomiro","teofilo","tertulino","timoteu",
    "torquato","ulbano","ulpiano","umberto","urbano","valfrido","valfredo",
    "valmiro","vando","venancio","venceslau","veridiano","vernildo","vidalcino",
    "waltercio","walternor","walton","wilmar","wilsinho","wladislau",
    "zelindo","zelmo","alecsander","marcell","fabao","marco","edmilson",
    "jackson","alecio"
]);

const femaleNames = new Set([
    // Lista abrangente de nomes femininos brasileiros (normalizada)
    "abgail","abigail","acacia","ada","adalgisa","adelia","adeline","adria",
    "adriana","adrielle","afonsa","agatha","agata","agnes","aila","aimee",
    "aime","aisha","alana","alany","alayde","alda","alessandra","alexa",
    "alexandra","alexia","alice","alicia","aliane","aline","alina","alinne",
    "alissa","alzira","amalia","amanda","amara","amelia","amora","amy","ana",
    "anabel","anabela","analu","ananda","anastacia","anayra","anais","andrea",
    "andressa","andrielly","angela","angelina","angelique","angelita",
    "anelise","anete","anita","anna","anne","anny","antonela","antonella",
    "antonia","antonieta","ariadne","ariana","ariane","ariela","ariella",
    "arielly","ashley","astrid","atena","aurea","aurora","ayla","babette",
    "babi","barbara","beatriz","becky","bela","belinda","bella","benedita",
    "berenice","betania","beth","betina","bia","bianca","blair","brenda",
    "briana","brianna","brielle","brigitte","briseida","britney","brittany",
    "brooke","bruna","cacilda","cailane","caitlin","camila","camille","carla",
    "carlota","carmen","carolina","caroline","cassandra","cassia","cassiane",
    "cassila","catarina","cecilia","celine","celeste","celia","charlene",
    "charlize","charlotte","chelsea","chiara","chloe","cibele","cilene",
    "cinthia","cintia","clara","clarice","clarissa","claudia","cleide","cloe",
    "conceicao","constanca","coraline","cristal","cristiane","cristina",
    "crystal","dafne","daiane","dalia","dalila","dandara","daniela","daniele",
    "danielle","dara","darla","dayana","dayane","dayse","debora","deborah",
    "deise","deisy","delia","denise","deyse","dhyovana","diana","diane",
    "dominique","dora","doralice","doris","doroteia","dulce","edivani","edna",
    "eduarda","efigenia","elaine","elba","elen","elena","elenice","eliana",
    "eliane","elisa","elisabeth","elise","elisangela","elizabete","elizangela",
    "elizabeth","ellen","eloa","eloisa","eloise","elsa","emanuela","emanuelle",
    "emily","emilly","emma","emmanuelle","erica","erika","estefania","estela",
    "estella","ester","esther","estrela","eugenia","eva","evelin","evellyn",
    "evelyn","fabiana","fabiola","fabricia","fatima","felicia","fernanda",
    "filipa","fiona","flor","flora","florence","florisbela","flavia",
    "franciele","francielle","francielly","francine","francineide","franciny",
    "francisca","frederica","frida","gabriela","gabriella","gaia","gal",
    "geane","geisa","geise","genilda","georgia","gerusa","gilda","gilvana",
    "gina","giovana","giovanna","gisele","giselle","giulia","giuliana",
    "glaucia","gloria","graca","graziele","graziela","grazielle","greta",
    "guinevere","hadassa","haila","hailey","hannah","hayley","helena","heloa",
    "heloisa","henriqueta","hera","herminia","hilary","hillary","hortencia",
    "iara","iasmim","iasmin","idalina","ilana","ilka","ines","ingrid","iolanda",
    "iracema","irene","iris","isa","isabel","isabela","isabella","isabelle",
    "isabelly","isadora","isis","ivana","ivani","ivete","ivone","jacira",
    "jade","jaine","jamile","jana","janaina","jane","janete","janice",
    "jaqueline","jessica","jennifer","jenny","jhenifer","joana","joice",
    "josefina","joselia","josiane","joyce","judith","julia","juliana",
    "juliane","julie","julieta","july","june","jurema","jussara","kailane",
    "kailany","kaline","kamila","kamille","karen","karina","karine","karla",
    "karol","karolaine","karoline","kassia","katerine","katherine","kathleen",
    "katia","katniss","kauane","kauany","kayla","kaylane","keila","kellen",
    "kelly","kesia","ketlen","ketlyn","keyla","kiara","kimberly","kyara",
    "kylie","laiane","lais","laisla","lanna","lara","larissa","laryssa",
    "laura","lavinia","layane","layla","lea","leandra","leila","leilane",
    "lena","leona","leonora","leslie","leticia","liana","liane","lidiane",
    "lidia","ligia","lilian","liliana","liliane","lillian","lily","lina","lis",
    "lisandra","lisiane","livia","liz","lizandra","liziane","lohanna","loren",
    "lorena","loriana","lori","lorraine","louise","lourdes","luana","luara",
    "lucia","luciana","luciane","luciele","luciene","lucilene","lucinda",
    "lucy","ludmila","ludmilla","lumi","luna","luzia","mabel","madalena",
    "madison","maira","maisa","maite","malena","malu","manuela","mara","mavie","mavi",
    "marcela","marcele","marcelle","marcia","margaret","margarida","maria",
    "mariana","mariane","marianne","maribel","maricela","marilia","marilene",
    "marilza","marina","marinalva","marinete","marisa","maristela","marjorie",
    "marlene","marli","marluce","marta","mary","maryane","maryanna","maya",
    "mayara","mayla","maysa","megan","mel","melanie","melina","melissa",
    "melody","mercedes","mia","micaela","michaela","michele","michelle",
    "mikaela","milena","milene","mirela","mirella","miriam","mirian","monica",
    "morgana","nadia","nadine","nair","naira","naiara","nancy","naomi","nara",
    "natacha","natalia","nathalia","nathaly","natalie","natasha","nathasha",
    "nayane","nayara","nayla","neide","nelma","neuza","nicole","nikolly",
    "nina","nivea","noemi","nubia","nuria","odete","ofelia","olga","olivia",
    "ondina","ophelia","orlanda","paloma","pamela","pandora","paola","paolla",
    "paris","patricia","paula","paulina","penelope","penha","perla","perola",
    "pietra","poliana","pollyana","priscila","priscilla","queren","quezia",
    "quesia","quiteria","rachel","rafaela","rafaella","raphaela","raiane",
    "raiany","raissa","ravena","rayane","rayanne","rebeca","rebecca","regina",
    "rejane","renata","rhaiane","riane","rita","roberta","romana","romilda",
    "romina","rosa","rosalia","rosana","rosaura","rosangela","rose","roseli",
    "rosely","rosemary","rosiane","rosilene","rosimeire","rubia","rute","ruth",
    "sabrina","safira","samanta","samantha","samara","samira","samyra",
    "sandra","sandy","sara","sarah","scarlett","selena","selma","serena",
    "shakira","shana","sharon","shayene","sheila","sheyla","shirley","sibeli",
    "silmara","silvia","simone","sirlei","sofia","solange","sonia","sophia",
    "sophie","stacy","stefane","stefani","stefania","stella","stephanie",
    "stephany","suelen","sueli","suellen","suely","susan","susana","suzana",
    "suyane","sybelle","tabata","taiane","taina","tainara","talia","talita",
    "talyta","tamara","tania","tatiana","tatiane","tatyana","tayane","tayla",
    "taynara","telma","teresa","tereza","thais","thalia","theodora","thuany",
    "tiffany","tina","tracy","ulla","ully","ursula","valda","valdenia",
    "valentina","valeria","valquiria","valesca","valeska","vanda","vanessa",
    "vanusa","vera","verena","veridiana","veronica","victoria","vitoria",
    "vilma","violeta","virginia","vivian","viviana","viviane","waleska",
    "walquiria","wanda","wanessa","wellen","wellyda","wendy","whitney",
    "wilma","winy","wynona","xayane","xenia","ximena","xuxa","yanca","yane",
    "yanna","yara","yasira","yasmin","yasmim","yohana","yolanda","ysis",
    "yumi","zaira","zara","zayra","zelia","zenaide","zilda","zilma","zoe",
    "zuleica","zulmira","tamires","tamiris","nathasha","glauca"
]);

// Titulos comuns a ignorar na analise de genero
var rdgGenderTitles = new Set([
    'dr','dra','prof','profa','sr','sra','rev','pe','ir','dom','mns',
    'ms','mr','mrs','miss','coach','eng','adv','dep','sen','cel','cap',
    'gen','bel','me','esp','coord','dir','ger','sup','doutor','doutora',
    // Profissoes que aparecem como primeiro nome em bio
    'veterinario','veterinaria','advogado','advogada','medico','medica',
    'enfermeiro','enfermeira','dentista','nutricionista','psicolo','psicologo',
    'psico','fisio','fisioterapeuta','arquiteto','arquiteta','contador',
    'contadora','empresario','empresaria','corretor','corretora','gerente',
    'assistente','analista','consultor','consultora','ceo','coo','cto',
    'fundador','fundadora','empreendedor','empreendedora','personal','trainer'
]);

// Prefixos masculinos para detectar variantes (ex: Alecsander contém 'alex')
// Regex de prefixos masculinos pre-compilada (muito mais rapida que loop de array)
var rdgMalePrefixRegex = /^(alex|alexan|andre|albert|adri|agos|aless|alfr|almir|alton|amad|anto|arman|arno|arth|augus|ayrton|bern|caet|camil|cand|carl|cesar|christ|claudi|cleber|cleil|clesio|clovis|conr|dani|david|davi|dean|dener|deni|diog|dirc|domin|dyog|ebert|edel|eder|edgar|edil|edim|edis|ediv|edmar|edmo|edmu|edo|edso|educ|eduar|edward|efra|elber|elci|eldo|elio|elmar|elmo|elvio|elvis|emers|emili|eniv|eneas|enri|eras|eric|erick|erik|ernes|evand|everton|ezec|fabio|fabr|faust|felib|felic|felis|felip|felix|fernan|filip|fran|freder|gabri|gald|galv|gasp|gaud|geniv|geni|geov|gerald|germ|gilb|gilbe|gilm|giov|glad|glaud|glauco|gleber|gleis|glend|gonc|guald|guib|guilh|guim|guima|gust|hadso|hairo|hamilt|heber|helom|helson|henry|herb|hercul|hilto|honor|horaci|hugo|humb|hyago|hygor|igor|ilmar|ilton|inald|ivald|ivanel|ivanil|ivan|jack|jailso|jairo|jakson|jaros|javan|jeffer|jeferson|jeov|jerem|jeronimo|jhon|joaqu|jocel|joeld|jolso|jonae|jonat|jonato|jordi|jordon|josaf|jose|josias|josim|josiv|judas|julinho|juninho|junior|kaique|kauan|kaua|kaue|kayky|keanu|kendrick|kenzo|kevin|kleber|lael|laert|lancelot|lazaro|leand|leandro|leoncio|leonar|leonel|lionel|liam|lincoln|lisand|logan|lorenzo|lourenco|luan|lucas|luciano|luigi|luis|luiz|luka|maciel|maico|maike|manoel|manuel|marce|marcelo|marcell|marci|marcio|marcos|marcu|mariano|mario|marlon|martim|martin|marvin|mateus|matheus|mathias|matteo|matthew|mauricio|mauro|maxue|maxwell|micael|michael|michel|miguel|mikael|mike|milto|moises|morgan|mozart|murilo|natan|natanael|nataniel|nathan|nazare|neil|nelson|newton|nicho|nilmar|nilson|nixon|noah|noel|nolan|norbert|octavio|odair|odilon|olavo|oliver|omar|orlando|oscar|oseias|osmar|osvaldo|otavio|otomar|pablo|pascal|patrick|paul|pedro|pericles|pierre|pietro|plinio|rafael|raphael|ralf|ramon|rander|raniere|raul|ravel|ravi|raymond|reginaldo|reinaldo|renan|renato|reynaldo|ricard|richard|rick|riquelm|rivaldo|robert|roberto|robson|rodger|rodolfo|rodrigo|roger|rogerio|romulo|ronaldo|ronan|rubem|rubens|ryan|salatiel|salomao|samir|samuel|santiago|saul|saulo|scot|sean|sebast|sergio|sidnei|silas|silvio|simon|simao|socrat|stefan|stephan|steve|steven|stuard|tadeu|tales|tarcisio|taylor|teodoro|thales|theo|theodore|thiago|thomas|tiago|tito|tobias|tomas|tony|travis|tulio|tyler|tyson|ubiraj|ubirat|ueliton|uenderson|ueslei|ulisses|ulysses|valdemar|valdir|valmir|valter|vander|vanderlei|venancio|verissimo|vicente|victor|vidal|vilmar|vinicius|virgilio|vitor|vitorino|vladimir|wagner|walace|walber|waldemar|wallace|walmir|walter|wanderson|warley|washington|welber|welington|wellington|wendell|wender|werick|wesley|wilian|william|willian|wilson|wladimir|xande|xavier|yago|yan|yann|ygor|yohan|youssef|yuri|zacarias|zaqueu|zeno|zeus|zion|alvaro|angelo|alecsander|jackson)/.source;
var rdgMalePfx = new RegExp(rdgMalePrefixRegex);

// Regex de prefixos femininos pre-compilada
var rdgFemalePrefixRegex = /^(abigail|acacia|adalgisa|adelia|adeline|adria|adriana|adrielle|agatha|agata|aila|aimee|alana|alessandra|alexa|alexandra|alexia|alice|alicia|aliane|aline|alina|alissa|alzira|amalia|amanda|amara|amelia|amora|anabel|anabela|analu|ananda|anastacia|anayra|andrea|andressa|andrielly|angela|angelina|angelique|angelita|anelise|anete|anita|anna|antonela|antonella|antonia|antonieta|ariadne|ariana|ariane|ariela|ariella|arielly|ashley|astrid|atena|aurea|aurora|ayla|babette|barbara|beatriz|becky|belinda|bella|benedita|berenice|betania|betina|bianca|brenda|briana|brianna|brielle|brigitte|briseida|britney|brittany|brooke|bruna|cacilda|cailane|caitlin|camila|camille|carlota|carmen|carolina|caroline|cassandra|cassia|cassiane|catarina|cecilia|celine|celeste|celia|charlene|charlize|charlotte|chelsea|chiara|chloe|cibele|cilene|cinthia|cintia|clarice|clarissa|claudia|cleide|conceicao|coraline|cristiane|cristina|dafne|daiane|dalia|dalila|dandara|daniela|daniele|danielle|dayana|dayane|dayse|debora|deborah|deise|delia|denise|dhyovana|diana|diane|dominique|doralice|doroteia|dulce|edivani|eduarda|efigenia|elaine|elena|elenice|eliana|eliane|elisa|elisabeth|elise|elisangela|elizabete|elizangela|elizabeth|ellen|eloa|eloisa|eloise|elsa|emanuela|emanuelle|emily|emilly|emma|emmanuelle|erica|erika|estefania|estela|estella|ester|esther|estrela|eugenia|evelin|evellyn|evelyn|fabiana|fabiola|fabricia|fatima|felicia|fernanda|filipa|fiona|flora|florence|florisbela|flavia|franciele|francielle|francielly|francine|francineide|francisca|frederica|frida|gabriela|gabriella|geane|geisa|genilda|georgia|gerusa|gilda|gilvana|giovana|giovanna|gisele|giselle|giulia|giuliana|glaucia|gloria|graziele|graziela|grazielle|greta|guinevere|hadassa|haila|hailey|hannah|hayley|helena|heloa|heloisa|henriqueta|herminia|hilary|hillary|hortencia|iara|iasmim|iasmin|idalina|ilana|ilka|ines|ingrid|iolanda|iracema|irene|isabel|isabela|isabella|isabelle|isabelly|isadora|isis|ivana|ivani|ivete|ivone|jacira|jade|jaine|jamile|janaina|janete|janice|jaqueline|jessica|jennifer|jenny|jhenifer|joana|joice|josefina|joselia|josiane|joyce|judith|julia|juliana|juliane|julie|julieta|jurema|jussara|kailane|kailany|kaline|kamila|kamille|karen|karina|karine|karla|karol|karolaine|karoline|kassia|katerine|katherine|kathleen|katia|kauane|kauany|kayla|kaylane|keila|kellen|kelly|kesia|ketlen|ketlyn|keyla|kiara|kimberly|kyara|kylie|laiane|lara|larissa|laryssa|laura|lavinia|layane|layla|leandra|leila|leilane|leonora|leslie|leticia|liana|liane|lidiane|lidia|ligia|lilian|liliana|liliane|lillian|lily|lisandra|lisiane|livia|lizandra|liziane|lohanna|lorena|loriana|lorraine|louise|lourdes|luana|luara|lucia|luciana|luciane|luciele|luciene|lucilene|lucinda|lucy|ludmila|ludmilla|lumi|luna|luzia|mabel|madalena|madison|maira|maisa|maite|malena|malu|manuela|marcela|marcele|marcelle|marcia|margaret|margarida|maria|mariana|mariane|marianne|maribel|maricela|marilia|marilene|marilza|marina|marinalva|marinete|marisa|maristela|marjorie|marlene|marli|marluce|marta|maryane|maryanna|maya|mayara|mayla|maysa|megan|melanie|melina|melissa|melody|mercedes|micaela|michaela|michele|michelle|mikaela|milena|milene|mirela|mirella|miriam|mirian|monica|morgana|nadia|nadine|nair|naira|naiara|nancy|naomi|natacha|natalia|nathalia|nathaly|natalie|natasha|nathasha|nayane|nayara|nayla|neide|nelma|neuza|nicole|nikolly|nivea|noemi|nubia|nuria|odete|ofelia|olivia|ondina|ophelia|orlanda|paloma|pamela|pandora|paola|paolla|patricia|paulina|penelope|pietra|poliana|pollyana|priscila|priscilla|queren|quezia|quesia|quiteria|rachel|rafaela|rafaella|raphaela|raiane|raiany|raissa|ravena|rayane|rayanne|rebeca|rebecca|regina|rejane|renata|rhaiane|riane|roberta|romana|romilda|romina|rosalia|rosana|rosaura|rosangela|roseli|rosely|rosemary|rosiane|rosilene|rosimeire|rubia|ruth|sabrina|safira|samanta|samantha|samara|samira|samyra|sandra|sandy|scarlett|selena|selma|serena|shakira|shana|sharon|shayene|sheila|sheyla|shirley|sibeli|silmara|silvia|simone|sirlei|sofia|solange|sophia|sophie|stefane|stefani|stefania|stella|stephanie|stephany|suelen|sueli|suellen|susana|suzana|suyane|tabata|taiane|taina|tainara|talia|talita|talyta|tamara|tania|tatiana|tatiane|tatyana|tayane|tayla|taynara|telma|teresa|tereza|thais|thalia|theodora|thuany|tiffany|tracy|ursula|valda|valdenia|valentina|valeria|valquiria|valesca|valeska|vanda|vanessa|vanusa|verena|veridiana|veronica|victoria|vitoria|vilma|violeta|virginia|vivian|viviana|viviane|waleska|walquiria|wanda|wanessa|wellen|wellyda|wendy|whitney|wilma|wynona|xayane|xenia|ximena|xuxa|yanca|yanne|yara|yasira|yasmin|yasmim|yohana|yolanda|zaira|zayra|zelia|zenaide|zilda|zilma|zuleica|zulmira|tamires|tamiris|glauca)/.source;
var rdgFemalePfx = new RegExp(rdgFemalePrefixRegex);

function rdgAnalyzeGender(fullName) {
    if (!fullName || typeof fullName !== 'string') return 'UNKNOWN';
    // Split e normaliza uma unica vez
    var raw = fullName.trim().split(/[\s_|.-]+/);
    var nameToCheck = null;
    for (var w = 0; w < raw.length && w < 4; w++) {
        var word = raw[w].toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        if (word.length > 1 && !rdgGenderTitles.has(word)) {
            nameToCheck = word;
            break;
        }
    }
    if (!nameToCheck) return 'UNKNOWN';

    // 1) Lookup O(1) nas listas exatas (femininos primeiro para evitar falsos positivos)
    if (femaleNames.has(nameToCheck)) return 'F';
    if (maleNames.has(nameToCheck)) return 'M';

    // 2) Sufixos
    if (/inha$|ela$|ila$|iana$|iane$|iele$|eline$|eide$|aide$|alda$|ilda$|ilene$|iene$|ineia$|neia$|mira$|mara$|lene$|nete$/.test(nameToCheck)) return 'F';
    if (/son$|nho$|naldo$|maldo$|aldo$|ildo$|andro$|eiro$|berto$|ilson$|inaldo$|cio$|lio$|gio$|vio$|pio$|bio$|dio$|tio$|fio$|mio$|ito$|ino$|into$|unto$|onto$|uto$|ao$/.test(nameToCheck)) return 'M';

    // 3) Prefixos femininos primeiro, depois masculinos
    if (rdgFemalePfx.test(nameToCheck)) return 'F';
    if (rdgMalePfx.test(nameToCheck)) return 'M';

    // 4) Nomes em -a geralmente femininos
    if (nameToCheck.length > 3 && nameToCheck.endsWith('a')) return 'F';

    return 'UNKNOWN';
}

function rdgPromptGenderFilter() {
    if ($('#genderFilterOverlay').length > 0) return;

    var overlay = document.createElement('div');
    overlay.id = 'genderFilterOverlay';
    overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.8);z-index:999999;display:flex;align-items:center;justify-content:center;';

    var modal = document.createElement('div');
    modal.style.cssText = 'background:#1e293b;border:1px solid #334155;border-radius:12px;padding:22px;width:380px;text-align:center;box-shadow:0 10px 25px rgba(0,0,0,0.5);color:#fff;font-family:Inter,sans-serif;';

    modal.innerHTML = `
        <h3 style="margin-top:0;margin-bottom:8px;font-size:18px;color:#38bdf8;">Filtrar Fila por Genero</h3>
        <p style="font-size:11px;color:#475569;margin-bottom:14px;">v4 - precisao otimizada</p>
        <p style="font-size:14px;color:#94a3b8;margin-bottom:18px;">Qual genero voce deseja <span style="color:#fff;font-weight:bold;">manter</span> na fila?</p>
        <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:14px;">
            <button id="btnFilterMale" style="padding:12px;border:none;border-radius:8px;background:#2563eb;color:#fff;font-weight:bold;cursor:pointer;font-size:14px;">Apenas Homens</button>
            <button id="btnFilterFemale" style="padding:12px;border:none;border-radius:8px;background:#db2777;color:#fff;font-weight:bold;cursor:pointer;font-size:14px;">Apenas Mulheres</button>
        </div>
        <p style="font-size:13px;color:#94a3b8;margin-bottom:10px;">Nomes <b style="color:#fbbf24;">nao identificados</b>: o que fazer?</p>
        <div style="display:flex;gap:8px;justify-content:center;margin-bottom:14px;">
            <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:13px;">
                <input type="radio" name="rdgUnknown" id="rdgUnknownKeep" value="keep" style="accent-color:#38bdf8;"> Manter na fila
            </label>
            <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:13px;">
                <input type="radio" name="rdgUnknown" id="rdgUnknownRemove" value="remove" checked style="accent-color:#f87171;"> Remover da fila
            </label>
        </div>
        <button id="btnFilterCancel" style="padding:9px 18px;border:1px solid #475569;border-radius:6px;background:transparent;color:#94a3b8;cursor:pointer;font-size:13px;">Cancelar</button>
    `;

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    document.getElementById('btnFilterMale').onclick = function() {
        var keepUnknown = document.getElementById('rdgUnknownKeep').checked;
        rdgExecuteGenderFilter('M', keepUnknown);
        overlay.remove();
    };

    document.getElementById('btnFilterFemale').onclick = function() {
        var keepUnknown = document.getElementById('rdgUnknownKeep').checked;
        rdgExecuteGenderFilter('F', keepUnknown);
        overlay.remove();
    };

    document.getElementById('btnFilterCancel').onclick = function() {
        overlay.remove();
    };
}

function rdgExecuteGenderFilter(targetGender, keepUnknown) {
    if (typeof keepUnknown === 'undefined') keepUnknown = false;
    if (acctsQueue.length === 0) {
        outputMessage('A fila esta vazia.');
        return;
    }

    var kept = [];
    var removedCount = 0;
    var unknownCount = 0;

    for (var i = 0; i < acctsQueue.length; i++) {
        var acct = acctsQueue[i];
        var nameStr = acct.full_name || acct.fullName || acct.name || acct.title || acct.username || '';
        var gender = rdgAnalyzeGender(nameStr);
        acct.genderWarning = false;

        if (gender === targetGender) {
            kept.push(acct);
        } else if (gender === 'UNKNOWN') {
            unknownCount++;
            if (keepUnknown) {
                acct.genderWarning = true;
                kept.push(acct);
            } else {
                removedCount++;
            }
        } else {
            removedCount++;
        }
    }

    acctsQueue = kept;

    // Persiste imediatamente a fila filtrada no armazenamento do Chrome (evita que o F5 restaure a fila antiga)
    try {
        chrome.storage.local.set({ acctsQueue: acctsQueue });
    } catch(e) {}
    if (typeof saveQueueToStorage === 'function') {
        try { saveQueueToStorage(); } catch(e) {}
    }

    var msg = 'Filtro Concluido! Removidos: ' + removedCount + ' | Mantidos na fila: ' + kept.length;
    if (unknownCount > 0) {
        msg += ' (' + unknownCount + ' desconhecidos ' + (keepUnknown ? 'mantidos com aviso' : 'removidos') + ')';
    }
    outputMessage(msg);

    if (typeof arrayOfUsersToDiv === 'function') {
        arrayOfUsersToDiv(acctsQueue, true, false);
    }
}

$(document).on('click', '#btnFilterQueueByGender', function() {
    rdgPromptGenderFilter();
});

// ====== FUNÇÃO ALO COM VERIFICAÇÃO SUPABASE ======
async function alo(username, nameDigitado) {
    console.log(`📡 Validando no Supabase: User [${username}] | Licença [${nameDigitado}]`);

    // Aqui 'nameDigitado' é tratado como a 'Chave de Licença'
    const result = await window.SupabaseAuth.validateLicense(nameDigitado, username);

    if (result.success) {
        console.log("✅ ACESSO LIBERADO: " + result.message);
        try { 
            localStorage.setItem('rdgSavedLicenseKey', nameDigitado); 
            if (result.license) {
                localStorage.setItem('rdgLicenseData', JSON.stringify(result.license));
                rdgUpdateHeaderLicenseUI(result.license);
            }
        } catch(e){}
        liberarInterface(true);
    } else {
        console.error(`🚫 ACESSO NEGADO: ${result.error}`);
        showErrorPopup(result.error, "#");
    }
}

function liberarInterface(status) {
    const divLoginWrapper = document.getElementById('divLoginWrapper');
    const mainSection = document.getElementById('mainSection');
    if (status) {
        window.rdgUiLayoutUnlocked = true;
        localStorage.setItem('rdgAuthenticated', 'true');
        // Save the license key so the user doesn't need to retype it
        try {
            const keyInput = document.getElementById('youNameLog');
            if (keyInput && keyInput.value) {
                localStorage.setItem('rdgSavedLicenseKey', keyInput.value.trim().toUpperCase());
            }
        } catch(e) {}
        if (divLoginWrapper) {
            divLoginWrapper.classList.add('rdg-hidden');
            divLoginWrapper.style.setProperty('display', 'none', 'important');
        }
        if (mainSection) {
            mainSection.style.setProperty('display', 'block', 'important');
        }
        $('#instabotIcon').removeClass('status-off');
        $('#instabotIcon').attr('title', 'RDG instaPRO (ON - Logado)');
        rdgVerifyAndRefreshLicenseFromSupabase();
    }
}

async function rdgVerifyAndRefreshLicenseFromSupabase() {
    try {
        if (localStorage.getItem('rdgAuthenticated') !== 'true') return;
        let savedKey = localStorage.getItem('rdgSavedLicenseKey');
        if (!savedKey) {
            try {
                let ld = JSON.parse(localStorage.getItem('rdgLicenseData') || '{}');
                if (ld && ld.key) {
                    savedKey = ld.key;
                    localStorage.setItem('rdgSavedLicenseKey', savedKey);
                }
            } catch(e) {}
        }
        if (!savedKey) {
            // No saved key found in storage. Force clean re-login to ensure F5 always syncs with Supabase.
            localStorage.removeItem('rdgAuthenticated');
            localStorage.removeItem('rdgLicenseData');
            window.rdgUiLayoutUnlocked = false;
            $('#mainSection').hide();
            $('#divLoginWrapper').removeClass('rdg-hidden').attr('style', 'display: flex !important;');
            return;
        }

        let keyUpper = savedKey.trim().toUpperCase();
        if (!keyUpper.startsWith('IG')) {
            localStorage.removeItem('rdgAuthenticated');
            localStorage.removeItem('rdgLicenseData');
            window.rdgUiLayoutUnlocked = false;
            $('#mainSection').hide();
            $('#divLoginWrapper').removeClass('rdg-hidden').attr('style', 'display: flex !important;');
            if (typeof showErrorPopup === 'function') {
                showErrorPopup('Esta chave não pertence ao RDG instaPRO. A chave deste produto deve iniciar com IG.');
            }
            return;
        }

        let username = '';
        try {
            username = window._sharedData.config.viewer.username || '';
        } catch(e) {}

        if (window.SupabaseAuth && window.SupabaseAuth.validateLicense) {
            let result = await window.SupabaseAuth.validateLicense(savedKey, username);
            if (!result.success) {
                console.warn("🚫 Licença expirada ou revogada no Supabase:", result.error);
                localStorage.removeItem('rdgAuthenticated');
                localStorage.removeItem('rdgLicenseData');
                window.rdgUiLayoutUnlocked = false;
                $('#mainSection').hide();
                $('#divLoginWrapper').removeClass('rdg-hidden').attr('style', 'display: flex !important;');
                if (typeof showErrorPopup === 'function') {
                    showErrorPopup(result.error);
                }
            } else if (result.license) {
                localStorage.setItem('rdgLicenseData', JSON.stringify(result.license));
                rdgUpdateHeaderLicenseUI(result.license);
                const dlw = document.getElementById('divLoginWrapper');
                if (dlw) {
                    dlw.classList.add('rdg-hidden');
                    dlw.style.setProperty('display', 'none', 'important');
                }
                const ms = document.getElementById('mainSection');
                if (ms) ms.style.setProperty('display', 'block', 'important');
            }
        }
    } catch(e) {
        console.error("Erro na verificação em tempo real do Supabase:", e);
    }
}

function entrarId() {
    document.getElementById("divEntrarId").style.display = "none";
    document.getElementById("divCampos").style.display = "flex";
}

function entrarKey() {
    document.getElementById("divEntrarId").style.display = "flex";
    document.getElementById("divCampos").style.display = "none";
}

/*
function checkVisibility() {
    const element = document.getElementById("mainSection");

    // Função que impede espaços e caracteres especiais nos campos
    function impedirEspacosCaracteresEspeciais(input) {
        // --- Adicione a verificação aqui! ---
        if (input) { // Checa se o elemento existe e não é null
            input.addEventListener('input', () => {
                input.value = input.value.replace(/[^a-zA-Z0-9-]/g, '');
            });
        }
    }

    const entrarIdAppInput = document.getElementById('entrarIdApp');
    const entrarNameAppInput = document.getElementById('youNameLog');

    impedirEspacosCaracteresEspeciais(entrarIdAppInput);
    impedirEspacosCaracteresEspeciais(entrarNameAppInput);
    // ... dentro da função checkVisibility
if (element) {
    const isVisible = element.offsetParent !== null;
    const divCampos = document.getElementById("divCampos");

    // Adicione a verificação para divCampos
    if (divCampos) {
        if (isVisible) {
            divCampos.style.display = "none";
        } else {
            divCampos.style.display = "flex";
        }
    }
} else {
    console.log("Elemento não encontrado.");
}
}

setInterval(checkVisibility, 1000);
*/

/* ==========================================================================
   EXTENSION ANNOUNCEMENTS (RDG Inteligente ver84) - Instagram pages
   ========================================================================== */
(function() {
    const ANNOUNCEMENTS_URL = 'https://adljdeekwifwcdcgbpit.supabase.co/storage/v1/object/public/user-data/admin/extensionver84-announcements.json';
    const STORAGE_KEY_ANNOUNCEMENTS = 'rdg_extensionver84_announcements';
    const INIT_STATE_KEY = '_rdgExtensionAnnouncementsInitState';

    async function fetchExtensionAnnouncements() {
      try {
        const response = await fetch(ANNOUNCEMENTS_URL + '?t=' + Date.now());
        if (!response.ok) return null;
        
        const data = await response.json();
        return data.announcements || [];
      } catch (error) {
        console.error('Erro ao buscar avisos:', error);
        return null;
      }
    }

    function getViewedAnnouncements() {
      try {
        return JSON.parse(localStorage.getItem(STORAGE_KEY_ANNOUNCEMENTS) || '{}');
      } catch { return {}; }
    }

    function saveViewedAnnouncement(id, announcement) {
      const viewed = getViewedAnnouncements();
      const now = Date.now();
      
      viewed[id] = {
        viewCount: ((viewed[id] && viewed[id].viewCount) || 0) + 1,
        lastViewed: now,
        firstViewed: (viewed[id] && viewed[id].firstViewed) || now
      };
      
      localStorage.setItem(STORAGE_KEY_ANNOUNCEMENTS, JSON.stringify(viewed));
    }

    function shouldShowAnnouncement(announcement) {
      return false; // DISABLED: User complained it shows up every time
      if (!announcement.isActive) return false;
      
      const viewed = getViewedAnnouncements()[announcement.id];
      if (!viewed) return true;
      
      const { frequencyType, frequencyValue, frequencyHours } = announcement;
      
      if (frequencyType === 'times_per_day') {
        const today = new Date().toDateString();
        const lastViewedDate = new Date(viewed.lastViewed).toDateString();
        if (today !== lastViewedDate) {
          return true;
        }
        return (viewed.viewCount || 0) < frequencyValue;
      }
      
      if (frequencyType === 'times_per_hours') {
        const hoursMs = (frequencyHours || 1) * 60 * 60 * 1000;
        const timeSinceFirst = Date.now() - (viewed.firstViewed || 0);
        if (timeSinceFirst >= hoursMs) return true;
        return (viewed.viewCount || 0) < frequencyValue;
      }
      
      if (frequencyType === 'once') {
        return viewed.viewCount < 1;
      }
      
      return true;
    }

    async function showAnnouncementWithDelay(announcement) {
      const delayMs = (announcement.delaySeconds || 0) * 1000;
      
      if (delayMs > 0) {
        await new Promise(resolve => setTimeout(resolve, delayMs));
      }
      
      if (shouldShowAnnouncement(announcement)) {
        const shown = displayAnnouncementPopup(announcement);
        saveViewedAnnouncement(announcement.id, announcement);
        return !!shown;
      }
      return false;
    }

    function displayAnnouncementPopup(announcement) {
      if (!document.body) return false;
      const existing = document.getElementById('rdg-extension-popup');
      if (existing) existing.remove();
      
      const popup = document.createElement('div');
      popup.id = 'rdg-extension-popup';
      popup.innerHTML = `
        <div style="
          position: fixed;
          top: 0; left: 0; right: 0; bottom: 0;
          background: rgba(36, 36, 36, 0.72);
          z-index: 2147483646;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        ">
          <div style="
            background: linear-gradient(180deg, #f3f4f6 0%, #e5e7eb 100%);
            border-radius: 18px;
            max-width: 500px;
            width: 100%;
            overflow: hidden;
            box-shadow: 0 28px 60px rgba(0,0,0,0.30);
            border: 1px solid rgba(148,163,184,0.35);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
          ">
            ${announcement.thumbnailUrl ? `
              <img src="${announcement.thumbnailUrl}" style="width: 100%; max-height: 300px; object-fit: cover; display: block;" />
            ` : ''}
            
            <div style="padding: 24px;">
              <h2 style="color: #1f2937; font-size: 20px; font-weight: bold; margin: 0 0 12px 0;">
                ${announcement.title}
              </h2>
              <p style="color: #4b5563; font-size: 14px; line-height: 1.6; white-space: pre-wrap; margin: 0 0 16px 0;">
                ${announcement.content}
              </p>
              
              ${announcement.buttonUrl ? `
                <a id="rdg-announcement-cta-btn" href="${announcement.buttonUrl}" target="_blank" style="
                  display: inline-block;
                  margin-top: 16px;
                  padding: 12px 24px;
                  background: linear-gradient(180deg, #facc15 0%, #eab308 100%);
                  color: #1f2937;
                  text-decoration: none;
                  border-radius: 10px;
                  font-weight: 700;
                  border: 1px solid rgba(161, 98, 7, 0.22);
                  box-shadow: 0 10px 24px rgba(234, 179, 8, 0.24);
                ">
                  ${announcement.buttonText || 'Saiba Mais'}
                </a>
              ` : ''}
              
              <button id="rdg-announcement-close-btn" style="
                display: block;
                width: 100%;
                margin-top: 16px;
                padding: 12px;
                background: linear-gradient(180deg, #facc15 0%, #eab308 100%);
                border: 1px solid rgba(161, 98, 7, 0.22);
                color: #1f2937;
                border-radius: 10px;
                cursor: pointer;
                font-size: 14px;
                font-weight: 700;
                box-shadow: 0 10px 24px rgba(234, 179, 8, 0.18);
              ">
                Fechar
              </button>
            </div>
          </div>
        </div>
      `;
      
      document.body.appendChild(popup);

      function closeAnnouncementPopup() {
        const p = document.getElementById('rdg-extension-popup');
        if (p) p.remove();
      }

      function wireAnnouncementButtonHover(el) {
        if (!el) return;
        var isCloseButton = el.id === 'rdg-announcement-close-btn';
        var activate = function() {
          if (isCloseButton) {
            el.style.background = 'linear-gradient(180deg, #fde047 0%, #facc15 100%)';
            el.style.color = '#1f2937';
            el.style.borderColor = 'rgba(100,116,139,0.42)';
            return;
          }
          el.style.filter = 'brightness(1.03)';
        };
        var reset = function() {
          if (isCloseButton) {
            el.style.background = 'linear-gradient(180deg, #facc15 0%, #eab308 100%)';
            el.style.color = '#1f2937';
            el.style.borderColor = 'rgba(161, 98, 7, 0.22)';
            return;
          }
          el.style.filter = 'none';
        };
        el.addEventListener('mouseenter', activate);
        el.addEventListener('mouseleave', reset);
        el.addEventListener('mousedown', activate);
        el.addEventListener('mouseup', function() {
          if (el.matches(':hover')) activate();
          else reset();
        });
      }
      
      const closeBtn = document.getElementById('rdg-announcement-close-btn');
      if (closeBtn) {
        wireAnnouncementButtonHover(closeBtn);
        closeBtn.addEventListener('click', function() {
            closeAnnouncementPopup();
        });
      }
      const ctaBtn = document.getElementById('rdg-announcement-cta-btn');
      if (ctaBtn) {
        wireAnnouncementButtonHover(ctaBtn);
        ctaBtn.addEventListener('click', function() {
          setTimeout(closeAnnouncementPopup, 80);
        });
      }
      return true;
    }

    function getInitState() {
        if (!window[INIT_STATE_KEY]) {
            window[INIT_STATE_KEY] = { running: false, done: false, startedAt: Date.now(), attempts: 0 };
        }
        return window[INIT_STATE_KEY];
    }

    async function tryInitExtensionAnnouncements() {
      const state = getInitState();
      if (state.done || state.running) return;
      if (!rdgCanShowUnlockedAutomationUi()) return;
      if (!state.unlockedStartedAt) state.unlockedStartedAt = Date.now();
      state.running = true;
      state.attempts++;

      try {
        const announcements = await fetchExtensionAnnouncements();
        if (announcements === null) {
            state.running = false;
            return;
        }

        if (!Array.isArray(announcements) || announcements.length === 0) {
            state.done = true;
            state.running = false;
            return;
        }

        for (const announcement of announcements) {
          if (!shouldShowAnnouncement(announcement)) continue;

          const shown = await showAnnouncementWithDelay(announcement);
          if (shown) {
            state.done = true;
          }
          break;
        }

        state.running = false;
      } catch (e) {
        state.running = false;
      }
    }

    function scheduleAnnouncementInitRetries() {
        const state = getInitState();
        if (state._timer) return;
        state._timer = setInterval(function() {
            const s = getInitState();
            if (s.done) {
                clearInterval(s._timer);
                s._timer = null;
                return;
            }
            if (s.unlockedStartedAt && (Date.now() - s.unlockedStartedAt > 180000)) {
                clearInterval(s._timer);
                s._timer = null;
                return;
            }
            tryInitExtensionAnnouncements();
        }, 5000);

        setTimeout(function() { tryInitExtensionAnnouncements(); }, 0);
        setTimeout(function() { tryInitExtensionAnnouncements(); }, 10000);
        setTimeout(function() { tryInitExtensionAnnouncements(); }, 30000);
    }
    
    /* --- INTEGRAÇÃO IA POLLINATIONS --- */
    $(document).ready(function() {
        window.rdgLastFocusedAiField = null;

        $(document).on('focus click', 'textarea', function() {
            window.rdgLastFocusedAiField = this;
        });


        
        function processInsertUsername(btnId, defaultTargetId) {
            $(document).on('click', '#' + btnId, function(e) {
                e.preventDefault();
                var targetField = window.rdgLastFocusedAiField;
                if (!targetField || $(targetField).is(':hidden')) {
                    targetField = document.getElementById(defaultTargetId);
                }
                if (!targetField) return;
                
                var val = $(targetField).val();
                var startPos = targetField.selectionStart;
                var endPos = targetField.selectionEnd;
                if (startPos !== undefined && endPos !== undefined) {
                    $(targetField).val(val.substring(0, startPos) + "{username}" + val.substring(endPos, val.length));
                    targetField.selectionStart = targetField.selectionEnd = startPos + 10;
                } else {
                    $(targetField).val(val + " {username}");
                }
                $(targetField).trigger('input').trigger('change');
                $(targetField).focus();
            });
        }

        processInsertUsername('btnInsertUsername', 'txtMassDM');
        processInsertUsername('btnAssistantInsertUsername', 'rdgAssistantDmTemplate');
        processInsertUsername('btnChainInsertUsername', 'txtChainDmMessage');
    });

    window.addEventListener('load', scheduleAnnouncementInitRetries);
    if (document.readyState === 'complete') {
        scheduleAnnouncementInitRetries();
    } else {
        document.addEventListener('DOMContentLoaded', scheduleAnnouncementInitRetries);
    }
})();
