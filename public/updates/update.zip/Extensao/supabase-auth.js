const SUPABASE_URL = 'https://yyoffdpzzoxrgigqupif.supabase.co';
const SUPABASE_KEY = 'sb_publishable_Cv5IVbK2bpo5PwCq-1PK3Q_d-8NPI10';

class SupabaseAuth {
    static async validateLicense(licenseKey, username) {
        if (!licenseKey || typeof licenseKey !== 'string') {
            return { success: false, error: 'Chave não fornecida.' };
        }

        const key = licenseKey.trim().toUpperCase();
        if (!key.startsWith('IG') && !key.startsWith('RDG-')) {
            return { success: false, error: 'Esta chave não pertence ao RDG instaPRO. Sua chave de licença deve iniciar com IG.' };
        }
        
        try {
            const url = `${SUPABASE_URL}/rest/v1/licenses?key=eq.${key}&select=*`;
            const res = await fetch(url, {
                method: 'GET',
                headers: {
                    'apikey': SUPABASE_KEY,
                    'Authorization': `Bearer ${SUPABASE_KEY}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!res.ok) {
                return { success: false, error: 'Erro ao conectar com o servidor.' };
            }

            const data = await res.json();
            if (!data || data.length === 0) {
                return { success: false, error: 'Licença inválida ou não encontrada.' };
            }

            const license = data[0];

            // If the table doesn't have an instagram_username column yet, we might get an error if we try to patch it.
            // I'll assume they will create it. Or we check if it exists in the response object.
            
            // For now, let's just do a basic active check and binding check
            // We assume the schema has 'status' and 'instagram_username'
            if (license.status && license.status !== 'active') {
                return { success: false, error: 'Esta licença está inativa ou expirada.' };
            }

            if (license.expires_at) {
                let expirationDate = parseSupabaseDate(license.expires_at);
                const now = new Date();
                if (expirationDate && !isNaN(expirationDate.getTime()) && expirationDate < now) {
                    return { success: false, error: 'Sua licença expirou em ' + formatDateTimePT(expirationDate, license.expires_at) + '. Por favor, renove sua assinatura.' };
                }
            }

            const cleanUser = username ? username.trim().toLowerCase().replace(/^@/, '') : '';
            const maxProfiles = Number(license.max_profiles) || 1;
            
            let linkedProfiles = [];
            if (Array.isArray(license.linked_profiles)) {
                linkedProfiles = license.linked_profiles.map(u => String(u).trim().toLowerCase().replace(/^@/, ''));
            } else if (license.instagram_username) {
                linkedProfiles = [license.instagram_username.trim().toLowerCase().replace(/^@/, '')];
            }

            // Check if current Instagram user is already in the linked profiles list
            if (cleanUser && linkedProfiles.includes(cleanUser)) {
                return { success: true, message: 'Licença validada com sucesso!', license: license };
            }

            // If user is NOT in the list, check if there's room to link a new profile
            if (cleanUser && linkedProfiles.length < maxProfiles) {
                const updatedList = [...linkedProfiles, cleanUser];
                
                const updateUrl = `${SUPABASE_URL}/rest/v1/licenses?key=eq.${key}`;
                const updateRes = await fetch(updateUrl, {
                    method: 'PATCH',
                    headers: {
                        'apikey': SUPABASE_KEY,
                        'Authorization': `Bearer ${SUPABASE_KEY}`,
                        'Content-Type': 'application/json',
                        'Prefer': 'return=representation'
                    },
                    body: JSON.stringify({ 
                        linked_profiles: updatedList 
                    })
                });

                if (!updateRes.ok) {
                    console.error("Erro ao atualizar lista de perfis no Supabase:", updateRes);
                } else {
                    try {
                        const updatedData = await updateRes.json();
                        if (updatedData && updatedData[0]) {
                            license = updatedData[0];
                        } else {
                            license.linked_profiles = updatedList;
                        }
                    } catch(e) {
                        license.linked_profiles = updatedList;
                    }
                }

                return { success: true, message: `Perfil @${cleanUser} vinculado com sucesso! (${updatedList.length}/${maxProfiles} perfis)`, license: license };
            } else if (cleanUser) {
                // Limit reached
                if (maxProfiles === 1) {
                    return { 
                        success: false, 
                        error: `Licença Bloqueada: Esta chave está vinculada ao perfil @${linkedProfiles[0]}. Seu plano atual permite apenas 1 perfil. Faça upgrade para o Plano Multi-Perfis.` 
                    };
                } else {
                    return { 
                        success: false, 
                        error: `Limite Atingido: Esta chave já atingiu o limite de ${maxProfiles} perfis vinculados (${linkedProfiles.map(p => '@' + p).join(', ')}). Faça upgrade para adicionar mais perfis.` 
                    };
                }
            }

            return { success: true, message: 'Licença validada com sucesso!', license: license };
        } catch (err) {
            console.error('Erro na validação do Supabase:', err);
            return { success: false, error: 'Falha na comunicação com o servidor.' };
        }
    }
}

function parseSupabaseDate(dateStr) {
    if (!dateStr) return null;
    if (typeof dateStr === 'string') {
        let matchBR = dateStr.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})(?:\s+|T)?(?:(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/);
        if (matchBR && matchBR[3].length === 4) {
            let day = parseInt(matchBR[1], 10);
            let month = parseInt(matchBR[2], 10) - 1;
            let year = parseInt(matchBR[3], 10);
            let hours = matchBR[4] ? parseInt(matchBR[4], 10) : 0;
            let minutes = matchBR[5] ? parseInt(matchBR[5], 10) : 0;
            let seconds = matchBR[6] ? parseInt(matchBR[6], 10) : 0;
            let d = new Date(year, month, day, hours, minutes, seconds);
            if (!isNaN(d.getTime())) return d;
        }
    }
    let d = new Date(dateStr);
    if (!isNaN(d.getTime())) return d;
    return null;
}

function formatDateTimePT(d, originalStr) {
    if (!d || isNaN(d.getTime())) return '';
    let dateStr = d.toLocaleDateString('pt-BR');
    let hasExplicitTime = false;
    if (originalStr && typeof originalStr === 'string') {
        if (originalStr.includes(':') && !originalStr.includes('00:00:00') && !originalStr.includes('T00:00:00')) {
            hasExplicitTime = true;
        }
    } else if (d.getHours() !== 0 || d.getMinutes() !== 0) {
        hasExplicitTime = true;
    }
    if (hasExplicitTime) {
        let timeStr = d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
        if (timeStr !== '00:00') {
            return dateStr + ' às ' + timeStr;
        }
    }
    return dateStr;
}

window.SupabaseAuth = SupabaseAuth;
